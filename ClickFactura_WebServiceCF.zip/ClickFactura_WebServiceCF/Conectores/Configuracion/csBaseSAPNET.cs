﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SAP.Middleware.Connector;
using ClickFactura_WebServiceCF.AccesoBD.Genericos;
using ClickFactura_Entidades.BD.Entidades;
using System.Reflection;

namespace ClickFactura_WebServiceCF.Conectores.Configuracion
{
    public class csBaseSAPNET
    {
        SAP.Middleware.Connector.RfcDestination conector = csBaseSAPNET.GetRfcDestination;

        public SAP.Middleware.Connector.RfcDestination Conector
        {
            get {return conector;    }
            set { conector = value; }
        }

        /// <summary>
        /// Lista que recupera de la BD los datos para realizar la conexión por Conectores a SAP
        /// </summary>
        /// <returns></returns>
        public List<KeyValuePair<string,string>> parametrosAlmacenados()
        {
                int result = 0;
                adT_Parametros adp = new adT_Parametros();
                List<objT_Parametros> objp = new List<objT_Parametros>();
                List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
                string entorno = "";

                objp = adp.mABCT_Parametros(out result, 0, "EntornoSAP", "Vacio", true, "ConsultaValor");
                {
                    entorno = objp[0].ValorParametro.ToString();
                }

                string _nombre = "";
                string _usuario = "";
                string _password = "";
                string _cliente = "";
                string _lenguaje = "";
                string _appserverhost = "";
                string _systemnumber = "";
                string _systemid = "";
                string _maxpoolsize = "";
                string _idletimeout = "";
                string  _gatewayservice="";
                string _gatewayhost="";

                if (entorno.Equals("QA") == true)
                {
                    objp = adp.mABCT_Parametros(out result, 0, "Name", "Vacio", true, "ConsultaValor");
                    {
                        _nombre = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Name",_nombre));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "User", "Vacio", true, "ConsultaValor");
                    {
                        _usuario = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("User", _usuario));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Password", "Vacio", true, "ConsultaValor");
                    {
                        _password = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Password", _password));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Client", "Vacio", true, "ConsultaValor");
                    {
                        _cliente = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Client", _cliente));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Language", "Vacio", true, "ConsultaValor");
                    {
                        _lenguaje = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Language", _lenguaje));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "SystemNumber", "Vacio", true, "ConsultaValor");
                    {
                        _systemnumber = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("SystemNumber", _systemnumber));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "SystemID", "Vacio", true, "ConsultaValor");
                    {
                        _systemid = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("SystemID", _systemid));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "MaxPoolSize", "Vacio", true, "ConsultaValor");
                    {
                        _maxpoolsize = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("MaxPoolSize", _maxpoolsize));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "IdleTimeout", "Vacio", true, "ConsultaValor");
                    {
                        _idletimeout = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("IdleTimeout", _idletimeout));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "AppServerHost", "Vacio", true, "ConsultaValor");
                    {
                        _appserverhost = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("AppServerHost", _appserverhost));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "GateWayService", "Vacio", true, "ConsultaValor");
                    {
                        _gatewayservice= objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("GateWayService", _gatewayservice));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "GateWayHost", "Vacio", true, "ConsultaValor");
                    {
                        _gatewayhost = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("GateWayHost", _gatewayhost));
                    }
                }
                return datos;
        }
        public static RfcDestination GetRfcDestination//string name , string username, string password, string client , string language, string appServerHost, string systemNumber, string maxPoolSize, string idleTimeout)
        {
           get
         {
             RfcConfigParameters parameters;
             try
             {
                 //Original
                //RfcConfigParameters parameters = new RfcConfigParameters();
                 parameters = new RfcConfigParameters();
             }
             catch
             {
                 Dictionary<string, string> _parameters = new Dictionary<string, string>();//RfcConfigParameters();
                 parameters = (RfcConfigParameters)_parameters;
             }
            int result = 0;
            adT_Parametros adp = new adT_Parametros();
            List<objT_Parametros> objp = new List<objT_Parametros>();
            string entorno ="";
            string log = "Inicia leer parametros";
            try
            {
                        log = log + " "+" Entrando a leer parametros ";
                        objp = adp.mABCT_Parametros(out result, 0, "EntornoSAP", "Vacio", true, "ConsultaValor");
                        {
                            entorno = objp[0].ValorParametro.ToString();
                            log = log + " " + " Resultado de leer parametros Result "+ result.ToString();
                        }

                            string _nombre="";
                            string _usuario = "";
                            string _password = "";
                            string _cliente = "";
                            string _lenguaje = "";
                            string _appserverhost = "";
                            string _messageserverhost = "";
                            string _systemnumber = "";
                            string _systemid = "";
                            string _maxpoolsize = "";
                            string _idletimeout = "";
                            string _logonGroup = "";
                            string _gatewayhost = "";
                            string _gatewayservice = "";

                        if (entorno.Equals("QA")==true)
                        {

                            objp = adp.mABCT_Parametros(out result, 0, "Name", "Vacio", true, "ConsultaValor");
                            {
                                _nombre = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero nombre "+ _nombre;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "User", "Vacio", true, "ConsultaValor");
                            {
                                _usuario = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero usuario " + _usuario;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "Password", "Vacio", true, "ConsultaValor");
                            {
                                _password = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero pasword " + _password;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "Client", "Vacio", true, "ConsultaValor");
                            {
                                _cliente = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero cliente " + _cliente;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "Language", "Vacio", true, "ConsultaValor");
                            {
                                _lenguaje = objp[0].ValorParametro.ToString();
                            if (_lenguaje == "")
                                _lenguaje = "EN";
                                log = log + " " + " recupero lenguaje " + _lenguaje;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "SystemNumber", "Vacio", true, "ConsultaValor");
                            {
                                _systemnumber = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero systemnumber " + _systemnumber;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "SystemID", "Vacio", true, "ConsultaValor");
                            {
                                _systemid = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero systemid " + _systemid;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "MaxPoolSize", "Vacio", true, "ConsultaValor");
                            {
                                _maxpoolsize = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero maxpoolsize " + _maxpoolsize;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "IdleTimeout", "Vacio", true, "ConsultaValor");
                            {
                                _idletimeout = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero idletiemout " + _idletimeout;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "AppServerHost", "Vacio", true, "ConsultaValor");
                            {
                                _appserverhost = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero appserverhost " + _appserverhost;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "MessageServerHost", "Vacio", true, "ConsultaValor");
                            {
                                _messageserverhost = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero messageserverhost " + _messageserverhost;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "LogonGroup", "Vacio", true, "ConsultaValor");
                            {
                                _logonGroup= objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero LogonGroup " + _logonGroup;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "GatewayHost", "Vacio", true, "ConsultaValor");
                            {
                                _gatewayhost = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero GatewayHost " + _gatewayhost;
                            }
                            objp = adp.mABCT_Parametros(out result, 0, "GatewayService", "Vacio", true, "ConsultaValor");
                            {
                                _gatewayservice = objp[0].ValorParametro.ToString();
                                log = log + " " + " recupero GatewayService " + _gatewayservice;
                            }
                        }


                        parameters.Add(RfcConfigParameters.Name, _nombre);//name);
                        parameters.Add(RfcConfigParameters.User,_usuario);// username);
                        parameters.Add(RfcConfigParameters.Password, _password);//password);
                        parameters.Add(RfcConfigParameters.Client, _cliente);//client);
                        parameters.Add(RfcConfigParameters.Language, _lenguaje);//language);
                        parameters.Add(RfcConfigParameters.AppServerHost, _appserverhost);//appServerHost);
                        parameters.Add(RfcConfigParameters.MessageServerHost, _messageserverhost);//appServerHost);
                        parameters.Add(RfcConfigParameters.SystemNumber,_systemnumber);// systemNumber);
                        parameters.Add(RfcConfigParameters.SystemID, _systemid);// systemNumber);
                        parameters.Add(RfcConfigParameters.MaxPoolSize, _maxpoolsize);//maxPoolSize);
                        parameters.Add(RfcConfigParameters.IdleTimeout, _idletimeout);//idleTimeout);
                        parameters.Add(RfcConfigParameters.LogonGroup, _logonGroup);//idleTimeout);
                        parameters.Add(RfcConfigParameters.GatewayHost, _gatewayhost);//idleTimeout);
                        parameters.Add(RfcConfigParameters.GatewayService, _gatewayservice);//idleTimeout);

                        log = log + " " + " Lanzandose por GetDestination";
                        return RfcDestinationManager.GetDestination(parameters);
            }
            catch (Exception ex)
            {
                throw (new System.Exception("Ocurrió un problema con la conexión mientras se recuperaban los valores de acceso, intente de nuevo en un momento...Resultado consulta "+result + "Error: "+ex.Message + log));
            }
         }
        }

        public SAP.Middleware.Connector.RfcDestination abreConector(ref bool result)
        {
            result = false;
            //SAP.Middleware.Connector.RfcDestination conector = csBaseSAPNET.GetRfcDestination;
            SAP.Middleware.Connector.RfcSessionManager.BeginContext(Conector);
            Conector.Ping();
            return Conector;
        }

        public SAP.Middleware.Connector.RfcDestination cierraConector(ref bool result)
        {
            result = false;
            SAP.Middleware.Connector.RfcSessionManager.EndContext(Conector);
            Conector = null;
            return Conector;
        }

        public List<KeyValuePair<string, string>> obtenInformacionCompañia(SAP.Middleware.Connector.RfcDestination conector, string companyid)
        {
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            if (conector.SystemID != null)
            {
                var funcion = conector.Repository.CreateFunction("BAPI_COMPANY_GETDETAIL");
                SAP.Middleware.Connector.IRfcFunction companyBapi = conector.Repository.CreateFunction("BAPI_COMPANY_GETDETAIL");
                companyBapi.SetValue("COMPANYID", companyid);// "006004");
                //######## Dispara a SAP
                RfcSessionManager.BeginContext(conector);   
                companyBapi.Invoke(conector);
                RfcSessionManager.EndContext(conector);
                //######## Dispara a SAP
                SAP.Middleware.Connector.IRfcStructure detail = companyBapi.GetStructure("COMPANY_DETAIL");
                if(detail.GetString("NAME1").Length>0)
                {
                    datos.Add(new KeyValuePair<string,string>("NAME1",detail.GetString("NAME1")));
                    datos.Add(new KeyValuePair<string, string>("COUNTRY", detail.GetString("COUNTRY")));
                    datos.Add(new KeyValuePair<string, string>("LANGU", detail.GetString("LANGU")));
                    datos.Add(new KeyValuePair<string, string>("STREET", detail.GetString("STREET")));
                    datos.Add(new KeyValuePair<string, string>("CITY", detail.GetString("CITY")));
                    datos.Add(new KeyValuePair<string, string>("CURRENCY", detail.GetString("CURRENCY")));
                    datos.Add(new KeyValuePair<string, string>("PO_BOX", detail.GetString("PO_BOX")));
                    datos.Add(new KeyValuePair<string, string>("POSTL_COD1", detail.GetString("POSTL_COD1")));
                }
                else
                {
                    datos.Add(new KeyValuePair<string, string>("NAME1", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("COUNTRY", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("LANGU", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("STREET", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("CITY", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("CURRENCY", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("PO_BOX", "Proveedor no localizado en SAP"));
                    datos.Add(new KeyValuePair<string, string>("POSTL_COD1", "Proveedor no localizado en SAP"));
                }
            }
            return datos;
        }

        private string convierteMoneyTKPM(string textoCantidad)
        {
            //En virtud que las cantidades vienen con un formato 3350,00 y la coma es un problema se debe reformatear el numero
            //19 Octubre 2017 GRD
            string salida = "0";
            adT_Parametros adp = new adT_Parametros();
            List<objT_Parametros> objp = new List<objT_Parametros>();
            int result = 0;
            #region Adecua formato moneda
            string entorno = "";
            bool publicado = false;
            objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
            {
                entorno = objp[0].ValorParametro.ToString();
                publicado = entorno.Equals("1") == true ? true : false;
            }
            if (publicado == false)
            {
                salida = Convert.ToDouble(textoCantidad, new System.Globalization.NumberFormatInfo { NumberDecimalSeparator = ".", NumberGroupSeparator = "," }).ToString();
            }
            else
            {
                salida = textoCantidad;
            }
            #endregion Adecua formato moneda
            return textoCantidad;// salida;
            //    return Convert.ToDouble(textoCantidad, new System.Globalization.NumberFormatInfo { NumberDecimalSeparator = ".", NumberGroupSeparator = "," }).ToString();
        }

        public List<KeyValuePair<string, string>> BAPI_INCOMINGINVOICE_CREATE(SAP.Middleware.Connector.RfcDestination conector, ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado HPasivo, ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos)
        {
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            try
            {
                   if (conector.SystemID != null)
                    {
                        //var funcion = conector.Repository.CreateFunction("BAPI_INCOMINGINVOICE_CREATE");
                        SAP.Middleware.Connector.IRfcFunction bapi_incoming_invoice = conector.Repository.CreateFunction("BAPI_INCOMINGINVOICE_CREATE");
                        IRfcFunction funcionCommit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
                        funcionCommit.SetValue("WAIT", "X");
                        bool harcodeado =false;
                        if(harcodeado==true)
                        {
                            #region Hardcore
                            SAP.Middleware.Connector.IRfcStructure _detail_Header = bapi_incoming_invoice.GetStructure("HEADERDATA");
                            _detail_Header.SetValue("INVOICE_IND", "X");
                            _detail_Header.SetValue("DOC_TYPE", "RE");
                            _detail_Header.SetValue("DOC_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_INCOMINGINVOICE_CREATE"));
                            _detail_Header.SetValue("PSTNG_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_INCOMINGINVOICE_CREATE"));
                            _detail_Header.SetValue("REF_DOC_NO", "75355");
                            _detail_Header.SetValue("COMP_CODE", "0050");
                            _detail_Header.SetValue("DIFF_INV", "0000041458");
                            _detail_Header.SetValue("CURRENCY", "MXN");

                        #region        En el Servidor
                              string Total = "65535,36";
                        #endregion En el Servidor

                            _detail_Header.SetValue("GROSS_AMOUNT",Total);
                            _detail_Header.SetValue("CALC_TAX_IND", "X");
                            //if (HPasivo.PMNTTRMS != null)
                            //    if (HPasivo.PMNTTRMS.Length > 0)
                            //        _detail_Header.SetValue("PMNTTRMS", HPasivo.PMNTTRMS);// "ZB01"); //Extraer de PO
                            #region Llenando ITEMDATA
                            SAP.Middleware.Connector.IRfcTable _detail_Item = bapi_incoming_invoice.GetTable("ITEMDATA");
                                //########### ESTRUCTURA EN QUE SE CARGARAN LAS LINEAS DEL DETALLE PASIVO
                                _detail_Item.Append();
                                _detail_Item.SetValue("INVOICE_DOC_ITEM",1);
                                _detail_Item.SetValue("PO_NUMBER", "4500742018");
                                _detail_Item.SetValue("PO_ITEM", "00010");
                                _detail_Item.SetValue("REF_DOC", "5005314568");
                                _detail_Item.SetValue("REF_DOC_YEAR", "2017");
                                _detail_Item.SetValue("REF_DOC_IT", "0001");
                                _detail_Item.SetValue("TAX_CODE", "V3");
                                #region configura Importes
                               string importe = "";
                                #region Adecua formato moneda
                                #region        En el Servidor
                                        importe = "6,42";
                                        string cantidad = "8800";
                                        string valorLinea = Convert.ToString(Convert.ToDecimal(importe)* Convert.ToDecimal(cantidad));
                                #endregion En el Servidor
                        #endregion Adecua formato moneda
                        #endregion configura Importes
                        RfcDataType.BCD.ToString();

                                _detail_Item.SetValue("ITEM_AMOUNT",valorLinea);// Convert.ToDecimal(amount));
                                _detail_Item.SetValue("QUANTITY", cantidad);
                                _detail_Item.SetValue("PO_UNIT", "L");


                        #region RETURN reporto issues
                        string origenes = "4500742018" + "_" + "5005314568" + "_" + "testing";
                        datos.Add(new KeyValuePair<string, string>("Orden de Compra ", "4500742018"));
                        datos.Add(new KeyValuePair<string, string>("Recepción ", "5005314568"));
                        datos.Add(new KeyValuePair<string, string>("UUID ", "Hardcodeada"));

                        try
                        {
                                datos.Add(new KeyValuePair<string, string>("Data", "Importe Total:" + Total));
                                datos.Add(new KeyValuePair<string, string>("Data", "Posicion Factura:" +"1"));
                                datos.Add(new KeyValuePair<string, string>("Data", "OrdenCompra:" + "4500742018"));
                                datos.Add(new KeyValuePair<string, string>("Data", "Recepcion:" + "5005314568"));
                                datos.Add(new KeyValuePair<string, string>("Data", "Cantidad:" + cantidad));
                                datos.Add(new KeyValuePair<string, string>("Data", "Importe Unitario:" + valorLinea));
                                datos.Add(new KeyValuePair<string, string>("Data", "Ind. impuesto:" + "V3"));
                                datos.Add(new KeyValuePair<string, string>("Data", "U Medida:" + "L"));
                        }
                        catch (Exception Ex)
                        {

                        }
                        List<string> errores = new List<string>();
                        foreach (KeyValuePair<string, string> data in datos)
                        {
                            errores.Add(data.Key + "- " + data.Value);
                        }
                        Service.Service1 servicio = new Service.Service1();
                        servicio.EscribeLOG(errores, origenes, "4500742018", "MIRO");
                        #endregion RETURN reporto issues


                        #endregion Llenando ITEMDATA
                        #endregion Hardcore
                    }
                    else
                      {
                        #region Dinamica
                        #region Llenando HEADERDATA
                        SAP.Middleware.Connector.IRfcStructure detail_Header = bapi_incoming_invoice.GetStructure("HEADERDATA");
                                    detail_Header.SetValue("INVOICE_IND", "X");
                                    detail_Header.SetValue("DOC_TYPE", "RE");
                                    detail_Header.SetValue("DOC_DATE", convierteFormatoSAP(Convert.ToDateTime(HPasivo.FechaFactura), "BAPI_INCOMINGINVOICE_CREATE"));
                                    detail_Header.SetValue("PSTNG_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_INCOMINGINVOICE_CREATE"));
                                    detail_Header.SetValue("REF_DOC_NO", HPasivo.FolioFactura);
                                    detail_Header.SetValue("COMP_CODE", HPasivo.Sociedad);
                                    detail_Header.SetValue("DIFF_INV", HPasivo.Proveedor_Diferente);
                                    detail_Header.SetValue("CURRENCY", HPasivo.Moneda);

                                #region configura Importes
                                adT_Parametros adp = new adT_Parametros();
                                List<objT_Parametros> objp = new List<objT_Parametros>();
                                int result = 0;
                                string cultura = "es-MX";
                                string valor = HPasivo.Importe;
                                #region Adecua formato moneda
                                string entorno = "";
                                string _Cantidad = "";
                                bool publicado = false;
                                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                {
                                    entorno = objp[0].ValorParametro.ToString();
                                    publicado = entorno.Equals("1") == true ? true : false;
                                }
                                if (publicado == false)
                                {
                                    #region Si estas local
                                    double val;
                                    if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                    {
                                        string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                    }
                                    valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                    _Cantidad = valor.Replace("$", "");
                                    _Cantidad = _Cantidad.Replace(",", "");
                                    _Cantidad = convierteMoneyTKPM(_Cantidad);
                                    #endregion Si estas local
                                }
                                else
                                {
                                    #region        En el Servidor
                                    //-->>_Cantidad = valor;
                                    //-->_Cantidad = _Cantidad.Replace(",",".");
                                    // int posComa = _Cantidad.LastIndexOf(",");
                                    //  int largo = _Cantidad.Length;
                                    //int nuevaUbicacion = 0;
                                    //if (posComa>0)
                                    //{
                                    //    nuevaUbicacion = largo - posComa;
                                    //}
                                    //if(nuevaUbicacion>0)
                                    //{
                                    //    string parcial = _Cantidad;
                                    //    string nuevaCadena = "";
                                    //    string nu = "";
                                    //    for (int i=0;i<largo;i++ )
                                    //        {
                                    //            nu = parcial[i].ToString();
                                    //            if((posComa-2)==i)
                                    //            {
                                    //                nuevaCadena = nuevaCadena + "." + nu;
                                    //            }
                                    //            else
                                    //            {
                                    //                if(nu.Equals(",")==false)
                                    //                    nuevaCadena = nuevaCadena + nu;
                                    //            }
                                    //        }
                                    //        _Cantidad = nuevaCadena;
                                    //}
                                    ////_Cantidad = _Cantidad.Replace(".", "");
                                    ////_Cantidad = _Cantidad.Replace(",", ".");
                                    _Cantidad = HPasivo.Importe;
                                    _Cantidad = _Cantidad.Replace(",", "");
                                    _Cantidad = _Cantidad.Replace(".", ",");
                                    #endregion En el Servidor
                                }
                        #endregion Adecua formato moneda
                               HPasivo.Importe = _Cantidad;
                               #endregion configura Importes

                                detail_Header.SetValue("GROSS_AMOUNT", HPasivo.Importe);
                                detail_Header.SetValue("CALC_TAX_IND", "X");
                                    if(HPasivo.PMNTTRMS!=null)
                                            if(HPasivo.PMNTTRMS.Length>0)
                                            detail_Header.SetValue("PMNTTRMS",HPasivo.PMNTTRMS);// "ZB01"); //Extraer de PO
                            #endregion Llenando HEADERDATA

                            #region Llenando ITEMDATA
                            int no_linea = 1;
                            SAP.Middleware.Connector.IRfcTable detail_Item = bapi_incoming_invoice.GetTable("ITEMDATA");
                            foreach (ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle detalle in detallesPasivos)
                            {
                                //########### ESTRUCTURA EN QUE SE CARGARAN LAS LINEAS DEL DETALLE PASIVO
                                detail_Item.Append();
                                detail_Item.SetValue("INVOICE_DOC_ITEM", no_linea);
                                detail_Item.SetValue("PO_NUMBER", detalle.OrdenCompra);
                                detail_Item.SetValue("PO_ITEM", detalle.PosicionOrden);
                                detail_Item.SetValue("REF_DOC", detalle.NumeroRecepcion);
                                detail_Item.SetValue("REF_DOC_YEAR", detalle.YearWE);
                                detail_Item.SetValue("REF_DOC_IT", detalle.PosicionRecepcion);
                                detail_Item.SetValue("TAX_CODE", detalle.Impuesto);


                            #region configura Importes
                            double amount = 0;
                            string _Importe = "0";
                                #region Adecua formato moneda
                            objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                {
                                    entorno = objp[0].ValorParametro.ToString();
                                    publicado = entorno.Equals("1") == true ? true : false;
                                }
                                if (publicado == false)
                                {
                                    #region Si estas local
                                    //Falta Multiplicar
                                    amount = Convert.ToDouble(Math.Round(Convert.ToDecimal(detalle.ImporteConcepto) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                    valor = amount.ToString();
                                    double val;
                                    if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                    {
                                        string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                    }
                                    valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                    _Cantidad = valor.Replace("$", "");
                                    _Cantidad = _Cantidad.Replace(",", "");
                                    _Cantidad = convierteMoneyTKPM(_Cantidad);
                                    amount = Convert.ToDouble(_Cantidad);
                                    #endregion Si estas local
                            }
                                else
                                {
                                #region        En el Servidor
                                //Falta Multiplicar
                                //_Cantidad = detalle.ImporteConcepto;
                                //_Cantidad = _Cantidad.Replace(",", ".");
                                //int posComa = _Cantidad.LastIndexOf(",");
                                //int largo = _Cantidad.Length;
                                //int nuevaUbicacion = 0;
                                //if (posComa > 0)
                                //{
                                //    nuevaUbicacion = largo - posComa;
                                //}
                                //if (nuevaUbicacion > 0)
                                //{
                                //    string parcial = _Cantidad;
                                //    string nuevaCadena = "";
                                //    string nu = "";
                                //    for (int i = 0; i < largo; i++)
                                //    {
                                //        nu = parcial[i].ToString();
                                //        if ((posComa - 2) == i)
                                //        {
                                //            nuevaCadena = nuevaCadena + "." + nu;
                                //        }
                                //        else
                                //        {
                                //            if (nu.Equals(",") == false)
                                //                nuevaCadena = nuevaCadena + nu;
                                //        }
                                //    }
                                //    _Cantidad = nuevaCadena;
                                //}
                                ////_Cantidad = _Cantidad.Replace(".", "");
                                ////_Cantidad = _Cantidad.Replace(",", ".");
                                //--> detalle.ImporteConcepto = _Cantidad;
                                _Importe = detalle.ImporteConcepto;
                                _Importe = _Importe.Replace(",","");
                                _Importe = _Importe.Replace(".", ",");
                                _Cantidad = detalle.CantidadConcepto;
                                _Cantidad = _Cantidad.Replace(",", "");
                                _Cantidad = _Cantidad.Replace(".", ",");
                                detalle.CantidadConcepto = _Cantidad;
                                String valorLinea = (Convert.ToDecimal(_Cantidad) * Convert.ToDecimal(_Importe)).ToString();
                                valorLinea = valorLinea.Replace(",","");
                                valorLinea = valorLinea.Replace(".", ",");
                                detalle.ImporteConcepto = valorLinea;
                                #endregion En el Servidor
                            }
                                #endregion Adecua formato moneda
                            #endregion configura Importes
                                detail_Item.SetValue("QUANTITY", detalle.CantidadConcepto);
                                detail_Item.SetValue("ITEM_AMOUNT", detalle.ImporteConcepto);// Convert.ToDecimal(amount));


                                if (detalle.UnidadMedida!=null)
                                        detail_Item.SetValue("PO_UNIT", detalle.UnidadMedida);//Extraer de PO--> Hoy dia se usara este campo Clase Condicion que al 10 Agosto no se usa para transportar la Unidad de Medida
                                else
                                    detail_Item.SetValue("PO_UNIT", detalle.ClaseCondicion);
                                no_linea++;
                            }

                            #endregion Llenando ITEMDATA
                            #endregion Dinamica
                       }


                        //######## Dispara a SAP
                        RfcSessionManager.BeginContext(conector);   
                        bapi_incoming_invoice.Invoke(conector);
                        if (aplicar_COMMIT_BAPI_MIRO()==true)
                        {
                            funcionCommit.Invoke(conector);
                        }
                        else
                       {
                        datos.Add(new KeyValuePair<string, string>("ERROR","La aplicación del COMMIT esta inhabilitado para este Portal en este momento, notifique a Soporte por favor."));
                       }

                    #region Extrayendo información
                            var tablaRet = bapi_incoming_invoice.GetTable("RETURN");
                            if(tablaRet!=null && tablaRet.RowCount>0)
                            {
                                for (int i = 0; i <= bapi_incoming_invoice.GetTable("RETURN").RowCount; i++)
                                {
                                    string strReturnType = bapi_incoming_invoice.GetTable("RETURN")[0].GetString("TYPE");
                                    string strReturnID = bapi_incoming_invoice.GetTable("RETURN")[0].GetString("ID");
                                    string strReturnNumber = bapi_incoming_invoice.GetTable("RETURN")[0].GetString("NUMBER");
                                    string strReturnMessage = bapi_incoming_invoice.GetTable("RETURN")[0].GetString("MESSAGE");
                                    var previos = from SAPerror in datos where SAPerror.Value.Equals(strReturnMessage) == true select SAPerror;
                                    if (previos != null)
                                        if (previos.Count() <= 0)
                                            datos.Add(new KeyValuePair<string, string>("Error", "TYPE: "+strReturnType+" MESSAGE: "+strReturnMessage+" NUMBER:"+ strReturnNumber+ " ID:" + strReturnID));
                                }
                            }

                           //SAP.Middleware.Connector.IRfcStructure detail = bapi_incoming_invoice.GetStructure("EXPORT");
                            string INVOICEDOCNUMBER = "";
                            string FISCALYEAR = "";
                            if (bapi_incoming_invoice.GetTable("RETURN").RowCount<=0)
                            {
                                //###################### V   E   R   I   F   I   C   A   D   O ################
                                 INVOICEDOCNUMBER = bapi_incoming_invoice.GetValue("INVOICEDOCNUMBER").ToString();
                                 FISCALYEAR = bapi_incoming_invoice.GetValue("FISCALYEAR").ToString();
                              //######################  V   E   R   I   F   I    C    A   D    O ################
                            }


                          if (INVOICEDOCNUMBER.Length > 0)
                            {
                                //Estos son los folios asignados de Recepción por SAP
                                datos.Add(new KeyValuePair<string, string>("INVOICEDOCNUMBER", INVOICEDOCNUMBER));
                                datos.Add(new KeyValuePair<string, string>("FISCALYEAR", FISCALYEAR));
                            }
                            else
                            {
                                 datos.Add(new KeyValuePair<string, string>("ERROR", "No se ingreso la Factura a SAP, consulte los errores relacionados por favor."));
                            }
                    #endregion Extrayendo información

                    RfcSessionManager.EndContext(conector);
                    //######## Dispara a SAP

                    if (harcodeado == true)
                    {
                        List<string> errores = new List<string>();
                        string origenes = "4500742018" + "_" + "5005314568" + "_" + "testing";
                        foreach (KeyValuePair<string, string> data in datos)
                        {
                            errores.Add(data.Key + "- " + data.Value);
                        }
                        Service.Service1 servicio = new Service.Service1();
                        servicio.EscribeLOG(errores, origenes, "4500742018", "MIRO");
                    }

                    }
            }
            catch(Exception _error)
            {
                datos.Add(new KeyValuePair<string, string>("Error", _error.Message));
            }
            var huboErrores = from err in datos where err.Key.Contains("rror") == true select err;
            if(huboErrores!=null)
            {
                #region Si hubo errores
                if (huboErrores.Count()>0)
                {
                    string origenes = detallesPasivos[0].OrdenCompra+"_"+ detallesPasivos[0].NumeroRecepcion+"_"+ HPasivo.UUID;
                    datos.Add(new KeyValuePair<string, string>("Orden de Compra ", detallesPasivos[0].OrdenCompra));
                    datos.Add(new KeyValuePair<string, string>("Recepción ", detallesPasivos[0].NumeroRecepcion));
                    datos.Add(new KeyValuePair<string, string>("UUID ", HPasivo.UUID));
                    datos.Add(new KeyValuePair<string, string>("DIFF_INV", HPasivo.Proveedor_Diferente));

                    try
                    {
                        datos.Add(new KeyValuePair<string, string>("Data", "UUID:"+HPasivo.UUID));
                        datos.Add(new KeyValuePair<string, string>("Data", "FolioFactura:"+HPasivo.FolioFactura));
                        datos.Add(new KeyValuePair<string, string>("Data", "Importe Total:" + HPasivo.Importe));
                        datos.Add(new KeyValuePair<string, string>("Data", "Moneda:" + HPasivo.Moneda));
                        datos.Add(new KeyValuePair<string, string>("Data", "PMNTTRMS:" + HPasivo.PMNTTRMS));
                        datos.Add(new KeyValuePair<string, string>("Data", "Subtotal:" + HPasivo.SubTotalXml));
                        datos.Add(new KeyValuePair<string, string>("Data", "Unidad:" + HPasivo.ClaseDoc));
                        foreach (var deta in detallesPasivos)
                        {
                            datos.Add(new KeyValuePair<string, string>("Data", "Posicion Factura:" + deta.PosicionFactura));
                            datos.Add(new KeyValuePair<string, string>("Data", "OrdenCompra:" + deta.OrdenCompra));
                            datos.Add(new KeyValuePair<string, string>("Data", "Posición OrdenCompra:" + deta.PosicionOrden));
                            datos.Add(new KeyValuePair<string, string>("Data", "Recepcion:" + deta.NumeroRecepcion));
                            datos.Add(new KeyValuePair<string, string>("Data", "Posición Recepcion:" + deta.PosicionRecepcion));
                            datos.Add(new KeyValuePair<string, string>("Data", "Cantidad:" + deta.CantidadConcepto));
                            datos.Add(new KeyValuePair<string, string>("Data", "Importe Unitario:" + deta.ImporteConcepto));
                            datos.Add(new KeyValuePair<string, string>("Data", "Ind. impuesto:" + deta.Impuesto));
                            datos.Add(new KeyValuePair<string, string>("Data", "U Medida:" + deta.ClaseCondicion));
                        }
                    }
                    catch(Exception Ex)
                    {

                    }
                    List<string> errores = new List<string>();
                    foreach (KeyValuePair<string, string> data in datos)
                    {
                        errores.Add(data.Key + "- " + data.Value);
                    }
                    Service.Service1 servicio = new Service.Service1();
                    servicio.EscribeLOG(errores, origenes, detallesPasivos[0].OrdenCompra,"MIRO");
                }
                #endregion Si hubo errores
            }
            else
            {
                #region RETURN reporto issues
                string origenes = detallesPasivos[0].OrdenCompra + "_" + detallesPasivos[0].NumeroRecepcion + "_" + HPasivo.UUID;
                datos.Add(new KeyValuePair<string, string>("Orden de Compra ", detallesPasivos[0].OrdenCompra));
                datos.Add(new KeyValuePair<string, string>("Recepción ", detallesPasivos[0].NumeroRecepcion));
                datos.Add(new KeyValuePair<string, string>("UUID ", HPasivo.UUID));

                try
                {
                    datos.Add(new KeyValuePair<string, string>("Data", "UUID:" + HPasivo.UUID));
                    datos.Add(new KeyValuePair<string, string>("Data", "FolioFactura:" + HPasivo.FolioFactura));
                    datos.Add(new KeyValuePair<string, string>("Data", "Importe Total:" + HPasivo.Importe));
                    datos.Add(new KeyValuePair<string, string>("Data", "Moneda:" + HPasivo.Moneda));
                    datos.Add(new KeyValuePair<string, string>("Data", "PMNTTRMS:" + HPasivo.PMNTTRMS));
                    datos.Add(new KeyValuePair<string, string>("Data", "Subtotal:" + HPasivo.SubTotalXml));
                    datos.Add(new KeyValuePair<string, string>("Data", "Unidad:" + HPasivo.ClaseDoc));
                    foreach (var deta in detallesPasivos)
                    {
                        datos.Add(new KeyValuePair<string, string>("Data", "Posicion Factura:" + deta.PosicionFactura));
                        datos.Add(new KeyValuePair<string, string>("Data", "OrdenCompra:" + deta.OrdenCompra));
                        datos.Add(new KeyValuePair<string, string>("Data", "Posición OrdenCompra:" + deta.PosicionOrden));
                        datos.Add(new KeyValuePair<string, string>("Data", "Recepcion:" + deta.NumeroRecepcion));
                        datos.Add(new KeyValuePair<string, string>("Data", "Posición Recepcion:" + deta.PosicionRecepcion));
                        datos.Add(new KeyValuePair<string, string>("Data", "Cantidad:" + deta.CantidadConcepto));
                        datos.Add(new KeyValuePair<string, string>("Data", "Importe Unitario:" + deta.ImporteConcepto));
                        datos.Add(new KeyValuePair<string, string>("Data", "Ind. impuesto:" + deta.Impuesto));
                        datos.Add(new KeyValuePair<string, string>("Data", "U Medida:" + deta.ClaseCondicion));
                    }
                }
                catch (Exception Ex)
                {

                }
                List<string> errores = new List<string>();
                foreach (KeyValuePair<string, string> data in datos)
                {
                    errores.Add(data.Key + "- " + data.Value);
                }
                Service.Service1 servicio = new Service.Service1();
                servicio.EscribeLOG(errores, origenes, detallesPasivos[0].OrdenCompra, "MIRO");
                #endregion RETURN reporto issues
            }

            return datos;
        }

        /// <summary>
        /// BAPI_GOODSMVT_CREATE
        /// BAPI de Recepción de Materiales 
        /// Este metodo recibe la(s) linea(s) enviadas por la interfaz de MIGO para dar entrada a los materiales en las cantidades indicadas 
        /// de 2 formas: Total o de forma parcial (línea por línea).
        /// </summary>
        /// <param name="conector"></param>
        /// <param name="renglon"></param>
        /// <returns></returns>
        public List<KeyValuePair<string, string>> BAPI_GOODSMVT_CREATE(SAP.Middleware.Connector.RfcDestination conector, ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon)
        {
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            bool disparoFue = false;
            if (conector.SystemID != null)
            {
                SAP.Middleware.Connector.IRfcFunction bapi_goodsmvt_create = conector.Repository.CreateFunction("BAPI_GOODSMVT_CREATE");
                IRfcFunction bapi_goodsmvt_create_Commit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
                bapi_goodsmvt_create_Commit.SetValue("WAIT", "X");
                #region MIGO
                IRfcFunction funcCommit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
                funcCommit.SetValue("WAIT", "X");

                #region Llenando HEADERDATA
                SAP.Middleware.Connector.IRfcStructure detail_Header = bapi_goodsmvt_create.GetStructure("GOODSMVT_HEADER");
                detail_Header.SetValue("REF_DOC_NO", DateTime.Now.Ticks.ToString());
                detail_Header.SetValue("DOC_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_GOODSMVT_CREATE"));
                detail_Header.SetValue("PSTNG_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_GOODSMVT_CREATE"));
                #endregion Llenando HEADERDATA

                #region Llenando CODE
                SAP.Middleware.Connector.IRfcStructure detail_Code = bapi_goodsmvt_create.GetStructure("GOODSMVT_CODE");
                detail_Code.SetValue("GM_CODE", "01");
                #endregion Llenando CODE

                #region Validando Información
                string material = renglon.Numero_Material != null || renglon.Numero_Material.Length > 0 ? renglon.Numero_Material : "INVALIDO";
                string plant = renglon.Planta != null || renglon.Planta.Length > 0 ? renglon.Planta : "INVALIDO";
                string stge_loc = renglon.Almacen != null || renglon.Almacen.Length > 0 ? renglon.Almacen : "INVALIDO";
                string entry_qnt = renglon.Cantidad != null || renglon.Cantidad.Length > 0 ? renglon.Cantidad : "INVALIDO";
                string entry_uom = renglon.Unidad_Medida != null || renglon.Unidad_Medida.Length > 0 ? renglon.Unidad_Medida : "INVALIDO";
                string po_number = renglon.Orden_Compra != null || renglon.Orden_Compra.Length > 0 ? renglon.Orden_Compra : "INVALIDO";
                string po_item = renglon.Posicion_OC != null || renglon.Posicion_OC.Length > 0 ? renglon.Posicion_OC : "INVALIDO";
                Dictionary<int, string> informacion = new Dictionary<int, string>();
                informacion.Add(1, material);
                informacion.Add(2, plant);
                informacion.Add(3, stge_loc);
                informacion.Add(4, entry_qnt);
                informacion.Add(5, entry_uom);
                informacion.Add(6, po_number);
                informacion.Add(7, po_item);
                #endregion Validando Información

                var esValido = from info in informacion where info.Value.Equals("INVALIDO") == true select info;

                try
                {
                    #region La(s) líneas son validas
                    if (esValido != null)
                    {
                        if (esValido.Count() == 0)
                        {
                            #region Llenando ITEMDATA
                            SAP.Middleware.Connector.IRfcTable detail_Item = bapi_goodsmvt_create.GetTable("GOODSMVT_ITEM");
                            detail_Item.Insert();
                            if (material.Length > 0)
                                detail_Item.SetValue("MATERIAL", material);
                            detail_Item.SetValue("PLANT", plant);
                            if (stge_loc.Length > 0)
                                if(stge_loc.Contains("Atención: Sin almacén") ==false)
                                          detail_Item.SetValue("STGE_LOC", stge_loc);
                            detail_Item.SetValue("MOVE_TYPE", "101");
                            detail_Item.SetValue("ENTRY_QNT", entry_qnt);
                            detail_Item.SetValue("ENTRY_UOM", entry_uom);
                            detail_Item.SetValue("PO_NUMBER", po_number);
                            detail_Item.SetValue("PO_ITEM", Convert.ToInt32(po_item).ToString());
                            detail_Item.SetValue("MVT_IND", "B");
                            #endregion Llenando ITEMDATA
                            #region Disparo hacia SAP
                            //######## Dispara a SAP  ############################################################################

                            RfcSessionManager.BeginContext(conector);   // =======================================================>> Abriendo the transaction
                            bapi_goodsmvt_create.Invoke(conector);
                            if (aplicar_COMMIT_BAPI_MIGO()==true)
                            {
                                        bapi_goodsmvt_create_Commit.Invoke(conector);
                            }
                            RfcSessionManager.EndContext(conector); //  ==========================================================>> Cerrando the transaction

                            //######## Dispara a SAP #############################################################################
                            #endregion Disparo hacia SAP
                            //######## Recuperando Folio de Recepción en Almacén

                            string MaterialDocument = bapi_goodsmvt_create.GetValue("MATERIALDOCUMENT").ToString();

                            #region Recuperando mensajes de la Transacción
                            try
                            {
                                if (MaterialDocument.Length <= 0)
                                {
                                    #region Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                    //###########################################################################
                                    //Estas son las estructuras en las que se devuelven excepciones disparadas en SAP
                                    //###########################################################################
                                    for (int i = 0; i <= bapi_goodsmvt_create.GetTable("RETURN").RowCount; i++)
                                    {
                                        string strReturnType = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("TYPE");
                                        string strReturnID = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("ID");
                                        string strReturnNumber = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("NUMBER");
                                        string strReturnMessage = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("MESSAGE");
                                        var previos = from SAPerror in datos where SAPerror.Value.Equals(strReturnMessage) == true select SAPerror;
                                        if (previos != null)
                                            if (previos.Count() <= 0)
                                                datos.Add(new KeyValuePair<string, string>("Error", strReturnMessage));
                                    }
                                    disparoFue = false;
                                    #endregion Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                }
                                else
                                {
                                    //throw new Exception();
                                    #region Transacción exitosa, en las siguientes variables SAP vacian detalles que se hayan generado desde allá
                                    //###########################################################################
                                    //Estas son las estructuras en las que se devuelven excepciones disparadas en SAP
                                    //###########################################################################
                                    for (int i = 0; i <= bapi_goodsmvt_create.GetTable("RETURN").RowCount; i++)
                                    {
                                        string strReturnType = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("TYPE");
                                        string strReturnID = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("ID");
                                        string strReturnNumber = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("NUMBER");
                                        string strReturnMessage = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("MESSAGE");
                                        var previos = from SAPerror in datos where SAPerror.Value.Equals(strReturnMessage) == true select SAPerror;
                                        if (previos != null)
                                            if (previos.Count() <= 0)
                                                datos.Add(new KeyValuePair<string, string>("Error", strReturnMessage));
                                    }
                                    disparoFue = true;
                                    #endregion Transacción exitosa, en las siguientes variables SAP vacian detalles que se hayan generado desde allá
                                }
                                //B I T A C O R A     T O D O
                                #region RETURN reporto issues
                                try
                                {
                                    string origenes = po_number + "_" + po_item + "_" + material;
                                    datos.Add(new KeyValuePair<string, string>("Orden de Compra ", po_number));
                                    datos.Add(new KeyValuePair<string, string>("Recepción ", po_item));
                                    datos.Add(new KeyValuePair<string, string>("Material ",material));

                                    try
                                    {
                                        datos.Add(new KeyValuePair<string, string>("Data", "Cantidad a ingresar:" + entry_qnt));
                                        datos.Add(new KeyValuePair<string, string>("Data", "U Medida:" + entry_uom));
                                        datos.Add(new KeyValuePair<string, string>("Data", "Planta:" + plant));
                                        if(disparoFue==false)
                                        {
                                            datos.Add(new KeyValuePair<string, string>("Data", "Resultado fue:  F A L L I D O "));
                                        }
                                        else
                                        {
                                            datos.Add(new KeyValuePair<string, string>("Data", "Resultado fue:  E X I T O S O "));
                                        }
                                    }
                                    catch (Exception Ex)
                                    {

                                    }
                                    List<string> errores = new List<string>();
                                    foreach (KeyValuePair<string, string> data in datos)
                                    {
                                        errores.Add(data.Key + "- " + data.Value);
                                    }
                                    Service.Service1 servicio = new Service.Service1();
                                    servicio.EscribeLOG(errores, origenes, po_number, "MIGO");
                                }
                                catch(Exception ex)
                                {
                                    string m = ex.Message;
                                }

                                #endregion RETURN reporto issues
                            }
                            catch (Exception _ex)
                            {
                                #region Recuperando Folio de Recepción en Almacén
                                string problema = _ex.Message;
                                //Si llego a este CATCH es por que la estructura anterior que es para devolver errores no se lleno=Sin errores en la transacción de ingresar datos a SAP
                                //######## Recuperando Folio de Recepción en Almacén
                                SAP.Middleware.Connector.IRfcStructure detail = bapi_goodsmvt_create.GetStructure("GOODSMVT_HEADRET");
                                string NoMaterial = detail["MAT_DOC"].ToString();

                                if (NoMaterial.Length > 0)
                                {
                                    //Estos son los folios asignados de Recepción por SAP
                                    datos.Add(new KeyValuePair<string, string>("MAT_DOC", detail.GetString("MAT_DOC").ToString()));
                                    datos.Add(new KeyValuePair<string, string>("DOC_YEAR", detail.GetString("DOC_YEAR").ToString()));
                                    if (aplicar_COMMIT_BAPI_MIGO() == true)
                                    {
                                        bapi_goodsmvt_create_Commit.Invoke(conector);
                                    }
                                }
                                else
                                {
                                   // datos = null;
                                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", problema);
                                    datos.Add(info);
                                }
                                //######## Recuperando Folio de Recepción en Almacén
                                #endregion Recuperando Folio de Recepción en Almacén
                            }
                            #endregion Recuperando mensajes de la Transacción  // =======================================================>> Cerrando the transaction
                        }
                        else
                        {
                            datos = null;
                        }
                    }
                    else
                    {
                        datos = null;
                    }
                    #endregion La(s) líneas son validas
                }
                catch (RfcCommunicationException e)
                {
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error",error1);
                    datos.Add(info);
                }
                catch (RfcLogonException e)
                {
                    // user could not logon...
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (RfcAbapRuntimeException e)
                {
                    // serious problem on ABAP system side...
                     string error1 = e.Message;
                     KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                     datos.Add(info);
                }
                catch (RfcAbapBaseException e)
                {
                    // The function module returned an ABAP exception, an ABAP message
                    // or an ABAP class-based exception...
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (Exception ex)
                {
                    string problema = ex.Message;
                    RfcSessionManager.EndContext(conector); //End the transaction
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", ex.Message);
                    datos.Add(info);
                }
                #endregion MIGO
            }
            return datos;
        }

        public List<KeyValuePair<string, string>> BAPI_GOODSMVT_CREATE_HARDCODEADA(SAP.Middleware.Connector.RfcDestination conector, ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon)
        {
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            if (conector.SystemID != null)
            {
                SAP.Middleware.Connector.IRfcFunction bapi_goodsmvt_create = conector.Repository.CreateFunction("BAPI_GOODSMVT_CREATE");
                IRfcFunction bapi_goodsmvt_create_Commit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
                bapi_goodsmvt_create_Commit.SetValue("WAIT", "X");
                #region MIGO
                IRfcFunction funcCommit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
                funcCommit.SetValue("WAIT", "X");

                #region Llenando HEADERDATA
                SAP.Middleware.Connector.IRfcStructure detail_Header = bapi_goodsmvt_create.GetStructure("GOODSMVT_HEADER");
                detail_Header.SetValue("REF_DOC_NO", DateTime.Now.Ticks.ToString());
                detail_Header.SetValue("DOC_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_GOODSMVT_CREATE"));
                detail_Header.SetValue("PSTNG_DATE", convierteFormatoSAP(DateTime.Now, "BAPI_GOODSMVT_CREATE"));
                #endregion Llenando HEADERDATA

                #region Llenando CODE
                SAP.Middleware.Connector.IRfcStructure detail_Code = bapi_goodsmvt_create.GetStructure("GOODSMVT_CODE");
                detail_Code.SetValue("GM_CODE", "01");
                #endregion Llenando CODE

                #region Validando Información
                string material = "";        // renglon.Numero_Material != null || renglon.Numero_Material.Length > 0 ? renglon.Numero_Material : "INVALIDO";
                string plant = "0050";                  // renglon.Planta != null || renglon.Planta.Length > 0 ? renglon.Planta : "INVALIDO";
                string stge_loc = "";            // renglon.Almacen != null || renglon.Almacen.Length > 0 ? renglon.Almacen : "INVALIDO";
                string entry_qnt = "1";                // renglon.Cantidad != null || renglon.Cantidad.Length > 0 ? renglon.Cantidad : "INVALIDO";
                string entry_uom = "ST";           // renglon.Unidad_Medida != null || renglon.Unidad_Medida.Length > 0 ? renglon.Unidad_Medida : "INVALIDO";
                string po_number = "4500723278";              // renglon.Orden_Compra != null || renglon.Orden_Compra.Length > 0 ? renglon.Orden_Compra : "INVALIDO";
                string po_item = "20";                   // renglon.Posicion_OC != null || renglon.Posicion_OC.Length > 0 ? renglon.Posicion_OC : "INVALIDO";
                Dictionary<int, string> informacion = new Dictionary<int, string>();
                informacion.Add(1, material);
                informacion.Add(2, plant);
                informacion.Add(3, stge_loc);
                informacion.Add(4, entry_qnt);
                informacion.Add(5, entry_uom);
                informacion.Add(6, po_number);
                informacion.Add(7, po_item);
                #endregion Validando Información

                var esValido = from info in informacion where info.Value.Equals("INVALIDO") == true select info;

                try
                {
                    #region La(s) líneas son validas
                    if (esValido != null)
                    {
                        if (esValido.Count() == 0)
                        {
                            #region Llenando ITEMDATA
                            SAP.Middleware.Connector.IRfcTable detail_Item = bapi_goodsmvt_create.GetTable("GOODSMVT_ITEM");
                            detail_Item.Insert();
                            if (material.Length > 0)
                                detail_Item.SetValue("MATERIAL", material);
                            detail_Item.SetValue("PLANT", plant);
                            if (stge_loc.Length>0)
                                    detail_Item.SetValue("STGE_LOC", stge_loc);
                            detail_Item.SetValue("MOVE_TYPE", "101");
                            detail_Item.SetValue("ENTRY_QNT", entry_qnt);
                            detail_Item.SetValue("ENTRY_UOM", entry_uom);
                            //detail_Item.SetValue("ENTRY_UOM_ISO", "PCE");
                            detail_Item.SetValue("PO_NUMBER", po_number);
                            detail_Item.SetValue("PO_ITEM", Convert.ToInt32(po_item).ToString());
                            detail_Item.SetValue("MVT_IND", "B");
                            #endregion Llenando ITEMDATA
                            #region Disparo hacia SAP
                            //######## Dispara a SAP  ############################################################################

                            RfcSessionManager.BeginContext(conector);   // =======================================================>> Abriendo the transaction
                            bapi_goodsmvt_create.Invoke(conector);
                            if (aplicar_COMMIT_BAPI_MIGO() == true)
                            {
                                bapi_goodsmvt_create_Commit.Invoke(conector);
                            }
                            RfcSessionManager.EndContext(conector); //  ==========================================================>> Cerrando the transaction

                            //######## Dispara a SAP #############################################################################
                            #endregion Disparo hacia SAP
                            //######## Recuperando Folio de Recepción en Almacén

                            string MaterialDocument = bapi_goodsmvt_create.GetValue("MATERIALDOCUMENT").ToString();

                            #region Recuperando mensajes de la Transacción
                            try
                            {
                                #region Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                //###########################################################################
                                //Estas son las estructuras en las que se devuelven excepciones disparadas en SAP
                                //###########################################################################
                                for(int i=0;i<= bapi_goodsmvt_create.GetTable("RETURN").RowCount;i++)
                                {
                                    string strReturnType = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("TYPE");
                                    string strReturnID = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("ID");
                                    string strReturnNumber = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("NUMBER");
                                    string strReturnMessage = bapi_goodsmvt_create.GetTable("RETURN")[0].GetString("MESSAGE");
                                    var previos = from SAPerror in datos where SAPerror.Value.Equals(strReturnMessage) == true select SAPerror;
                                        if(previos!=null)
                                            if(previos.Count()<=0)
                                                  datos.Add(new KeyValuePair<string, string>("Error", strReturnMessage));
                                }


                                //string strReturnType2 = funcCommit.GetStructure("RETURN").GetString("TYPE");
                                //string strReturnID2 = funcCommit.GetStructure("RETURN").GetString("ID");
                                //string strReturnNumber2 = funcCommit.GetStructure("RETURN").GetString("NUMBER");
                                //string strReturnMessage2 = funcCommit.GetStructure("RETURN").GetString("MESSAGE");
                                //if (strReturnMessage2.Length > 0)
                                //{
                                //    datos.Add(new KeyValuePair<string, string>("Error", strReturnMessage2));
                                //}
                                #endregion Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                            }
                            catch (Exception _ex)
                            {
                                #region Recuperando Folio de Recepción en Almacén
                                string problema = _ex.Message;
                                //Si llego a este CATCH es por que la estructura anterior que es para devolver errores no se lleno=Sin errores en la transacción de ingresar datos a SAP
                                //######## Recuperando Folio de Recepción en Almacén
                                SAP.Middleware.Connector.IRfcStructure detail = bapi_goodsmvt_create.GetStructure("GOODSMVT_HEADRET");
                                string NoMaterial = detail["MAT_DOC"].ToString();

                                if (NoMaterial.Length > 0)
                                {
                                    //Estos son los folios asignados de Recepción por SAP
                                    datos.Add(new KeyValuePair<string, string>("MAT_DOC", detail.GetString("MAT_DOC").ToString()));
                                    datos.Add(new KeyValuePair<string, string>("DOC_YEAR", detail.GetString("DOC_YEAR").ToString()));
                                    if (aplicar_COMMIT_BAPI_MIGO() == true)
                                    {
                                        bapi_goodsmvt_create_Commit.Invoke(conector);
                                    }
                                }
                                else
                                {
                                    // datos = null;
                                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", problema);
                                    datos.Add(info);
                                }
                                //######## Recuperando Folio de Recepción en Almacén
                                #endregion Recuperando Folio de Recepción en Almacén
                            }
                            #endregion Recuperando mensajes de la Transacción  // =======================================================>> Cerrando the transaction
                        }
                        else
                        {
                            datos = null;
                        }
                    }
                    else
                    {
                        datos = null;
                    }
                    #endregion La(s) líneas son validas
                }
                catch (RfcCommunicationException e)
                {
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (RfcLogonException e)
                {
                    // user could not logon...
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (RfcAbapRuntimeException e)
                {
                    // serious problem on ABAP system side...
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (RfcAbapBaseException e)
                {
                    // The function module returned an ABAP exception, an ABAP message
                    // or an ABAP class-based exception...
                    string error1 = e.Message;
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", error1);
                    datos.Add(info);
                }
                catch (Exception ex)
                {
                    string problema = ex.Message;
                    RfcSessionManager.EndContext(conector); //End the transaction
                    KeyValuePair<string, string> info = new KeyValuePair<string, string>("Error", ex.Message);
                    datos.Add(info);
                }
                #endregion MIGO
            }
            return datos;
        }

        public System.Data.DataTable obtenOrdenCompraWeb(string ordencompra, ref List<KeyValuePair<string, string>> datos)
        {
            SAP.Middleware.Connector.RfcDestination conector= Conector;
            List<KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>> tablas = new List<KeyValuePair<string, IRfcTable>>();
            System.Data.DataTable tbl = new System.Data.DataTable();
            if (conector.SystemID != null)
            {
                try
                {
                    var funcion = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL");
                    SAP.Middleware.Connector.IRfcFunction ordencompraBapi = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL");
                    ordencompraBapi.SetValue("PURCHASEORDER", "4500741972");//ordencompra);
                    ordencompraBapi.SetValue("ITEMS", "x");
                    ordencompraBapi.SetValue("HISTORY", "x");
                    ordencompraBapi.Invoke(conector);

                    IRfcTable tblReturn = ordencompraBapi.GetTable("RETURN");

                    IRfcTable tblPO_ITEMS = ordencompraBapi.GetTable("PO_ITEMS");
                    if (tblPO_ITEMS.RowCount > 0)
                    {
                        datos.Add(new KeyValuePair<string, string>("PO_ITEMS", "OK"));
                        tablas.Add(new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEMS", tblPO_ITEMS));
                        tbl = ConvertirRfcTableToDataTable(ref tbl, new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEMS", tblPO_ITEMS));
                        tbl = PoblarDataTabledesdeIRfcTable(tblPO_ITEMS, tbl);
                    }

                    IRfcTable tblPO_ITEM_HISTORY = ordencompraBapi.GetTable("PO_ITEM_HISTORY");
                    if (tblPO_ITEM_HISTORY.RowCount > 0)
                    {
                        datos.Add(new KeyValuePair<string, string>("tblPO_ITEM_HISTORY", "OK"));
                        tablas.Add(new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEM_HISTORY", tblPO_ITEM_HISTORY));
                        tbl = ConvertirRfcTableToDataTable(ref tbl, new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEM_HISTORY", tblPO_ITEM_HISTORY));
                        tbl = PoblarDataTabledesdeIRfcTable(tblPO_ITEM_HISTORY, tbl);
                    }
                    //IRfcTable tblLifnr = fordencompraBapi.GetTable("T_LIFNR");
                    //funcArtikel.SetValue("I_EAN11", "4006984001992");

                }
                catch (Exception ex)
                {
                    datos.Add(new KeyValuePair<string, string>("Error", ex.Message));
                }
            }
            return tbl;
        }
        public System.Data.DataTable obtenOrdenCompra(SAP.Middleware.Connector.RfcDestination conector, string ordencompra, ref List<KeyValuePair<string, string>> datos)
        {
            if(conector==null)
            {
                conector = Conector;
            }
            List<KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>> tablas = new List<KeyValuePair<string, IRfcTable>>();
            System.Data.DataTable tbl = new System.Data.DataTable();
            if (conector.SystemID != null)
            {
                try
                {
                        var funcion = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL");
                        SAP.Middleware.Connector.IRfcFunction ordencompraBapi = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL");
                        ordencompraBapi.SetValue("PURCHASEORDER", ordencompra);
                        ordencompraBapi.SetValue("ITEMS","x");
                        ordencompraBapi.Invoke(conector);

                        Conector.Ping();

                        IRfcTable tblReturn = ordencompraBapi.GetTable("RETURN");

                        IRfcTable tblPO_ITEMS = ordencompraBapi.GetTable("PO_ITEMS");
                        if (tblPO_ITEMS.RowCount>0)
                        {
                               datos.Add(new KeyValuePair<string,string>("PO_ITEMS","OK"));
                               tablas.Add(new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEMS",tblPO_ITEMS));
                               tbl=ConvertirRfcTableToDataTable(ref tbl,new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEMS", tblPO_ITEMS));
                               tbl = PoblarDataTabledesdeIRfcTable(tblPO_ITEMS, tbl);
                        }

                        IRfcTable tblPO_ITEM_HISTORY = ordencompraBapi.GetTable("PO_ITEM_HISTORY");
                        if (tblPO_ITEM_HISTORY.RowCount > 0)
                        {
                             datos.Add(new KeyValuePair<string, string>("tblPO_ITEM_HISTORY", "OK"));
                             tablas.Add(new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEM_HISTORY", tblPO_ITEM_HISTORY));
                             tbl=ConvertirRfcTableToDataTable(ref tbl,new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>("PO_ITEM_HISTORY", tblPO_ITEM_HISTORY));
                             tbl = PoblarDataTabledesdeIRfcTable(tblPO_ITEM_HISTORY, tbl);
                        }
                        //IRfcTable tblLifnr = fordencompraBapi.GetTable("T_LIFNR");
                        //funcArtikel.SetValue("I_EAN11", "4006984001992");
                }
                catch(Exception ex)
                {
                    datos.Add(new KeyValuePair<string, string>("Error", ex.Message));
                }
            }
            return tbl;
        }
       public List<string> GetCustomers(SAP.Middleware.Connector.RfcDestination conector)
     {
         List<string> customerList = new List<string>();
         MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult customerResult = ExecuteSelect("FUNCTION_NAME",
                     new List<MVC5_full_version.Clases.Conector_SAPNET_3.DTO.NParameter>
                                {
                                    new MVC5_full_version.Clases.Conector_SAPNET_3.DTO.NParameter{Name = "PARAMETER_NAME", Value="PARAMETER_VALUE"}
                                },
                     new List<string>
                                {
                                    "TABLE_NAME1","TABLE_NAME2"
                                });
         if (customerResult.IsSuccess)
         {
             IRfcTable customersTable = (IRfcTable)customerResult.Data[0];
             if (customersTable.ElementCount > 0 && customersTable.RowCount > 0)
             {
                 customersTable.CurrentIndex = 0;
                 for (int i = 0; i < customersTable.RowCount; i++)
                 {
                       string CustomerId = customersTable.GetString("CUSTOMER_ID");
                       string   Name = customersTable.GetString("CUSTOMER_NAME");


                     if (customersTable.CurrentIndex < (customersTable.RowCount - 1))
                     {
                         customersTable.CurrentIndex++;
                     }
                 }
             }
     }
         return customerList;
     }

       /// <summary>
       /// Crear un  DataTable con la misma estructura que trae el 
       /// RfcTable.
       /// </summary>
       /// <param name="tableToConvert">RfcTable a copiar.</param>
       /// <param name="tableName">Nombre de la DataTable creada.</param>
       /// <returns>DataTable instanciada.</returns>
       public System.Data.DataTable ConvertirRfcTableToDataTable(ref System.Data.DataTable tabla,KeyValuePair<string, SAP.Middleware.Connector.IRfcTable> param)
       {
           //var columnsMetadata = tableToConvert.Metadata.LineType;
           //var dataTable = new System.Data.DataTable(tableName);
           var columnsMetadata = param.Value.Metadata.LineType;
           var dataTable = new System.Data.DataTable(param.Key.ToString());
           dataTable = tabla.Copy();

           for (var i = 0; i < columnsMetadata.FieldCount; i++)
           {
               dataTable.Columns
                   .Add(columnsMetadata[i].Name, obtenercorrespondenciaSAPDotNetType(columnsMetadata[i].DataType.ToString(), columnsMetadata[i].NucLength));
           }

           return dataTable;
       }

       /// <summary>
       /// Mapear tipos SAP a tipos .Net.
       /// </summary>
       /// <param name="sapType">Tipo SAP a mapear</param>
       /// <param name="typeLength">Largo o dominio del tipo SAP type (ejemplo: CHAR(16) => typeLength = 16)</param>
       /// <returns>Tipo .Net</returns>
       private Type obtenercorrespondenciaSAPDotNetType(string sapType, int typeLength)
       {
           switch (sapType)
           {
               case "BYTE":
                   return typeof(byte[]);

               case "INT":
                   return typeof(int);

               case "INT1":
                   return typeof(byte);

               case "INT2":
                   return typeof(short);

               case "FLOAT":
                   return typeof(double);

               case "NUM":

                   if (typeLength <= 9)
                   {
                       return typeof(int);
                   }

                   if (typeLength <= 19)
                   {
                       return typeof(long);
                   }

                   return typeof(string);

               default:
                   return typeof(string);
           }
       }

       /// Extraer el valor de la  RfcColumn by using the correct method for the 
       /// column type and put extracted value into the DataColumn.
       /// </summary>
       /// <param name="rfcColumn">Value source.</param>
       /// <param name="dataRow">Value destination.</param>
       /// <param name="dataColumn">Column to be set from destination.</param>
       private void SetDataColumnValueFromRfcColumn(IRfcField rfcColumn, System.Data.DataRow dataRow, System.Data.DataColumn dataColumn)
       {

           if (dataColumn.DataType == typeof(byte[]))
           {
               dataRow[dataColumn.ColumnName] = rfcColumn.GetByteArray();

               return;
           }

           if (dataColumn.DataType == typeof(int))
           {
               dataRow[dataColumn.ColumnName] = rfcColumn.GetInt();

               return;
           }

           if (dataColumn.DataType == typeof(byte))
           {
               dataRow[dataColumn.ColumnName] = rfcColumn.GetByte();

               return;
           }

           if (dataColumn.DataType == typeof(short))
           {
               dataRow[dataColumn.ColumnName] = rfcColumn.GetShort();

               return;
           }

           if (dataColumn.DataType == typeof(double))
           {
               dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

               return;
           }

           dataRow[dataColumn.ColumnName] = rfcColumn.GetString();
       }

       /// <summary>
       /// Poblar la DataTable con los valores
       /// proporcinados por el RfcTable
       /// </summary>
       /// <param name="rfcTable">Tabla SAP Fuente</param>
       /// <param name="dataTable">DataTable destino</param>
       public System.Data.DataTable PoblarDataTabledesdeIRfcTable(IRfcTable rfcTable, System.Data.DataTable dataTable)
       {
           for (var i = 0; i < rfcTable.RowCount; i++)
           {
               rfcTable.CurrentIndex = i;

               var row = dataTable.NewRow();

               foreach (System.Data.DataColumn column in dataTable.Columns)
               {
                   try
                   {
                       SetDataColumnValueFromRfcColumn(rfcTable.CurrentRow[column.ColumnName], row, column);
                   }
                   catch (Exception ex)
                   {
                       throw new Exception(
                           string.Format("Ocurrio un error intentando agregar el valor a la columna '{0}' de la tabla '{1}'. For more details check inner exception.", column.ColumnName, dataTable.TableName), ex);
                   }
               }

               dataTable.Rows.Add(row);
           }
           return dataTable;
       }

       #region        FUNCIONES Z

        /// <summary>
        ///  BAPI Z ===> ZMF_CFS_PROVEEDOR_PP
        ///  BAPI desarrollada para recuperar información especifica del Proveedor(es), Sociedad(es) y  Correo(s) que complementa la información necesaria para procesar las facturas
        ///  tales como los RFC, Sociedades relacionadas de un proveedor y sus correos existentes en SAP por ejemplo
        /// </summary>
        /// <param name="conector"></param>
        /// <param name="S"></param>
        /// <param name="OP"></param>
        /// <param name="Vendor_Low"></param>
        /// <param name="Vendor_High"></param>
       /// <param name="Tipo">Tipo =  1 Solo Proveedor, 2 Recuperar las Retenciones </param>
        /// <returns></returns>
       public List<KeyValuePair<string, string>> BAPIZ_obtenInformacionProveedoresGral(SAP.Middleware.Connector.RfcDestination conector, string S,string OP,string Vendor_Low,string Vendor_High,int Tipo)
       {
           List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
           if (conector.SystemID != null)
           {
               //Z_PFI_GETVENDOR Funcion dentro de Servidor TKPM
               string queFuncion = "";
               string tablaProveedoresAll = "";
                string Proveedores = "";
                string rangoProveedor = "";
               string hostingDestino = System.Configuration.ConfigurationManager.AppSettings["hostingDestino"];
               if(hostingDestino.Equals("false")==true)
               {
                   //Estamos en equipo de desarrollo
                   queFuncion = "ZMF_CFS_PROVEEDOR_PP";
                   tablaProveedoresAll = "RBUKRS";
                    Proveedores = "PROVEEDORES";
                    rangoProveedor = "LIFNR";
               }
               else
               {
                   //Estamos en el servidor de Thyseen
                    queFuncion = "Z_PFI_GETVENDOR";
                    tablaProveedoresAll = "RBURKS";
                    Proveedores = "VENDOR";
                    rangoProveedor = "RLIFNR";
               }

                #region Configurando Commit

                var funcion = conector.Repository.CreateFunction(queFuncion);
               SAP.Middleware.Connector.IRfcFunction ZMF_CFS_PROVEEDOR_PP = conector.Repository.CreateFunction(queFuncion);
               IRfcFunction funcionCommit = conector.Repository.CreateFunction("BAPI_TRANSACTION_COMMIT");
               funcionCommit.SetValue("WAIT", "X");

                #endregion Configurando Commit

               SAP.Middleware.Connector.IRfcTable detail_Item = ZMF_CFS_PROVEEDOR_PP.GetTable("RLIFNR");
               SAP.Middleware.Connector.IRfcTable detail_All = ZMF_CFS_PROVEEDOR_PP.GetTable(tablaProveedoresAll);

                #region Carga de Parametros
                           switch (Tipo)
                           {
                               case 1:
                                   #region Configuración 1 Solo Proveedor Tipo=1
                                       detail_Item.Insert();
                                       detail_Item.SetValue("SIGN", S);
                                       detail_Item.SetValue("OPTION", OP);
                                       detail_Item.SetValue("VENDOR_LOW", Vendor_Low);
                                       detail_Item.SetValue("VENDOR_HIGH", Vendor_High);
                                   #endregion Configuración 1 Solo Proveedor Tipo=1
                                   break;
                               case 2:
                                   #region Configuración 1 Solo Proveedor pero recuperando sus Retenciones
                                   detail_Item.Insert();
                                   detail_Item.SetValue("SIGN", S);
                                   detail_Item.SetValue("OPTION", OP);
                                   detail_Item.SetValue("VENDOR_LOW", Vendor_Low);
                                   detail_Item.SetValue("VENDOR_HIGH", Vendor_High);
                                   #endregion Configuración 1 Solo Proveedor  pero recuperando sus Retenciones
                                   break;
                               case 3:
                                   #region Configuración 1 Solo Proveedor pero recuperando sus Retenciones
                                   detail_All.Insert();
                                   detail_All.SetValue("SIGN", S);
                                   detail_All.SetValue("OPTION", OP);
                                   detail_All.SetValue("LOW", Vendor_Low);
                                   detail_All.SetValue("HIGH", Vendor_High);
                                   #endregion Configuración 1 Solo Proveedor  pero recuperando sus Retenciones
                                   break;
                           }
                #endregion Carga de Parametros

                #region estrayendo resultados volvados en las Tablas
                try
                {
                        //######## Dispara a SAP
                        RfcSessionManager.BeginContext(conector);
                           ZMF_CFS_PROVEEDOR_PP.Invoke(conector);
                           funcionCommit.Invoke(conector);
                           RfcSessionManager.EndContext(conector);
                    //######## Dispara a SAP

                        //ZECSFI_PROVEEDOR
                         SAP.Middleware.Connector.IRfcTable detail = ZMF_CFS_PROVEEDOR_PP.GetTable(Proveedores);

                          //RETENCIONES DEL PROVEEDOR
                           SAP.Middleware.Connector.IRfcTable detailRetenciones = ZMF_CFS_PROVEEDOR_PP[3].GetTable();

                           //TODOS PROVEEDOR
                           SAP.Middleware.Connector.IRfcTable detailAll = ZMF_CFS_PROVEEDOR_PP[1].GetTable();

                        #endregion estrayendo resultados volvados en las Tablas

                        switch (Tipo)
                           {
                               case 1:
                                   #region Configuración 1 Solo Proveedor Tipo=1
                                   try
                                   {
                                       if (detail.GetString("LIFNR").Length > 0)
                                       {
                                           #region Extrayendo la informacion
                                           datos.Add(new KeyValuePair<string, string>("LIFNR", detail.GetString("LIFNR")));
                                           datos.Add(new KeyValuePair<string, string>("BUKRS", detail.GetString("BUKRS")));
                                           datos.Add(new KeyValuePair<string, string>("BUTXT", detail.GetString("BUTXT")));
                                           datos.Add(new KeyValuePair<string, string>("LAND1", detail.GetString("LAND1")));
                                           datos.Add(new KeyValuePair<string, string>("NAME1", detail.GetString("NAME1")));
                                           datos.Add(new KeyValuePair<string, string>("ADRNR", detail.GetString("ADRNR")));
                                           datos.Add(new KeyValuePair<string, string>("KTOKK", detail.GetString("KTOKK")));
                                           datos.Add(new KeyValuePair<string, string>("LOEVM", detail.GetString("LOEVM")));
                                           datos.Add(new KeyValuePair<string, string>("STCD1", detail.GetString("STCD1")));
                                           datos.Add(new KeyValuePair<string, string>("XCPDK", detail.GetString("XCPDK")));
                                           datos.Add(new KeyValuePair<string, string>("STCD3", detail.GetString("XCPDK")));
                                           datos.Add(new KeyValuePair<string, string>("BUTXT", detail.GetString("BUTXT")));
                                            #region Extrae el RFC
                                            try
                                            {
                                                datos.Add(new KeyValuePair<string, string>("RFCSO", detail.GetString("RFCSO")));//RFC del Proveedor
                                            }
                                            catch (Exception _rfc)
                                            {
                                                try
                                                {
                                                    datos.Add(new KeyValuePair<string, string>("RFCSO", detail.GetString("RFCBK")));
                                                }
                                                catch
                                                {
                                                    datos.Add(new KeyValuePair<string, string>("RFCSO", "No en SAP"));
                                                }
                                            }
                                            #endregion Extrae el RFC
                                    #endregion Extrayendo la informacion
                                }
                            }
                                   catch (Exception _e)
                                   {
                                           #region       Recuperando errores
                                       //try
                                       //{
                                       //    #region Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                       //    //###########################################################################
                                       //    //Estas son las estructuras en las que se devuelven excepciones disparadas en SAP
                                       //    //###########################################################################

                                       //    #endregion Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                       //}
                                       //catch (Exception e)
                                       //{
                                       #region Llenando datos de repuesta NEGATIVA
                                       datos.Add(new KeyValuePair<string, string>("LIFNR", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("BUKRS", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("BUTXT", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("LAND1", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("NAME1", "Error "+_e.Message));
                                       datos.Add(new KeyValuePair<string, string>("ADRNR", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("KTOKK", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("LOEVM", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("STCD1", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("XCPDK", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("STCD3", "No localizado"));
                                       datos.Add(new KeyValuePair<string, string>("BUTXT", "Proveedor no localizado"));
                                       datos.Add(new KeyValuePair<string, string>("RFCSO", "No localizado"));
                                       #endregion Llenando datos de repuesta NEGATIVA
                                       //}
                                       #endregion Recuperando errores
                                   }
                                  #endregion Configuración 1 Solo Proveedor Tipo=1
                               break;
                               case 2:
                               #region Configuración 1 Solo Proveedor Tipo=2  pero recuperando sus Retenciones
                               try
                               {
                                   if (detailRetenciones.GetString("MANDT").Length > 0)
                                   {
                                       #region Extrayendo la informacion
                                       datos.Add(new KeyValuePair<string, string>("MANDT", detailRetenciones.GetString("MANDT")));
                                       datos.Add(new KeyValuePair<string, string>("LIFNR", detailRetenciones.GetString("LIFNR")));
                                       datos.Add(new KeyValuePair<string, string>("BUKRS", detailRetenciones.GetString("BUKRS")));
                                       datos.Add(new KeyValuePair<string, string>("WITHT", detailRetenciones.GetString("WITHT")));
                                       datos.Add(new KeyValuePair<string, string>("WT_SUBJCT", detailRetenciones.GetString("WT_SUBJCT")));
                                       datos.Add(new KeyValuePair<string, string>("QSREC", detailRetenciones.GetString("QSREC")));
                                       datos.Add(new KeyValuePair<string, string>("WT_WTSTCD", detailRetenciones.GetString("WT_WTSTCD")));
                                       datos.Add(new KeyValuePair<string, string>("WT_WITHCD", detailRetenciones.GetString("WT_WITHCD")));
                                       datos.Add(new KeyValuePair<string, string>("WT_EXNR", detailRetenciones.GetString("WT_EXNR")));
                                       datos.Add(new KeyValuePair<string, string>("WT_EXRT", detailRetenciones.GetString("WT_EXRT")));
                                       datos.Add(new KeyValuePair<string, string>("WT_EXDF", detailRetenciones.GetString("WT_EXDF")));
                                       datos.Add(new KeyValuePair<string, string>("WT_EXDT", detailRetenciones.GetString("WT_EXDT")));
                                       datos.Add(new KeyValuePair<string, string>("WT_WTEXRS", detailRetenciones.GetString("WT_WTEXRS")));
                                       #endregion Extrayendo la informacion
                                   }
                               }
                               catch (Exception _e)
                               {
                                   #region Llenando datos de repuesta NEGATIVA
                                   datos.Add(new KeyValuePair<string, string>("NAME1","Error"));
                                   datos.Add(new KeyValuePair<string, string>("MANDT", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("LIFNR", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("BUKRS", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WITHT", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_SUBJCT", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("QSREC", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_WTSTCD", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_WITHCD", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_EXNR", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_EXRT", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_EXDF", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_EXDT", "No localizado"));
                                   datos.Add(new KeyValuePair<string, string>("WT_WTEXRS", "No localizado"));
                                   #endregion Llenando datos de repuesta NEGATIVA
                               }
                               #endregion Configuración 1 Solo Proveedor Tipo=2  pero recuperando sus Retenciones
                               break;
                               case 3:
                               #region Configuración todos los Proveedores Tipo=3
                                       if (detail.RowCount>0)
                                                {
                                                    #region Extrayendo la informacion de la Sociedad
                                                   // datos.Add(new KeyValuePair<string, string>("LIFNR", detail.GetString("LIFNR")));
                                                   // datos.Add(new KeyValuePair<string, string>("BUKRS", detail.GetString("BUKRS")));
                                                   // datos.Add(new KeyValuePair<string, string>("BUTXT", detail.GetString("BUTXT")));
                                                   // datos.Add(new KeyValuePair<string, string>("LAND1", detail.GetString("LAND1")));
                                                   // datos.Add(new KeyValuePair<string, string>("NAME1", detail.GetString("NAME1")));
                                                   // datos.Add(new KeyValuePair<string, string>("ADRNR", detail.GetString("ADRNR")));
                                                   // datos.Add(new KeyValuePair<string, string>("KTOKK", detail.GetString("KTOKK")));
                                                   // datos.Add(new KeyValuePair<string, string>("LOEVM", detail.GetString("LOEVM")));
                                                   // datos.Add(new KeyValuePair<string, string>("STCD1", detail.GetString("STCD1")));
                                                   // datos.Add(new KeyValuePair<string, string>("XCPDK", detail.GetString("XCPDK")));
                                                   // datos.Add(new KeyValuePair<string, string>("STCD3", detail.GetString("XCPDK")));
                                                   // datos.Add(new KeyValuePair<string, string>("BUTXT", detail.GetString("BUTXT")));
                                                   // try
                                                   //   {
                                                   //      datos.Add(new KeyValuePair<string, string>("RFCSO", detail.GetString("RFCSO")));//RFC del Proveedor
                                                   //   }
                                                   //catch(Exception _u)
                                                   //   {
                                                   //         try
                                                   //         {
                                                   //               datos.Add(new KeyValuePair<string, string>("RFCSO", detail.GetString("RFCBK")));
                                                   //         }
                                                   //         catch
                                                   //         {
                                                   //                 datos.Add(new KeyValuePair<string, string>("RFCSO", "No en SAP"));
                                                   //         }
                                                   //   }
                                                    #endregion Extrayendo la informacion de la Sociedad
                                                    foreach(var detailAl in detail)
                                                    {
                                                               #region capturando los resultados
                                                                           try
                                                                           {
                                                                                //rangoProveedor
                                                                               if (detailAl.GetString("LIFNR").Length > 0)
                                                                               {
                                                                                   #region Extrayendo la informacion de la Sociedad
                                                                                   datos.Add(new KeyValuePair<string, string>("LIFNR", detailAl.GetString("LIFNR")));
                                                                                   datos.Add(new KeyValuePair<string, string>("BUKRS", detailAl.GetString("BUKRS")));
                                                                                   datos.Add(new KeyValuePair<string, string>("BUTXT", detailAl.GetString("BUTXT")));
                                                                                   datos.Add(new KeyValuePair<string, string>("LAND1", detailAl.GetString("LAND1")));
                                                                                   datos.Add(new KeyValuePair<string, string>("NAME1", detailAl.GetString("NAME1")));
                                                                                   datos.Add(new KeyValuePair<string, string>("ADRNR", detailAl.GetString("ADRNR")));
                                                                                   datos.Add(new KeyValuePair<string, string>("KTOKK", detailAl.GetString("KTOKK")));
                                                                                   datos.Add(new KeyValuePair<string, string>("LOEVM", detailAl.GetString("LOEVM")));
                                                                                   datos.Add(new KeyValuePair<string, string>("STCD1", detailAl.GetString("STCD1")));
                                                                                   datos.Add(new KeyValuePair<string, string>("XCPDK", detailAl.GetString("XCPDK")));
                                                                                   datos.Add(new KeyValuePair<string, string>("STCD3", detailAl.GetString("XCPDK")));
                                                                                   datos.Add(new KeyValuePair<string, string>("BUTXT", detailAl.GetString("BUTXT")));
                                                                                    #region Extrae el RFC
                                                                                    try
                                                                                    {
                                                                                        datos.Add(new KeyValuePair<string, string>("RFCSO", detailAl.GetString("RFCSO")));//RFC del Proveedor
                                                                                    }
                                                                                    catch(Exception _rfc)
                                                                                    {
                                                                                        try
                                                                                        {
                                                                                            datos.Add(new KeyValuePair<string, string>("RFCSO", detailAl.GetString("RFCBK")));
                                                                                        }
                                                                                        catch
                                                                                        {
                                                                                            datos.Add(new KeyValuePair<string, string>("RFCSO", "No en SAP"));
                                                                                        }
                                                                                    }
                                                                                    #endregion Extrae el RFC
                                                                                    #endregion Extrayendo la informacion de la Sociedad
                                                                                }
                                                                            }
                                                                           catch (Exception _e)
                                                                           {
                                                                               #region       Recuperando errores
                                                                               //try
                                                                               //{
                                                                               //    #region Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                                                               //    //###########################################################################
                                                                               //    //Estas son las estructuras en las que se devuelven excepciones disparadas en SAP
                                                                               //    //###########################################################################

                                                                               //    #endregion Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                                                                               //}
                                                                               //catch (Exception e)
                                                                               //{
                                                                               #region Llenando datos de repuesta NEGATIVA
                                                                               datos.Add(new KeyValuePair<string, string>("LIFNR", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("BUKRS", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("BUTXT", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("LAND1", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("NAME1", "Error " + _e.Message));
                                                                               datos.Add(new KeyValuePair<string, string>("ADRNR", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("KTOKK", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("LOEVM", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("STCD1", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("XCPDK", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("STCD3", "No localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("BUTXT", "Proveedor no localizado"));
                                                                               datos.Add(new KeyValuePair<string, string>("RFCSO", "No localizado"));
                                                                               #endregion Llenando datos de repuesta NEGATIVA
                                                                               //}
                                                                               #endregion Recuperando errores
                                                                           }
                                                                #endregion capturando Resultados
                                                    }
                                       }
                                       else
                                       {
                                            //No recupero nada
                                            datos.Add(new KeyValuePair<string, string>("Error", "No se encontro níngun proveedor en SAP"));
                                        }
                               #endregion Configuración todos los Proveedores Tipo=3
                               break;
                           }
                }
                catch(Exception _ex)
                {
                     #region Llenando datos de repuesta NEGATIVA
                    datos.Add(new KeyValuePair<string, string>("LIFNR", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("BUKRS", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("BUTXT", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("LAND1", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("NAME1", "Error " + _ex.Message));
                    datos.Add(new KeyValuePair<string, string>("ADRNR", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("KTOKK", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("LOEVM", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("STCD1", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("XCPDK", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("STCD3", "No localizado"));
                    datos.Add(new KeyValuePair<string, string>("BUTXT", "Proveedor no localizado"));
                    datos.Add(new KeyValuePair<string, string>("RFCSO", "No localizado"));
                    #endregion Llenando datos de repuesta NEGATIVA
                }
            }
           return datos;
       }


       #endregion FUNCIONES Z

       #region Variables

       private string _destinationName;
        private RfcDestination _destination;
        private IRfcFunction _function;

        #endregion Variables

        #region Constructors

        //public SAPConnection(string destinationName)
        //{
        //    _destinationName = destinationName;

        //    _config = new SAPConfiguration();

        //    RfcDestinationManager.RegisterDestinationConfiguration(_config);

        //    _config.AddOrEditDestination(_destinationName,
        //        UserName,
        //        Password,
        //        Language,
        //        Client,
        //        ApplicationServer,
        //        SystemNumber);
        //    _destination = RfcDestinationManager.GetDestination(_destinationName);
        //}

        #endregion Constructors
        
        #region Execute Methods
                public MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult ExecuteInsert(string functionName, List<MVC5_full_version.Clases.Conector_SAPNET_3.DTO.NTable> parameters, List<string> tableNames)
                {
                    try
                    {
                        SAP.Middleware.Connector.RfcDestination conector = GetRfcDestination;
                        _function = conector.Repository.CreateFunction(functionName);

                        for (int i = 0; i < tableNames.Count; i++)
                        {
                            RfcStructureMetadata metaData = conector.Repository.GetStructureMetadata(parameters[i].StructureName);

                            IRfcTable tblInput = _function.GetTable(tableNames[i]);

                            foreach (System.Data.DataRow row in parameters[i].Parameters.Rows)
                            {
                                IRfcStructure structRow = metaData.CreateStructure();

                                foreach (System.Data.DataColumn column in parameters[i].Parameters.Columns)
                                {
                                    object obj = row[column];
                                    structRow.SetValue(column.ToString(), obj);
                                }

                                tblInput.Append(structRow);
                            }
                        }

                        RfcSessionManager.BeginContext(conector);
                        _function.Invoke(conector);

                        IRfcTable returnTable = _function.GetTable("NOTESRETURN");

                        return new MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult
                        {
                            IsSuccess = true,
                            Data = new List<object> { returnTable }
                        };
                    }
                    catch (Exception ex)
                    {
                        return new MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult
                        {
                            IsSuccess = false,
                            ErrorMessage = ex.ToString()
                        };
                    }
                }
                public MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult ExecuteSelect(string functionName, List<MVC5_full_version.Clases.Conector_SAPNET_3.DTO.NParameter> parameters, List<string> tableNames)
                {
                    try
                    {
                        SAP.Middleware.Connector.RfcDestination _destination = csBaseSAPNET.GetRfcDestination;
                        _function = _destination.Repository.CreateFunction(functionName);

                        foreach (MVC5_full_version.Clases.Conector_SAPNET_3.DTO.NParameter param in parameters)
                            _function.SetValue(param.Name, param.Value);

                        _function.Invoke(_destination);

                        List<object> tables = tableNames.Select(table => _function.GetTable(table)).Cast<object>().ToList();

                        return new MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult()
                        {
                            IsSuccess = true,
                            Data = tables
                        };
                    }
                    catch (Exception ex)
                    {
                        return new MVC5_full_version.Clases.Conector_SAPNET_3.DTO.FunctionResult
                        {
                            IsSuccess = false,
                            ErrorMessage = ex.ToString()
                        };
                    }
                }

                public void actualizaParametros(ClickFactura_Entidades.BD.Entidades.configuracionConexionSAPModel obj)
                {
                    List<ClickFactura_Entidades.BD.Entidades.T_Parametros> t_parametros = new List<T_Parametros>();//Instanciando laEstructura para acceso a LINQ
                    ClickFactura_Entidades.BD.Entidades.T_Parametros parametro = new T_Parametros();
                    ClickFactura_Entidades.BD.Entidades.T_Parametros BD=new T_Parametros();                                             //Instanciando la tabla para acceso directo a los campos - valor
                    #region Pasa valores del obj al T_Parametros
                    
                    #endregion Pasa valores del obj al T_Parametros
                    

                    Desarrollo_CF Contexto = new Desarrollo_CF();
                    try
                    {
                         Desarrollo_CF contexto = new Desarrollo_CF();
                         using (contexto)
                         {
                              #region fijando los nuevos valores
                             //var nombre = (from reg in t_parametros where reg.descParametro.Equals("Name") == true select reg).First();
                             //nombre.valorParametro = obj.Name;
                             //var usuario = (from reg in t_parametros where reg.descParametro.Equals("User") == true select reg).First();
                             //usuario.valorParametro = obj.User;
                             //var password = (from reg in t_parametros where reg.descParametro.Equals("Password") == true select reg).First();
                             //password.valorParametro = obj.Password;
                             //var cliente = (from reg in t_parametros where reg.descParametro.Equals("Client") == true select reg).First();
                             //cliente.valorParametro = obj.Client;
                             //var lenguaje = (from reg in t_parametros where reg.descParametro.Equals("Language") == true select reg).First();
                             //lenguaje.valorParametro = obj.Language;
                             //var nosistema = (from reg in t_parametros where reg.descParametro.Equals("SystemNumber") == true select reg).First();
                             //nosistema.valorParametro = obj.SystemNumber;
                             //var ip = (from reg in t_parametros where reg.descParametro.Equals("AppServerHost") == true select reg).First();
                             //ip.valorParametro = obj.AppServerHost;
                             //var maxpool = (from reg in t_parametros where reg.descParametro.Equals("MaxPoolSize") == true select reg).First();
                             //maxpool.valorParametro = obj.MaxPoolSize;
                             //var idle = (from reg in t_parametros where reg.descParametro.Equals("IdleTimeOut") == true select reg).First();
                             //idle.valorParametro = obj.IdleTimeOut;
                                #endregion fijando los nuevos valores
                             string[] campos = { "AppServerHost", "User", "Password", "Client", "Language", "SystemNumber", "MaxPoolSize", "IdleTimeout", "Name", "SystemID", "MessageServerHost","LogonGroup","GateWayHost","AppServerService","MessageServerService","GateWayService" };                             
                             #region        Pasando los valores
                             foreach(string campo in campos)
                             {
                                 try
                                 {
                                    string consulta = "";
                                    if(campo.Equals("Name")==true)
                                           consulta = "Update T_Parametros Set valorParametro = '" + obj.Name + "' Where descParametro='"+campo+"' ";
                                    if (campo.Equals("AppServerHost") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.AppServerHost + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("MessageServerHost") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.MessageServerHost + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("User") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.User + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("Password") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.Password + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("Client") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.Client + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("Language") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.Language + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("SystemNumber") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.SystemNumber + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("MaxPoolSize") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.MaxPoolSize + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("IdleTimeout") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.IdleTimeOut + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("SystemID") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.SystemNumber + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("LogonGroup") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.LogonGroup + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("GateWayHost") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.GateWayHost + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("MessageServerService") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.MessageServerService + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("AppServerService") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.AppServerService + "' Where descParametro='" + campo + "'";
                                    if (campo.Equals("GateWayService") == true)
                                        consulta = "Update T_Parametros Set valorParametro = '" + obj.GateWayService + "' Where descParametro='" + campo + "'";
                                    Service.Service1 servicio = new Service.Service1();
                                    System.Data.DataTable t=  servicio.genericos_consultaCualquierTabla(consulta);
                                 }
                                 catch(Exception ex)
                                 {
                                     string error = ex.Message;
                                 }
                             }
                             //var nombre = (from reg in t_parametros where reg.descParametro.Equals("Name") == true select reg).First();
                             //nombre.valorParametro = obj.Name;
                             //var usuario = (from reg in t_parametros where reg.descParametro.Equals("User") == true select reg).First();
                             //usuario.valorParametro = obj.User;
                             //var password = (from reg in t_parametros where reg.descParametro.Equals("Password") == true select reg).First();
                             //password.valorParametro = obj.Password;
                             //var cliente = (from reg in t_parametros where reg.descParametro.Equals("Client") == true select reg).First();
                             //cliente.valorParametro = obj.Client;
                             //var lenguaje = (from reg in t_parametros where reg.descParametro.Equals("Language") == true select reg).First();
                             //lenguaje.valorParametro = obj.Language;
                             //var nosistema = (from reg in t_parametros where reg.descParametro.Equals("SystemNumber") == true select reg).First();
                             //nosistema.valorParametro = obj.SystemNumber;
                             //var ip = (from reg in t_parametros where reg.descParametro.Equals("AppServerHost") == true select reg).First();
                             //ip.valorParametro = obj.AppServerHost;
                             //var maxpool = (from reg in t_parametros where reg.descParametro.Equals("MaxPoolSize") == true select reg).First();
                             //maxpool.valorParametro = obj.MaxPoolSize;
                             //var idle = (from reg in t_parametros where reg.descParametro.Equals("IdleTimeOut") == true select reg).First();
                             //idle.valorParametro = obj.IdleTimeOut;
                             #endregion Pasando lo valores
                             contexto.SaveChanges();
                        }
                    }
                    catch (Exception ex)
                    {
                        //Genericos.ad_T_BitacoraOperaciones bb = new Genericos.ad_T_BitacoraOperaciones();
                        //Genericos.objBitacora obje = new Genericos.objBitacora();
                        //obje.IdBitacora = 0;
                        //obje.Descripcion = "Error actualizando en Parametros " + ex.Message + ", " + ex.InnerException;
                        //obje.Fecha = DateTime.Now;
                        //obje.Operacion = "Problema actualizando parametros configuración SAP";
                        //obje.Usuario = "Administrador";
                        //bb.registrarBitacora(obje);
                    }
                }

       #endregion Execute Methods

       #region      Estructuras PO_HEADER

                public Dictionary<KeyValuePair<string,string>, int> estructura_PO_HEADER()
                {
                    Dictionary<KeyValuePair<string, string>, int> campos = new Dictionary<KeyValuePair<string, string>, int>();
                    campos.Add(new KeyValuePair<string, string>("Número del documento de compras", "PO_NUMBER"), 0);
                    campos.Add(new KeyValuePair<string, string>("Tipo de documento de compras", "DOC_CAT"), 1);
                    campos.Add(new KeyValuePair<string, string>("Clase de documento de compras", "DOC_TYPE"), 1);
                    campos.Add(new KeyValuePair<string, string>("Fecha de creación del registro", "CREATED_ON"), 1);
                    campos.Add(new KeyValuePair<string, string>("Número de cuenta del proveedor", "VENDOR"), 1);
                    campos.Add(new KeyValuePair<string, string>("Sociedad", "CO_CODE"), 1);
                    campos.Add(new KeyValuePair<string, string>("Clave moneda", "CURRENCY"), 1);
                    campos.Add(new KeyValuePair<string, string>("Tipo de cambio cotizado diariamente", "EXCH_RATE"), 1);
                    campos.Add(new KeyValuePair<string, string>("Intervalo de posición", "ITEM_INTVL"), 1);
                    campos.Add(new KeyValuePair<string, string>("Indicador de borrado en el documento de compras", "DELETE_IND"), 1);
                    campos.Add(new KeyValuePair<string, string>("Clave de condiciones de pago", "PMNTTRMS"), 1);
                    campos.Add(new KeyValuePair<string, string>("Organización de compras", "PURCH_ORG"), 1);
                    campos.Add(new KeyValuePair<string, string>("Número de la condición de documento", "DOC_COND"), 1);
                    campos.Add(new KeyValuePair<string, string>("Grupo de compras", "PUR_GROUP"), 1);
                    campos.Add(new KeyValuePair<string, string>("Referencia", "REF_1"), 1);
                    return campos;
                }

                public Dictionary<KeyValuePair<string, string>, string> estructura_PO_HEADER_SQLServer()
                {
                    Dictionary<KeyValuePair<string, string>, string> campos = new Dictionary<KeyValuePair<string, string>, string>();
                    campos.Add(new KeyValuePair<string, string>("OrdCompra", "PO_NUMBER"), "");
                    campos.Add(new KeyValuePair<string, string>("", "DOC_CAT"), "");
                    campos.Add(new KeyValuePair<string, string>("", "DOC_TYPE"), "");
                    campos.Add(new KeyValuePair<string, string>("", "CREATED_ON"), "");
                    campos.Add(new KeyValuePair<string, string>("", "VENDOR"), "");
                    campos.Add(new KeyValuePair<string, string>("", "CO_CODE"), "");
                    campos.Add(new KeyValuePair<string, string>("", "CURRENCY"), "");
                    campos.Add(new KeyValuePair<string, string>("", "EXCH_RATE"), "");
                    campos.Add(new KeyValuePair<string, string>("", "ITEM_INTVL"), "");
                    campos.Add(new KeyValuePair<string, string>("", "DELETE_IND"), "");
                    campos.Add(new KeyValuePair<string, string>("", "PMNTTRMS"), "");
                    campos.Add(new KeyValuePair<string, string>("", "PURCH_ORG"), "");
                    campos.Add(new KeyValuePair<string, string>("", "DOC_COND"), "");
                    campos.Add(new KeyValuePair<string, string>("", "PUR_GROUP"), "");
                    campos.Add(new KeyValuePair<string, string>("", "REF_1"), "");
                    return campos;
                }

                #endregion Estructura PO_HEADER

       #region      Estructuras PO_ITEMS

        /// <summary>
        /// Clase que mapea el campo SAP obtenido de la BAPI PO_ITEMS e indica en que posición del array se encuentra para obtener su valor
        /// </summary>
        /// <returns>Estructura Dictionary<KeyValuePair<string, string>, int>  que son el repositorio de la información obtenida directo de la BAPI PO_ITEMS </returns>
                public Dictionary<KeyValuePair<string, string>, int> estructura_PO_ITEMS()
                {
                    Dictionary<KeyValuePair<string, string>, int> campos = new Dictionary<KeyValuePair<string, string>, int>();
                    campos.Add(new KeyValuePair<string, string>("Número del documento de compras", "PO_NUMBER"), 0);
                    campos.Add(new KeyValuePair<string, string>("Número de posición del documento de compras", "PO_ITEM"), 1);
                    campos.Add(new KeyValuePair<string, string>("Cantidad", "QUANTITY"), 16);
                    campos.Add(new KeyValuePair<string, string>("Importe", "NET_PRICE"), 23);
                    campos.Add(new KeyValuePair<string, string>("Texto breve", "SHORT_TEXT"), 5);
                    campos.Add(new KeyValuePair<string, string>("Indicador de borrado en el documento de compras", "DELETE_IND"), 2);
                    campos.Add(new KeyValuePair<string, string>("Número de material", "MATERIAL"), 6);
                    campos.Add(new KeyValuePair<string, string>("Centro-Sociedad", "PLANT"), 9);
                    campos.Add(new KeyValuePair<string, string>("Almacén", "STORE_LOC"), 10);
                    campos.Add(new KeyValuePair<string, string>("Número de necesidad", "TRACKINGNO"), 11);
                    campos.Add(new KeyValuePair<string, string>("Gripo de articulos", "MAT_GRP"), 12);
                    campos.Add(new KeyValuePair<string, string>("Número del registro info de compras", "INFO_REC"), 13);
                    campos.Add(new KeyValuePair<string, string>("Unidad de medida de pedido", "UNIT"), 17);
                    campos.Add(new KeyValuePair<string, string>("Cantidad base", "PRICE_UNIT"), 24);
                    campos.Add(new KeyValuePair<string, string>("Indicador IVA", "TAX_CODE"), 29);
                    campos.Add(new KeyValuePair<string, string>("Clase de valoración", "VAL_TYPE"), 42);
                    campos.Add(new KeyValuePair<string, string>("Tipo de posición del documento de compras", "ITEM_CAT"), 48);
                    campos.Add(new KeyValuePair<string, string>("Tipo de imputación", "ACCTASSCAT"), 49);
                    return campos;
                }

        /// <summary>
        /// Clase que establece a que campo del las tablas SQL Sever corresponde cada campo SAP obtenido de la BAPI
        /// </summary>
        public class estructura_SAP_SQLServer
                {
                    public string Campo_SQLServer { get; set; }
                    public string Campo_SAP { get; set; }
                    public string Valor { get; set; }
                }


        /// <summary>
        /// Estructura base  List<estructura_SAP_SQLServer> que crea 1 renglón equivalente entre SAP-SQL Server para almacenar 1 renglon como en la base de datos SQL Server
        /// </summary>
        /// <returns>Estructura List<estructura_SAP_SQLServer> equivalente a un renglon de la base de datos Detalle_OrdenCompra</returns>
              public List<estructura_SAP_SQLServer> renglon_PO_ITEMS_SQLServer()
                {
                  List<estructura_SAP_SQLServer> campos=new List<estructura_SAP_SQLServer>();


                  for (int i = 0; i <= 17; i++)
                  {
                     estructura_SAP_SQLServer campo=new csBaseSAPNET.estructura_SAP_SQLServer();
                      switch (i)
                      {
                          case 0:
                          campo.Campo_SQLServer = "Orden_Compra";
                          campo.Campo_SAP = "PO_NUMBER";
                          campo.Valor = "";
                          break;
                          case 1:
                          campo.Campo_SQLServer = "Posicion_OC";
                          campo.Campo_SAP = "PO_ITEM";
                          campo.Valor = "";
                          break;
                          case 2:
                          campo.Campo_SQLServer = "Cantidad";
                          campo.Campo_SAP = "QUANTITY";
                          campo.Valor = "";
                          break;
                          case 3:
                          campo.Campo_SQLServer = "Importe";
                          campo.Campo_SAP = "NET_PRICE";
                          campo.Valor = "";
                          break;
                          case 4:
                          campo.Campo_SQLServer = "Descripcion";
                          campo.Campo_SAP = "SHORT_TEXT";
                          campo.Valor = "";
                          break;
                          case 5:
                          campo.Campo_SQLServer = "Borrado";
                          campo.Campo_SAP = "DELETE_IND";
                          campo.Valor = "";
                          break;
                          case 6:
                          campo.Campo_SQLServer = "Numero_Material";
                          campo.Campo_SAP = "MATERIAL";
                          campo.Valor = "";
                          break;
                          case 7:
                          campo.Campo_SQLServer = "Planta";
                          campo.Campo_SAP = "PLANT";
                          campo.Valor = "";
                          break;
                          case 8:
                          campo.Campo_SQLServer = "Almacen";
                          campo.Campo_SAP = "STORE_LOC";
                          campo.Valor = "";
                          break;
                          case 9:
                          campo.Campo_SQLServer = "Numero_Necesidad";
                          campo.Campo_SAP = "TRACKINGNO";
                          campo.Valor = "";
                          break;
                          case 10:
                          campo.Campo_SQLServer = "Grupo_Articulos";
                          campo.Campo_SAP = "MAT_GRP";
                          campo.Valor = "";
                          break;
                          case 11:
                          campo.Campo_SQLServer = "Numero_Compras";
                          campo.Campo_SAP = "INFO_REC";
                          campo.Valor = "";
                          break;
                          case 12:
                          campo.Campo_SQLServer = "Unidad_Medida";
                          campo.Campo_SAP = "UNIT";
                          campo.Valor = "";
                          break;
                          case 13:
                          campo.Campo_SQLServer = "Cantidad_Base";
                          campo.Campo_SAP = "PRICE_UNIT";
                          campo.Valor = "";
                          break;
                          case 14:
                          campo.Campo_SQLServer = "Indicador_IVA";
                          campo.Campo_SAP = "TAX_CODE";
                          campo.Valor = "";
                          break;
                          case 15:
                          campo.Campo_SQLServer = "Clase_Valoracion";
                          campo.Campo_SAP = "VAL_TYPE";
                          campo.Valor = "";
                          break;
                          case 16:
                          campo.Campo_SQLServer = "Tipo_OC";
                          campo.Campo_SAP = "ITEM_CAT";
                          campo.Valor = "";
                          break;
                          case 17:
                          campo.Campo_SQLServer = "Tipo_Imputacion";
                          campo.Campo_SAP = "ACCTASSCAT";
                          campo.Valor = "";
                          break;
                      }
                          campos.Add(campo);
                  }


                  return campos;
                }

                #endregion Estructura PO_ITEMS

       #region      Estructuras PO_ITEM_HISTORY

              /// <summary>
              /// Clase que mapea el campo SAP obtenido de la BAPI PO_ITEM_HISTORY e indica en que posición del array se encuentra para obtener su valor
              /// </summary>
              /// <returns>Estructura Dictionary<KeyValuePair<string, string>, int>  que son el repositorio de la información obtenida directo de la BAPI PO_ITEM_HISTORY </returns>
              public Dictionary<KeyValuePair<string, string>, int> estructura_PO_ITEM_HISTORY()
              {
                  Dictionary<KeyValuePair<string, string>, int> campos = new Dictionary<KeyValuePair<string, string>, int>();
                  campos.Add(new KeyValuePair<string, string>("Número de posición del documento de compras", "PO_ITEM"), 0);
                  campos.Add(new KeyValuePair<string, string>("Número actual de la imputación", "SERIAL_NO"), 1);
                  campos.Add(new KeyValuePair<string, string>("Historial pedido de clase operación", "PROCESS_ID"), 2);
                  campos.Add(new KeyValuePair<string, string>("Ejercicio del documento de material", "DOC_YEAR"), 3);
                  campos.Add(new KeyValuePair<string, string>("Número de documento material", "MAT_DOC"), 4);
                  campos.Add(new KeyValuePair<string, string>("Posición en documento de material", "MATDOC_ITM"), 5);
                  campos.Add(new KeyValuePair<string, string>("Tipo de historial de pedido", "HIST_TYPE"), 6);
                  campos.Add(new KeyValuePair<string, string>("Clase de movimiento (gestión stocks)", "MOVE_TYPE"), 7);
                  campos.Add(new KeyValuePair<string, string>("Fecha de contabilización en el documento", "PSTNG_DATE"), 8);
                  campos.Add(new KeyValuePair<string, string>("Cantidad", "QUANTITY"),9); //"MENGE_D"), 9);//Quizás debiera ser QUANTITY
                  campos.Add(new KeyValuePair<string, string>("Importe en moneda local", "VAL_LOCCUR"), 10);
                  campos.Add(new KeyValuePair<string, string>("Importe en moneda doc.", "VAL_FORCUR"), 11);
                  campos.Add(new KeyValuePair<string, string>("Clave de moneda", "CURRENCY"), 12);
                  campos.Add(new KeyValuePair<string, string>("Indicador debe/haber", "DB_CR_IND"), 16);
                  campos.Add(new KeyValuePair<string, string>("Ejercicio de un documento de referencia", "REF_DOC_YR"), 20);
                  campos.Add(new KeyValuePair<string, string>("Número de documento de un doc.de referencia", "REF_DOC"), 21);
                  campos.Add(new KeyValuePair<string, string>("Posición de un documento de referencia", "REF_DOC_IT"), 22);
                  return campos;
              }

              ///// <summary>
              ///// Clase que establece a que campo del las tablas SQL Sever corresponde cada campo SAP obtenido de la BAPI
              ///// </summary>
              //public class estructura_SAP_SQLServer
              //{
              //    public string Campo_SQLServer { get; set; }
              //    public string Campo_SAP { get; set; }
              //    public string Valor { get; set; }
              //}


              /// <summary>
              /// Estructura base  List<estructura_SAP_SQLServer> que crea 1 renglón equivalente entre SAP-SQL Server para almacenar 1 renglon como en la base de datos SQL Server
              /// </summary>
              /// <returns>Estructura List<estructura_SAP_SQLServer> equivalente a un renglon de la base de datos Detalle_Recepciones</returns>
              public List<estructura_SAP_SQLServer> renglon_PO_ITEM_HISTORY_SQLServer()
              {
                  List<estructura_SAP_SQLServer> campos = new List<estructura_SAP_SQLServer>();


                  for (int i = 0; i <= 16; i++)
                  {
                      estructura_SAP_SQLServer campo = new csBaseSAPNET.estructura_SAP_SQLServer();
                      switch (i)
                      {
                          case 0:
                              campo.Campo_SQLServer = "Posicion_OrdenCompra";
                              campo.Campo_SAP = "PO_ITEM";
                              campo.Valor = "";
                              break;
                          case 1:
                              campo.Campo_SQLServer = "Numero_ActualImput";
                              campo.Campo_SAP = "SERIAL_NO";
                              campo.Valor = "";
                              break;
                          case 2:
                              campo.Campo_SQLServer = "Clase_operacion";
                              campo.Campo_SAP = "PROCESS_ID";
                              campo.Valor = "";
                              break;
                          case 3:
                              campo.Campo_SQLServer = "YearDocumento";
                              campo.Campo_SAP = "DOC_YEAR";
                              campo.Valor = "";
                              break;
                          case 4:
                              campo.Campo_SQLServer = "Numero_Documento";
                              campo.Campo_SAP = "MAT_DOC";
                              campo.Valor = "";
                              break;
                          case 5:
                              campo.Campo_SQLServer = "Posicion_Documento";
                              campo.Campo_SAP = "MATDOC_ITM";
                              campo.Valor = "";
                              break;
                          case 6:
                              campo.Campo_SQLServer = "Tipo_Movimiento";
                              campo.Campo_SAP = "HIST_TYPE";
                              campo.Valor = "";
                              break;
                          case 7:
                              campo.Campo_SQLServer = "Clave_Movimiento";
                              campo.Campo_SAP = "MOVE_TYPE";
                              campo.Valor = "";
                              break;
                          case 8:
                              campo.Campo_SQLServer = "Fecha_Contable";
                              campo.Campo_SAP = "PSTNG_DATE";
                              campo.Valor = "";
                              break;
                          case 9:
                              campo.Campo_SQLServer = "Cantidad";
                              campo.Campo_SAP = "QUANTITY";//"MENGE_D";
                              campo.Valor = "";
                              break;
                          case 10:
                              campo.Campo_SQLServer = "Importe_Local";
                              campo.Campo_SAP = "VAL_LOCCUR";
                              campo.Valor = "";
                              break;
                          case 11:
                              campo.Campo_SQLServer = "Importe_Documento";
                              campo.Campo_SAP = "VAL_FORCUR";
                              campo.Valor = "";
                              break;
                          case 12:
                              campo.Campo_SQLServer = "Moneda";
                              campo.Campo_SAP = "CURRENCY";
                              campo.Valor = "";
                              break;
                          case 13:
                              campo.Campo_SQLServer = "IndicadorHD";
                              campo.Campo_SAP = "DB_CR_IND";
                              campo.Valor = "";
                              break;
                          case 14:
                              campo.Campo_SQLServer = "YearDocumentoRef";
                              campo.Campo_SAP = "REF_DOC_YR";
                              campo.Valor = "";
                              break;
                          case 15:
                              campo.Campo_SQLServer = "Documento_Referencia";
                              campo.Campo_SAP = "REF_DOC";
                              campo.Valor = "";
                              break;
                          case 16:
                              campo.Campo_SQLServer = "Posicion_DocumentoRef";
                              campo.Campo_SAP = "REF_DOC_IT";
                              campo.Valor = "";
                              break;
                      }
                      campos.Add(campo);
                  }


                  return campos;
              }

              #endregion Estructura PO_ITEM_HISTORY

       #region Metodos auxiliares varios

        public  string convierteFormatoSAP(DateTime fecha, string tipo)
         {
             string convertida = "";
             string año = fecha.Year.ToString();
             string mes = "";
            if(fecha.Month>=10)
                  mes = fecha.Month.ToString();
            else
                mes = "0" + fecha.Month.ToString();
            string dia = "";
           if(fecha.Day>=10)
                  dia = fecha.Day.ToString();
            else
                  dia = "0"+ fecha.Day.ToString();
             string hora = fecha.Hour.ToString();
             string minutos = fecha.Minute.ToString();
             string segundos = fecha.Second.ToString();

             if (tipo.Equals("BAPI_INCOMINGINVOICE_CREATE") == true)
            {
                //Formato ejemplo "20170721"
                convertida = año + mes + dia;
            }
            if (tipo.Equals("BAPI_GOODSMVT_CREATE") == true)
            {
                //Formato ejemplo "20170721"
                convertida = año + mes + dia;
            }

             return convertida;
         }

        public bool aplicar_COMMIT_BAPI_MIRO()
        {
            bool aplicar=false;
                       #region Buscando importe de Prorrateo Directo maximo permitido
                      int result = 0;
                      ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros adp = new ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros();
                      List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros> objp = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros>();
                      //Busca cantidad de prorrateo Directo permitido
                      Boolean rangoDirecto = false;
                      objp = adp.mABCT_Parametros(out result, 0, "Commit_BAPI_MIRO", "Vacio", true, "ConsultaValor");
                      {
                          string valor = objp[0].ValorParametro.ToString();
                          rangoDirecto = valor=="0"?false:true;
                      }
                      aplicar = rangoDirecto != null ? rangoDirecto : false;
                      #endregion Buscando importe de Prorrateo Directo maximo permitido
                      return aplicar;
        }

        public bool aplicar_COMMIT_BAPI_MIGO()
        {
            bool aplicar = false;
            #region Buscando importe de Prorrateo Directo maximo permitido
            int result = 0;
            ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros adp = new ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros();
            List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros> objp = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros>();
            //Busca cantidad de prorrateo Directo permitido
            Boolean rangoDirecto = false;
            objp = adp.mABCT_Parametros(out result, 0, "Commit_BAPI_MIGO", "Vacio", true, "ConsultaValor");
            {
                string valor = objp[0].ValorParametro.ToString();
                rangoDirecto = valor == "0" ? false : true;
            }
            aplicar = rangoDirecto != null ? rangoDirecto : false;
            #endregion Buscando importe de Prorrateo Directo maximo permitido
            return aplicar;
        }

        #endregion Metodos auxiliares varios

        #region Crear Funciones SAP-NET
        private static IRfcFunction crearFuncionRfc(RfcDestination conector, string nombre, bool param = false, Dictionary<string, object> valores = null)
        {
            if (param)
            {
                var com = conector.Repository.CreateFunction(nombre);
                if (valores != null)
                {
                    foreach (var item in valores)
                    {
                        if (item.Value.GetType().Equals(typeof(string)))
                        {
                            if (item.Key.Contains("DATE"))
                            {
                                var aFecha = item.Value.ToString().Split('.');
                                com.SetValue(item.Key, aFecha[2] + "" + aFecha[1] + "" + aFecha[0]);
                            }
                            else
                                com.SetValue(item.Key, item.Value);
                        }
                        else if (item.Value.GetType().Equals(typeof(Dictionary<string, object>)))
                        {
                            var estructura = crearEstructura(com, item.Key, (Dictionary<string, object>)item.Value);
                            com.SetValue(item.Key, estructura);
                        }
                    }
                }
                else
                {

                }
                return com;
            }
            return conector.Repository.CreateFunction(nombre);
        }
        private static IRfcStructure crearEstructura(IRfcFunction funcion, string nombre, Dictionary<string, object> valores)
        {
            IRfcStructure header = funcion.GetStructure(nombre);
            foreach (var item in valores)
            {
                if (item.Key.Contains("DATE"))
                {
                    var aFecha = item.Value.ToString().Split('.');
                    header.SetValue(item.Key, aFecha[2] + "" + aFecha[1] + "" + aFecha[0]);
                }
                else
                    header.SetValue(item.Key, item.Value);
            }
            return header;
        }
        private static Dictionary<int, List<string>> consultarTablaRfc(IRfcFunction funcion, string nombreTabla, List<string> columnas)
        {
            IRfcTable tabla = funcion.GetTable(nombreTabla);

            var tablaResultado = new Dictionary<int, List<string>>();
            if (tabla.RowCount > 0)
            {
                for (int i = 0; i < tabla.RowCount; i++)
                {
                    var dato = new List<string>();
                    foreach (var col in columnas)
                    {
                        dato.Add(tabla[i].GetString(col));
                    }
                    tablaResultado.Add(i + 1, dato);
                }
            }
            else
            {
                try
                {
                    #region Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                    IRfcStructure estructura = funcion.GetStructure("RETURN");
                    string strReturnType = funcion.GetStructure("RETURN").GetString("TYPE");
                    string strReturnID = funcion.GetStructure("RETURN").GetString("CODE");
                    string strReturnMessage = funcion.GetStructure("RETURN").GetString("MESSAGE");
                    string strLogNo = funcion.GetStructure("RETURN").GetString("LOG_NO");
                    string strLogMsg = funcion.GetStructure("RETURN").GetString("LOG_MSG_NO");
                    string strReturnMessage1 = funcion.GetStructure("RETURN").GetString("MESSAGE_V1");
                    string strReturnMessage2 = funcion.GetStructure("RETURN").GetString("MESSAGE_V2");
                    string strReturnMessage3 = funcion.GetStructure("RETURN").GetString("MESSAGE_V3");
                    string strReturnMessage4 = funcion.GetStructure("RETURN").GetString("MESSAGE_V4");
                    //datos.Add(new KeyValuePair<string, string>("Error", strReturnMessage));

                    #endregion Transacción falló, en las siguientes variables SAP vacia la exección que se haya generado desde allá
                }
                catch (Exception _ex)
                {
                    IRfcTable estructura = funcion.GetTable("RETURN");
                    string strReturnType = funcion.GetStructure("RETURN").GetString("TYPE");
                    string strReturnID = funcion.GetStructure("RETURN").GetString("CODE");
                    string strReturnMessage = funcion.GetStructure("RETURN").GetString("MESSAGE");
                    string strLogNo = funcion.GetStructure("RETURN").GetString("LOG_NO");
                    string strLogMsg = funcion.GetStructure("RETURN").GetString("LOG_MSG_NO");
                    string strReturnMessage1 = funcion.GetStructure("RETURN").GetString("MESSAGE_V1");
                    string strReturnMessage2 = funcion.GetStructure("RETURN").GetString("MESSAGE_V2");
                    string strReturnMessage3 = funcion.GetStructure("RETURN").GetString("MESSAGE_V3");
                    string strReturnMessage4 = funcion.GetStructure("RETURN").GetString("MESSAGE_V4");
                }
            }
            return tablaResultado;
        }
        public static Dictionary<string, Dictionary<int, List<string>>> BAPI_CONSULTA(string nombreBAPI, Dictionary<string, object> parametros, List<TablaColumnasSAP> lsColumnasTablas)
        {
            Dictionary<string, Dictionary<int, List<string>>> tablas = new Dictionary<string, Dictionary<int, List<string>>>();
            RfcDestination conector = GetRfcDestination;
            try
            {
                if (conector.SystemID != null)
                {
                    IRfcFunction funcion = crearFuncionRfc(conector, nombreBAPI, true, parametros);
                    RfcSessionManager.BeginContext(conector);
                    funcion.Invoke(conector);
                    RfcSessionManager.EndContext(conector);

                    if (lsColumnasTablas != null && lsColumnasTablas.Count > 0)
                    {
                        foreach (var item in lsColumnasTablas)
                        {
                            var tab = consultarTablaRfc(funcion, item.nombreTabla, item.lsColumnas);
                            tablas.Add(item.nombreTabla, tab);
                        }
                    }
                    else
                    {
                        try
                        {
                            IRfcTable tabla = funcion.GetTable("RETURN");
                        }catch  (Exception ex)
                        {
                            IRfcStructure estr = funcion.GetStructure("RETURN");
                        }
                    }
                }
            }
            catch (RfcCommunicationException e)
            {
                string error1 = e.Message;
            }
            catch (RfcLogonException e)
            {
                // user could not logon...
                string error1 = e.Message;
            }
            catch (RfcAbapRuntimeException e)
            {
                // serious problem on ABAP system side...
                string error1 = e.Message;
            }
            catch (RfcAbapBaseException e)
            {
                // The function module returned an ABAP exception, an ABAP message
                // or an ABAP class-based exception...
                string error1 = e.Message;
            }
            catch (Exception ex)
            {
                string problema = ex.Message;
                RfcSessionManager.EndContext(conector); //End the transaction
            }
            return tablas;
        }

        #endregion

    }
    public struct TablaColumnasSAP
    {
        public string nombreTabla { get; set; }
        public List<string> lsColumnas { get; set; }
    }
}

namespace MVC5_full_version.Clases.Conector_SAPNET_3.DTO
{
    public class NTable
    {
        public string StructureName { get; set; }
        public System.Data.DataTable Parameters { get; set; }
    }
    public class NParameter
    {
        public string Name { get; set; }
        public string Value { get; set; }
    }
    public class NDestination
    {
        public string Name { get; set; }
        public RfcConfigParameters Parameters { get; set; }
    }
    public class FunctionResult
    {
        public bool IsSuccess { get; set; }

        public List<object> Data { get; set; }

        public string ErrorMessage { get; set; }
    }

}

