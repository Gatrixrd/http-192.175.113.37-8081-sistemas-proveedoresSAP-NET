﻿using ClickFactura_Entidades.BD.Modelos;
using ClickFactura_WebServiceCF.Conectores.Configuracion;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_WebServiceCF.Service.Clases.Monitoreo
{
    public class EstadoDeCuenta
    {
        private TablaGeneralModel configurarTablaCartera(string filtro, out string mensaje)
        {
            mensaje = "";
            try
            {
                /*
                 *                                  columns.Bound(p => p.R1).Title("<strong>Sociedad</strong>");
                                                    columns.Bound(p => p.R2).Title("<strong>Código proveedor</strong>").Width(80);
                                                    columns.Bound(p => p.R3).Title("<strong>Nom. proveedor</strong>").Width(350);
                                                    columns.Bound(p => p.R4).Title("<strong>Estatus</strong>").Width(100);
                                                    columns.Bound(p => p.R5).Title("<strong>No. factura</strong>").Width(180);
                                                    columns.Bound(p => p.R6).Title("<strong>Referencia</strong>").Width(300);
                                                    columns.Bound(p => p.R7).Title("<strong>Fecha Doc.</strong>").Width(120);
                                                    columns.Bound(p => p.R8).Title("<strong>Tipo Doc.</strong>").Width(100);
                                                    columns.Bound(p => p.R9).Format("{0:C}").Title("<strong>Importe MD</strong>").Width(130);
                                                    columns.Bound(p => p.R10).Format("{0:C}").Title("<strong>Importe ML</strong>").Width(130);
                                                    columns.Bound(p => p.R11).Title("<strong>Moneda</strong>").Width(90);
                                                    columns.Bound(p => p.R12).Title("<strong>Tipo cambio</strong>").Width(130);
                                                    columns.Bound(p => p.R13).Title("<strong>Vencimiento</strong>").Width(120);
                                                    columns.Bound(p => p.R14).Title("<strong>Día estim. pago</strong>").Width(120);
                                                    columns.Bound(p => p.R15).Title("<strong>Orden compra</strong>").Width(130);
                 */
                Dictionary<string, string> columnas = new Dictionary<string, string>();
                columnas.Add("Posicion_OrdenCompra", "Pos. OC");        //R1
                columnas.Add("Numero_Documento", "Documento Recepcion");//R2
                columnas.Add("Posicion_Documento", "Pos. Recep");       //R3
                columnas.Add("Tipo_Movimiento", "Tipo Movimiento");     //R4
                columnas.Add("Fecha_Contable", "Fecha");                //R5
                columnas.Add("Cantidad", "Cantidad");                   //R6
                columnas.Add("Importe_Documento", "Importe Documento"); //R7
                columnas.Add("Descripcion", "Descripción");             //R8
                columnas.Add("Indicador_IVA", "Ind. Impuesto");         //R9
                columnas.Add("Numero_Cancelacion", "Numero_Cancelacion");//R10
                columnas.Add("Unidad_Medida", "Unidad_Medida");         //R11
                columnas.Add("Numero_Pasivo", "Numero_Pasivo");            //R12
                columnas.Add("YearDocumento", "YearDocumento");         //R13
                columnas.Add("YearDocumentoRef", "YearDocumentoRef");   //R14
                columnas.Add("Posicion_DocumentoRef", "Posicion_DocumentoRef");//R15
                columnas.Add("Documento_Referencia", "Documento_Referencia");//R16
                columnas.Add("Importe", "Importe");                   //R17
                string[] template = { "", "", "", "", "", "", "#: kendo.format('{0:c}', R7) #", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" };
                bool[] filtros = { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
                bool[] ocultos = { false, false, false, false, false, false, false, false, false, true, true, true, true, true, true, true, true, false, false, false, false, false };

                string[] AnchoColumna = { "80px", "200px", "80px", "60px", "100px", "100px", "100px", "400px", "60px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px" };

                //string[] AnchoColumna = { "150px", "300px", "150px", "150px", "150px", "150px", "150px", "150px", "100px", "100px", "100px", "100px", "150px" };
                TablaGeneralModel tabla = new TablaGeneralModel();
                tabla.NombreGrid = "rg";
                tabla.Nuevo = false;
                tabla.Excel = true;
                tabla.Edicion = false;
                tabla.CeldaAccion = false;                
                tabla.NombreUpdate = "Actualizar";
                tabla.Control = "Monitoreo";
                tabla._Edicion = "onEdit";
                tabla._Guardar = "onSave";
                tabla.NombreExcel = "Cartera_" + DateTime.Now.ToShortDateString() + ".xlsx";
                int x = 1;

                List<string> parametros = new List<string>();
                parametros.Add(filtro);
                parametros.Add("Ordenes_de_Compra");
                var dTabla = new TablasDinamicasModel().EjecutarSP("Reportes_Generales", parametros, out mensaje);

                foreach (System.Data.DataColumn item in dTabla.Columns)
                {
                    tabla.Columnas.Add(new Columna()
                    {
                        Nombre = item.ColumnName,
                        Tipo = item.DataType,
                        oculto = item.ColumnName.Contains("Id") ? true : false,
                        Ancho = AnchoColumna[x - 1]
                    });
                    tabla.NombresModel.Add("R" + x);
                    x += 1;
                }

                foreach (System.Data.DataRow item in dTabla.Rows)
                {
                    List<object> reg = new List<object>();
                    foreach (var celda in item.ItemArray)
                    {
                        reg.Add(celda);
                    }
                    tabla.Registros.Add(new Registros().MapeaDatos(reg));
                }
                return tabla;
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
                return null;
            }
        }

        public TablaGeneralModel BuscarOC(List<object> parametros, out string mensaje)
        {
            try
            {
                var consulta = new TablaGeneralModel();
                mensaje = "";
                if (parametros != null)
                {
                    #region Cargar filtros
                    int x = 1;
                    List<string> param = new List<string>();
                    foreach (var item in parametros)
                    {
                        if (item != null)
                        {
                            string cadena = item.ToString();
                            switch (x)
                            {
                                case 1://Fecha inicial
                                    if (cadena != "")
                                    {
                                        param.Add("(CONVERT(Datetime, dbo.Detalle_Recepciones.Fecha_Contable, 103)>= CONVERT(DATETIME, '" + cadena + "', 103))");
                                    }
                                    break;
                                case 2://Fecha Final
                                    if (cadena != "")
                                    {
                                        param.Add("(CONVERT(Datetime, dbo.Detalle_Recepciones.Fecha_Contable, 103)<=CONVERT(DATETIME, '" + cadena + "', 103))");
                                    }
                                    break;
                                case 3://Orden de compra
                                    if (cadena != "")
                                    {
                                        param.Add("OrdenesCompra.OrdCompra like '%" + cadena + "%'");
                                    }
                                    break;
                                case 4://Recepciones
                                    if (cadena != "")
                                    {
                                        param.Add("Detalle_Recepciones.Numero_Documento like '%" + cadena + "%'");
                                    }
                                    break;
                                case 5://No Proveedor
                                    if (cadena != "")
                                    {
                                        param.Add("Cat_Proveedor.Num_Proveedor like '%" + cadena + "%'");
                                    }
                                    break;
                                case 6://RFC Proveedor
                                    if (cadena != "")
                                    {
                                        param.Add("Cat_Proveedor.RFC like '%" + cadena + "%'");
                                    }
                                    break;
                                case 7://No. sociedad
                                    if (cadena != "")
                                    {
                                        param.Add("OrdenesCompra.Num_Sociedad  like '%" + cadena + "%'");
                                    }
                                    break;
                                default:
                                    break;
                            }
                        }
                        x += 1;
                    }
                    string filterExp = " WHERE ";
                    for (int i = 0; i < param.Count; i++)
                    {
                        if (i == 0)
                        {
                            filterExp += param[i];
                        }
                        else
                        {
                            filterExp += " AND " + param[i];
                        }
                    }
                    #endregion Cargar filtros                    
                    consulta = configurarTablaCartera(filterExp, out mensaje);
                }
                else
                {
                    consulta = configurarTablaCartera("", out mensaje);
                }
                return consulta;
            }
            catch (Exception ex)
            {
                mensaje = ex.Message;
                return null;
            }
        }
        public static void consultarCartera(string sociedad = "6000", string proveedor = "100263", string fecha = "20.09.2017")
        {
            csBaseSAPNET obj = new csBaseSAPNET();
            Pasivo_Encabezado header = new Pasivo_Encabezado();
            ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos = new Pasivo_Detalle[0];

            var res =obj.BAPI_INCOMINGINVOICE_CREATE(csBaseSAPNET.GetRfcDestination, header, detallesPasivos);
            /////////////////////////////////////GET DETAIL//////////////////////////////////////////////////////////////////
            var tablaKey = new List<KeyValuePair<string, string>>();
            var tabla = obj.obtenOrdenCompraWeb("", ref tablaKey);
            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////


            //////////////////////////////////////////////ABIERTAS/////////////////////////////////////////////////////////////////////////
            string nombreBAPI = "BAPI_AP_ACC_GETOPENITEMS";
            var param = new Dictionary<string, object>();
            param.Add("COMPANYCODE", "0050");
            param.Add("VENDOR", "0000016099");
            param.Add("KEYDATE", fecha);
            var tablasCol = new List<TablaColumnasSAP>();
            var columnas = new List<string>();
            columnas.Add("COMP_CODE");
            columnas.Add("VENDOR");
            columnas.Add("ALLOC_NMBR");
            columnas.Add("FISC_YEAR");
            columnas.Add("DOC_NO");
            columnas.Add("ITEM_NUM");
            columnas.Add("PSTNG_DATE");
            columnas.Add("DOC_DATE");
            columnas.Add("ENTRY_DATE");
            columnas.Add("CURRENCY");
            columnas.Add("LOC_CURRCY");
            columnas.Add("REF_DOC_NO");
            columnas.Add("DOC_TYPE");///filtrar: 
            columnas.Add("FIS_PERIOD");
            columnas.Add("POST_KEY");
            columnas.Add("DB_CR_IND");
            columnas.Add("BUS_AREA");
            columnas.Add("TAX_CODE");
            columnas.Add("LC_AMOUNT");
            tablasCol.Add(new TablaColumnasSAP()
            {
                nombreTabla = "LINEITEMS",
                lsColumnas = columnas
            });
            var resultado = csBaseSAPNET.BAPI_CONSULTA(nombreBAPI, param, tablasCol);

            /////////////////////////////////////CERRADAS//////////////////////////////////////////////////////////////////

            nombreBAPI = "BAPI_AP_ACC_GETBALANCEDITEMS";
            param = new Dictionary<string, object>();
            param.Add("COMPANYCODE", "0050");
            param.Add("VENDOR", "0000016099");
            param.Add("DATE_FROM", "20.08.2016");
            param.Add("DATE_TO", "30.06.2017");
            var resultado2 = csBaseSAPNET.BAPI_CONSULTA(nombreBAPI, param, tablasCol);

            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            nombreBAPI = "BAPI_AP_ACC_GETSTATEMENT";
            param = new Dictionary<string, object>();
            param.Add("COMPANYCODE", "0050");
            param.Add("VENDOR", "0000016099");
            param.Add("DATE_FROM", "20.08.2016");
            param.Add("DATE_TO", "30.06.2017");
            var resultado3 = csBaseSAPNET.BAPI_CONSULTA(nombreBAPI, param, tablasCol);

            //////////////////////////////////////////////////////////////////////////////////////////////////////////////////

            nombreBAPI = "BAPI_COMPANYCODE_EXISTENCECHK";
            param = new Dictionary<string, object>();
            param.Add("COMPANYCODEID", "0050");
            //param.Add("VENDOR", "0000001095");
            //param.Add("DATE_FROM", "20.08.1997");
            //param.Add("DATE_TO", "30.06.1998");
            var resultado4 = csBaseSAPNET.BAPI_CONSULTA(nombreBAPI, param, new List<TablaColumnasSAP>());


            /////////////////////////////////////////////////////////////////////////////////////////////////////////////////
            nombreBAPI = "BAPI_ACC_DOCUMENT_POST";
            var paramXTablas = new Dictionary<string, object>();
            //DOCUMENTHEADER
            param = new Dictionary<string, object>();
            param.Add("USERNAME", "HERCORI");
            param.Add("COMP_CODE", sociedad);
            param.Add("DOC_DATE", "23.09.2017");
            param.Add("PSTNG_DATE", "23.09.2017");
            param.Add("TRANS_DATE", "23.09.2017");
            param.Add("FISC_YEAR", "2017");
            param.Add("FIS_PERIOD", "09");
            param.Add("DOC_TYPE", "KR");
            paramXTablas.Add("DOCUMENTHEADER", param);
            //ACOUNTGL
            param = new Dictionary<string, object>();
            param.Add("ITEMNO_ACC", "0000000002");
            param.Add("GL_ACCOUNT", "416200");
            param.Add("DOC_TYPE", "KR");
            param.Add("COMP_CODE", sociedad);
            param.Add("FISC_YEAR", "2017");
            param.Add("FIS_PERIOD", "09");
            paramXTablas.Add("ACCOUNTGL", param);
            //ACCOUNTPAYABLE
            param = new Dictionary<string, object>();
            param.Add("USERNAME", "HERCORI");
            param.Add("COMP_CODE", sociedad);
            param.Add("DOC_DATE", "23.09.2017");
            param.Add("PSTNG_DATE", "23.09.2017");
            param.Add("TRANS_DATE", "23.09.2017");
            param.Add("FISC_YEAR", "2017");
            param.Add("FIS_PERIOD", "09");
            param.Add("DOC_TYPE", "KR");
            paramXTablas.Add("ACCOUNTPAYABLE", param);
            //ACCOUNTTAX
            param = new Dictionary<string, object>();
            param.Add("USERNAME", "HERCORI");
            param.Add("COMP_CODE", sociedad);
            param.Add("DOC_DATE", "23.09.2017");
            param.Add("PSTNG_DATE", "23.09.2017");
            param.Add("TRANS_DATE", "23.09.2017");
            param.Add("FISC_YEAR", "2017");
            param.Add("FIS_PERIOD", "09");
            param.Add("DOC_TYPE", "KR");
            paramXTablas.Add("ACCOUNTTAX", param);
            //CURRENCYAMOUNT
            param = new Dictionary<string, object>();
            param.Add("USERNAME", "HERCORI");
            param.Add("COMP_CODE", sociedad);
            param.Add("DOC_DATE", "23.09.2017");
            param.Add("PSTNG_DATE", "23.09.2017");
            param.Add("TRANS_DATE", "23.09.2017");
            param.Add("FISC_YEAR", "2017");
            param.Add("FIS_PERIOD", "09");
            param.Add("DOC_TYPE", "KR");
            paramXTablas.Add("CURRENCYAMOUNT", param);
            
            var resultado5 = csBaseSAPNET.BAPI_CONSULTA(nombreBAPI, paramXTablas, tablasCol);



        }
    }
}
