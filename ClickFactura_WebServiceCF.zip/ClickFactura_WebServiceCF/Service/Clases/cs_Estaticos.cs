﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization.Json;
using System.Text;
using context = System.Web.HttpContext;
using System.Web;

namespace ClickFactura_WebServiceCF.Service.Clases
{
    public static class cs_Estaticos
    {
        //public static class Extensions
        //{
            public static DataTable ConvertToDataTable<T>(this IEnumerable<T> source)
            {
                DataTable table = new DataTable();
                var properties = TypeDescriptor.GetProperties(typeof(T));
                foreach (PropertyDescriptor property in properties)
                {
                    if (property.PropertyType.IsGenericType && property.PropertyType.GetGenericTypeDefinition().Equals(typeof(Nullable<>)))
                        table.Columns.Add(property.Name, property.PropertyType.GetGenericArguments()[0]);
                    else
                        table.Columns.Add(property.Name, property.PropertyType);
                }

                object[] values = new object[properties.Count];
                foreach (var item in source)
                {
                    for (int i = 0; i < properties.Count; i++)
                        values[i] = properties[i].GetValue(item);
                    table.Rows.Add(values);
                }
                return table;
            }
        //}

        public static List<T> MappingToEntity<T>(this DataTable dt)
        {
            try
            {
                var lst = new List<T>();
                var tClass = typeof(T);
                PropertyInfo[] proInModel = tClass.GetProperties();
                List<DataColumn> proInDataColumns = dt.Columns.Cast<DataColumn>().ToList();
                T cn;
                foreach (DataRow item in dt.Rows)
                {
                    cn = (T)Activator.CreateInstance(tClass);
                    foreach (var pc in proInModel)
                    {


                        var d = proInDataColumns.Find(c => string.Equals(c.ColumnName.ToLower().Trim(), pc.Name.ToLower().Trim(), StringComparison.CurrentCultureIgnoreCase));
                        if (d != null)
                            pc.SetValue(cn, item[pc.Name], null);


                    }
                    lst.Add(cn);
                }
                return lst;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>

        /// Método extensor para serializar JSON cualquier objeto

        /// </summary>

        public static string SerializandoToJson(this object objeto)
        {

            string jsonResult = string.Empty;

            try
            {

                DataContractJsonSerializer jsonSerializer =

                  new DataContractJsonSerializer(objeto.GetType());

                MemoryStream ms = new MemoryStream();

                jsonSerializer.WriteObject(ms, objeto);

                jsonResult = Encoding.Default.GetString(ms.ToArray());

            }

            catch { throw; }

            return jsonResult;

        }

        public static T DeserializarJsonTo<T>(this string jsonSerializado)
        {

            try
            {

                T obj = Activator.CreateInstance<T>();

                MemoryStream ms = new MemoryStream(Encoding.Unicode.GetBytes(jsonSerializado));

                DataContractJsonSerializer serializer = new DataContractJsonSerializer(obj.GetType());

                obj = (T)serializer.ReadObject(ms);

                ms.Close();

                ms.Dispose();

                return obj;

            }

            catch { return default(T); }

        }

        public static DataTable ToDataTable<T>(this IList<T> data)
        {
            PropertyDescriptorCollection props =
                TypeDescriptor.GetProperties(typeof(T));
            DataTable table = new DataTable();
            for (int i = 0; i < props.Count; i++)
            {
                PropertyDescriptor prop = props[i];
                table.Columns.Add(prop.Name, prop.PropertyType);
            }
            object[] values = new object[props.Count];
            foreach (T item in data)
            {
                for (int i = 0; i < values.Length; i++)
                {
                    values[i] = props[i].GetValue(item);
                }
                table.Rows.Add(values);
            }
            return table;
        }

        private static Dictionary<Type, IList<PropertyInfo>> typeDictionary = new Dictionary<Type, IList<PropertyInfo>>();
        public static IList<PropertyInfo> GetPropertiesForType<T>()
        {
            var type = typeof(T);
            if (!typeDictionary.ContainsKey(typeof(T)))
            {
                typeDictionary.Add(type, type.GetProperties().ToList());
            }
            return typeDictionary[type];
        }

        public static IList<T> ToList<T>(this DataTable table) where T : new()
        {
            IList<PropertyInfo> properties = GetPropertiesForType<T>();
            IList<T> result = new List<T>();

            foreach (var row in table.Rows)
            {
                var item = CreateItemFromRow<T>((DataRow)row, properties);
                result.Add(item);
            }

            return result;
        }

        private static T CreateItemFromRow<T>(DataRow row, IList<PropertyInfo> properties) where T : new()
        {
            T item = new T();
            foreach (var property in properties)
            {
                property.SetValue(item, row[property.Name], null);
            }
            return item;
        }

        public static bool EsUsuarioInterno(string quienEntro)
        {
            var ctx = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF();
            ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
            #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
            string consulta = "";
            consulta = consulta + " " + "SELECT dbo.Cat_Usuario.Usuario, dbo.Cat_Perfil.IdPerfil, dbo.Cat_Perfil.Perfil, dbo.Cat_Perfil.Activo, dbo.Cat_Perfil.esUsuarioExterno, dbo.Cat_Usuario.IdUsuario, ";
            consulta = consulta + " " + "dbo.Cat_Usuario.Password, dbo.Cat_Usuario.IdProveedor, dbo.Cat_Proveedor.Nombre, dbo.Cat_Proveedor.Num_Proveedor,  dbo.Cat_Proveedor.Num_Sociedad";
            consulta = consulta + " " + " FROM dbo.Cat_Usuario INNER JOIN dbo.Cat_Perfil ON dbo.Cat_Usuario.IdPerfil = dbo.Cat_Perfil.IdPerfil INNER JOIN dbo.Cat_Proveedor ON dbo.Cat_Usuario.IdProveedor = dbo.Cat_Proveedor.IdProveedor AND dbo.Cat_Usuario.IdProveedor = dbo.Cat_Proveedor.IdProveedor";
            consulta = consulta + " " + " WHERE        (dbo.Cat_Perfil.esUsuarioExterno = 0) AND (dbo.Cat_Perfil.Activo = 1) ";
            consulta = consulta + " " + " And Usuario='"+quienEntro+"'";
            var _proveedor = generico.genericos_consultaCualquierTabla(consulta);
            #endregion
            if (_proveedor != null)
            {
                if (_proveedor.Rows.Count > 0)
                {
                    string encontrado = _proveedor.Rows[0].Field<string>("Usuario").ToString();
                    if (encontrado.Equals(quienEntro) == true)
                    {
                        return true;
                    }
                    else
                        return false;
                }
                else
                    return false;
            }
            else
                return false;
        }

        public static bool EsAdministradorBafar(string quienEntro)
        {
            var ctx = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF();
            var r = (from t in ctx.T_Parametros.AsEnumerable() where t.descParametro == "AdmonBafar" select t.valorParametro).FirstOrDefault();
            if (quienEntro.Equals(r.ToString()) == true)
                return true;
            else
                return false;
        }

        public static string tipoUsuario(string id)
        {
            var ctx = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF();
            string tipo = "";
            var qq = (from u in ctx.Cat_Perfil where (u.IdPerfil.Equals(id)) select u.esUsuarioExterno).FirstOrDefault();
            {
                tipo = qq == true ? "Externo" : "Interno";
            }
            return tipo;
        }

        public static List<T> ConvertDataTableaLista<T>(DataTable dt)  
        {  
           List<T> data = new List<T>();  
           foreach (DataRow row in dt.Rows)  
           {  
              T item = GetItem<T>(row);  
              data.Add(item);  
           }  
           return data;  
        }  
  
        private static T GetItem<T>(DataRow dr)  
        {  
           Type temp = typeof(T);  
           T obj =Activator.CreateInstance<T>();  
           foreach (DataColumn column in dr.Table.Columns)  
           {  
              foreach (PropertyInfo pro in temp.GetProperties())  
              {  
                 if (pro.Name == column.ColumnName)  
                 pro.SetValue(obj,dr[column.ColumnName], null);  
                 else  
                 continue;  
              }  
           }  
           return obj;  
        }

        public static void identificaLineaMayor(Object Recepciones, ref string _Importe, ref string _NoRecepcion, ref string _Posicion, ref int totalLineas, DataTable _Detalle_Recepciones)
        {
            List<KeyValuePair<double, KeyValuePair<string, string>>> datos = new List<KeyValuePair<double, KeyValuePair<string, string>>>();
            List<List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo>> _Recepciones = new List<List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo>>();
            // DataTable _Detalle_Recepciones = new DataTable();
            _Recepciones = (List<List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo>>)Recepciones;
            foreach (List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> _recepciones in _Recepciones)
            {
                if (_recepciones != null)
                    if (_recepciones.Count > 0)
                    {
                        foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo _recepcion in _recepciones)
                        {
                            string _recepcionActual = _recepcion.NoRecepcion;
                            string _posicion = _recepcion.NoItem;
                            double _importe = 0;
                            _importe = Convert.ToDouble(_recepcion.ImporteUnitario) * Convert.ToDouble(_recepcion.Piezas);
                            _importe = Convert.ToDouble(Math.Round(Convert.ToDecimal(_importe) * 1.00m, 2, MidpointRounding.AwayFromZero));
                            ratificaCostoLinea(_recepcionActual, _posicion, ref _importe,_Detalle_Recepciones);
                            KeyValuePair<string, string> informacion = new KeyValuePair<string, string>(_recepcionActual, _posicion);
                            KeyValuePair<double, KeyValuePair<string, string>> dato = new KeyValuePair<double, KeyValuePair<string, string>>(_importe, informacion);
                            datos.Add(dato);
                        }
                    }
            }
            if (datos != null)
                if (datos.Count > 0)
                {
                    var Mayor = datos.Where(x => x.Key == datos.Max(y => y.Key));
                    if (Mayor != null)
                        if (Mayor.Count() > 0)
                        {
                            foreach (KeyValuePair<double, KeyValuePair<string, string>> encontrado in Mayor)
                            {
                                _Importe = encontrado.Key.ToString();
                                _NoRecepcion = encontrado.Value.Key;
                                _Posicion = encontrado.Value.Value;
                                break;
                            }

                        }
                }
        }

        public static void ratificaCostoLinea(string _recepcionActual, string _posicion, ref double _importe,DataTable _Detalle_Recepciones)
        {
            double _importe_Documento = 0;
            try
            {
                var Detalle_Recepciones = ConvertDataTableaLista<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones>(_Detalle_Recepciones);
                var q = from c in Detalle_Recepciones where c.Numero_Documento.Equals(_recepcionActual) == true && c.Posicion_Documento.Equals(_posicion) == true select c;//contexto.Detalle_Recepciones where c.Numero_Documento.Equals(_recepcionActual) == true && c.Posicion_Documento.Equals(_posicion) == true select c;
                if (q != null)
                    if (q.Count() > 0)
                    {
                        string _posicionOrden = "";
                        string _orden_Compra = "";
                        foreach (var reg in q)
                        {
                            _orden_Compra = reg.Orden_Compra.ToString();
                            _posicionOrden = reg.Posicion_OrdenCompra.ToString();
                            _importe_Documento = Convert.ToDouble(reg.Importe_Documento.ToString());
                            #region extrae importes de ImporteDocumento
                            //System.Data.Linq.Table<DataContext.Detalle_OrdenCompra> ordenes= contexto.GetTable<DataContext.Detalle_OrdenCompra>();
                            //var p = from g in ordenes where g.Orden_Compra.Equals(_orden_Compra)==true && g..Equals(_posicionOrden)==true select g;
                            //        if (p != null)
                            //            if (p.Count() > 0)
                            //            {
                            //                foreach(var h in p)
                            //                {
                            //                      _importe_Documento=h.
                            //                }
                            //            }
                            #endregion extrae importes de ImporteDocumento
                        }
                    }
            }
            catch
            {
                _importe_Documento = _importe;
            }
            if (_importe != _importe_Documento)
                _importe = _importe_Documento;
        }

        private static String ErrorlineNo, Errormsg, extype, exurl, hostIp, ErrorLocation, HostAdd;

        public static void SendErrorToText(Exception ex,List<string> errores, int tipo, string origen,string oc,string proceso)
        {
            if(tipo==0)
            {
                var line = Environment.NewLine + Environment.NewLine;

                ErrorlineNo = ex.StackTrace.Substring(ex.StackTrace.Length - 7, 7);
                Errormsg = ex.GetType().Name.ToString();
                extype = ex.GetType().ToString();
                exurl = context.Current.Request.Url.ToString();
                ErrorLocation = ex.Message.ToString();
            }
            try
            {
                string filepath = Path.Combine(@"C:\Temp\LogsPortal",  proceso+@"\"+oc);// context.Current.Server.MapPath(@"C:\Temp");// ExceptionDetailsFile/");  //Text File Path

                if (!Directory.Exists(filepath))
                {
                    Directory.CreateDirectory(filepath);

                }
                filepath = filepath + @"\" + DateTime.Today.ToString("dd-MM-yy") + "_" + proceso + "_" + oc + ".txt"; //Text File Name
                if (!File.Exists(filepath))
                {
                    File.Create(filepath).Dispose();
                }
                using (StreamWriter sw = File.AppendText(filepath))
                {
                    int line = 0;
                    sw.WriteLine("---------------------------------------------------------------------------------------");
                    sw.WriteLine("---------------------------      CLICK FACTURA     ----------------------------------");
                    string error = "LOG escrito el día:" + " " + DateTime.Now.ToString() +  " para "+ origen ;// + ErrorlineNo + line + "Error Message:" + " " + Errormsg + line + "Exception Type:" + " " + extype + line + "Error Location :" + " " + ErrorLocation + line + " Error Page Url:" + " " + exurl + line + "User Host IP:" + " " + hostIp + line;
                    sw.WriteLine(error);
                    sw.WriteLine(" ");
                    sw.WriteLine("Excepciones ocurridas el " + " " + DateTime.Now.ToString() );
                    sw.WriteLine(" ");
                    sw.WriteLine("                                         TABLA RETURN SAP");
                    sw.WriteLine(" ");
                    foreach (string err in errores)
                    {
                        if (err.Contains("Error") == true)
                        {
                            sw.WriteLine(line.ToString() + " :  " + err);
                            line++;
                        }
                    }
                    sw.WriteLine(" ");
                    sw.WriteLine("                                        Mensajes Portal");
                    foreach (string err in errores)
                    {
                        if(err.Contains("ERROR")==true)
                        {
                            sw.WriteLine(line.ToString()+" :  "+ err);
                            line++;
                        }
                    }
                    sw.WriteLine(" ");
                    sw.WriteLine("                                     Informacion procesada de la OC "+oc);
                    foreach (string err in errores)
                    {
                        if (err.Contains("Data") == true)
                        {
                            sw.WriteLine(line.ToString() + " :  " + err);
                            line++;
                        }
                    }
                    sw.WriteLine("---------------------------------------------------------------------------------------");
                    sw.WriteLine("--------------------------------*   FIN    *------------------------------------------");
                    sw.WriteLine("---------------------------------------------------------------------------------------");
                    sw.Flush();
                    sw.Close();
                }

            }
            catch (Exception e)
            {
                e.ToString();
            }
        }

    }
}
