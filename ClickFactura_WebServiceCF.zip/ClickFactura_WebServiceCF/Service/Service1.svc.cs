﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;
using ClickFactura_WebServiceCF.AccesoBD.Genericos;
using ClickFactura_WebServiceCF.Conectores.Configuracion;
using ClickFactura_Entidades.BD.Entidades;
using SAP.Middleware.Connector;
using System.Data;
using System.Web.Services.Description;
using System.Reflection;
using ClickFactura_Facturacion.Clases.paraVerificacionFactura;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Xml.Serialization;
using System.Xml;
using System.Xml.XPath;
using System.Data.SqlClient;
using ClickFactura_WebServiceCF.Service.Clases;

namespace ClickFactura_WebServiceCF.Service
{
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
   
    public class Service1 : IService1
    {
        #region Variables Globales
        ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET csbaseSAPnet = new Conectores.Configuracion.csBaseSAPNET();
        List<KeyValuePair<string, string>> recepcionesAnalisadas = new List<KeyValuePair<string, string>>();

        #endregion Variables Globales

        #region       Genericos
        public DataTable genericos_consultaCualquierTabla(string consulta)
        {
            DataTable dt = new DataTable();
            string constring = ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion; //ConfigurationManager.ConnectionStrings[DataBase].ConnectionString.ToString();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(constring))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(consulta, con))
                {
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
                    if (dr != null)
                    {
                        dt.Load(dr);
                    }
                    con.Close();
                }
            }
            return dt;
        }

        /// <summary>
        /// Este metodo se utiliza para convertir el formato de fecha proporcionado por el servidor NET
        /// hacia el formato valido en la base de datos de SQL Server que facilitara crear consultas posteriormente
        /// </summary>
        /// <param name="fechaLarga">Viene de DateTime.Now.ToLongDateString()</param>
        /// <param name="horaLarga">Viene de DateTime.Now.ToLongTimeString()</param>
        /// <returns></returns>
        private string convierteFechaBaseDatos(string fechaLarga, string horaLarga)
        {
            string convertida = "";

            convertida = fechaLarga + " " + horaLarga;
            return convertida;
        }

        public string diasMaximosConsultasFechas
        {
            get
            {
                string noDias = "365";// System.Web.Configuration.WebConfigurationManager.AppSettings["diasMaximoBusquedaFechas"];

                return noDias;
            }
        }

        public void formateaFechasSQL(ref string inicial, ref string final, ref string mensaje, string num_proveedor, string quienEntro)
        {
            Dictionary<string, string> convertidos = new Dictionary<string, string>();
            #region Analiza fechas solo Estado de Cuenta
            System.Globalization.CultureInfo mx = new System.Globalization.CultureInfo("es-MX");
            Dictionary<string, string> filtros = new Dictionary<string, string>();
            bool incluyeFechas = false;
            string incluyendoFecha = "";
            if ((inicial != null && inicial.Length > 0) && (inicial != null && final.Length > 0))// && opcion == 1)
            {
                //DateTime.Parse()
                //if (Convert.ToDateTime(final)<=DateTime.Now)
                if (DateTime.Parse(final, mx) <= DateTime.Now)
                {
                    int noDias = Convert.ToInt32(diasMaximosConsultasFechas);
                    noDias = noDias == 0 ? 90 : noDias;
                    //if (EsAdministradorBafar(quienEntro) == true)
                    //{
                    //    noDias = 5000;
                    //}
                    DateTime ini = DateTime.Parse(inicial, mx);//Convert.ToDateTime(inicial);
                    DateTime fin = DateTime.Parse(final, mx);// Convert.ToDateTime(final);
                    if (ini <= fin)
                    {
                        double totalDias = 0;
                        if (num_proveedor != null)
                            totalDias = (fin - ini).TotalDays;
                        else
                            totalDias = 0;
                        if (totalDias <= noDias)
                        {
                            incluyeFechas = true;
                            //Genericos.Configuracion con = new Genericos.Configuracion();
                            if (inicial.Contains("/") == true)
                            {
                                inicial = formatearfechaparaSAP(inicial);
                                final = formatearfechaparaSAP(final);
                            }

                        }
                        else
                        {
                            mensaje = "Periodo fuera de rangos : La búsqueda de información es con un máximo de  " + noDias.ToString() + " atrás, la fecha de inicio debe ser más reciente.";
                        }
                    }
                    else
                    {
                        mensaje = "Rango de fechas incorrecto : La fecha inicial debe ser menor a la fecha final de consulta.Verifique esto por favor";
                    }
                }
                else
                {
                    mensaje = "Fecha final inválida : Las búsquedas se realizarán a un periodo máximo del día de hoy.";
                }
            }
            else
            {
                if (inicial != null || final != null)
                {
                    if ((inicial == null))
                    {
                        mensaje = "Falta fecha inicial : Si desea filtrar por fechas, debe especificar una de inicio para la búqueda por favor.";
                    }
                    else
                    {
                        mensaje = "Falta fecha final : Si desea filtrar por fechas, debe especificar una  final para la búqueda por favor.";
                    }
                }

            }
            #endregion Analiza fechas solo Estado de Cuenta
        }

        public string formatearfechaparaSAP(string fechaoriginal)
        {
            string salida = "";
            string _fechaoriginal = fechaoriginal;
            string dia = "";
            string mes = "";
            string año = "";
            int largo = 0;
            int pos = 0;
            try
            {
                largo = fechaoriginal.Length;
                pos = fechaoriginal.IndexOf("/");
                dia = fechaoriginal.Substring(0, pos);
                fechaoriginal = fechaoriginal.Remove(0, 3);
                pos = fechaoriginal.IndexOf("/");
                mes = fechaoriginal.Substring(0, pos);
                fechaoriginal = fechaoriginal.Remove(0, 3);
                año = fechaoriginal.Substring(0, 4);
                salida = dia + "." + mes + "." + año;
            }
            catch
            {

            }
            //salida = "2015-09-07 12:00:00 AM";
            //if(_fechaoriginal.Contains("12:00:00 AM")==true)
            if (salida.Equals("") == true)
            {
                //2015-09-07 12:00:00 AM
                largo = _fechaoriginal.Length;
                pos = _fechaoriginal.IndexOf("-");
                año = _fechaoriginal.Substring(0, pos);
                _fechaoriginal = _fechaoriginal.Remove(0, 5);
                pos = _fechaoriginal.IndexOf("-");
                mes = _fechaoriginal.Substring(0, pos);
                _fechaoriginal = _fechaoriginal.Remove(0, 3);
                dia = _fechaoriginal.Substring(0, 2);
                salida = dia + "." + mes + "." + año;
            }
            return salida;
        }

        public string formatearCantidadesImportes(string posibleNumero)
        {
            string nuevaCantidad = "0";
            string acumulado = "";
            string numeroActual = "";
            int largo = posibleNumero.Length;
            int posicionActual;
            int contadorInterno = 1;
            bool sinComas = false;
            int posicionComa = posibleNumero.IndexOf(",");
            #region Si estas local
            if (posicionComa > 0)
            {
                for (int i = 0; i < largo; i++)
                {
                    string num = posibleNumero[i].ToString();
                    if (num.Equals(",") == true)
                    {
                        if (contadorInterno > 3)
                        {
                            acumulado = acumulado + ".";
                            contadorInterno = 1;
                        }
                        else
                        {
                            //Nada, esta en notacion decimal común
                            acumulado = acumulado + "";
                            contadorInterno++;
                        }
                    }
                    else
                    {
                        if (num.Equals(".") == false)
                        {
                            acumulado = acumulado + num;
                        }
                        else
                        {
                            acumulado = acumulado + "";
                        }
                        contadorInterno++;
                    }
                }
            }
            else
            {
                acumulado = posibleNumero;
            }
            #endregion Si estas local
            nuevaCantidad = Convert.ToDecimal(acumulado).ToString();
            return nuevaCantidad;
        }

        public DateTime primerDiaMes()
        {
            DateTime dCalcDate = DateTime.Now;
            DateTime returnDate = DateTime.Now;
            returnDate = new DateTime(dCalcDate.Year, dCalcDate.Month, 1);
            return returnDate;
        }

        public DateTime primerDiaMes(DateTime Fecha)
        {
            DateTime dCalcDate = Fecha;// DateTime.Now;
            DateTime returnDate = Fecha;// DateTime.Now;
            returnDate = new DateTime(dCalcDate.Year, dCalcDate.Month, 1);
            return returnDate;
        }

        public DateTime ultimoDiaMes()
        {
            DateTime dCalcDate = DateTime.Now;
            DateTime returnDate = DateTime.Now;
            returnDate = new DateTime(dCalcDate.Year, dCalcDate.Month, DateTime.DaysInMonth(dCalcDate.Year, dCalcDate.Month));
            return returnDate;
        }

        public DateTime ultimoDiaMes(DateTime Fecha)
        {
            DateTime dCalcDate = Fecha;// DateTime.Now;
            DateTime returnDate = Fecha;// DateTime.Now;
            returnDate = new DateTime(dCalcDate.Year, dCalcDate.Month, DateTime.DaysInMonth(dCalcDate.Year, dCalcDate.Month));
            return returnDate;
        }

        public void EscribeLOG(List<string> errores, string origenes,string oc,string proceso)
        {
            cs_Estaticos.SendErrorToText(null, errores,1,origenes,oc,proceso);
        }

        #endregion Genericos

        #region Ejemplos
        public String DoWork()
        {
            return "Hello REST WCF Service! :)";
        }

        public int DoSquare(int value)
        {
            return value * value;
        }

        public int DoAddValues(AddValues addValues)
        {
            return addValues.Value1 + addValues.Value2;
        }

        #endregion Ejemplos

        #region       Funcionalidades Configuración del Portal

        public List<KeyValuePair<string, string>> ABCUsuario(ClickFactura_Entidades.BD.Entidades.Cat_Usuario usuario, ref List<KeyValuePair<string, string>> datos)
        {
            using (var ctx = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF())
            {
                try
                {
                    ClickFactura_Entidades.BD.Entidades.Cat_Usuario _usuario = new ClickFactura_Entidades.BD.Entidades.Cat_Usuario();
                    _usuario.IdUsuario = usuario.IdUsuario;
                    _usuario.Usuario = usuario.Usuario;
                    _usuario.Password = usuario.Password;
                    _usuario.IdProveedor = usuario.IdProveedor;
                    _usuario.Correo = usuario.Correo;
                    _usuario.Activo = usuario.Activo;
                    _usuario.IdPerfil = usuario.IdPerfil;
                    _usuario.fechaSolicitud = Convert.ToDateTime(DateTime.UtcNow);
                    if (usuario.IdUsuario < 0)
                    {
                        //Insertando
                        ctx.Cat_Usuario.Add(_usuario);
                        datos.Add(new KeyValuePair<string, string>("OK", "El usuario se agrego al grupo del Proveedor correctamente!"));
                    }
                    else
                    {
                        //Modificando
                        var usuarioExistente = from usu in ctx.Cat_Usuario where usu.IdUsuario == usuario.IdUsuario select usu;
                        if (usuarioExistente != null && usuarioExistente.Count() > 0)
                        {
                            foreach (ClickFactura_Entidades.BD.Entidades.Cat_Usuario s in usuarioExistente)
                            {
                                s.Usuario = usuario.Usuario;
                                s.Password = usuario.Password;
                                s.IdProveedor = usuario.IdProveedor;
                                s.Correo = usuario.Correo;
                                s.Activo = usuario.Activo;
                                s.IdPerfil = usuario.IdPerfil;
                                datos.Add(new KeyValuePair<string, string>("OK", "El usuario se actualizo correctamente!"));
                                break;
                            }
                        }
                        else
                        {
                            datos.Add(new KeyValuePair<string, string>("Error", "Ocurrío un problema localizando al usuario, intente de nuevo por favor."));
                        }
                    }
                    ctx.SaveChanges();
                }
                catch (Exception ex)
                {
                    datos.Add(new KeyValuePair<string, string>("Error", "Ocurrío un problema en esta operacion :" + ex.Message));
                }
                return datos;
            }
        }

        public List<KeyValuePair<string, string>> misUsuarios(string idproveedor)
        {
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            int _idproveedor=Convert.ToInt32(idproveedor);
            using (var ctx = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF())
            {
                var todos = from usu in ctx.Cat_Usuario where usu.IdProveedor == _idproveedor select usu;
                if(todos!=null && todos.Count()>0)
                {
                    foreach(ClickFactura_Entidades.BD.Entidades.Cat_Usuario usuario in  todos)
                    {
                        datos.Add(new KeyValuePair<string,string>(usuario.IdUsuario.ToString(),usuario.Usuario));
                    }
                }
                else
                {
                    datos.Add(new KeyValuePair<string, string>("-2", "Sin usuarios adicionales"));
                }
            }
            return datos;
        }

        #endregion       Funcionalidades Configuración del Portal
        
        #region        Implementación de Conectores

        SAP.Middleware.Connector.RfcDestination conector = csBaseSAPNET.GetRfcDestination;

        public SAP.Middleware.Connector.RfcDestination Conector
        {
            get { return conector; }
            set { conector = value; }
        }

      public SAP.Middleware.Connector.RfcDestination abreConector(ref bool result)
        {
            result = false;
            //SAP.Middleware.Connector.RfcDestination conector = csBaseSAPNET.GetRfcDestination;
            SAP.Middleware.Connector.RfcSessionManager.BeginContext(Conector);
            Conector.Ping();
            return Conector;
        }

      public SAP.Middleware.Connector.RfcDestination cierraConector(ref bool result)
        {
            result = false;
            SAP.Middleware.Connector.RfcSessionManager.EndContext(Conector);
            Conector = null;
            return Conector;
        }
       
      public List<KeyValuePair<string,string>> parametrosAlmacenados()
        {
                int result = 0;
                adT_Parametros adp = new adT_Parametros();
                List<objT_Parametros> objp = new List<objT_Parametros>();
                List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
                string entorno = "";

                objp = adp.mABCT_Parametros(out result, 0, "EntornoSAP", "Vacio", true, "ConsultaValor");
                {
                    entorno = objp[0].ValorParametro.ToString();
                }

                string _nombre = "";
                string _usuario = "";
                string _password = "";
                string _cliente = "";
                string _lenguaje = "";
                string _appserverhost = "";
                string _messageserverhost = "";
                string _systemnumber = "";
                string _systemid = "";
                string _maxpoolsize = "";
                string _idletimeout = "";
                string _logonGroup = "";
                string _gatewayhost = "";
                string _messageserverservice = "";
                string _appserverservice = "";
                string _gatewayservice = "";

                if (entorno.Equals("QA") == true)
                {
                    objp = adp.mABCT_Parametros(out result, 0, "Name", "Vacio", true, "ConsultaValor");
                    {
                        _nombre = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Name",_nombre));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "User", "Vacio", true, "ConsultaValor");
                    {
                        _usuario = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("User", _usuario));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Password", "Vacio", true, "ConsultaValor");
                    {
                        _password = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Password", _password));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Client", "Vacio", true, "ConsultaValor");
                    {
                        _cliente = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Client", _cliente));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "Language", "Vacio", true, "ConsultaValor");
                    {
                        _lenguaje = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("Language", _lenguaje));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "SystemNumber", "Vacio", true, "ConsultaValor");
                    {
                        _systemnumber = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("SystemNumber", _systemnumber));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "SystemID", "Vacio", true, "ConsultaValor");
                    {
                        _systemid = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("SystemID", _systemid));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "MaxPoolSize", "Vacio", true, "ConsultaValor");
                    {
                        _maxpoolsize = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("MaxPoolSize", _maxpoolsize));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "IdleTimeout", "Vacio", true, "ConsultaValor");
                    {
                        _idletimeout = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("IdleTimeout", _idletimeout));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "AppServerHost", "Vacio", true, "ConsultaValor");
                    {
                        _appserverhost = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("AppServerHost", _appserverhost));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "MessageServerHost", "Vacio", true, "ConsultaValor");
                    {
                        _messageserverhost = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("MessageServerHost", _messageserverhost));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "LogonGroup", "Vacio", true, "ConsultaValor");
                    {
                        _logonGroup= objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("LogonGroup", _logonGroup));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "GateWayHost", "Vacio", true, "ConsultaValor");
                    {
                        _gatewayhost = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("GateWayHost", _gatewayhost));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "AppServerService", "Vacio", true, "ConsultaValor");
                    {
                        _appserverservice = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("AppServerService", _appserverservice));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "MessageServerService", "Vacio", true, "ConsultaValor");
                    {
                        _messageserverservice = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("MessageServerService", _messageserverservice));
                    }
                    objp = adp.mABCT_Parametros(out result, 0, "GateWayService", "Vacio", true, "ConsultaValor");
                    {
                        _gatewayservice = objp[0].ValorParametro.ToString();
                        datos.Add(new KeyValuePair<string, string>("GateWayService", _gatewayservice));
                    }
                }
                //Console.WriteLine(AssemblyName.GetAssemblyName(@"C:\Users\Gabriel\Documents\Visual Studio 2013\Projects\Portal TKPM\Abril2017\Recursos\sapnco.dll"));
                return datos;
        }

      public List<KeyValuePair<string, string>> disparaCargarProveedorPrincipal(string companyid)
                {

                    List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
                    SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
                    try
                    {
                        datos = csbaseSAPnet.obtenInformacionCompañia(conector, companyid);
                    }
                    catch (Exception ex)
                    {
                        System.Console.WriteLine(ex.Message);
                        System.Console.ReadLine();
                    }
                    return datos;
                }

        /// <summary>
       /// BAPI_INCOMINGINVOICE_CREATE
        /// Implementación de la BAPI de Verificación o Recepción de la Factura Financiera SAP
        /// </summary>
        /// <param name="HPasivo"></param>
        /// <param name="detallesPasivos"></param>
        /// <returns></returns>
      public List<KeyValuePair<string, string>> MIRO_dispara_BAPI_INCOMINGINVOICE_CREATE(ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado HPasivo, ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos)
      {
          List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
          //Sube VPN ###########################################################################################
          SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
          try
          {
              datos = csbaseSAPnet.BAPI_INCOMINGINVOICE_CREATE(conector, HPasivo,detallesPasivos);
          }
          catch (Exception ex)
          {
              System.Console.WriteLine(ex.Message);
                datos.Add(new KeyValuePair<string,string>("Error",ex.Message));
              //System.Console.ReadLine();
          }
          return datos;
      }

      //List<KeyValuePair<string, string>> BAPIZ_obtenInformacionProveedoresGral(SAP.Middleware.Connector.RfcDestination conector, string S,string OP,string Vendor_Low,string Vendor_High)

        /// <summary>
        /// BAPI_GOODSMVT_CREATE
       /// Implementacion de la BAPI de Recepción de Mercancías a SAP
       /// </summary>
      /// <param name="renglon">ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon</param>
      /// <returns></returns>
      public List<KeyValuePair<string, string>> dispara_BAPI_GOODSMVT_CREATE(ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon)
      {

          List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
          SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
          try
          {
                //datos = csbaseSAPnet.BAPI_GOODSMVT_CREATE_HARDCODEADA(conector, renglon);
                datos = csbaseSAPnet.BAPI_GOODSMVT_CREATE(conector, renglon);
          }
          catch (Exception ex)
          {
              System.Console.WriteLine(ex.Message);
                //System.Console.ReadLine();
                datos.Add(new KeyValuePair<string, string>("Error", "No se alcanzo MIGO, "+ex.Message));
            }
          return datos;
      }

      //public List<KeyValuePair<string, List<RespuestasGenericasModel>>> _disparaCargarOrdenCompra(string companyid)
      //  {
      //      List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
      //      List<KeyValuePair<string, System.Data.DataTable>> respuesta = new List<KeyValuePair<string, System.Data.DataTable>>();
      //      List<KeyValuePair<string, List<RespuestasGenericasModel>>> salida = new List<KeyValuePair<string, List<RespuestasGenericasModel>>>();
      //      SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
      //      try
      //      {
      //          List<KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>> tablas = new List<KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>>();
      //          tablas = csbaseSAPnet.obtenOrdenCompra(conector, companyid, ref datos);
      //          foreach (var estructura in tablas)
      //          {
      //              System.Data.DataTable tbl = csbaseSAPnet.ConvertirRfcTableToDataTable(estructura.Value, estructura.Key);
      //              tbl = csbaseSAPnet.PoblarDataTabledesdeIRfcTable(estructura.Value, tbl);
      //              respuesta.Add(new KeyValuePair<string, System.Data.DataTable>(estructura.Key, tbl));
      //              List<RespuestasGenericasModel> _salida = new List<RespuestasGenericasModel>();
      //              salida.Add(new KeyValuePair<string, List<RespuestasGenericasModel>>(estructura.Key, CargaTabla(tbl, estructura.Key, _salida)));
      //          }
      //      }
      //      catch (Exception ex)
      //      {
      //          System.Console.WriteLine(ex.Message);
      //          System.Console.ReadLine();
      //      }
      //      return salida;
      //  }

        /// <summary>
        /// BAPI relacionada a la extracción del Encabezado,detalles e Historial de Recepciones de una Orden de Compra
        /// </summary>
        /// <param name="conector"></param>
        /// <param name="ordencompra"></param>
        /// <param name="datos"></param>
        /// <param name="estructura_SAP"></param>
        /// <returns></returns>
      public System.Data.DataSet conectores_obtenBAPI_PO_GETDETAIL(SAP.Middleware.Connector.RfcDestination conector, string ordencompra, ref List<KeyValuePair<string, string>> datos,string estructura_SAP)
      {
          List<KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>> tablas = new List<KeyValuePair<string, IRfcTable>>();
          System.Data.DataSet OC = new DataSet();
          if (conector.SystemID != null)
          {
              #region Ejecuta BAPI_PO_GETDETAIL
              try
              {
                  //var funcion = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL");
                  SAP.Middleware.Connector.IRfcFunction ordencompraBapi = conector.Repository.CreateFunction("BAPI_PO_GETDETAIL") ;
                  ordencompraBapi.SetValue("PURCHASEORDER", ordencompra);
                  ordencompraBapi.SetValue("ITEMS", "x");
                  ordencompraBapi.SetValue("ACCOUNT_ASSIGNMENT", "x");
                  ordencompraBapi.SetValue("SCHEDULES", "x");
                  ordencompraBapi.SetValue("CONFIRMATIONS", "x");
                    if (estructura_SAP.Equals("PO_ITEM_HISTORY")==true)
                      ordencompraBapi.SetValue("HISTORY", "x");

                  RfcSessionManager.BeginContext(conector);  
                  ordencompraBapi.Invoke(conector);
                  RfcSessionManager.EndContext(conector);  

                  IRfcTable tblReturn = ordencompraBapi.GetTable("RETURN");
                  try
                  {
                         IRfcParameter tblParameter = ordencompraBapi[1];
                         SAP.Middleware.Connector.IRfcField[] datosEncabezado=tblParameter.GetStructure().ToArray();
                         ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra encabezado = new ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra();
                         encabezado.OrdenCompra = datosEncabezado[0].GetObject().ToString();
                         encabezado.Moneda = datosEncabezado[21].GetObject().ToString();
                         encabezado.Proveedor = datosEncabezado[11].GetObject().ToString();
                         encabezado.Sociedad = datosEncabezado[1].GetObject().ToString();
                         encabezado.PMNTTRMS = datosEncabezado[13].GetObject().ToString();
                         encabezado.tipoOrdenCompra = "Normal";
                         System.Web.HttpContext.Current.Session["Encabezado_" + datosEncabezado[0].GetObject().ToString()] = encabezado;
                  }
                  catch(Exception ex)
                  {
                       //NO SE LOCALIZARON DATOS DE LA ORDEN DE COMPRA ENCABEZADO Ó OCURRIÍO UN ERROR
                      datos.Add(new KeyValuePair<string, string>("Error ", tblReturn[0][2].ToString()+ " adicionalmente "+ex.Message));
                  }
                  try
                  {
                          IRfcTable tbl_SAP = ordencompraBapi.GetTable(estructura_SAP);
                          if (tbl_SAP.RowCount > 0)
                          {
                              datos.Add(new KeyValuePair<string, string>(estructura_SAP, "OK"));
                              tablas.Add(new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>(estructura_SAP, tbl_SAP));
                              System.Data.DataTable tbl = new System.Data.DataTable();
                              tbl = ConvertirRfcTableToDataTable(ref tbl, new KeyValuePair<string, SAP.Middleware.Connector.IRfcTable>(estructura_SAP, tbl_SAP));
                              tbl = PoblarDataTabledesdeIRfcTable(tbl_SAP, tbl);
                                #region       Establece si es una Orden de Servicio
                                string tipoOrden = identificaTipoOrdenxUMedida(tbl.Rows[0].ItemArray[17].ToString());
                                ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra encabezado = System.Web.HttpContext.Current.Session["Encabezado_" + tbl.Rows[0].ItemArray[0].ToString()] as ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra;
                                #endregion Establece si es una Orden de Servicio
                            tbl.TableName = estructura_SAP;
                              OC.Tables.Add(tbl);
                          }
                  }
                  catch(Exception ex)
                  {
                      IRfcStructure tbl_SAP = ordencompraBapi.GetStructure(estructura_SAP);
                  }
                  #endregion Ejecuta BAPI_PO_GETDETAIL
              }
              catch (Exception ex)
              {
                  var encontrado = from actual in datos where actual.Value.Contains(ex.Message) == true select actual;
                  if(encontrado.Count()<=0)
                          datos.Add(new KeyValuePair<string, string>("Error", ex.Message));

              }
          }
          return OC;
      }

    public string identificaTipoOrdenxUMedida(string unidad)
     {
        string tipo = "Normal";
            if(unidad.Length>0)
            {
                ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                var resultado= generico.genericos_consultaCualquierTabla( "Select * From Cat_UMedidaWF Where UnidadMedida='"+unidad+"'");
                if(resultado!=null)
                {
                    if (resultado.Rows.Count > 0)
                    {
                        string proceso = resultado.Rows[0].ItemArray[4].ToString();
                        var workflow = generico.genericos_consultaCualquierTabla("Select * From Cat_ProcesosWF Where idWF=" + proceso);
                        if (workflow != null)
                        {
                            if (workflow.Rows.Count > 0)
                            {
                                tipo = workflow.Rows[0].ItemArray[1].ToString();
                            }
                        }
                    }
                }
                #endregion
            }
            return tipo;
     }

      public List<RespuestasGenericasModel> CargaTabla(System.Data.DataTable tabla, string _tabla, List<RespuestasGenericasModel> salida)
          {
              // List<BAFAR.Models.RespuestasGenericasModel> salida = new List<BAFAR.Models.RespuestasGenericasModel>();
              var a = new RespuestasGenericasModel();
              if (_tabla.Equals("PO_ITEMS") == true)
              {
                  foreach (System.Data.DataRow row in tabla.Rows)
                  {
                      a.R1 = row.ItemArray[0].ToString();
                      a.R2 = row.ItemArray[1].ToString();
                      a.R3 = row.ItemArray[2].ToString();
                      a.R4 = row.ItemArray[3].ToString();
                      a.R5 = row.ItemArray[4].ToString();
                      a.R6 = row.ItemArray[5].ToString();
                      a.R7 = row.ItemArray[6].ToString();
                      a.R8 = row.ItemArray[7].ToString();
                      salida.Add(a);
                  }
              }
              return (salida);
          }
   
        //public JsonResult guardarConfiguracion(string name,string user,string password,string client,string language,string systemnumber,string appserverhost,string maxpoolsize,string idletimeout)
        //{
        //    List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
        //    SAP.Middleware.Connector.RfcDestination conector = BAFAR.Clases.Conector_SAPNET_3.csBaseSAPNET.GetRfcDestination;
        //    try
        //    {
        //        BAFAR.Models.configuarcionConexionSAPModel modelo = new configuarcionConexionSAPModel();
        //        modelo.Name = name;
        //        modelo.User = user;
        //        modelo.Password = password;
        //        modelo.Client = client;
        //        modelo.Language = language;
        //        modelo.SystemNumber = systemnumber;
        //        modelo.AppServerHost = appserverhost;
        //        modelo.MaxPoolSize = maxpoolsize;
        //        modelo.IdleTimeOut = idletimeout;

        //        BAFAR.Clases.Genericos.ad_configuracionConexionSAP guardaParametros = new Clases.Genericos.ad_configuracionConexionSAP();
        //        guardaParametros.actualizaParametros(modelo);
        //        datos.Add(new KeyValuePair<string, string>("Name", name));
        //        datos.Add(new KeyValuePair<string, string>("User", user));
        //        datos.Add(new KeyValuePair<string, string>("Password", password));
        //        datos.Add(new KeyValuePair<string, string>("Client", client));
        //        datos.Add(new KeyValuePair<string, string>("Language", language));
        //        datos.Add(new KeyValuePair<string, string>("SystemNumber", systemnumber));
        //        //datos.Add(new KeyValuePair<string, string>("SystemID", systemid));
        //        datos.Add(new KeyValuePair<string, string>("MaxPoolSize", maxpoolsize));
        //        datos.Add(new KeyValuePair<string, string>("IdleTimeout", idletimeout));
        //        datos.Add(new KeyValuePair<string, string>("AppServerHost", appserverhost));
        //    }
        //    catch (Exception ex)
        //    {
        //        System.Console.WriteLine(ex.Message);
        //        System.Console.ReadLine();
        //    }
        //    return Json(datos);
        //}

      public System.Data.DataTable ConvertirRfcTableToDataTable(ref System.Data.DataTable tabla, KeyValuePair<string, SAP.Middleware.Connector.IRfcTable> param)
      {
          //var columnsMetadata = tableToConvert.Metadata.LineType;
          //var dataTable = new System.Data.DataTable(tableName);
          var columnsMetadata = param.Value.Metadata.LineType;
          var dataTable = new System.Data.DataTable(param.Key.ToString());
          dataTable = tabla.Copy();

          for (var i = 0; i < columnsMetadata.FieldCount; i++)
          {
              dataTable.Columns
                  .Add(columnsMetadata[i].Name, obtenercorrespondenciaSAPDotNetType(columnsMetadata[i].DataType.ToString(), columnsMetadata[i].NucLength));
          }

          return dataTable;
      }

      /// <summary>
      /// Poblar la DataTable con los valores
      /// proporcinados por el RfcTable
      /// </summary>
      /// <param name="rfcTable">Tabla SAP Fuente</param>
      /// <param name="dataTable">DataTable destino</param>
      public System.Data.DataTable PoblarDataTabledesdeIRfcTable(IRfcTable rfcTable, System.Data.DataTable dataTable)
      {
          for (var i = 0; i < rfcTable.RowCount; i++)
          {
              rfcTable.CurrentIndex = i;

              var row = dataTable.NewRow();

              foreach (System.Data.DataColumn column in dataTable.Columns)
              {
                  try
                  {
                      SetDataColumnValueFromRfcColumn(rfcTable.CurrentRow[column.ColumnName], row, column);
                  }
                  catch (Exception ex)
                  {
                      throw new Exception(
                          string.Format("Ocurrio un error intentando agregar el valor a la columna '{0}' de la tabla '{1}'. For more details check inner exception.", column.ColumnName, dataTable.TableName), ex);
                  }
              }

              dataTable.Rows.Add(row);
          }
          return dataTable;
      }

      /// Extraer el valor de la  RfcColumn by using the correct method for the 
      /// column type and put extracted value into the DataColumn.
      /// </summary>
      /// <param name="rfcColumn">Value source.</param>
      /// <param name="dataRow">Value destination.</param>
      /// <param name="dataColumn">Column to be set from destination.</param>
      private void SetDataColumnValueFromRfcColumn(IRfcField rfcColumn, System.Data.DataRow dataRow, System.Data.DataColumn dataColumn)
      {
            if (dataColumn.Caption.Equals("VAL_LOCCUR") == true)
            {
                if (rfcColumn.Metadata.DataType.ToString().Equals("BCD") == true)
                {
                    dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

                    return;
                }
            }
            if (dataColumn.Caption.Equals("VAL_FORCUR") == true)
            {
                if (rfcColumn.Metadata.DataType.ToString().Equals("BCD") == true)
                {
                    dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

                    return;
                }
            }
            if (dataColumn.Caption.Equals("AMOUNT") == true)
            {
                if (rfcColumn.Metadata.DataType.ToString().Equals("BCD") == true)
                {
                    dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

                    return;
                }
            }
            if (dataColumn.Caption.Equals("QUANTITY")==true)
            {
                if (rfcColumn.Metadata.DataType.ToString().Equals("BCD") == true)
                {
                    dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

                    return;
                }
            }
            if (dataColumn.Caption.Equals("NET_PRICE") == true)
            {
                if (rfcColumn.Metadata.DataType.ToString().Equals("BCD") == true)
                {
                    dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

                    return;
                }
            }

            if (dataColumn.DataType == typeof(byte[]))
          {
              dataRow[dataColumn.ColumnName] = rfcColumn.GetByteArray();

              return;
          }

          if (dataColumn.DataType == typeof(int))
          {
              dataRow[dataColumn.ColumnName] = rfcColumn.GetInt();

              return;
          }

          if (dataColumn.DataType == typeof(byte))
          {
              dataRow[dataColumn.ColumnName] = rfcColumn.GetByte();

              return;
          }

          if (dataColumn.DataType == typeof(short))
          {
              dataRow[dataColumn.ColumnName] = rfcColumn.GetShort();

              return;
          }

          if (dataColumn.DataType == typeof(double))
          {
              dataRow[dataColumn.ColumnName] = rfcColumn.GetDouble();

              return;
          }

          dataRow[dataColumn.ColumnName] = rfcColumn.GetString();
      }


      /// <summary>
      /// Mapear tipos SAP a tipos .Net.
      /// </summary>
      /// <param name="sapType">Tipo SAP a mapear</param>
      /// <param name="typeLength">Largo o dominio del tipo SAP type (ejemplo: CHAR(16) => typeLength = 16)</param>
      /// <returns>Tipo .Net</returns>
      private Type obtenercorrespondenciaSAPDotNetType(string sapType, int typeLength)
      {
          switch (sapType)
          {
              case "BYTE":
                  return typeof(byte[]);

              case "INT":
                  return typeof(int);

              case "INT1":
                  return typeof(byte);

              case "INT2":
                  return typeof(short);

              case "FLOAT":
                  return typeof(double);

              case "NUM":

                  if (typeLength <= 9)
                  {
                      return typeof(int);
                  }

                  if (typeLength <= 19)
                  {
                      return typeof(long);
                  }

                  return typeof(string);
                case "BDC":
                    return typeof(string);
                case "BCD":
                    return typeof(string);
                default:
                  return typeof(string);
          }
      }

      #region         CONECTORES Y BAPIS Z

        /// <summary>
      ///  BAPI Z ===> ZMF_CFS_PROVEEDOR_PP
      ///  BAPI desarrollada para recuperar información especifica del Proveedor(es), Sociedad(es) y  Correo(s) que complementa la información necesaria para procesar las facturas
      ///  tales como los RFC, Sociedades relacionadas de un proveedor y sus correos existentes en SAP por ejemplo
        /// </summary>
        /// <param name="S"></param>
        /// <param name="OP"></param>
        /// <param name="Vendor_Low"></param>
        /// <param name="Vendor_High"></param>
        /// <returns></returns>
      public List<KeyValuePair<string, string>> BAPIZ_dispara_obtenInformacionProveedoresGral_ZMF_CFS_PROVEEDOR_PP(string S, string OP, string Vendor_Low, string Vendor_High,int Tipo)
      {

          List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
          SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
          try
          {
              switch (Tipo)
              {
                  case 1:
                      #region Configuración 1 Solo Proveedor Tipo=1 IMPORTANDO DE SAP
                      datos = csbaseSAPnet.BAPIZ_obtenInformacionProveedoresGral(conector, S, OP, Vendor_Low, Vendor_High, Tipo);
                      #region        Envia a la Base de Datos del Portal
                      List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> proveedores = new List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor>();
                      List<string> mensajes = new List<string>();
                      mensajes.Add("Proceso iniciado " + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString());
                      using (var ctx = new Desarrollo_CF())
                      {
                          ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                          #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                          var _proveedor = generico.genericos_consultaCualquierTabla(Vendor_Low.Count() == 0 ? "Select * From Cat_Proveedor " : "Select * From Cat_Proveedor Where Num_Proveedor='" + Vendor_Low + "'");
                          #endregion
                          if (_proveedor != null)
                          {
                              if (_proveedor.Rows.Count > 0)
                              {
                                  foreach (DataRow p in _proveedor.AsEnumerable())
                                  {
                                      #region recuperacion y carga de la información
                                      ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                      proveedor.IdProveedor = p.Field<int>("IdProveedor");
                                      proveedor.Nombre = p.Field<string>("Nombre");
                                      proveedor.Num_Sociedad = p.Field<string>("Num_Sociedad");
                                      proveedor.Num_Proveedor = p.Field<string>("Num_Proveedor");
                                      proveedor.Sociedad = p.Field<string>("Sociedad");
                                      proveedor.Pais = p.Field<string>("Pais");
                                      proveedor.Direccion = p.Field<string>("Direccion");
                                      proveedor.GrupoCA = p.Field<string>("GrupoCA");
                                      proveedor.RFC = p.Field<string>("RFC");
                                      proveedor.CPD = p.Field<string>("CPD");
                                      proveedor.GrupoCCPD = p.Field<string>("GrupoCCPD");
                                      proveedor.Correo = p.Field<string>("Correo");
                                      proveedor.Activo = p.Field<bool>("Activo");
                                      proveedor.P_General = p.Field<decimal>("P_General");
                                      proveedor.P_Comercial = p.Field<decimal>("P_Comercial");
                                      proveedor.RFC2 = p.Field<string>("RFC2");
                                      proveedor.Poblacion = p.Field<string>("Poblacion");
                                      proveedores.Add(proveedor);
                                      #endregion recuperacion y carga de la información
                                  }
                                  mensajes.Add("Se han encontrado " + proveedores.Count().ToString() + " proveedores actualmente registrados en el Portal relacionados al número de proveedor específicado.");
                              }
                              else
                              {
                                  mensajes.Add("No existen proveedores registrados en el Portal actualmente.Se inicia el proceso de registro hacia el Portal");

                                  ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                  //proveedor.IdProveedor = 0;
                                  var nombre = from d in datos where d.Key.Equals("NAME1") == true select d.Value;
                                  string _nombre = nombre.FirstOrDefault();
                                  proveedor.Nombre = _nombre;
                                  if(_nombre.Contains("Error")==false)
                                  {
                                          #region Insertando si no fue erronea la localización en SAP 
                                          #region recuperacion y carga de la información
                                          var num_sociedad = from d in datos where d.Key.Equals("BUKRS") == true select d.Value;
                                          string _num_sociedad = num_sociedad.FirstOrDefault();
                                          proveedor.Num_Sociedad = _num_sociedad;

                                          proveedor.Num_Proveedor = Vendor_Low;

                                          proveedor.Sociedad = _num_sociedad;

                                          var pais = from d in datos where d.Key.Equals("LAND1") == true select d.Value;
                                          string _pais = pais.FirstOrDefault();
                                          proveedor.Pais = _pais;

                                          proveedor.Direccion = "";
                                          proveedor.GrupoCA = "";

                                          //RFC
                                          var rfc = from d in datos where d.Key.Equals("STCD1") == true select d.Value;
                                          string _rfc = rfc.FirstOrDefault();
                                          proveedor.RFC = _rfc;

                                          proveedor.CPD = "";
                                          proveedor.GrupoCCPD = "";

                                          var correo = from d in datos where d.Key.Equals("ADRNR") == true select d.Value;
                                          string _correo = correo.FirstOrDefault();
                                          proveedor.Correo = _correo;

                                          proveedor.Activo = true;
                                          proveedor.P_General = 0;
                                          proveedor.P_Comercial = 0;
                                          proveedor.RFC2 = "";
                                          proveedor.Poblacion = "";
                                          proveedores.Add(proveedor);
                                          #endregion recuperacion y carga de la información
                                          #region Guardando Información en Cat_Proveedores y Cat Usuarios
                                          foreach (Cat_Proveedor prov in proveedores)
                                          {
                                              ctx.Cat_Proveedor.Add(prov);
                                              ctx.SaveChanges();
                                              mensajes.Add("Proveedor número " + Vendor_Low + " importado desde SAP al Portal exitosamente!");
                                              int _ID = prov.IdProveedor;
                                              Cat_Usuario usuario = new Cat_Usuario();
                                              usuario.Activo = false;
                                              usuario.Usuario = Vendor_Low;
                                              usuario.Password = Vendor_Low;
                                              usuario.Correo = "";
                                              usuario.IdPerfil = 3;// Definir por parametro cual seria el Perfil por default en general para arranque de proveedores
                                              usuario.IdProveedor = _ID;
                                              ctx.Cat_Usuario.Add(usuario);
                                              ctx.SaveChanges();
                                              mensajes.Add("Usuario básico del Proveedor " + Vendor_Low + "  tambien ha sido creado exitosamente!.");
                                              mensajes.Add("El proveedor ya puede comenzar a realizar operaciones.");
                                          }
                                          #endregion Guardando Información en Cat_Proveedores y Cat Usuarios
                                          #endregion Insertando si no fue erronea la localización en SAP
                                  }
                                  else
                                  {
                                      datos.Add(new KeyValuePair<string, string>("Error", "No se encontro el No. de Proveedor capturado en SAP" + _nombre));
                                  }
                              }
                          }
                          else
                          {
                              mensajes.Add("No existen proveedores registrados en el Portal actualmente.");
                          }
                      }
                      #endregion  Envia a la Base de Datos del Portal
                      break;
                      #endregion Configuración 1 Solo Proveedor Tipo=1 IMPORTANDO DE SAP
                  case 0:
                      #region        Consultando datos de Cat_Proveedor solo 1
                      List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> proveedoresConsulta = new List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor>();
                      using (var ctx = new Desarrollo_CF())
                      {
                          ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                          #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                          var _proveedor = generico.genericos_consultaCualquierTabla(Vendor_Low.Count() == 0 ? "Select * From Cat_Proveedor " : "Select * From Cat_Proveedor Where RFC='" + Vendor_Low + "'");
                          #endregion
                          if (_proveedor != null)
                          {
                              if (_proveedor.Rows.Count > 0)
                              {
                                  foreach (DataRow p in _proveedor.AsEnumerable())
                                  {
                                      #region recuperacion y carga de la información
                                      ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                      proveedor.IdProveedor = p.Field<int>("IdProveedor");
                                      proveedor.Nombre = p.Field<string>("Nombre");
                                      proveedor.Num_Sociedad = p.Field<string>("Num_Sociedad");
                                      proveedor.Num_Proveedor = p.Field<string>("Num_Proveedor");
                                      proveedor.Sociedad = p.Field<string>("Sociedad");
                                      proveedor.Pais = p.Field<string>("Pais");
                                      proveedor.Direccion = p.Field<string>("Direccion");
                                      proveedor.GrupoCA = p.Field<string>("GrupoCA");
                                      proveedor.RFC = p.Field<string>("RFC");
                                      proveedor.CPD = p.Field<string>("CPD");
                                      proveedor.GrupoCCPD = p.Field<string>("GrupoCCPD");
                                      proveedor.Correo = p.Field<string>("Correo");
                                      proveedor.Activo = p.Field<bool>("Activo");
                                      proveedor.P_General = p.Field<decimal>("P_General");
                                      proveedor.P_Comercial = p.Field<decimal>("P_Comercial");
                                      proveedor.RFC2 = p.Field<string>("RFC2");
                                      proveedor.Poblacion = p.Field<string>("Poblacion");
                                      datos.Add(new KeyValuePair<string,string>("Nombre",p.Field<string>("Nombre")));
                                      datos.Add(new KeyValuePair<string, string>("RFC", p.Field<string>("RFC")));
                                      datos.Add(new KeyValuePair<string, string>("Sociedad", p.Field<string>("Sociedad")));
                                      datos.Add(new KeyValuePair<string, string>("Num_Proveedor", p.Field<string>("Num_Proveedor")));
                                      //proveedoresConsulta.Add(proveedor);
                                      break;
                                      #endregion recuperacion y carga de la información
                                  }
                              }
                          }
                      }
                 #endregion Consultando datos de Cat_Proveedor solo 1
                 break;
                  case 2:
                      #region Configuración 1 Solo Proveedor Tipo=2 Recuperando Retenciones
                        datos = csbaseSAPnet.BAPIZ_obtenInformacionProveedoresGral(conector, S, OP, Vendor_Low, Vendor_High, Tipo);
                                  var nombreR = from d in datos where d.Key.Equals("NAME1") == true select d.Value;
                                  string _nombreR = nombreR.FirstOrDefault();
                                  if (_nombreR == null)
                                      _nombreR = "Encontrado";
                                  if(_nombreR.Equals("Error")==false)
                                  {
                                      ClickFactura_Entidades.BD.Modelos.retencionesProveedor r = new ClickFactura_Entidades.BD.Modelos.retencionesProveedor();
                                      foreach(KeyValuePair<string,string> item in datos)
                                      {
                                          string campo = item.Key;
                                          string valor = item.Value;
                                          if (campo.Equals("MANDT") == true)
                                          {
                                              r.MANDT = valor;
                                          }
                                          if (campo.Equals("LIFNR") == true)
                                          {
                                              r.LIFNR = valor;
                                          }
                                          if (campo.Equals("BUKRS") == true)
                                          {
                                              r.BUKRS = valor;
                                          }
                                          if (campo.Equals("WITHT") == true)
                                          {
                                              r.WITHT = valor;
                                          }
                                          if (campo.Equals("WT_SUBJCT") == true)
                                          {
                                              r.WT_SUBJCT = valor;
                                          }
                                          if (campo.Equals("QSREC") == true)
                                          {
                                              r.QSREC = valor;
                                          }
                                          if (campo.Equals("WT_WTSTCD") == true)
                                          {
                                              r.WT_WTSTCD = valor;
                                          }
                                          if (campo.Equals("WT_WITHCD") == true)
                                          {
                                              r.WT_WITHCD = valor;
                                          }
                                          if (campo.Equals("WT_EXNR") == true)
                                          {
                                              r.WT_EXNR = valor;
                                          }
                                          if (campo.Equals("WT_EXRT") == true)
                                          {
                                              r.WT_EXRT = valor;
                                          }
                                          if (campo.Equals("WT_EXDF") == true)
                                          {
                                              r.WT_EXDF = valor;
                                          }
                                          if (campo.Equals("WT_EXDT") == true)
                                          {
                                              r.WT_EXDT = valor;
                                          }
                                          if (campo.Equals("WT_WTEXRS") == true)
                                          {
                                              r.WT_WTEXRS = valor;
                                          }
                                      }
                                      System.Web.HttpContext.Current.Session["retenciones_"+Vendor_Low] = r;
                                  }
                                  else
                                  {
                                      datos.Add(new KeyValuePair<string, string>("Error", "No se encontraron Retenciones para el  No. de Proveedor , por favor corrobóre esto en SAP"));
                                      System.Web.HttpContext.Current.Session["retenciones_" + Vendor_Low] = null;
                                  }
                        
                        break;
                        #endregion Configuración 1 Solo Proveedor Tipo=2 Recuperando Retenciones
                  case 3:
                        #region Configuración todos los Proveedor Tipo=3 desde SAP
                        datos = csbaseSAPnet.BAPIZ_obtenInformacionProveedoresGral(conector, S, OP, Vendor_Low, Vendor_High, Tipo);
                        #region        Envia a la Base de Datos del Portal
                        List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> proveedoresAll = new List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor>();
                        List<string> mensajesAll = new List<string>();
                        mensajesAll.Add("Proceso iniciado de extracción de todos" + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString());
                        using (var ctx = new Desarrollo_CF())
                        {
                            ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                            //#region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                            ////var _proveedor = generico.genericos_consultaCualquierTabla(Vendor_Low.Count() == 0 ? "Select * From Cat_Proveedor " : "Select * From Cat_Proveedor Where Num_Proveedor='" + Vendor_Low + "'");
                            //#endregion
                            //if (_proveedor != null)
                            if (datos != null)
                            {
                                 //   if (_proveedor.Rows.Count > 0)
                                if (datos.Count <= 0)
                                {
                                    #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                                    var _proveedor = generico.genericos_consultaCualquierTabla(Vendor_Low.Count() == 0 ? "Select * From Cat_Proveedor " : "Select * From Cat_Proveedor Where Num_Proveedor='" + Vendor_Low + "'");
                                    #endregion
                                    foreach (DataRow p in _proveedor.AsEnumerable())
                                    {
                                        #region recuperacion y carga de la información
                                        ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                        proveedor.IdProveedor = p.Field<int>("IdProveedor");
                                        proveedor.Nombre = p.Field<string>("Nombre");
                                        proveedor.Num_Sociedad = p.Field<string>("Num_Sociedad");
                                        proveedor.Num_Proveedor = p.Field<string>("Num_Proveedor");
                                        proveedor.Sociedad = p.Field<string>("Sociedad");
                                        proveedor.Pais = p.Field<string>("Pais");
                                        proveedor.Direccion = p.Field<string>("Direccion");
                                        proveedor.GrupoCA = p.Field<string>("GrupoCA");
                                        proveedor.RFC = p.Field<string>("RFC");
                                        proveedor.CPD = p.Field<string>("CPD");
                                        proveedor.GrupoCCPD = p.Field<string>("GrupoCCPD");
                                        proveedor.Correo = p.Field<string>("Correo");
                                        proveedor.Activo = p.Field<bool>("Activo");
                                        proveedor.P_General = p.Field<decimal>("P_General");
                                        proveedor.P_Comercial = p.Field<decimal>("P_Comercial");
                                        proveedor.RFC2 = p.Field<string>("RFC2");
                                        proveedor.Poblacion = p.Field<string>("Poblacion");
                                        proveedoresAll.Add(proveedor);
                                        #endregion recuperacion y carga de la información
                                    }
                                    mensajesAll.Add("Se han encontrado " + proveedoresAll.Count().ToString() + " proveedores actualmente registrados en el Portal relacionados al número de proveedor específicado.");
                                }
                                else
                                {
                                    List<ClickFactura_Entidades.BD.Modelos.Proveedores> _datos=convierteEnLista(datos);
                                    datos.Clear();
                                    datos.Add(new KeyValuePair<string, string>("Inicio", "Proceso de importación para "+_datos.Count().ToString() +" de la Sociedad "+ Vendor_Low+ " inicio pero esta pendiente su conclusión, revise no ocurran errores."));
                                    foreach(ClickFactura_Entidades.BD.Modelos.Proveedores prov in _datos)
                                    {
                                        #region INSERTANDO PROVEEDOR
                                                    mensajesAll.Add("Se inicia la inserción masiva inicia el proceso de registro hacia el Portal");

                                                    ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                                    //proveedor.IdProveedor = 0;
                                                    //var nombre = from d in prov where d.Key.Equals("NAME1") == true select d.Value;
                                                    //string _nombre = nombre.FirstOrDefault();
                                                    //proveedor.Nombre = _nombre;
                                                    string _nombre = prov.NAME1;
                                                    proveedor.Nombre = prov.NAME1;
                                                    if (_nombre.Contains("Error") == false)
                                                    {
                                                        #region Insertando si no fue erronea la localización en SAP
                                                        #region recuperacion y carga de la información
                                                        //var num_sociedad = from d in datos where d.Key.Equals("BUKRS") == true select d.Value;
                                                        //string _num_sociedad = num_sociedad.FirstOrDefault();
                                                        string _num_sociedad = prov.BUKRS; //num_sociedad.FirstOrDefault();
                                                        proveedor.Num_Sociedad = prov.BUKRS;// _num_sociedad;

                                                        proveedor.Num_Proveedor = prov.LIFNR;// Vendor_Low;

                                                        proveedor.Sociedad = _num_sociedad;

                                                        //var pais = from d in datos where d.Key.Equals("LAND1") == true select d.Value;
//                                                        string _pais = pais.FirstOrDefault();
                                                        string _pais = prov.LAND1;
                                                        proveedor.Pais = _pais;

                                                        proveedor.Direccion = "";
                                                        proveedor.GrupoCA = "";

                                                        //RFC
                                                        //var rfc = from d in datos where d.Key.Equals("STCD1") == true select d.Value;
                                                        string _rfc = prov.STCD1;// rfc.FirstOrDefault();
                                                        proveedor.RFC = _rfc;

                                                        proveedor.CPD = "";
                                                        proveedor.GrupoCCPD = "";

                                                        //var correo = from d in datos where d.Key.Equals("ADRNR") == true select d.Value;
                                                        string _correo = prov.ADRNR;// correo.FirstOrDefault();
                                                        proveedor.Correo = _correo;

                                                        proveedor.Activo = true;
                                                        proveedor.P_General = 0;
                                                        proveedor.P_Comercial = 0;
                                                        proveedor.RFC2 = prov.STCD3;
                                                        proveedor.Poblacion = "";
                                                        proveedoresAll.Clear();
                                                        proveedoresAll.Add(proveedor);
                                                        #endregion recuperacion y carga de la información
                                                        #region Guardando Información en Cat_Proveedores y Cat Usuarios
                                                        foreach (Cat_Proveedor _prov in proveedoresAll)
                                                        {
                                                            try
                                                            {
                                                                #region revisando si ya existia
                                                                String Recupera = "";
                                                                string Id = "-1";
                                                                try
                                                                {
                                                                    Recupera = "Select IdProveedor From dbo.Cat_Proveedor  Where Nombre='" + proveedor.Nombre + "' And Num_Proveedor='" + proveedor.Num_Proveedor + "' And Num_Sociedad='" + proveedor.Num_Sociedad + "' ";
                                                                    DataTable t = generico.genericos_consultaCualquierTabla(Recupera);
                                                                     Id = t.Rows[0].ItemArray[0].ToString();
                                                                }
                                                                catch(Exception _n)
                                                                {
                                                                    //datos.Add(new KeyValuePair<string, string>("Error", "Ocurrío un error inspecionando si existía el proveedor " + proveedor.Nombre+" con no. de proveedor "+proveedor.Num_Proveedor));
                                                                    Id = "-1";
                                                                }
                                                                #endregion  revisando si ya existia
                                                                if(Convert.ToInt32(Id)< 0)
                                                                {
                                                                            #region Proceso de Inserción NO EXISTE Y ES NUEVO
                                                                                //ctx.Cat_Proveedor.Add(_prov);
                                                                                //ctx.SaveChanges();
                                                                                var currVal = DateTime.Now.Ticks;
                                                                                string Inserta = "";
                                                                                Inserta = "Insert into dbo.Cat_Proveedor (Nombre, Num_Sociedad, Num_Proveedor, Sociedad, Pais, Direccion, GrupoCA, RFC, CPD, GrupoCCPD, Correo, Activo, P_General, P_Comercial, RFC2, Poblacion) Values (";
                                                                                Inserta = Inserta + "'"+ proveedor.Nombre + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Num_Sociedad + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Num_Proveedor + "', ";// currVal + "', ";//proveedor.Num_Proveedor + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Sociedad + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Pais + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Direccion + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.GrupoCA + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.RFC + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.CPD + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.GrupoCCPD + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Correo + "', ";
                                                                                Inserta = Inserta + (proveedor.Activo==true?"1":"0") + ", ";
                                                                                Inserta = Inserta + proveedor.P_General + ", ";
                                                                                Inserta = Inserta + proveedor.P_Comercial + ", ";
                                                                                Inserta = Inserta + "'" + proveedor.RFC2 + "', ";
                                                                                Inserta = Inserta + "'" + proveedor.Poblacion + "') ";
                                                                                try
                                                                                {
                                                                                    generico.genericos_consultaCualquierTabla(Inserta);
                                                                                    datos.Add(new KeyValuePair<string, string>("Importado ", "El proveedor " + proveedor.Nombre + " con el no. de proveedor  " + proveedor.Num_Proveedor + " ya fue ingresado exitosamente!"));
                                                                                    Recupera ="";
                                                                                    Recupera = "Select IdProveedor From dbo.Cat_Proveedor  Where Nombre='" + proveedor.Nombre + "' And Num_Proveedor='" + proveedor.Num_Proveedor + "' And Num_Sociedad='" + proveedor.Num_Sociedad + "' ";
                                                                                    DataTable t=generico.genericos_consultaCualquierTabla(Recupera);
                                                                                    var ID = t.Rows[0].ItemArray[0].ToString();
                                                                                    mensajesAll.Add("Proveedor número " + proveedor.Num_Proveedor + " importado desde SAP al Portal exitosamente!");
                                                                                    int _ID = Convert.ToInt32(ID);// _prov.IdProveedor;
                                                                                    Cat_Usuario usuario = new Cat_Usuario();
                                                                                    usuario.Activo = true;
                                                                                    usuario.Usuario = proveedor.RFC.Length > 0 ? proveedor.RFC : proveedor.RFC2.Length > 0 ? proveedor.RFC2 : proveedor.Num_Proveedor ;
                                                                                    usuario.Password = proveedor.RFC.Length > 0 ? proveedor.RFC : proveedor.RFC2.Length > 0 ? proveedor.RFC2 : proveedor.Num_Proveedor ;
                                                                                    usuario.Correo = "";
                                                                                  #region extrae la moneda del Sistema
                                                                                    int perfilEstandarProveedor = 1;
                                                                                    int result = 0;
                                                                                    adT_Parametros adp = new adT_Parametros();
                                                                                    List<objT_Parametros> objp = new List<objT_Parametros>();
                                                                                    objp = adp.mABCT_Parametros(out result, 0, "IdPerfilEstandarProveedor", "Vacio", true, "ConsultaValor");
                                                                                    {
                                                                                        perfilEstandarProveedor = Convert.ToInt32(objp[0].ValorParametro.ToString());
                                                                                    }
                                                                                    #endregion extrae la moneda del Sistema
                                                                                    usuario.IdPerfil = perfilEstandarProveedor;// Definir por parametro cual seria el Perfil por default en general para arranque de proveedores
                                                                                   usuario.IdProveedor = _ID;
                                                                                    ctx.Cat_Usuario.Add(usuario);
                                                                                    ctx.SaveChanges();
                                                                                    mensajesAll.Add("Usuario básico del Proveedor " + proveedor.Num_Proveedor + "  tambien ha sido creado exitosamente!.");
                                                                                    mensajesAll.Add("El proveedor ya puede comenzar a realizar operaciones.");
                                                                                    datos.Add(new KeyValuePair<string, string>("Usuario de logeo ", "Para el proveedor " + proveedor.Nombre + " con el no. de proveedor  " + proveedor.Num_Proveedor + " fue creado su usuario interno " + usuario.Usuario + " exitosamente!"));
                                                                                }
                                                                                catch(Exception _m)
                                                                                {
                                                                                    string m = _m.Message;
                                                                                }
                                                                            //Fin decimal insertar al Proveedor
                                                                                #endregion Proceso de inserción
                                                                }
                                                                else
                                                                {
                                                                    #region Ya existia el Proveedor
                                                                    string Actualiza = "";
                                                                    Actualiza = "Update dbo.Cat_Proveedor  Set ";
                                                                    Actualiza = Actualiza + " Num_Proveedor='" + proveedor.Num_Proveedor+ "' , " ;
                                                                    Actualiza = Actualiza + " Nombre='" + proveedor.Nombre + "' , ";
                                                                    Actualiza = Actualiza + " Num_Sociedad='" + proveedor.Num_Sociedad + "' , ";
                                                                    Actualiza = Actualiza + " Sociedad='" + proveedor.Sociedad + "' , ";
                                                                    Actualiza = Actualiza + " Direccion ='" + proveedor.Direccion + "' , ";
                                                                    Actualiza = Actualiza + " RFC='" + proveedor.RFC + "' , ";
                                                                    Actualiza = Actualiza + " GrupoCA='" + proveedor.GrupoCA + "' , ";
                                                                    Actualiza = Actualiza + " CPD='" + proveedor.CPD + "' , ";
                                                                    Actualiza = Actualiza + " GrupoCCPD='" + proveedor.GrupoCCPD+ "' , ";
                                                                    Actualiza = Actualiza + " Correo='" + proveedor.Correo + "' , ";
                                                                    Actualiza = Actualiza + " P_General= " + Convert.ToInt64(proveedor.P_General).ToString() + " , ";
                                                                    Actualiza = Actualiza + " P_Comercial =" + Convert.ToInt64(proveedor.P_Comercial).ToString() + " , ";
                                                                    Actualiza = Actualiza + " RFC2 ='" + proveedor.RFC2 + "' , ";
                                                                    Actualiza = Actualiza + " Poblacion='" + proveedor.Poblacion + "'  ";
                                                                     Actualiza = Actualiza + " Where IdProveedor=" + Id + " ";
                                                                     try
                                                                     {
                                                                        generico.genericos_consultaCualquierTabla(Actualiza);
                                                                        datos.Add(new KeyValuePair<string, string>(" Actualización ", "Se actualizó la información del proveedor " + proveedor.Nombre + "previamente ingresado, con el no. de proveedor  " + proveedor.Num_Proveedor));
                                                                     }
                                                                    catch(Exception _K)
                                                                     {
                                                                         datos.Add(new KeyValuePair<string, string>("Error", "Ocurrio un problema actulizando la información de un proveedor " + proveedor.Nombre + "previamente ingresado, con el no. de proveedor  " + proveedor.Num_Proveedor+" , error "+_K.Message));
                                                                    }
                                                                    #endregion Ya existia el Proveedor
                                                                }
                                                            }
                                                            catch(Exception _ex)
                                                            {
                                                                  string _exx = _ex.Message;
                                                                  datos.Add(new KeyValuePair<string, string>(" Error ", "Uno o varios elementos para importar del listado de " + _datos.Count().ToString() + " elementos de la Sociedad " + Vendor_Low));
                                                            }
                                                        }
                                                        #endregion Guardando Información en Cat_Proveedores y Cat Usuarios
                                                        #endregion Insertando si no fue erronea la localización en SAP
                                                    }
                                                    else
                                                    {
                                                        datos.Add(new KeyValuePair<string, string>("Error", "No se encontro el No. de Proveedor capturado en SAP" + _nombre));
                                                    }
                                        #endregion INSERTANDO PROVEEDOR
                                    }

                                }
                            }
                            else
                            {
                                mensajesAll.Add("No existen proveedores registrados en el Portal actualmente.");
                                
                            }
                        }
                        #endregion  Envia a la Base de Datos del Portal
                        break;
                        #endregion Configuración 1 Solo Proveedor Tipo=1 IMPORTANDO DE SAP
              }

          }
          catch (Exception ex)
          {
              datos.Add(new KeyValuePair<string, string>("Error", ex.Message));
              System.Console.WriteLine(ex.Message);
          }
          
          return datos;
      }

     private  List<ClickFactura_Entidades.BD.Modelos.Proveedores> convierteEnLista(List<KeyValuePair<string,string>>datos)
     {
         List<ClickFactura_Entidades.BD.Modelos.Proveedores> salidaProveedores = new List<ClickFactura_Entidades.BD.Modelos.Proveedores>();
         int contador = 1;
         string LIFNR = "";
         string BUKRS = "";
         string LAND1 = "";
         string NAME1 = "";
         string ADRNR = "";
         string KTOKK = "";
         string LOEVM = "";
         string STCD1 = "";
         string XCPDK = "";
         string STCD3 = "";
         string BUTXT = "";
         string RFCSO = "";
         foreach(KeyValuePair<string, string> origen in datos)
         {
             #region carga
                                                                           //1datos.Add(new KeyValuePair<string, string>("LIFNR", detailAl.GetString("LIFNR")));
                                                                           //2 datos.Add(new KeyValuePair<string, string>("BUKRS", detailAl.GetString("BUKRS")));
                                                                           //3 datos.Add(new KeyValuePair<string, string>("LAND1", detailAl.GetString("LAND1")));
                                                                           //4 datos.Add(new KeyValuePair<string, string>("NAME1", detailAl.GetString("NAME1")));
                                                                           //5 datos.Add(new KeyValuePair<string, string>("ADRNR", detailAl.GetString("ADRNR")));
                                                                           //6 datos.Add(new KeyValuePair<string, string>("KTOKK", detailAl.GetString("KTOKK")));
                                                                           //7 datos.Add(new KeyValuePair<string, string>("LOEVM", detailAl.GetString("LOEVM")));
                                                                           //8 datos.Add(new KeyValuePair<string, string>("STCD1", detailAl.GetString("STCD1")));
                                                                           //9 datos.Add(new KeyValuePair<string, string>("XCPDK", detailAl.GetString("XCPDK")));
                                                                           //10 datos.Add(new KeyValuePair<string, string>("STCD3", detailAl.GetString("XCPDK")));
                                                                           //11datos.Add(new KeyValuePair<string, string>("BUTXT", detailAl.GetString("BUTXT")));
                                                                           //12 datos.Add(new KeyValuePair<string, string>("RFCSO", detailAl.GetString("RFCSO")));
             if (origen.Key.Equals("LIFNR") == true) { 
                LIFNR = origen.Value;
                 contador++;
             }
             if (origen.Key.Equals("BUKRS") == true)
             {
                 BUKRS = origen.Value;
                 contador++;
             }
             if (origen.Key.Equals("LAND1") == true)
             {
                 LAND1 = origen.Value;
                 contador++;
             }
             if (origen.Key.Equals("NAME1") == true)
             {
                 NAME1 = origen.Value;
                 contador++;
             }
             if (origen.Key.Equals("ADRNR") == true)
             {
               ADRNR = origen.Value;
              contador++;
             }
             if (origen.Key.Equals("KTOKK") == true)
             {
                 KTOKK = origen.Value;
                contador++;
             }
             if (origen.Key.Equals("LOEVM") == true)
             {
                 LOEVM = origen.Value;
                 contador++;
             }
             if (origen.Key.Equals("STCD1") == true)
             {
                 STCD1 = origen.Value;
             contador++;
             }
             if (origen.Key.Equals("XCPDK") == true)
             {
                 XCPDK = origen.Value;
             contador++;
             }
             if (origen.Key.Equals("STCD3") == true)
             {
                 STCD3 = origen.Value;
             contador++;
             }
             if (origen.Key.Equals("BUTXT") == true)
             {
                 BUTXT = origen.Value;
             contador++;
             }
             if (origen.Key.Equals("RFCSO") == true)
             {
                 RFCSO = origen.Value;
                contador++;
             }
             if (contador > 13)
             {
                 ClickFactura_Entidades.BD.Modelos.Proveedores destino = new ClickFactura_Entidades.BD.Modelos.Proveedores();
                 destino.LIFNR = LIFNR;
                 destino.KTOKK = KTOKK;
                 destino.LAND1 = LAND1;
                 destino.LOEVM = LOEVM;
                 destino.NAME1 = NAME1;
                 destino.RFCSO = RFCSO;
                 destino.STCD1 = STCD1;
                 destino.STCD3 = STCD3;
                 destino.XCPDK = XCPDK;
                 destino.ADRNR = ADRNR;
                 destino.BUKRS = BUKRS;
                 destino.BUTXT = BUTXT;
                 salidaProveedores.Add(destino);
                 contador = 1;
                  LIFNR = "";
                  BUKRS = "";
                  LAND1 = "";
                  NAME1 = "";
                  ADRNR = "";
                  KTOKK = "";
                  LOEVM = "";
                  STCD1 = "";
                  XCPDK = "";
                  STCD3 = "";
                  BUTXT = "";
                  RFCSO = "";
             }
             #endregion carga
         }
         return salidaProveedores;
     }

      #endregion CONECTORES Y BAPIS Z

       #endregion Implementación de Conectores #######################################################################################

      #region Implementación y operaciones de Recepciones  #################################################################################################

      #region Grid de Recepciones (Vista)
      public ClickFactura_Entidades.BD.Modelos.TablaGeneralModel ListadoOrdenesRecepciones(ref string orden, string numProveedor, string tipoUsuario, string sociedadVerificar,out string tablaDetalle, out string mensaje, bool soloOrden = false, bool esAdmin = false)
      {
          mensaje = "";
          try
          {
              Dictionary<string, string> columnas = new Dictionary<string, string>();
              columnas.Add("Posicion_OrdenCompra", "Pos. OC");        //R1
              columnas.Add("Numero_Documento", "Documento Recepcion");//R2
              columnas.Add("Posicion_Documento", "Pos. Recep");       //R3
              columnas.Add("Tipo_Movimiento", "Tipo Movimiento");     //R4
              columnas.Add("Fecha_Contable", "Fecha");                //R5
              columnas.Add("Cantidad", "Cantidad");                   //R6
              columnas.Add("Importe_Documento", "Importe Documento"); //R7
              columnas.Add("Descripcion", "Descripción");             //R8
              columnas.Add("Indicador_IVA", "Ind. Impuesto");         //R9
              columnas.Add("Numero_Cancelacion", "Numero_Cancelacion");//R10
              columnas.Add("Unidad_Medida", "Unidad_Medida");         //R11
              columnas.Add("Numero_Pasivo", "Numero_Pasivo");            //R12
              columnas.Add("YearDocumento", "YearDocumento");         //R13
              columnas.Add("YearDocumentoRef", "YearDocumentoRef");   //R14
              columnas.Add("Posicion_DocumentoRef", "Posicion_DocumentoRef");//R15
              columnas.Add("Documento_Referencia", "Documento_Referencia");//R16
              columnas.Add("Importe", "Importe");                   //R17
              string[] template = { "", "", "", "", "", "", "#: kendo.format('{0:c}', R7) #", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" };
              bool[] filtros = { false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
              bool[] ocultos = { false, false, false, false, false, false, false, false, false, true, true, true, true, true, true, true, true, false, false, false, false, false };

              string[] AnchoColumna = { "80px", "200px", "80px", "60px", "150px", "100px", "100px", "400px", "60px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px", "100px" };
              ClickFactura_Entidades.BD.Modelos.TablaGeneralModel tabla = new ClickFactura_Entidades.BD.Modelos.TablaGeneralModel();
              tabla.Personalizar = true;
              tabla.ControlPersonalizado = "<button type=\"button\" class=\"btn btn-success\" style=\"padding: 0px; width: 25px; height:25px; border-radius:45px;\"><i style=\"padding-top:0px;\" class=\"fa fa-check-circle\"></i></button>";
              tabla.NombreBtnPersonalizado = "btnCheck";
              tabla.SendDataKey = true;
              tabla.EventoClick = "Seleccionar";
              tabla.Seleccionar = false;
              tabla.NombreCreate = "Crear";
              tabla.NombreUpdate = "Actualizar";
              tabla.Control = "OrdenyRecepcion";
              tabla._Edicion = "onEdit";
              tabla._Guardar = "onSave";
              tabla.ID = "R3";
              tabla.BtnToolbarPersonalizado = true;
              tabla.TemplatePersonalizado = "<button type=\"button\" id=\"btnSeleccionarTodo\" onclick=\"SeleccionarTodo(this)\" class=\"btn btn-info\" ><i style=\"padding-top:0px;\" class=\"fa fa-check-circle\"></i>Seleccionar Todo</button>";
              tabla.NombreExcel = "excel.xlsx";
              tabla.Numerico = false;
              int x = 1;

              DataTable recepciones = new DataTable();
              DataTable incrementables = new DataTable();
              //Devuelve el detalle de Compra
              var dTabla = ObtenerRegistrosOrden(ref orden, numProveedor, ref incrementables, ref recepciones, sociedadVerificar, soloOrden, esAdmin);

              if(dTabla!=null)
                {
                    bool inhabilta = false;
                  foreach(DataRow revisarIndicadorIVA in dTabla.Rows)
                    {
                        if(revisarIndicadorIVA[29].ToString().Contains("Error")==true)
                        {
                            inhabilta = true;
                        }
                    }
                   if(inhabilta==true)
                    {
                        AnchoColumna[8] = "210px";
                    }
                }
              bool laOrdenesMia = false;
              string filtroEsmiOrden = System.Configuration.ConfigurationManager.AppSettings["habilitarOCequalProveedor"];
              string esAdmon = ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.EsAdministradorBafar(System.Web.HttpContext.Current.Session["Usuario"] as string).ToString();
                filtroEsmiOrden = esAdmon.Equals("True") == true ? "true" : filtroEsmiOrden;
              if (filtroEsmiOrden.Equals("true")==true)
              {
                      #region Validar si la orden es mía
                      ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra encabezado = System.Web.HttpContext.Current.Session["Encabezado_" + orden] as ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra;
                    if(encabezado!=null)
                    {
                          if(esAdmon.Equals("True")==true)
                        {
                            System.Web.HttpContext.Current.Session["Num_Proveedor"] = encabezado.Proveedor;
                            numProveedor = encabezado.Proveedor;
                        }
                          if (encabezado.Proveedor.Equals(numProveedor) == false)
                          {
                              dTabla = null;
                              dTabla = Service.Clases.cs_Estaticos.ToDataTable(ordenSinHistorial(orden, 2));
                           }
                          else
                            {
                               laOrdenesMia = true;
                            }
                    }
                   else
                    {
                        dTabla = Service.Clases.cs_Estaticos.ToDataTable(ordenSinHistorial(orden,1));
                    }
                      #endregion Validar si la orden es mía
              }



              if (dTabla == null)
              {
                  tablaDetalle = "<table class=\"table table-bordered table-striped\">"
                      + "<thead>"
                          + "<tr>"
                              + "<th>#</th>"
                              + "<th>Descripción</th>"
                              + "<th>Posición</th>"
                              + "<th>Fecha</th>"
                              + "<th>Cantidad</th>"
                              + "<th>Importe</th>"
                              + "<th>Moneda</th>"
                              + "<th>Doc. Pasivo</th>"
                              + "<th>Doc. Cancelación</th>"
                              + "<th>No. Material </th>"
                               + "<th>Ind. impuesto</th>"
                          + "</tr>"
                      + "</thead> </table>";
                  return tabla;
              }
              DataSet DsdTabla = new DataSet();
              DsdTabla.Tables.Add(dTabla);
              tablaDetalle = TablaDetalle(DsdTabla);
              foreach (var col in columnas)
              {
                  {
                      foreach (System.Data.DataColumn item in recepciones.Columns)
                      {
                          if (col.Key == item.ColumnName)
                          {
                              tabla.Columnas.Add(new ClickFactura_Entidades.BD.Modelos.Columna()
                              {
                                  Nombre = col.Value,
                                  Tipo = item.DataType,
                                  oculto = ocultos[x - 1],
                                  filtreable = filtros[x - 1],
                                  Ancho = AnchoColumna[x - 1],
                                  ClientTemplate = template[x - 1]
                              });
                              tabla.NombresModel.Add("R" + x);
                              x += 1;
                              break;
                          }
                          else if (col.Key == "Descripcion" || col.Key == "Indicador_IVA" || col.Key == "Numero_Cancelacion" || col.Key == "Unidad_Medida" || col.Key == "Numero_Pasivo" || col.Key == "Importe")
                          {
                              var colsdf = dTabla.Columns[col.Key];

                              tabla.Columnas.Add(new ClickFactura_Entidades.BD.Modelos.Columna()
                              {
                                  Nombre = col.Value,
                                  Tipo = dTabla.Columns[col.Key].DataType,
                                  oculto = ocultos[x - 1],
                                  filtreable = filtros[x - 1],
                                  Ancho = AnchoColumna[x - 1],
                                  ClientTemplate = template[x - 1]
                              });
                              tabla.NombresModel.Add("R" + x);
                              x += 1;
                              break;
                          }
                      }
                  }
              }

              try
                {
                    //Candado que las recepciones sean mías
                    if (laOrdenesMia == false)
                        recepciones = Service.Clases.cs_Estaticos.ToDataTable(respuestaSinHistorial(orden));
                    else
                    {
                        DataTable dePaso = new DataTable();
                        bool sinQs = true;
                        string filtradoQ=sinQs==false?"":" Tipo_Movimiento <> 'Q'";
                        DataRow[] ordenado = recepciones.Select(filtradoQ,"Numero_Documento Desc, Posicion_Documento Asc, Fecha_Contable Asc");
                        if(ordenado.Length>=0)
                        {
                            //Candado que las recepciones sean mías
                            //if (laOrdenesMia == true)
                                recepciones = ordenado.CopyToDataTable();
                            //else
                            //    recepciones = Service.Clases.cs_Estaticos.ToDataTable(respuestaSinHistorial(orden));
                        }
                    }
                }
                catch
                {
                    if(recepciones!=null)
                    {
                        if (recepciones.Rows.Count <= 0)
                        {
                                 recepciones = Service.Clases.cs_Estaticos.ToDataTable(respuestaSinHistorial(orden));
                        }
                        else
                        {
                            //Candado que las recepciones sean mías
                            if (laOrdenesMia == false)
                                recepciones = Service.Clases.cs_Estaticos.ToDataTable(respuestaSinHistorial(orden));
                        }
                    }
                    else
                    {
                        recepciones = Service.Clases.cs_Estaticos.ToDataTable(respuestaSinHistorial(orden));
                    }
                }

              //Recepciones sin facturar
              for (int i = 0; i < recepciones.Rows.Count; i++)
              {
                  List<object> reg = new List<object>();
                  foreach (var col in tabla.Columnas)
                  {
                      if (col.Nombre == "Descripción" || col.Nombre == "Ind. Impuesto" || col.Nombre == "Numero_Cancelacion" || col.Nombre == "Unidad_Medida" || col.Nombre == "Numero_Pasivo" || col.Nombre == "Importe")
                      {
                            string posicion = "";
                            try
                            {
                                posicion = recepciones.Rows[i]["Posicion_OrdenCompra"].ToString();
                            }
                            catch
                            {
                                posicion = recepciones.Rows[i]["Posicion_Orden_Compra"].ToString();
                            }
                          var nombre = columnas.First(t => t.Value == col.Nombre);
                          var datos = (from t in dTabla.AsEnumerable() where t["Posicion_OC"].ToString().Equals(posicion) select t).FirstOrDefault();
                          string dato = datos[nombre.Key].ToString();
                          reg.Add(dato);
                      }
                      else
                      {
                          var nombre = columnas.First(t => t.Value == col.Nombre);
                          var _orden = "";
                          if (nombre.Key == "Numero_Documento")
                          {
                              string cadena = "";
                              bool? existe = false;
                              System.Data.Entity.Core.Objects.ObjectParameter _existe = new System.Data.Entity.Core.Objects.ObjectParameter("existe", typeof(bool));
                              _existe.Value = (bool?)false;
                               System.Data.Entity.Core.Objects.ObjectParameter _mensaje = new System.Data.Entity.Core.Objects.ObjectParameter("mensaje", typeof(string));
                               _mensaje.Value = "Vacio";
                              string recepcion = recepciones.Rows[i][nombre.Key].ToString();
                               cadena = recepcion.Length > 0 ? recepcion : "";
                                var ctx = new Desarrollo_CF();
                              if (!recepciones.Rows[i]["Tipo_Movimiento"].ToString().Equals("Q") && recepciones.Rows[i]["Clave_Movimiento"].ToString().Equals("102") == false)
                              {

                                  //HABILITAR VALIDACION DE RECEPCION YA PROCESADA 17 OCT 2017 var resp = ctx.SP_checarRecepcionesVerifivcadas(recepcion, orden, _existe, _mensaje, "checarRecepcionVerificada");//recepcion, orden, ref existe, ref mensaje, "checarRecepcionVerificada");
                                  existe = (bool?)_existe.Value;
                                  mensaje = (string)_mensaje.Value;
                                  _orden = orden;
                                  List<ClickFactura_Entidades.BD.Modelos.IndicadoresImpuesto1OrdenxWE> indicadores = new List<ClickFactura_Entidades.BD.Modelos.IndicadoresImpuesto1OrdenxWE>();//Hay que crear el metodo que busque en el historial los indicadoresde IVA de las Recepciones 30 May 2017 GRD (from t in ctx.view_IndicadoresImpxOrdenxWE where t.Orden_Compra == _orden && t.Documento_Referencia == recepcion select t).FirstOrDefault();
                                  foreach (DataRow ocyimpuesto in dTabla.Rows)
                                  {
                                      string _oc = recepciones.Rows[i]["Orden_Compra"].ToString();
                                      string _recepcion = recepciones.Rows[i]["Documento_Referencia"].ToString();
                                      string _indicador = ocyimpuesto.ItemArray[29].ToString();
                                      ClickFactura_Entidades.BD.Modelos.IndicadoresImpuesto1OrdenxWE ind = new ClickFactura_Entidades.BD.Modelos.IndicadoresImpuesto1OrdenxWE();
                                      ind.Orden_Compra = _oc;
                                      ind.Documento_Referencia = _recepcion;
                                      ind.Indicador_IVA= _indicador;
                                      indicadores.Add(ind);
                                  }
                                  if (existe == false)
                                  {
                                      if (indicadores != null )// GRD 30 May && indicadores.Indicador_IVA != "")
                                      {
                                          foreach(var indicador in indicadores)
                                          {
                                              if(indicador.Indicador_IVA != "")
                                              {
                                                      cadena = recepcion;
                                                      #region Crea estructura que almacena lineas válidas de procesar 22 Nov 2016 GRD
                                                      try
                                                      {

                                                          if (System.Web.HttpContext.Current.Session["recepcionesAnalisadas"] != null)
                                                              recepcionesAnalisadas = (List<KeyValuePair<string, string>>)System.Web.HttpContext.Current.Session["recepcionesAnalisadas"];
                                                          recepcionesAnalisadas.Add(new KeyValuePair<string, string>(_orden, cadena));
                                                          System.Web.HttpContext.Current.Session["recepcionesAnalisadas"] = recepcionesAnalisadas;
                                                      }
                                                      catch (Exception ex)
                                                      {
                                                          string Error_mensaje = ex.Message;
                                                      }
                                                      #endregion Crea estructura que almacena lineas válidas de procesar 22 Nov 2016 GRD
                                              }
                                          }
                                      }
                                      else
                                      {
                                          //Una de las lineas no esta correctamente configura en sus indicadores de Impuestos!!
                                          cadena = "Advertencia: " + recepcion;
                                      }
                                  }
                                  else
                                  {
                                      //Facturado
                                      cadena = "Facturado con No. de Documento " + recepcion;
                                  }
                              }
                              else if (recepciones.Rows[i]["Clave_Movimiento"].ToString().Equals("102"))
                              {
                                  cadena = "Movimiento de cancelación de " + recepcion;
                              }
                              else
                              {
                                  cadena = "Facturado con No. de Documento " + recepcion;
                              }
                              reg.Add(cadena);
                          }
                          else
                          {
                                    reg.Add(recepciones.Rows[i][nombre.Key]);
                          }
                      }
                  }
                    if (reg.Count == 0)
                        tabla.TemplatePersonalizado = "En este momento no existe historial de recepciones para esta orden de compra, por favor verifique que su orden este bien escrita  y/o verifique esto con su contacto en ThyssenKrupp o soporte del Portal.";
                    if (laOrdenesMia == false)
                        tabla.TemplatePersonalizado = "No es posible mostrarle las recepciones de esta orden ya que al parecer no esta asignada a usted, por favor verifique haber escrito correctamente el no. de orden o llame a su contacto en ThyssenKrupp o soporte del Portal";
                    if(reg[8].ToString().Contains("Error : Falta Indicador!")==false)
                          tabla.Registros.Add(new ClickFactura_Entidades.BD.Modelos.Registros().MapeaDatos(reg));
              }

                return tabla;
          }
          catch (Exception ex)
          {
              mensaje = ex.Message;
              tablaDetalle = "";
              return null;
          }
      }

        private List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> ordenSinHistorial(string OrdenCompra,int tipo)
        {
            List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> ordenes = new List<Detalle_OrdenCompra>();
            ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra orden = new Detalle_OrdenCompra();
            orden.IDDetalleOrden = 0;
            orden.Orden_Compra = OrdenCompra;
            orden.Item = "0";
            orden.Descripcion = "";
            orden.Codigo_Producto = "Sin información";
            orden.Doc_Mov = "Sin información";
            orden.Pos_Doc_Mov = "Sin información";
            orden.Tipo_Mov = "Sin información";
            orden.Clase_Mov = "Sin información";
            orden.Fecha_Contable = "Sin información";
            orden.Cantidad = "0.00";
            orden.Importe = "0.00";
            orden.Moneda = "MXN";
            orden.Indicador_HD = "Sin información";
            orden.Ejercicio = "20XX";
            orden.Doc_Ref = "Sin información";
            orden.Pos_Doc_Ref = "Sin información";
            orden.Numero_Pasivo = "";
            orden.Numero_Cancelacion = "";
            orden.Posicion_OC = "00000";
            orden.Borrado = "";
            orden.Numero_Material = "Sin información";
            orden.Planta = "0000";
            orden.Almacen = "Null";
            orden.Numero_Necesidad = "Null";
            orden.Grupo_Articulos = "Null";
            orden.Numero_Compras = "Null";
            orden.Unidad_Medida = "XXX";
            orden.Cantidad_Base = "0";
            orden.Indicador_IVA = "";
            orden.Clase_Valoracion = "";
            orden.Tipo_OC = "0";
            orden.Tipo_Imputacion = "X";
            orden.Cuenta_Imputacion = "19000101";
            switch(tipo)
            {
                case 1:
                    orden.Descripcion = "Orden de Compra "+OrdenCompra+" no fue localizada en SAP";
                    break;
                case 2:
                    orden.Descripcion = "Orden de Compra " + OrdenCompra + " no esta creada para usted en SAP";
                    break;
            }
            ordenes.Add(orden);
            return ordenes;
        }
        private List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones> respuestaSinHistorial(string OrdenCompra)
        {
            List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones> recepciones = new List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones>();
            ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones recepcion = new ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones();
            recepcion.IdRecepcion = "1";
            recepcion.Orden_Compra = OrdenCompra;
            recepcion.Posicion_OrdenCompra = "00000";
            recepcion.Numero_ActualImput = "00";
            recepcion.Clase_Operacion = "0";
            recepcion.YearDocumento = "20XX";
            recepcion.Numero_Documento = "Sin Historial disponible";
            recepcion.Posicion_Documento = "0000";
            recepcion.Tipo_Movimiento = "Q";
            recepcion.Clave_Movimiento = "XXX";
            recepcion.Fecha_Contable = "19000101";
            recepcion.Cantidad = "0";
            recepcion.Importe_Local = "0.00";
            recepcion.Importe_Documento = "0.00";
            recepcion.Moneda = "MXN";
            recepcion.IndicadorHD = "Null";
            recepcion.YearDocumentoRef = "20XX";
            recepcion.Documento_Referencia = "Sin Historial";
            recepcion.Posicion_DocumentoRef = "0000";
            recepcion.Cantidad_Medida_Pedido = "0.000";
            recepciones.Add(recepcion);
            return recepciones;
        }
        private DataTable ObtenerRegistrosOrden(ref string ordenCompra, string numProveedor, ref DataTable Incrementables, ref DataTable Recepcionados, string sociedadVerificar, bool solo3000 = false, bool esAdmin = false)
      {
          #region cargaDetalle
          bool esTicket = false;
          DataSet tablas = new DataSet();
          #region Obteniendo la información de los Conectores

          #region       Declarando los Tablas que recibiran la información de SAP
          DataTable IncrementablesfromSAP = new DataTable();
          IncrementablesfromSAP.TableName = "Incrementables";
          DataTable RecepcionadosfromSAP = new DataTable();
          RecepcionadosfromSAP.TableName = "Recepciones";
          DataTable TipoD = new DataTable();
          TipoD.TableName = "TipoD";

          List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones> ListRecepciones = new List<Detalle_Recepciones>();
          #endregion Declarando los Tablas que recibiran la información de SAP

          #region        Cargando la información desde SAP
          //ordenCompra = "4500015468";
          ListRecepciones = Carga_Detalle_Recepciones(ordenCompra);
          //RecepcionadosfromSAP = Servicio.Clases.cs_Estaticos.ToDataTable(ListRecepciones);
          RecepcionadosfromSAP = Clases.cs_Estaticos.ToDataTable(ListRecepciones);

          #endregion Cargando la información desde SAP

          tablas.Tables.Add(new DataTable());
          tablas.Tables.Add(IncrementablesfromSAP);
          tablas.Tables.Add(RecepcionadosfromSAP);
          tablas.Tables.Add(TipoD);
            bool buscaRececpiones = true;
          #endregion Obteniendo la información de los Conectores
          try
          {
              if (ordenCompra != null)
              {
                  //var tablas = 30 May GRD Método en desuso por los conectores bafar.Carga_DetalleOrden(ordenCompra);
                  List<KeyValuePair<string, string>> mensajes = new List<KeyValuePair<string, string>>();
                  List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> _tablas = Carga_DetalleOrden(ordenCompra,ref mensajes);

                    #region Revisar si trae indicadores de IVA
                    bool faltaIndicador = false;
                    foreach(ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra revisandose in _tablas)
                      {
                        if(revisandose.Indicador_IVA.Length<=0)
                        {
                            faltaIndicador = true;
                            revisandose.Indicador_IVA = "Error : Falta Indicador!";
                        }
                      }
                    #endregion Revisar si trae indicadores de IVA

                    DataTable tabla = Service.Clases.cs_Estaticos.ToDataTable(_tablas);

                    if(mensajes!=null)
                    {
                        if(mensajes.Count()>0)
                        {
                            foreach(KeyValuePair<string,string> _m in mensajes)
                            {
                                if(_m.Value.Contains("Indicador de")==true)
                                {
                                    //JavaScript(@"javascript:showSuccess('"+_m.Value+"');");
                                    buscaRececpiones = false;
                                }
                                else
                                {
                                    //Orden no existe does not exist!!
                                    if (_m.Value.Contains("does not exist") == true)
                                    {
                                        buscaRececpiones = false;
                                    }
                                }
                            }
                        }
                    }

                    //if(faltaIndicador==false)
                    //{
                    #region Calculando las recepciones
                    if(buscaRececpiones==true)
                    {
                          //30 May GRD Método en desuso por los conectores
                          #region Subfiltrando solo Sociedad 3000 si es Punto de Venta Tickets
                          //var _sociedad = new SP_ObtenTicketsResult();
                          //if (solo3000)
                          //{
                          //    _sociedad = soloSociedad3000(esAdmin, numProveedor, ordenCompra);
                          //    esTicket = _sociedad == null ? true : (_sociedad.OrdCompra != ordenCompra && _sociedad.Organizacion_Compra != "") ? true : false;
                          //}
                          //Modificación
                          var _sociedad="Nada";
                          #endregion Subfiltrando solo Sociedad 3000 si es Punto de Venta Tickets
                          if (esTicket)
                          {
                              #region Obsoleto 12 Julio 2017
                              //string mensaje;
                              //if (_sociedad != null)
                              //{
                              //    if (_sociedad.OrdCompra != "")
                              //    {
                              //        tablas = bafar.Carga_DetalleOrden(_sociedad.OrdCompra);
                              //        tabla = tablas.Tables[0];
                              //        tabla = VerificarExistenciaOrdenesVivas(tablas, tabla, ref Incrementables, ref Recepcionados);
                              //    }
                              //    else
                              //    {
                              //        BuscarTicket(ordenCompra, out mensaje);
                              //        _sociedad = soloSociedad3000(false, numProveedor, ordenCompra);
                              //        if (_sociedad != null)
                              //        {
                              //            tablas = bafar.Carga_DetalleOrden(_sociedad.OrdCompra);
                              //            tabla = tablas.Tables[0];
                              //            tabla = VerificarExistenciaOrdenesVivas(tablas, tabla, ref Incrementables, ref Recepcionados);
                              //        }
                              //    }
                              //    ordenCompra = _sociedad.OrdCompra;
                              //}
                              //else
                              //    return null;
                              #endregion Obsoleto 12 Julio 2017
                          }
                          else
                          {
                              tabla =  VerificarExistenciaOrdenesVivas(tablas, tabla, ref Incrementables, ref Recepcionados);
                          }
                          return tabla;
                    }
                    else
                    {
                        return tabla;
                    }
                    #endregion Calculando las recepciones
                    //}

                }
                else
              {
                  return null;
              }
          }
          catch (Exception ex)
          {
              string error = ex.Message;
              return null;
          }
          #endregion  cargaDetalle
      }
      public DataTable VerificarExistenciaOrdenesVivas(DataSet tablas, DataTable tabla, ref DataTable Incrementables, ref DataTable Recepcionados)
      {
          #region Verificamos sea una Orden aún VIVA
          //Si es Q implicando ya Facturado
          //Si tiene algún documento de Pasivo o de Cancelación asignado
          //(dr["Tipo_Mov"].ToString().Equals("Q") == true) ||

          var viva = (from dr in tabla.AsEnumerable()
                      where (dr["Numero_Pasivo"].ToString().Equals("") == false) || (dr["Numero_Cancelacion"].ToString().Equals("") == false)
                      select dr).ToList();
          if (viva.Count() > 0)
          {
              string pasivo = "";
              foreach (DataRow r in viva)
              {
                  var rr = r.ItemArray;
                  pasivo = rr[17].ToString();
                  //Session["tienePasivo"] = "La orden " + oc + " ya tienen un pasivo generado con el documento de referencia :" + pasivo;
                  break;
              }
          }
          else
          {
              if (tablas.Tables[1].Rows.Count > 0)
              {
                  //Trae INCREMENTABLES
                  Incrementables = tablas.Tables[1];
              }
              if (tablas.Tables[2].Rows.Count > 0)
              {
                  #region    Actualizado el 22 Nov 2016 GRD
                  ////Trae RECEPCIONADO

                  //Recepcionados = tablas.Tables[2];
                  //var filtrado = (from t in Recepcionados.AsEnumerable()
                  //                where t["Tipo_Movimiento"].ToString() != "Q"
                  //                orderby t["Documento_Referencia"] descending
                  //                select t);
                  //Recepcionados = filtrado.CopyToDataTable();
                  ////List<string> indicesRecepcionados = new List<string>();
                  ////foreach (var item in filtrado)
                  ////{
                  ////    indicesRecepcionados.Add(item.ItemArray[0].ToString());
                  ////}
                  //#region Posibles Hojas de Servicio
                  //var TipoD = tablas.Tables[3];
                  //var filtroTipoD = (from t in TipoD.AsEnumerable()
                  //                   where (t["Tipo_Movimiento"].ToString() != "D")//(t["Numero_Documento"].ToString() != t["Documento_Referencia"].ToString()) && 
                  //                   select t).ToList();
                  //foreach (var item in filtroTipoD)
                  //{
                  //    if (item.ItemArray[8].ToString() != "D")
                  //    {
                  //        var existe = Recepcionados.Select("IdRecepcion=" + item.ItemArray[0].ToString());
                  //        if (existe.Count() == 0)
                  //        {
                  //            Recepcionados.ImportRow(item);
                  //        }
                  //    }
                  //    //KeyValuePair<string, string> nuevo = new KeyValuePair<string, string>(item.ItemArray[0].ToString(), item.ItemArray[6].ToString());
                  //    //indicesFacturados.Add(nuevo);
                  //}
                  //#endregion Posibles Hojas de Servicio
                  #endregion Actualizado el 22 Nov 2016 GRD
                  System.Data.DataTable TipoD = new System.Data.DataTable();
                  Recepcionados = tablas.Tables[2];
                  #region       Nuevo tipo de recepcionar un Servicio Tipo D 28 Octubre 2016
                  Recepcionados = subfiltradoTipoDUnicaReferencia(Recepcionados);
                  #endregion Nuevo tipo de recepcionar un Servicio Tipo D 28 Octubre 2016
                  //Buscando las Qs
                  Recepcionados = subfiltradoNoFacturadas(Recepcionados);
                  #region Posibles Hojas de Servicio
                  TipoD = tablas.Tables[3];
                  if (TipoD.Rows.Count > 0)
                  {
                      Recepcionados = subfiltradoTipoD(Recepcionados, TipoD);
                  }
                  #endregion Posibles Hojas de Servicio

              }
          }
          #endregion Verificamos sea una Orden aún VIVA
          //tabla = Recepcionados;
          return tabla;
      }
      private DataTable subfiltradoTipoD(DataTable Recepcionadas, DataTable TipoD)
      {
          DataTable Recepcionada = new DataTable();
          Recepcionada = Recepcionadas;
          DataTable parcial = new DataTable();
          DataTable sonQs = new DataTable();
          DataView dvr = new DataView(Recepcionadas);
          parcial = dvr.ToTable();
          DataTable deSalida = new DataTable();
          deSalida = parcial.Clone();
          List<KeyValuePair<string, string>> indicesFacturados = new List<KeyValuePair<string, string>>();
          //Original 12 Enero
          //DataTable _newDataTable = TipoD;

          //Cambio en 24 Feb 2016
          //string _sql_apuntan_a_una_Referencia = "Numero_Documento<>Documento_Referencia"; //Significa que SON "Q"s
          string _sql_apuntan_a_una_Referencia = "Numero_Documento=Documento_Referencia"; //Significa que SON "Q"s
          string _sql_buscando_las_Qs = "Numero_Documento<>Documento_Referencia"; //Buscando las Qs
          string _sqlTipoD = "Tipo_Movimiento = 'D'";
          //bool totalmenteNuevo = false;
          #region localizando tipos D
          //DataTable tiposD  = TipoD.Select("Tipo_Movimiento='D'").CopyToDataTable();
          //if(tiposD.Rows.Count==0)
          //       TipoD = Recepcionadas;
          //else
          //{
          //  #region Logica de identificar en TipoD registros con tipo movimiento D y cruzarlos contra Recepcionadas para matar y limpiarlas ahi en Recepcionadas!
          //                List<string> referencias = new List<string>();
          //                foreach(DataRow aBuscar in tiposD.Rows)
          //                {
          //                    int posicion = 0;
          //                    foreach(DataRow analizado in TipoD.Rows)
          //                    {
          //                        posicion++;
          //                        if (aBuscar.ItemArray[6].ToString().Equals(analizado.ItemArray[17].ToString()) == true && analizado.ItemArray[8].ToString().Equals("D")!=true)
          //                        {
          //                            referencias.Add(analizado.ItemArray[0].ToString());
          //                        }
          //                    }
          //                }
          //                foreach(string borrar in referencias)
          //                {
          //                    //Recepcionadas.Rows.RemoveAt(Convert.ToInt32(borrar));
          //                    Recepcionadas.AsEnumerable().Where(r => r.Field<Int32>("IdRecepcion") == Convert.ToInt32(borrar)).ToList().ForEach(row => row.Delete());
          //                    Recepcionadas.AcceptChanges();
          //                }
          //    #endregion Logica de identificar en TipoD registros con tipo movimiento D y cruzarlos contra Recepcionadas para matar y limpiarlas ahi en Recepcionadas!
          //}
          #endregion localizando tipos D
          TipoD = Recepcionadas;
          if (TipoD != null)
          {
              try
              {
                  DataTable TipoDD = new DataTable();
                  if (TipoD.Rows.Count > 0)
                      TipoDD = TipoD.Select(_sql_apuntan_a_una_Referencia).CopyToDataTable();
                  sonQs = TipoD.Select(_sql_buscando_las_Qs).CopyToDataTable();
                  foreach (DataRow apunta_a_otro in TipoDD.Rows)
                  {
                      //Trabajando las que NO SON Q
                      string _sql_Referencia_que_es_apuntada = " Tipo_Movimiento <> 'D' ";
                      if (TipoDD != null)
                      {
                          try
                          {
                              if (TipoDD.Rows.Count > 0)
                              {
                                  TipoD = TipoDD.Select(_sql_Referencia_que_es_apuntada).CopyToDataTable();
                                  break;
                              }
                          }
                          catch (Exception ex)
                          {
                              string mensaje = ex.Message;
                          }
                      }
                  }
              }
              catch (Exception ex)
              {
                  string mensaje = ex.Message;
                  //totalmenteNuevo = true;
              }
          }
          #region Quitando D
          //if (TipoD != null)
          //{
          //    try
          //    {
          //        if (TipoD.Rows.Count > 0)
          //            TipoD = TipoD.Select(_sqlTipoD).CopyToDataTable();
          //    }
          //    catch(Exception ex)
          //    {
          //        string mensaje = ex.Message;
          //    }
          //}
          #endregion Quitando D

          #region Quitando Q
          //if (TipoD != null)
          //{
          //    try
          //    {
          //        if (TipoD.Rows.Count > 0)
          //            TipoD = TipoD.Select("Tipo_Movimiento <> 'Q'").CopyToDataTable();
          //    }
          //    catch (Exception ex)
          //    {
          //        string mensaje = ex.Message;
          //    }
          //}
          #endregion Quitando Q

          //DataTable _newDataTable =new DataTable();
          //if(totalmenteNuevo==false)
          //     _newDataTable = TipoD;

          //27 Mayo 2016 DataTable _newDataTable = TipoD;
          DataTable _newDataTable = TipoD;
          //Para extraer los que ya fueron Facturados previamente, viene con tipo de Movimiento 'Q'
          //Tipo_Movimiento <> 'Q' and Numero_Documento=Documento_Referencia
          string _sqlWhere = "";
          try
          {
              //Recepcionadas.Select(_sqlWhere).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
              Recepcionadas = Recepcionadas.Select(_sqlWhere).CopyToDataTable(); //Los guardamos en esta Tabla _newDataTable 
              foreach (DataRow r in Recepcionada.Rows)
              {
                  string _recepcion = r["Documento_Referencia"].ToString().Length > 0 ? r["Documento_Referencia"].ToString() : r["Numero_Documento"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.
                  foreach (DataRow renglon in _newDataTable.Rows)
                  {
                      string OrdenBuscada = "";
                      OrdenBuscada = renglon["Orden_Compra"].ToString();
                      DataTable t = new DataTable();
                      t = _newDataTable.AsEnumerable().CopyToDataTable(); //.Where(row => row.Field<String>("Numero_Documento") == _recepcion == true).CopyToDataTable();
                      if (t.Rows.Count > 0)
                      {
                          //Si encontro una línea previa que actualmente ya esta facturada!!
                          try
                          {
                              foreach (DataRow reng in t.Rows)
                              {
                                  foreach (DataRow rengg in _newDataTable.Rows)
                                  {
                                      if (rengg.ItemArray[0].ToString().Equals(reng.ItemArray[0].ToString()) == true)
                                      {

                                          var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Key.Equals(reng.ItemArray[0].ToString()) == true select previosIndices;
                                          if (existiaAntes.Count() == 0)
                                          {
                                              KeyValuePair<string, string> nuevo = new KeyValuePair<string, string>(reng.ItemArray[0].ToString(), reng.ItemArray[6].ToString());
                                              indicesFacturados.Add(nuevo);//reng.ItemArray[0].ToString());
                                              break;
                                          }
                                      }
                                  }
                              }
                          }
                          catch (Exception ex)
                          {
                              string mensaje = ex.Message;
                          }
                      }
                  }
              }
          }
          catch (Exception ex)
          {
              string mensaje = ex.Message;
          }
          #region Limpia registros
          foreach (KeyValuePair<string, string> IDs in indicesFacturados)
          {
              int cuantos = _newDataTable.Rows.Count - 1;
              for (int i = cuantos; i >= 0; i--)
              {
                  #region Para Mostrar los 10000
                  //if (_newDataTable.Rows[i].ItemArray[0].ToString().Equals(IDs.Key) == true)
                  //{
                  //    //_newDataTable.Rows.RemoveAt(i);
                  //    deSalida.ImportRow(_newDataTable.Rows[i]);
                  //}
                  #endregion Para Mostrar los 10000
                  #region Para mostrar los 500
                  if (_newDataTable.Rows[i].ItemArray[0].ToString().Equals(IDs.Key) == false)
                  {
                      //_newDataTable.Rows.RemoveAt(i);
                      if (_newDataTable.Rows[i].ItemArray[8].ToString().Equals("D") == false)
                      {
                          DataRow[] preexistencia = deSalida.Select("IdRecepcion=" + _newDataTable.Rows[i].ItemArray[0].ToString());
                          if (preexistencia.Count() == 0)
                              deSalida.ImportRow(_newDataTable.Rows[i]);
                      }
                  }
                  #endregion Para mostrar los 500
              }
          }
          #endregion Limpia registros

          try
          {
              if (_newDataTable.Rows.Count == 1 && deSalida.Rows.Count == 0)
                  deSalida = _newDataTable;
              else
              {
                  if (_newDataTable.Rows.Count == 0 && deSalida.Rows.Count == 0)
                      deSalida = Recepcionadas;
              }
          }
          catch (Exception ex)
          {
              string mensaje = ex.Message;
          }
          foreach (DataRow q in sonQs.Rows)
          {
              deSalida.ImportRow(q);
          }
          #region revisando si no ha sido previamente verificacdo posiblemente en sesiones pasadas o actual.
          #endregion revisando si no ha sido previamente verificacdo posiblemente en sesiones pasadas o actual.
          return deSalida;
      }
      private DataTable subfiltradoNoFacturadas(DataTable Recepcionadas)
      {
          DataTable Recepcionada = new DataTable();
          Recepcionada = Recepcionadas;
          DataTable parcial = new DataTable();
          DataView dvr = new DataView(Recepcionadas);
          parcial = dvr.ToTable();
          DataTable deSalida = new DataTable();
          deSalida = parcial.Clone();
          List<string> indicesFacturados = new List<string>();
          //Cambio 30 Mayo
          // List<string> indicesFacturadosOrigenes = new List<string>();
          List<KeyValuePair<string, string>> indicesFacturadosOrigenes = new List<KeyValuePair<string, string>>();
          List<string> FacturadosOrigenes = new List<string>();
          bool listadoPosicionesQ = true;
          #region reexaminando tipos Q
          string _sqlWhere = "Tipo_Movimiento = 'Q'"; //Para extraer los que ya fueron Facturados previamente, viene con tipo de Movimiento 'Q'
          try
          {
              #region Identificando registro tipo por Letra
              DataTable _newDataTable = Recepcionadas.Select(_sqlWhere).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
              if (listadoPosicionesQ == true)
              {
                  //Cambio 30 Mayo 2016 configuracion.extraePosiconesVerificadas(_newDataTable);
                  indicesFacturadosOrigenes = extraePosiconesVerificadasOrigenes2(_newDataTable);
              }
              string _PosicionQ = "";
              bool continuar = true;
              int posr = 0;
              int totalRs = _newDataTable.Rows.Count;
              //foreach(DataRow r in _newDataTable.Rows)
              while (continuar == true)
              {
                  //DataRow r;
                  //r = _newDataTable.Rows[posr];
                  int indiceQ = 0;
                  //foreach(string posicionQ in indicesFacturadosOrigenes)
                  try
                  {
                      #region Try
                      while (indicesFacturadosOrigenes.Count() >= 0)
                      {
                          //Cambio 27 Mayo
                          DataRow r;
                          r = _newDataTable.Rows[posr];
                          //Cambio 27 Mayo
                          indiceQ = indicesFacturadosOrigenes.Count() - 1;
                          //Cambio 30 Mayo
                          //_PosicionQ =indicesFacturadosOrigenes[indiceQ];
                          _PosicionQ = indicesFacturadosOrigenes[indiceQ].Key;
                          #region       Analizando por cada renglon que tenia Q en una Posicion especifica
                          string _recepcion = r["Documento_Referencia"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.
                          DataTable renglonesconesaPosicion = Recepcionadas.Select("Posicion_OrdenCompra=" + _PosicionQ + " And Tipo_Movimiento = 'E'").CopyToDataTable();
                          #region Rastreando las líneas
                          foreach (DataRow renglon in renglonesconesaPosicion.Rows)//Original 13 Mayo 2016 Recepcionada.Rows)
                          {
                              //string OrdenBuscada = renglon["Orden_Compra"].ToString();
                              //ItemArray 6 es Numero de Documento
                              //ItemArray 17 es Documento Referencia
                              //Cambio 30 decimal Mayo 
                              //_recepcion = renglonesconesaPosicion.Rows[0].ItemArray[17].ToString();
                              _recepcion = renglon.ItemArray[17].ToString();
                              //if(_recepcion.Equals("5003061286")==true)
                              //{
                              //    bool encontrado = true;
                              //}
                              DataTable t = new DataTable();
                              try
                              {
                                  //Original
                                  //t= Recepcionada.AsEnumerable().Where(row => row.Field<String>("Numero_Documento")==_recepcion == true).CopyToDataTable();
                                  //Cambio
                                  t = renglonesconesaPosicion.AsEnumerable().Where(row => row.Field<String>("Numero_Documento") == _recepcion == true).CopyToDataTable();
                              }
                              catch (Exception _ex)
                              {
                                  string mensaje = _ex.Message;
                                  goto Outer;
                              }
                              bool listandoPosiciones = true;
                              if (t.Rows.Count > 0)
                              {
                                  //Si encontro una línea previa que actualmente ya esta facturada!!
                                  try
                                  {
                                      listadoPosicionesQ = false;
                                      //List<string> pocisiones_Qs = new List<string>();
                                      Dictionary<string, string> pocisiones_Qs = new Dictionary<string, string>();
                                      foreach (DataRow reng in t.Rows)
                                      {
                                          //Tenemos un listado renglones que cuentan con su Q, estas lineas son unas Posiciones especificas, extaremos y listamos cuales son esas posiciones
                                          if (listandoPosiciones == true)
                                          {
                                              pocisiones_Qs = extraePosiconesVerificadas2(t);
                                          }
                                          string _verificado = "";
                                          //Tenemos un listado renglones que cuentan con su Q, estas lineas son unas Posiciones especificas, extaremos y listamos cuales son esas posiciones
                                          foreach (DataRow rengg in Recepcionada.Rows)
                                          {
                                              string Posicion_OC_Procesando = rengg.ItemArray[2].ToString();
                                              //Original
                                              //if (rengg.ItemArray[0].ToString().Equals(reng.ItemArray[0].ToString()) == true)
                                              //{
                                              //Original
                                              string _IdRecepcion = "";
                                              //Original
                                              //var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(reng.ItemArray[0].ToString()) == true select previosIndices;
                                              //if(existiaAntes.Count()==0)
                                              //{
                                              //        indicesFacturados.Add(reng.ItemArray[0].ToString());
                                              //        break;
                                              //}
                                              //Cambio 13 Viernes 2106 -----------------------------------------------------------------------------------------------------------------------------------------------------
                                              bool yaVerificado = false;
                                              foreach (string verificado in pocisiones_Qs.Keys)
                                              {
                                                  //Vamos a determinar si en el lista de renglones totales y originales de la Recepción existe la linea a la que apunta la Q que estoy trabajando
                                                  bool Has = Recepcionada.AsEnumerable().Any(cus => cus.ItemArray[2].ToString() == verificado && cus.ItemArray[6].ToString() == _recepcion);//);
                                                  if (Has == true)
                                                  {
                                                      Has = indicesFacturadosOrigenes.Any(cus => cus.Key == verificado && cus.Value == _recepcion);
                                                  }
                                                  else
                                                      Has = false;
                                                  if (Has == true)
                                                  {
                                                      yaVerificado = true;
                                                      // Se determino que en el listado global de las Recepciones se encontro la linea a la que apunta nuestra Q  actual
                                                      //Ahora obtendremos su IDRecepcion para marcarla como a eliminar y no será mostrada al usuario!
                                                      var indice = from ubicandolo in Recepcionada.AsEnumerable() where ubicandolo.ItemArray[2].ToString().Equals(verificado) == true && ubicandolo.ItemArray[6].ToString().Equals(_recepcion) select ubicandolo;
                                                      foreach (var ubicado in indice)
                                                      {
                                                          _IdRecepcion = ubicado.ItemArray[0].ToString();
                                                          _verificado = verificado;
                                                          Recepcionada.Rows.Remove((DataRow)ubicado);
                                                          break;
                                                      }
                                                      break;
                                                  }
                                                  else
                                                  {
                                                      //Encontramos una Posicion pero que es absolutamente una 'E' Entrada
                                                      yaVerificado = false;
                                                      //Hay que ordenar avanzar
                                                      goto Outer;
                                                  }
                                              }
                                              if (yaVerificado == true)
                                              {
                                                  //Original
                                                  //var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(reng.ItemArray[0].ToString()) == true select previosIndices;
                                                  //Cambio el 13 Mayo 2106
                                                  //--> pocisiones_Qs.Remove(_verificado);
                                                  //Cambio el 30 de Mayo
                                                  pocisiones_Qs =eliminaPosiconesVerificadas2(_verificado, _recepcion, pocisiones_Qs);

                                                  //Elimina de _newDataTable el renglón analizado
                                                  //_newDataTable = configuracion.eliminaPosicionesconQs(_verificado, _recepcion, _newDataTable);
                                                  posr++;
                                                  //----------------------------------------------------------------

                                                  var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(_IdRecepcion) == true select previosIndices;
                                                  if (existiaAntes.Count() == 0)
                                                  {
                                                      //Original
                                                      //indicesFacturados.Add(reng.ItemArray[0].ToString());
                                                      //Cambio el 13 Mayo 2016
                                                      indicesFacturados.Add(_IdRecepcion);
                                                      break;
                                                  }
                                              }
                                              //Cambio 13 Viernes 2106-----------------------------------------------------------------------------------------------------------------------------------------------------
                                              //Original
                                              //}
                                              //Original
                                          }
                                          listandoPosiciones = false;
                                          break;
                                      }
                                  }
                                  catch (Exception ex)
                                  {
                                      string mensaje = ex.Message;
                                  }
                              }
                              else
                              {
                                  #region        Ahora preguntando por la Referencia
                                  t = Recepcionada.AsEnumerable().Where(row => row.Field<String>("Documento_Referencia") == _recepcion == true && row.Field<String>("Tipo_Movimiento") == "E").CopyToDataTable();
                                  if (t.Rows.Count > 0)
                                  {
                                      //Si encontro una línea previa que actualmente ya esta facturada!!
                                      try
                                      {
                                          foreach (DataRow reng in t.Rows)
                                          {
                                              foreach (DataRow rengg in Recepcionada.Rows)
                                              {
                                                  if (rengg.ItemArray[0].ToString().Equals(reng.ItemArray[0].ToString()) == true)
                                                  {
                                                      var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(reng.ItemArray[0].ToString()) == true select previosIndices;
                                                      if (existiaAntes.Count() == 0)
                                                      {
                                                          indicesFacturados.Add(reng.ItemArray[0].ToString());
                                                          break;
                                                      }
                                                  }
                                              }
                                          }
                                      }
                                      catch (Exception ex)
                                      {
                                          string mensaje = ex.Message;
                                      }
                                  }
                                  #endregion Ahora preguntando por la Referencia
                              }
                          }
                          #endregion Rastreando las líneas
                          #endregion Analizando por cada renglon que tenia Q en una Posicion especifica
                      Outer:
                          //Cambio 30 de Mayo 
                          //indicesFacturadosOrigenes.Remove(_PosicionQ);
                          indicesFacturadosOrigenes = eliminaPosiconesOrigenes(_PosicionQ, _recepcion, indicesFacturadosOrigenes);
                          listadoPosicionesQ = false;
                          //Elimina todas los registros que posean esa Posicion _PosicionQ de indicesFacturadosOrigenes
                          eliminaRegistrosdePosicion(_PosicionQ, ref indicesFacturadosOrigenes);
                          //Elimina todas los registros que posean esa Posicion _PosicionQ de indicesFacturadosOrigenes
                          continue;
                      }
                      #endregion Try
                  }
                  catch (Exception _ex)
                  {
                      string error = _ex.Message;
                      ////Elimina todas los registros que posean esa Posicion _PosicionQ de indicesFacturadosOrigenes
                      //eliminaRegistrosdePosicion(_PosicionQ,ref indicesFacturadosOrigenes);
                      ////Elimina todas los registros que posean esa Posicion _PosicionQ de indicesFacturadosOrigenes
                      break;
                  }
                  var existenciasQs = from qs in _newDataTable.AsEnumerable() where qs.ItemArray[8].ToString().Equals("Q") == true select qs;
                  if (existenciasQs != null)
                  {
                      if (existenciasQs.Count() > 0)
                          continuar = true;
                      else
                          continuar = false;
                  }
              }
              #endregion Identificando registro tipo por Letra
          }
          catch (Exception ex)
          {
              string mensaje = ex.Message;
          }
          #region                                                                                                                                           Limpia registros E compensados por una Q
          foreach (string IDs in indicesFacturados)
          {
              int cuantos = Recepcionada.Rows.Count - 1;
              for (int i = cuantos; i >= 0; i--)
              {
                  if (Recepcionada.Rows[i].ItemArray[0].ToString().Equals(IDs) == true)
                  {
                      Recepcionada.Rows.RemoveAt(i);
                  }
              }

          }
          #endregion                                                                                                                                     Limpia registros E compensados por una Q

          #endregion reexaminando tipos Q

          #region Buscando tipos de movimientos númericos
          #region Agregando los tipos de registro a mapear
          List<string> tipos = new List<string>();
          tipos.Add("Clave_Movimiento = '102'");
          tipos.Add("Clave_Movimiento = '122'");
          //tipos.Add("Clave_Movimiento = ??");
          #endregion Agregando los tipos de registro a mapear
          _sqlWhere = "";
          #region obsoleta
          //foreach (string _tipo in tipos)
          //{
          //    //Por cada tipo de movimiento númerico definido se hara una búsqueda
          //            try
          //            {//Try principal
          //                #region Identificando registro tipo por NUMERO
          //                DataTable _newDataTable = Recepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
          //                foreach (DataRow r in _newDataTable.Rows)
          //                {
          //                    //string porBuscar = r["Orden_Compra"].ToString();
          //                    var existiaAntes = from previosIndices in indicesFacturados where r.Equals(r.ItemArray[0].ToString()) == true select previosIndices;
          //                    if (existiaAntes.Count() == 0)
          //                    {
          //                        indicesFacturados.Add(r.ItemArray[0].ToString());
          //                    }
          //                    string _recepcion = r["Documento_Referencia"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.

          //                        //Por cada tipo de movimiento númerico definido se hara una búsqueda
          //                        #region Ciclo de busqueda de registros de cierto tipo
          //                        foreach (DataRow renglon in Recepcionada.Rows)
          //                        {
          //                            //string OrdenBuscada = renglon["Orden_Compra"].ToString();
          //                            DataTable t = new DataTable();
          //                            t = Recepcionada.AsEnumerable().Where(row => row.Field<String>("Numero_Documento") == _recepcion == true).CopyToDataTable();
          //                            if (t.Rows.Count > 0)
          //                            {
          //                                //Si encontro una línea previa que actualmente ya esta facturada!!
          //                                try
          //                                {
          //                                    foreach (DataRow reng in t.Rows)
          //                                    {
          //                                        foreach (DataRow rengg in Recepcionada.Rows)
          //                                        {
          //                                            if (rengg.ItemArray[0].ToString().Equals(reng.ItemArray[0].ToString()) == true)
          //                                            {
          //                                                existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(reng.ItemArray[0].ToString()) == true select previosIndices;
          //                                                if (existiaAntes.Count() == 0)
          //                                                {
          //                                                    indicesFacturados.Add(reng.ItemArray[0].ToString());
          //                                                    break;
          //                                                }
          //                                            }
          //                                        }
          //                                    }
          //                                }
          //                                catch (Exception ex)
          //                                {
          //                                    string mensaje = ex.Message;
          //                                }

          //                            }

          //                        }
          //                        #endregion Ciclo de busqueda de registros de cierto tipo


          //                }
          //                #endregion Identificando registro tipo por NUMERO
          //            }//Del Try principal
          //            catch (Exception ex)
          //            {
          //                string mensaje = ex.Message;
          //            }
          //}
          #endregion Obsoleta
          List<string> ReferenciasRevisadas = new List<string>();
          foreach (string _tipo in tipos)
          {
              //Por cada tipo de movimiento númerico definido se hara una búsqueda
              try
              {//Try principal

                  #region Identificando registro tipo por NUMERO
                  ReferenciasRevisadas.Clear();
                  //-->DataTable _newDataTable = Recepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
                  foreach (DataRow r in Recepcionadas.Rows)
                  {
                      try
                      {
                          string _recepcion = r["Documento_Referencia"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.
                          if (indicesFacturados.Count() == 0)
                          {
                              //Primera revisión
                              DataTable _newDataTableRecepcionadas = Recepcionadas.Select(" Documento_Referencia='" + _recepcion + "'").CopyToDataTable();
                              DataTable _newDataTable = _newDataTableRecepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
                              //Por cada tipo de movimiento númerico definido se hara una búsqueda
                              #region Ciclo de busqueda de registros de cierto tipo
                              foreach (DataRow renglon in _newDataTableRecepcionadas.Rows)
                              {
                                  #region Codigo buscando la linea 101 que era origen de la 102
                                  //DataTable t = new DataTable();
                                  //t = Recepcionada.AsEnumerable().Where(row => row.Field<String>("Numero_Documento") == _recepcion == true).CopyToDataTable();
                                  //if (t.Rows.Count > 0)
                                  //{
                                  //    //Si encontro una línea previa que actualmente ya esta facturada!!
                                  //    try
                                  //    {
                                  //        foreach (DataRow reng in _newDataTable.Rows)
                                  //        {
                                  //            var existiaAntes = from previosIndices in indicesFacturados where reng.Equals(r.ItemArray[0].ToString()) == true select previosIndices;
                                  //            foreach (DataRow rengg in t.Rows)
                                  //            {
                                  //                if (rengg.ItemArray[2].ToString().Equals(reng.ItemArray[2].ToString()) == true)
                                  //                {
                                  //                    existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(rengg.ItemArray[0].ToString()) == true select previosIndices;
                                  //                    if (existiaAntes.Count() == 0)
                                  //                    {
                                  //                        indicesFacturados.Add(rengg.ItemArray[0].ToString());
                                  //                        break;
                                  //                    }
                                  //                }
                                  //            }
                                  //        }
                                  //    }
                                  //    catch (Exception ex)
                                  //    {
                                  //        string mensaje = ex.Message;
                                  //    }

                                  //}
                                  #endregion Codigo buscando la linea 101 que era origen de la 102
                                  var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(renglon.ItemArray[0].ToString()) == true select previosIndices;
                                  if (existiaAntes.Count() == 0)
                                  {
                                      indicesFacturados.Add(renglon.ItemArray[0].ToString());
                                  }
                              }
                              ReferenciasRevisadas.Add(_recepcion);
                              #endregion Ciclo de busqueda de registros de cierto tipo
                          }
                          else
                          {
                              #region analizando posteriores
                              var analisados = from previosIndices in ReferenciasRevisadas where previosIndices.Equals(_recepcion) == true select previosIndices;
                              if (analisados.Count() > 0)
                              {
                                  string avanzar = "Ya esta analizado y listado para ser matado junto con su registro origen";
                              }
                              else
                              {
                                  //Revisando Numeros de referencia posteriores
                                  DataTable _newDataTableRecepcionadas = Recepcionadas.Select(" Documento_Referencia='" + _recepcion + "'").CopyToDataTable();
                                  DataTable _newDataTable = _newDataTableRecepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
                                  //Por cada tipo de movimiento númerico definido se hara una búsqueda
                                  #region Ciclo de busqueda de registros de cierto tipo
                                  foreach (DataRow renglon in _newDataTableRecepcionadas.Rows)
                                  {
                                      var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(renglon.ItemArray[0].ToString()) == true select previosIndices;
                                      if (existiaAntes.Count() == 0)
                                      {
                                          indicesFacturados.Add(renglon.ItemArray[0].ToString());
                                      }
                                  }
                                  ReferenciasRevisadas.Add(_recepcion);
                                  #endregion Ciclo de busqueda de registros de cierto tipo
                              }
                              #endregion analizando posteriores
                          }
                      }
                      catch (Exception _ex)
                      {
                          string x = _ex.Message;
                      }
                  }
                  #endregion Identificando registro tipo por NUMERO
              }//Del Try principal
              catch (Exception ex)
              {
                  string mensaje = ex.Message;
              }
          }
          #endregion  Buscando tipos de movimientos númericos

          #region         Buscando tipos de movimientos Alfanuméricos
          //--    ----     -----   -----     --->
          #region         Agregando los tipos de registro a mapear
          List<string> tipos_Letter = new List<string>();
          tipos_Letter.Add("Tipo_Movimiento = 'N'");

          //tipos_Letter.Add("Tipo_Movimiento = '?'");
          #endregion Agregando los tipos de registro a mapear

          _sqlWhere = "";

          //List<string> ReferenciasRevisadas = new List<string>();
          foreach (string _tipo in tipos_Letter)
          {
              //Por cada tipo de movimiento númerico definido se hara una búsqueda
              try
              {//Try principal
                  #region Identificando registro tipo por NUMERO
                  ReferenciasRevisadas.Clear();
                  foreach (DataRow r in Recepcionadas.Rows)
                  {
                      try
                      {
                          string _recepcion = r["Documento_Referencia"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.
                          if (indicesFacturados.Count() == 0)
                          {
                              //Primera revisión
                              DataTable _newDataTableRecepcionadas = Recepcionadas.Select(" Documento_Referencia='" + _recepcion + "'").CopyToDataTable();
                              DataTable _newDataTable = _newDataTableRecepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
                              //Por cada tipo de movimiento númerico definido se hara una búsqueda
                              #region Ciclo de busqueda de registros de cierto tipo
                              foreach (DataRow renglon in _newDataTableRecepcionadas.Rows)
                              {
                                  var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(renglon.ItemArray[0].ToString()) == true select previosIndices;
                                  if (existiaAntes.Count() == 0)
                                  {
                                      indicesFacturados.Add(renglon.ItemArray[0].ToString());
                                  }
                              }
                              ReferenciasRevisadas.Add(_recepcion);
                              #endregion Ciclo de busqueda de registros de cierto tipo
                          }
                          else
                          {
                              #region analizando posteriores
                              var analisados = from previosIndices in ReferenciasRevisadas where previosIndices.Equals(_recepcion) == true select previosIndices;
                              if (analisados.Count() > 0)
                              {
                                  string avanzar = "Ya esta analizado y listado para ser matado junto con su registro origen";
                              }
                              else
                              {
                                  //Revisando Numeros de referencia posteriores
                                  DataTable _newDataTableRecepcionadas = Recepcionadas.Select(" Documento_Referencia='" + _recepcion + "'").CopyToDataTable();
                                  DataTable _newDataTable = _newDataTableRecepcionadas.Select(_tipo).CopyToDataTable();//Los guardamos en esta Tabla _newDataTable 
                                  //Por cada tipo de movimiento númerico definido se hara una búsqueda
                                  #region Ciclo de busqueda de registros de cierto tipo
                                  foreach (DataRow renglon in _newDataTableRecepcionadas.Rows)
                                  {
                                      var existiaAntes = from previosIndices in indicesFacturados where previosIndices.Equals(renglon.ItemArray[0].ToString()) == true select previosIndices;
                                      if (existiaAntes.Count() == 0)
                                      {
                                          indicesFacturados.Add(renglon.ItemArray[0].ToString());
                                      }
                                  }
                                  ReferenciasRevisadas.Add(_recepcion);
                                  #endregion Ciclo de busqueda de registros de cierto tipo
                              }
                              #endregion analizando posteriores
                          }
                      }
                      catch (Exception _ex)
                      {
                          string x = _ex.Message;
                      }
                  }
                  #endregion Identificando registro tipo por NUMERO
              }//Del Try principal
              catch (Exception ex)
              {
                  string mensaje = ex.Message;
              }
          }
          //--    ----     -----   -----     --->
          #endregion  Buscando tipos de movimientos Alfanuméricos

          #region Limpia registros a Matar
          foreach (string IDs in indicesFacturados)
          {
              int cuantos = Recepcionada.Rows.Count - 1;
              for (int i = cuantos; i >= 0; i--)
              {
                  if (Recepcionada.Rows[i].ItemArray[0].ToString().Equals(IDs) == true)
                  {
                      Recepcionada.Rows.RemoveAt(i);
                  }
              }
          }
          #endregion Limpia registros a Matar

          return Recepcionadas;
      }
      private void eliminaRegistrosdePosicion(string PosicionCompletada, ref List<KeyValuePair<string, string>> Origenes)
      {
          List<KeyValuePair<string, string>> lista = new List<KeyValuePair<string, string>>();
          lista = Origenes.Where(x => x.Key != PosicionCompletada).ToList();
          Origenes = lista;
      }
      private DataTable subfiltradoTipoDUnicaReferencia(DataTable Recepcionadas)
      {
          DataTable Recepcionada = new DataTable();
          Recepcionada = Recepcionadas;
          DataTable parcial = new DataTable();
          DataView dvr = new DataView(Recepcionadas);
          parcial = dvr.ToTable();
          DataTable deSalida = new DataTable();
          deSalida = parcial.Clone();
          List<string> indicesFacturados = new List<string>();
          List<KeyValuePair<string, string>> indicesFacturadosOrigenes = new List<KeyValuePair<string, string>>();
          List<string> FacturadosOrigenes = new List<string>();
          bool listadoPosicionesQ = true;
          #region reexaminando tipos Q
          string _sqlWhere = "Tipo_Movimiento = 'Q'"; //Para extraer los que ya fueron Facturados previamente, viene con tipo de Movimiento 'Q'
          try
          {
              #region Identificando registro tipo por Letra
              DataTable _newDataTable = Recepcionadas.Select(_sqlWhere).CopyToDataTable();
              if (listadoPosicionesQ == true)
              {
                  indicesFacturadosOrigenes = extraePosiconesVerificadasOrigenes2(_newDataTable);
              }
              string _PosicionQ = "";
              bool continuar = true;
              int posr = 0;
              int totalRs = _newDataTable.Rows.Count;
              while (continuar == true)
              {
                  int indiceQ = 0;
                  try
                  {
                      #region Try
                      //while (indicesFacturadosOrigenes.Count() >= 0)
                      //{
                      DataRow r;
                      r = _newDataTable.Rows[posr];
                      indiceQ = indicesFacturadosOrigenes.Count() - 1;
                      _PosicionQ = indicesFacturadosOrigenes[indiceQ].Key;
                      #region       Analizando por cada renglon que tenia Q en una Posicion especifica
                      string _recepcion = r["Documento_Referencia"].ToString();// Extraemos el Numero de Documento al que esta línea informa YA HA SIDO FACTURADA.
                      var contexto = new Desarrollo_CF();

                      //GRD 30 Mayo 2017 Obsoleto por uso de Conectores
                      //DatosBafarDataContext contexto = new DatosBafarDataContext(BAFAR.Clases.Genericos.Configuracion.CadenaConexion);
                      //System.Data.Linq.Table<Detalle_Recepciones> recepciones = contexto.GetTable<Detalle_Recepciones>();
                      //GRD 30 Mayo 2017 Obsoleto por uso de Conectores

                      List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones> recepciones = new List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones>();
                      var registrosdeD = from reg in recepciones where reg.Orden_Compra.Equals(Recepcionada.Rows[0].ItemArray[1].ToString()) == true && reg.Tipo_Movimiento.Equals("D") == true select reg;
                      if (registrosdeD != null)
                      {
                          if (registrosdeD.Count() > 0)
                          {
                              var todosdeD = from reg in recepciones where reg.Orden_Compra.Equals(Recepcionada.Rows[0].ItemArray[1].ToString()) == true && reg.Documento_Referencia.Equals(_recepcion) == true select reg;
                              foreach (var analizado in todosdeD)
                              {
                                  //Preparalo para ser borrado
                                  if (analizado.Tipo_Movimiento.Equals("Q") == false && analizado.Tipo_Movimiento.Equals("D") == false)
                                      indicesFacturados.Add(analizado.IdRecepcion.ToString());
                              }
                              continuar = false;
                          }
                          else
                              continuar = false;
                      }
                      else
                      {
                          continuar = false;
                      }
                      #endregion Analizando por cada renglon que tenia Q en una Posicion especifica
                      //}
                      #endregion Try
                  }
                  catch (Exception _ex)
                  {
                      string error = _ex.Message;
                      break;
                  }
              }
              #endregion Identificando registro tipo por Letra
          }
          catch (Exception ex)
          {
              string mensaje = ex.Message;
          }
          #endregion reexaminando tipos Q

          if (indicesFacturados.Count() > 0)
          {
              #region                                                                                                                                           Limpia registros D y E compensados por una Q
              foreach (string IDs in indicesFacturados)
              {
                  int cuantos = Recepcionada.Rows.Count - 1;
                  for (int i = cuantos; i >= 0; i--)
                  {
                      if (Recepcionada.Rows[i].ItemArray[0].ToString().Equals(IDs) == true)
                      {
                          Recepcionada.Rows.RemoveAt(i);
                      }
                  }
              }
              #endregion                                                                                                                                 Limpia registros D y E compensados por una Q
          }
          else
          {
              Recepcionada = Recepcionadas;
          }

          return Recepcionada;
      }
      public List<KeyValuePair<string, string>> extraePosiconesVerificadasOrigenes2(DataTable t)
      {
          List<KeyValuePair<string, string>> salida = new List<KeyValuePair<string, string>>();
          foreach (DataRow renglon in t.Rows)
          {
              KeyValuePair<string, string> dato = new KeyValuePair<string, string>(renglon.ItemArray[2].ToString(), renglon.ItemArray[17].ToString());
              salida.Add(dato);
          }
          return salida;
      }
      public Dictionary<string, string> extraePosiconesVerificadas2(DataTable t)
      {
          Dictionary<string, string> salida = new Dictionary<string, string>();
          foreach (DataRow renglon in t.Rows)
          {
              KeyValuePair<string, string> dato = new KeyValuePair<string, string>(renglon.ItemArray[2].ToString(), renglon.ItemArray[17].ToString());
              salida.Add(renglon.ItemArray[2].ToString(), renglon.ItemArray[17].ToString());
          }
          return salida;
      }
      public Dictionary<string, string> eliminaPosiconesVerificadas2(string Posicion, string Referencia, Dictionary<string, string> listado)
      {
          Dictionary<string, string> salida = new Dictionary<string, string>();
          foreach (KeyValuePair<string, string> renglon in listado)
          {
              if (renglon.Key.Equals(Posicion) == true && renglon.Value.Equals(Referencia) == true)
              {

              }
              else
              {
                  salida.Add(renglon.Key, renglon.Value);
              }
          }
          return salida;
      }
      public List<KeyValuePair<string, string>> eliminaPosiconesOrigenes(string Posicion, string Referencia, List<KeyValuePair<string, string>> listado)
      {
          bool existeListado = listado.Any(cus => cus.Value == Referencia);
          List<KeyValuePair<string, string>> salida = new List<KeyValuePair<string, string>>();
          if (existeListado == true)
          {
              foreach (KeyValuePair<string, string> renglon in listado)
              {
                  if (renglon.Key.Equals(Posicion) == true && renglon.Value.Equals(Referencia) == true)
                  {

                  }
                  else
                  {
                      //bool Existe=from actuales in listado where actuales.Key.Equals(Posicion)==false && actuales.Value.Equals(Referencia)==false select actuales;
                      salida.Add(renglon);
                  }
              }
          }
          else
          {
              //No existen Posiciones con esa Referencia, asumiremos que ya se acabaron todos los registros de esa posicion
              foreach (KeyValuePair<string, string> renglon in listado)
              {
                  if (renglon.Key.Equals(Posicion) == true)
                  {

                  }
                  else
                  {
                      //bool Existe=from actuales in listado where actuales.Key.Equals(Posicion)==false && actuales.Value.Equals(Referencia)==false select actuales;
                      salida.Add(renglon);
                  }
              }
          }
          return salida;
      }
      public List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> Carga_DetalleOrden(string OrdenCompra,ref List<KeyValuePair<string, string>>mensajes )
      {
          List<ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra> ordenes = new List<ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra>();
          //ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra orden = new ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra();
          #region        Recupera la información desde el Conector SAP
                  SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
                  List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
                  try
                  {
                   conector.Ping();
                  }
                  catch(Exception ex)
                  {
                      datos.Add(new KeyValuePair<string,string>("Error",ex.Message));
                  }
          #endregion Recupera la información desde el Conector SAP

          #region Extrayendo Información de la Orden de Compra
                   Dictionary<string, string> estructurasOrdenCompra = new Dictionary<string, string>();
                  //Define las estructuras que se empatarán entre SAP y la antigua base de datos de SQL Server, base de las estructuras manejadas en la aplicación
                   csBaseSAPNET csbasesapnet = new csBaseSAPNET();
                   estructurasOrdenCompra.Add("OrdenesCompra", "PO_HEADER");
                   estructurasOrdenCompra.Add("Detalle_OrdenCompra", "PO_ITEMS");

                #region  Poblando la estructuras SAP-SQL Server
                  foreach(KeyValuePair<string,string> estructura in estructurasOrdenCompra)
                  {
                       string estructura_SAP = estructura.Value;
                       string estructura_SQLSever = estructura.Key;
                       DataSet OC = conectores_obtenBAPI_PO_GETDETAIL(conector, OrdenCompra, ref datos, estructura_SAP);
                       if (OC.Tables.Count>0)
                       foreach(DataTable tbl in OC.Tables)
                        {
                            if (tbl.TableName == estructura_SAP)
                            {
                                Dictionary<KeyValuePair<string, string>, int> estructuraxImplementar=new Dictionary<KeyValuePair<string,string>,int>();
                                //List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer> renglonRepositorio = csbasesapnet.renglon_PO_ITEMS_SQLServer();
                                List<List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer>> Lista_renglonRepositorio = new List<List<csBaseSAPNET.estructura_SAP_SQLServer>>();
                                List<string> camposSQL = new List<string>();//renglonRepositorio.Select(s => (string)s.Campo_SQLServer).ToList();
                                if(estructura_SAP.Equals("PO_HEADER")==true)
                                {
                                       estructuraxImplementar = csbasesapnet.estructura_PO_HEADER();
                                }
                                 #region PO_ITEMS
                                 if (estructura_SAP.Equals("PO_ITEMS") == true)
                                 {
                                    estructuraxImplementar = csbasesapnet.estructura_PO_ITEMS();
                                   var camposSAP=from c in estructuraxImplementar.Keys select c;
                                   string valorSAP="";
                                    foreach(DataRow ren in tbl.Rows)
                                    {
                                        List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer> renglonRepositorio = csbasesapnet.renglon_PO_ITEMS_SQLServer();
                                        camposSQL = renglonRepositorio.Select(s => (string)s.Campo_SQLServer).ToList();
                                        foreach(DataColumn col in tbl.Columns)//  ###################
                                        {
                                                 var encontrado = from columna in camposSAP where columna.Value.Equals(col.Caption) == true select columna; 
                                                if (encontrado!=null && encontrado.Count()>0)
                                                {
                                                    var valor = from val in estructuraxImplementar where val.Key.Value.Equals(col.Caption) == true select val;
                                                    foreach(var recuperado in valor)
                                                    {
                                                        int posicion = Convert.ToInt32(recuperado.Value.ToString());
                                                        valorSAP=ren.ItemArray[posicion].ToString();
                                                        break;
                                                    }
                                                    foreach(var _renglonSQLServer in renglonRepositorio)
                                                    {
                                                        if(_renglonSQLServer.Campo_SAP.Equals(col.Caption)==true)
                                                        {
                                                            _renglonSQLServer.Valor = valorSAP;
                                                            break;
                                                        }
                                                    }
                                                }
                                        }
                                        Lista_renglonRepositorio.Add(renglonRepositorio);
                                    }// ######## Del foreach(DataRow ren in tbl.Rows)  ##############
                                 }// Del ###  if (estructura_SAP.Equals("PO_ITEMS") == true)
                                //La estructura "tbl" contiene los registro directos de SAP
                                 if (estructura_SAP.Equals("PO_ITEMS") == true)
                                 {
                                #region Llenado de las líneas de los Detalle de Orden de Compra
                                #region extrae la moneda del Sistema
                                                int result = 0;
                                                adT_Parametros adp = new adT_Parametros();
                                                List<objT_Parametros> objp = new List<objT_Parametros>();
                                                string cultura = "es-MX";
                                                objp = adp.mABCT_Parametros(out result, 0, "CurrencySystem", "Vacio", true, "ConsultaValor");
                                                {
                                                    cultura = objp[0].ValorParametro.ToString();
                                                    System.Globalization.CultureInfo actualCultura = System.Threading.Thread.CurrentThread.CurrentCulture;
                                                    cultura = actualCultura.ToString();
                                                    System.Console.WriteLine(actualCultura.ToString());
                                                }
                                #endregion extrae la moneda del Sistema
                                 for (int j = 0; j <= tbl.Rows.Count-1; j++)
                                 {
                                        ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra orden = new ClickFactura_Entidades.BD.Modelos.Detalle_OrdenCompra();
                                        List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer> _renglonRepositorio =Lista_renglonRepositorio[j];
                                        foreach(var desdeSAP in _renglonRepositorio )
                                        {
                                            string valor=desdeSAP.Valor;
                                            string columna=desdeSAP.Campo_SQLServer;
                                            var esColumna = from col in camposSQL where col.Equals(columna) == true select col;
                                            if (esColumna != null && esColumna.Count() > 0)
                                            {//######################################################################################################################
                                                if (desdeSAP.Campo_SQLServer.Equals(columna) == true)
                                                {
                                                    #region Pasa la información
                                                    if (desdeSAP.Campo_SQLServer.Equals("IDDetalleOrdenCompra") == true)
                                                        orden.IDDetalleOrdenCompra = "1"; 
                                                    if (desdeSAP.Campo_SQLServer.Equals("Orden_Compra") == true)
                                                        orden.Orden_Compra = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Item") == true)
                                                        orden.Item = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Descripcion") == true)
                                                        orden.Descripcion = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Codigo_Producto") == true)
                                                        orden.Codigo_Producto = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Doc_Mov") == true)
                                                        orden.Doc_Mov = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Pos_Doc_Mov") == true)
                                                        orden.Pos_Doc_Mov = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Tipo_Mov") == true)
                                                        orden.Tipo_Mov = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Codigo_Producto") == true)
                                                        orden.Clase_Mov = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Fecha_Contable") == true)
                                                        orden.Fecha_Contable = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Cantidad") == true)
                                                        {
                                                    //System.Globalization.CultureInfo cultureInfo = System.Globalization.CultureInfo.InvariantCulture; //Use relevant culture in which your number is formatted. In this case InvariantCulture would do.
                                                    //var culture = new System.Globalization.CultureInfo("de-DE");
                                                    //decimal d;
                                                    //bool succesful = Decimal.TryParse(valor, System.Globalization.NumberStyles.Number, culture, out d);
                                                    //if (succesful == true)
                                                    //{
                                                    //     valor = d.ToString(new System.Globalization.CultureInfo("en-US"));
                                                    //}
                                                    //    orden.Cantidad = valor;


                                                    //double val;
                                                    //if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                    //{
                                                    //    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                    //}
                                                    //valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                    //orden.Cantidad = valor.Replace("$", "");

                                                    //orden.Cantidad = orden.Cantidad.Replace(",", "");
                                                    //orden.Cantidad = convierteMoneyTKPM(orden.Cantidad);

                                                    #region Adecua formato moneda
                                                    string entorno = "";
                                                    string _Cantidad = "";
                                                    bool publicado = false;
                                                    objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                                    {
                                                        entorno = objp[0].ValorParametro.ToString();
                                                        publicado = entorno.Equals("1") == true ? true : false;
                                                    }
                                                    if (publicado == false)
                                                    {
                                                        #region Si estas local
                                                        double val;
                                                        if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                        {
                                                            string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                        }
                                                        valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                        _Cantidad = valor.Replace("$", "");
                                                        _Cantidad = _Cantidad.Replace(",", "");
                                                        _Cantidad = convierteMoneyTKPM(_Cantidad);
                                                        #endregion Si estas local
                                                    }
                                                    else
                                                    {
                                                        #region        En el Servidor
                                                        _Cantidad = valor;
                                                        //_Cantidad = _Cantidad.Replace(".", "");
                                                        //_Cantidad = _Cantidad.Replace(",", ".");
                                                        #endregion En el Servidor
                                                    }
                                                    #endregion Adecua formato moneda
                                                    orden.Cantidad = _Cantidad;


                                                    //Con moneda alineada
                                                    //orden.Cantidad = valor;
                                                }
                                                    if (desdeSAP.Campo_SQLServer.Equals("Importe") == true)
                                                        {
                                                           #region Adecua formato moneda
                                                                    string entorno = "";
                                                                    string _Cantidad = "";
                                                                    bool publicado = false;
                                                                    objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                                                        {
                                                                            entorno = objp[0].ValorParametro.ToString();
                                                                            publicado = entorno.Equals("1") == true ? true : false;
                                                                        }
                                                                        if (publicado == false)
                                                                        {
                                                                            #region Si estas local
                                                                                double val;
                                                                                if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                                                {
                                                                                    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                                                }
                                                                                valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                                                _Cantidad = valor.Replace("$", "");
                                                                                _Cantidad = _Cantidad.Replace(",", "");
                                                                                _Cantidad = convierteMoneyTKPM(_Cantidad);
                                                                            #endregion Si estas local
                                                                          }
                                                                        else
                                                                        {
                                                                                #region        En el Servidor
                                                                                    _Cantidad = valor;
                                                                                    //_Cantidad = _Cantidad.Replace(".", "");
                                                                                    //_Cantidad = _Cantidad.Replace(",", ".");
                                                                                #endregion En el Servidor
                                                                        }
                                                                #endregion Adecua formato moneda
                                                                orden.Importe = _Cantidad;
                                                            //Con moneda alineada
                                                            //orden.Importe = valor;
                                                        }
                                                if (desdeSAP.Campo_SQLServer.Equals("Moneda") == true)
                                                        orden.Moneda = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("IndicadorHD") == true)
                                                        orden.IndicadorHD = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Ejercicio") == true)
                                                        orden.Ejercicio = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Doc_Ref") == true)
                                                        orden.Doc_Ref = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Pos_Doc_Ref") == true)
                                                        orden.Pos_Doc_Ref = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Numero_Pasivo") == true)
                                                        orden.Numero_Pasivo = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Numero_Cancelacion") == true)
                                                        orden.Numero_Cancelacion = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Posicion_OC") == true)
                                                        orden.Posicion_OC = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Borrado") == true)
                                                        orden.Borrado = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Numero_Material") == true)
                                                        orden.Numero_Material = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Planta") == true)
                                                        orden.Planta = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Almacen") == true)
                                                        orden.Almacen = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Numero_Necesidad") == true)
                                                        orden.Numero_Necesidad = valor;
                                                    orden.Grupo_Articulos = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Numero_Compras") == true)
                                                        orden.Numero_Compras = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Unidad_Medida") == true)
                                                        orden.Unidad_Medida = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Cantidad_Base") == true)
                                                        orden.Cantidad_Base = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Indicador_IVA") == true)
                                                        orden.Indicador_IVA = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Clase_Valoracion") == true)
                                                        orden.Clase_Valoracion = "";
                                                    if (desdeSAP.Campo_SQLServer.Equals("Tipo_OC") == true)
                                                        orden.Tipo_OC = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Tipo_Imputacion") == true)
                                                        orden.Tipo_Imputacion = valor;
                                                    if (desdeSAP.Campo_SQLServer.Equals("Cuenta_Imputacion") == true)
                                                       orden.Cuenta_Imputacion = valor;
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Clase_Mov") == true)
                                                    //    orden.Clase_Mov = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Codigo_Producto") == true)
                                                    //    orden.Codigo_Producto = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Cuenta_Imputacion") == true)
                                                    //    orden.Cuenta_Imputacion = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Doc_Mov") == true)
                                                    //    orden.Doc_Mov = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Doc_Ref") == true)
                                                    //    orden.Doc_Ref = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Ejercicio") == true)
                                                    //    orden.Ejercicio = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Fecha_Contable") == true)
                                                    //    orden.Fecha_Contable = "";
                                                    //if (desdeSAP.Campo_SQLServer.Equals("Doc_Mov") == true)
                                                    //    orden.Doc_Mov = "";
                                                    #endregion Pasa la información
                                                }
                                           }//######################################################################################################################
                                        }
                                     //Agregando el nuevo renglón a Detalles de Orden de Compra tabla virtual
                                     ordenes.Add(orden);
                                 }
                                #endregion Llenando de las línea de los Detalles de Orden de Compra
                                 }
                                 #endregion PO_ITEMS
                            }
                        }
                       else
                       {
                           datos.Add(new KeyValuePair<string, string>("Error", "No se logró conectar con la estructuras SAP"));
                       }
                  }
                  #endregion Poblando la estructuras SAP-SQL Server
          #endregion Extrayendo Información de la Orden de Compra

          #region Datos Ejemplo
                  //orden.IDDetalleOrdenCompra = "2000";
                  //orden.Orden_Compra = "6000000018";
                  //orden.Item = "Null";
                  //orden.Descripcion = "RENTA FEB 17";
                  //orden.Codigo_Producto = "Null";
                  //orden.Doc_Mov = "Null";
                  //orden.Pos_Doc_Mov = "Null";
                  //orden.Tipo_Mov = "Null";
                  //orden.Clase_Mov = "Null";
                  //orden.Fecha_Contable = "Null";
                  //orden.Cantidad = "1.00";
                  //orden.Importe = "10000.00";
                  //orden.Moneda = "Null";
                  //orden.IndicadorHD = "Null";
                  //orden.Ejercicio = "Null";
                  //orden.Doc_Ref = "Null";
                  //orden.Pos_Doc_Ref = "Null";
                  //orden.Numero_Pasivo = "";
                  //orden.Numero_Cancelacion = "";
                  //orden.Posicion_OC = "00010";
                  //orden.Borrado = "";
                  //orden.Numero_Material = "000000000000084501";
                  //orden.Planta = "3000";
                  //orden.Almacen = "Null";
                  //orden.Numero_Necesidad = "Null";
                  //orden.Grupo_Articulos = "Null";
                  //orden.Numero_Compras = "Null";
                  //orden.Unidad_Medida = "SER";
                  //orden.Cantidad_Base = "1";
                  //orden.Indicador_IVA = "T2";
                  //orden.Clase_Valoracion = "";
                  //orden.Tipo_OC = "0";
                  //orden.Tipo_Imputacion = "K";
                  //orden.Cuenta_Imputacion = "20170313";
                  //ordenes.Add(orden);
                  #endregion Datos Ejemplo

          #region        Pasando a  List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra>
          //ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra dtOC = new ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra();
          List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> ListadtOC = new List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra>();
          int contador = 0;
         foreach (var reg in ordenes)
          {
              ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra dtOC = new ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra();
              dtOC.IDDetalleOrden = reg.IDDetalleOrdenCompra!=null?Convert.ToInt32(reg.IDDetalleOrdenCompra):contador++;
              dtOC.Orden_Compra = reg.Orden_Compra!=null?reg.Orden_Compra:"";
              dtOC.Item = reg.Item!=null?reg.Item:"";
              dtOC.Descripcion = reg.Descripcion!=null? reg.Descripcion:"";
              dtOC.Codigo_Producto = reg.Codigo_Producto!=null? reg.Codigo_Producto:"";
              dtOC.Doc_Mov = reg.Doc_Mov!=null?reg.Doc_Mov:"";
              dtOC.Fecha_Contable =  reg.Fecha_Contable!=null? reg.Fecha_Contable: "";
              dtOC.Cantidad = reg.Cantidad!=null? reg.Cantidad: "";
              dtOC.Importe = reg.Importe!=null? reg.Importe: "";
              dtOC.Moneda = reg.Moneda!=null?reg.Moneda:"";
              dtOC.Indicador_HD = reg.IndicadorHD!=null?reg.IndicadorHD:"";
              dtOC.Ejercicio = reg.Ejercicio!=null? reg.Ejercicio:"";
              dtOC.Doc_Ref = reg.Doc_Ref!=null?reg.Doc_Ref:"";
              dtOC.Pos_Doc_Ref = reg.Pos_Doc_Ref!=null?reg.Pos_Doc_Ref:"";
              dtOC.Numero_Pasivo = reg.Numero_Pasivo!=null?reg.Numero_Pasivo:"";
              dtOC.Numero_Cancelacion = reg.Numero_Cancelacion!=null?reg.Numero_Cancelacion:"";
              dtOC.Posicion_OC = reg.Posicion_OC!=null?complementaCeros(reg.Posicion_OC):"";
              dtOC.Borrado = reg.Borrado!=null?reg.Borrado:"";
              dtOC.Numero_Material = reg.Numero_Material!=null?reg.Numero_Material:"";
              dtOC.Planta = reg.Planta!=null?reg.Planta:"";
              dtOC.Almacen = reg.Almacen!=null?reg.Almacen:"";
              dtOC.Numero_Necesidad = reg.Numero_Necesidad!=null?reg.Numero_Necesidad:"";
              dtOC.Grupo_Articulos = reg.Grupo_Articulos!=null?reg.Grupo_Articulos:"";
              dtOC.Numero_Compras = reg.Numero_Compras!=null?reg.Numero_Compras:"";
              dtOC.Unidad_Medida = reg.Unidad_Medida!=null?reg.Unidad_Medida:"";
              dtOC.Cantidad_Base = reg.Cantidad_Base!=null?reg.Cantidad_Base:"";
              dtOC.Indicador_IVA = reg.Indicador_IVA!=null?reg.Indicador_IVA:"";
              dtOC.Clase_Valoracion = reg.Clase_Valoracion!=null?reg.Clase_Valoracion:"";
              dtOC.Tipo_OC = reg.Tipo_OC!=null?reg.Tipo_OC:"";
              dtOC.Tipo_Mov = reg.Tipo_Mov != null ? reg.Tipo_Mov : "";
              dtOC.Tipo_Imputacion = reg.Tipo_Imputacion!=null?reg.Tipo_Imputacion:"";
              dtOC.Cuenta_Imputacion = reg.Cuenta_Imputacion!=null?reg.Cuenta_Imputacion:"";
              dtOC.Pos_Doc_Mov = reg.Pos_Doc_Mov != null ? reg.Pos_Doc_Mov : "";
              dtOC.Clase_Mov = reg.Clase_Mov != null ? reg.Clase_Mov : "";
              dtOC.Cuenta_Imputacion = reg.Cuenta_Imputacion != null ? reg.Cuenta_Imputacion : "";
              ListadtOC.Add(dtOC);
          }
         if(ordenes.Count<=0)
            {
                #region Registro vacio o con errores
                ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra dtOC = new ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra();
                dtOC.IDDetalleOrden =1;
                dtOC.Orden_Compra = OrdenCompra;
                dtOC.Item = "";
                dtOC.Descripcion ="";
                dtOC.Codigo_Producto =  "";
                dtOC.Doc_Mov =  "";
                dtOC.Fecha_Contable =  "";
                dtOC.Cantidad =  "0";
                dtOC.Importe = "0";
                dtOC.Moneda =  "XXX";
                dtOC.Indicador_HD = "";
                dtOC.Ejercicio =  "";
                dtOC.Doc_Ref =  "";
                dtOC.Pos_Doc_Ref =  "";
                dtOC.Numero_Pasivo =  "";
                dtOC.Numero_Cancelacion =  "";
                dtOC.Posicion_OC =  "";
                dtOC.Borrado = "";
                dtOC.Numero_Material =  "";
                dtOC.Planta =  "";
                dtOC.Almacen = "";
                dtOC.Numero_Necesidad =  "";
                dtOC.Grupo_Articulos = "";
                dtOC.Numero_Compras =  "";
                dtOC.Unidad_Medida =  "";
                dtOC.Cantidad_Base =  "";
                dtOC.Indicador_IVA =  "";
                dtOC.Clase_Valoracion =  "";
                dtOC.Tipo_OC =  "";
                dtOC.Tipo_Mov =  "";
                dtOC.Tipo_Imputacion =  "";
                dtOC.Cuenta_Imputacion =  "";
                dtOC.Pos_Doc_Mov =  "";
                dtOC.Clase_Mov =  "";
                dtOC.Cuenta_Imputacion =  "";
                int pos = 0;
                List<KeyValuePair<int, string>> previos = new List<KeyValuePair<int, string>>();
                foreach(var m in datos)
                {
                    string _mensaje = m.Value;
                    if(_mensaje.Equals("No se logró conectar con la estructuras SAP") ==false)
                    {
                        if (pos == 0)
                            previos.Add(new KeyValuePair<int, string>(pos, _mensaje));
                        else
                        {
                            var existe = from prev in previos where prev.Value.Equals(_mensaje) == true select prev;
                            if(existe!=null)
                                if(existe.Count()<=0)
                                    previos.Add(new KeyValuePair<int, string>(pos, _mensaje));
                        }
                    }
                    pos++;
                }
                foreach(KeyValuePair<int, string> p in previos)
                {
                    dtOC.Descripcion = dtOC.Descripcion +" | "+ p.Value;
                }
                ListadtOC.Add(dtOC);
                #endregion ---------------------------------
            }
          #endregion Pasando a  List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra>
          mensajes = datos;
            #region       Establece si es una Orden de Servicio
            List<string> unidades = new List<string>();
            foreach(Detalle_OrdenCompra revisando in ListadtOC)
            {
                unidades.Add(identificaTipoOrdenxUMedida(revisando.Unidad_Medida));
            }
            foreach(string uni in unidades)
            {
                if(uni!="Normal")
                {
                    ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra encabezado = System.Web.HttpContext.Current.Session["Encabezado_" + OrdenCompra] as ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra;
                    encabezado.tipoOrdenCompra = uni;
                    System.Web.HttpContext.Current.Session["Encabezado_" + OrdenCompra] = encabezado;
                }
            }
            #endregion Establece si es una Orden de Servicio
            return ListadtOC;
      }
      private string complementaCeros(string Posicion_OC)
      {
          int largo = Posicion_OC.Length;
          const int  total=4;
          int complementar = total - largo;
          for (int i = 0; i <= complementar;i++ )
          {
              Posicion_OC = "0" + Posicion_OC;
          }
          return Posicion_OC;
      }

      private string complementaCerosWe(string Posicion_Documento)
      {
          int largo = Posicion_Documento.Length;
          const int total = 3;
          int complementar = total - largo;
          for (int i = 0; i <= complementar; i++)
          {
              Posicion_Documento = "0" + Posicion_Documento;
          }
          return Posicion_Documento;
      }

        /// <summary>
        /// RECEPCIONES
        /// Método que extrae, crea y devuelve la información del Historial de Recepciones a partir de la Orden de Compra proporcionada
        /// </summary>
        /// <param name="OrdenCompra"></param>
        /// <returns></returns>
      public List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones> Carga_Detalle_Recepciones(string OrdenCompra)
      {
          #region        Tabla de Detalle_Recepciones Hardcodeada

          List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones> recepciones = new List<ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones>();
          //ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones recepcion = new ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones();

          #region        Recupera la información desde el Conector SAP

          SAP.Middleware.Connector.RfcDestination conector = Conectores.Configuracion.csBaseSAPNET.GetRfcDestination;
          List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();

          #region Extrayendo Información de la Orden de Compra
          Dictionary<string, string> estructurasRecepciones = new Dictionary<string, string>();
          //Define las estructuras que se empatarán entre SAP y la antigua base de datos de SQL Server, base de las estructuras manejadas en la aplicación
          csBaseSAPNET csbasesapnet = new csBaseSAPNET();
          estructurasRecepciones.Add("Detalle_Recepciones", "PO_ITEM_HISTORY");

          #region  Poblando la estructuras SAP-SQL Server
          foreach (KeyValuePair<string, string> estructura in estructurasRecepciones)
          {
              string estructura_SAP = estructura.Value;
              string estructura_SQLSever = estructura.Key;
              DataSet OC = conectores_obtenBAPI_PO_GETDETAIL(conector, OrdenCompra, ref datos, estructura_SAP);
              foreach (DataTable tbl in OC.Tables)
              {
                  if (tbl.TableName == estructura_SAP)
                  {
                      Dictionary<KeyValuePair<string, string>, int> estructuraxImplementar = new Dictionary<KeyValuePair<string, string>, int>();
                      List<List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer>> listadoRecepciones = new List<List<csBaseSAPNET.estructura_SAP_SQLServer>>(); //csbasesapnet.renglon_PO_ITEMS_SQLServer();
                      List<ClickFactura_WebServiceCF.Conectores.Configuracion.csBaseSAPNET.estructura_SAP_SQLServer> renglonRepositorio = new List<csBaseSAPNET.estructura_SAP_SQLServer>();//csbasesapnet.renglon_PO_ITEM_HISTORY_SQLServer(); 
                      List<string> camposSQL = new List<string>();
                      //if (estructura_SAP.Equals("PO_ITEM_HISTORY") == true)
                      //{
                      //    estructuraxImplementar = csbasesapnet.estructura_PO_ITEM_HISTORY();
                      //}
                      #region PO_ITEMS
                      if (estructura_SAP.Equals("PO_ITEM_HISTORY") == true)
                      {
                          estructuraxImplementar = csbasesapnet.estructura_PO_ITEM_HISTORY();
                          var camposSAP = from c in estructuraxImplementar.Keys select c;
                          string valorSAP = "";
                          foreach (DataRow ren in tbl.Rows)
                          {
                              renglonRepositorio = csbasesapnet.renglon_PO_ITEM_HISTORY_SQLServer(); //csbasesapnet.renglon_PO_ITEMS_SQLServer();
                              if (camposSQL == null || camposSQL.Count() == 0)
                                     camposSQL = renglonRepositorio.Select(s => (string)s.Campo_SQLServer).ToList();
                              foreach (DataColumn col in tbl.Columns)//  ###################
                              {
                                  var encontrado = from columna in camposSAP where columna.Value.Equals(col.Caption) == true select columna;
                                  if (encontrado != null && encontrado.Count() > 0)
                                  {
                                      var valor = from val in estructuraxImplementar where val.Key.Value.Equals(col.Caption) == true select val;
                                      foreach (var recuperado in valor)
                                      {
                                          int posicion = Convert.ToInt32(recuperado.Value.ToString());
                                          valorSAP = ren.ItemArray[posicion].ToString();
                                          break;
                                      }
                                      foreach (var _renglonSQLServer in renglonRepositorio)
                                      {
                                          if (_renglonSQLServer.Campo_SAP.Equals(col.Caption) == true)
                                          {
                                              _renglonSQLServer.Valor = valorSAP;
                                              break;
                                          }
                                      }
                                  }
                              }
                              listadoRecepciones.Add(renglonRepositorio);
                          }// ######## Del foreach(DataRow ren in tbl.Rows)  ##############
                      }// Del ###  if (estructura_SAP.Equals("PO_ITEM_HISTORY") == true)
                       //La estructura "tbl" contiene los registro directos de SAP
                        #region extrae la moneda del Sistema
                        int result = 0;
                        adT_Parametros adp = new adT_Parametros();
                        List<objT_Parametros> objp = new List<objT_Parametros>();
                        string cultura = "es-MX";
                        objp = adp.mABCT_Parametros(out result, 0, "CurrencySystem", "Vacio", true, "ConsultaValor");
                        {
                            cultura = objp[0].ValorParametro.ToString();
                            System.Globalization.CultureInfo actualCultura = System.Threading.Thread.CurrentThread.CurrentCulture;
                            cultura = actualCultura.ToString();
                            System.Console.WriteLine(actualCultura.ToString());
                        }
                        #endregion extrae la moneda del Sistema
                        if (estructura_SAP.Equals("PO_ITEM_HISTORY") == true)
                      {
                          int posiciones = 0;
                          #region Llenado de las líneas de los Detalle de Orden de Compra
                          if (camposSQL == null || camposSQL.Count()==0)
                              camposSQL = renglonRepositorio.Select(s => (string)s.Campo_SQLServer).ToList();
                          for (int j = 0; j <= tbl.Rows.Count - 1; j++)
                          {
                              ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones recepcion = new ClickFactura_Entidades.BD.Modelos.Detalle_Recepciones();

                              renglonRepositorio=listadoRecepciones[j];
                              foreach (var desdeSAP in renglonRepositorio)
                              {
                                  string valor = desdeSAP.Valor;
                                  string columna = desdeSAP.Campo_SQLServer;
                                  var esColumna = from col in camposSQL where col.Equals(columna) == true select col;
                                  if (esColumna != null && esColumna.Count() > 0)
                                  {//######################################################################################################################
                                      if (desdeSAP.Campo_SQLServer.Equals(columna) == true)
                                      {
                                          #region Pasa la información
                                          //if (desdeSAP.Campo_SQLServer.Equals("IdRecepcion") == true)
                                              recepcion.IdRecepcion = posiciones.ToString();
                                          //if (desdeSAP.Campo_SQLServer.Equals("Orden_Compra") == true)
                                              recepcion.Orden_Compra = OrdenCompra;
                                          if (desdeSAP.Campo_SQLServer.Equals("Posicion_OrdenCompra") == true)
                                              recepcion.Posicion_OrdenCompra = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Numero_ActualImput") == true)
                                              recepcion.Numero_ActualImput = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("YearDocumento") == true)
                                              recepcion.YearDocumento = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Numero_Documento") == true)
                                              recepcion.Numero_Documento = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Posicion_Documento") == true)
                                              recepcion.Posicion_Documento = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Tipo_Movimiento") == true)
                                              recepcion.Tipo_Movimiento = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Clave_Movimiento") == true)
                                              recepcion.Clave_Movimiento = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Fecha_Contable") == true)
                                              recepcion.Fecha_Contable = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Cantidad") == true)
                                            {
                                                //double val;
                                                //if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                //{
                                                //    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                //}
                                                //valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                //recepcion.Cantidad = valor.Replace("$", "");
                                                //recepcion.Cantidad = recepcion.Cantidad.Replace(",", "");
                                                //recepcion.Cantidad = convierteMoneyTKPM(recepcion.Cantidad);

                                                #region Adecua formato moneda
                                                string entorno = "";
                                                string _Cantidad = "";
                                                bool publicado = false;
                                                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                                {
                                                    entorno = objp[0].ValorParametro.ToString();
                                                    publicado = entorno.Equals("1") == true ? true : false;
                                                }
                                                if (publicado == false)
                                                {
                                                    #region Si estas local
                                                    double val;
                                                    if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                    {
                                                        string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                    }
                                                    valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                    _Cantidad = valor.Replace("$", "");
                                                    _Cantidad = _Cantidad.Replace(",", "");
                                                    _Cantidad = convierteMoneyTKPM(_Cantidad);
                                                    #endregion Si estas local
                                                }
                                                else
                                                {
                                                    #region        En el Servidor
                                                    _Cantidad = valor;
                                                    _Cantidad = _Cantidad.Replace(".", "");
                                                    _Cantidad = _Cantidad.Replace(",", ".");
                                                    #endregion En el Servidor
                                                }
                                                #endregion Adecua formato moneda
                                                recepcion.Cantidad = _Cantidad;

                                                //Con moneda alineada
                                                //recepcion.Cantidad = valor;
                                            }
                                          if (desdeSAP.Campo_SQLServer.Equals("Importe_Local") == true)
                                            {
                                                //double val;
                                                //if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                //{
                                                //    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                //}
                                                //valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                //recepcion.Importe_Local = valor.Replace("$", "");
                                                //recepcion.Importe_Local = recepcion.Importe_Local.Replace(",", "");
                                                //recepcion.Importe_Local = convierteMoneyTKPM(recepcion.Importe_Local);

                                                #region Adecua formato moneda
                                                string entorno = "";
                                                string _Cantidad = "";
                                                bool publicado = false;
                                                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                                {
                                                    entorno = objp[0].ValorParametro.ToString();
                                                    publicado = entorno.Equals("1") == true ? true : false;
                                                }
                                                if (publicado == false)
                                                {
                                                    #region Si estas local
                                                    double val;
                                                    if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                    {
                                                        string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                    }
                                                    valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                    _Cantidad = valor.Replace("$", "");
                                                    _Cantidad = _Cantidad.Replace(",", "");
                                                    _Cantidad = convierteMoneyTKPM(_Cantidad);
                                                    #endregion Si estas local
                                                }
                                                else
                                                {
                                                    #region        En el Servidor
                                                    _Cantidad = valor.Replace(".",",");
                                                   // _Cantidad = _Cantidad.Replace(".", "");
                                                   // _Cantidad = _Cantidad.Replace(",", ".");
                                                    #endregion En el Servidor
                                                }
                                                #endregion Adecua formato moneda
                                                recepcion.Importe_Local = _Cantidad;

                                                //Con moneda alineada
                                                //recepcion.Importe_Local = valor;
                                            }
                                          if (desdeSAP.Campo_SQLServer.Equals("Importe_Documento") == true)
                                            {
                                                //double val;
                                                //if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                //{
                                                //    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                //}
                                                //valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                //recepcion.Importe_Documento = valor.Replace("$", "");
                                                //recepcion.Importe_Documento = recepcion.Importe_Documento.Replace(",", "");
                                                //recepcion.Importe_Documento = convierteMoneyTKPM(recepcion.Importe_Documento);

                                                #region Adecua formato moneda
                                                string entorno = "";
                                                string _Cantidad = "";
                                                bool publicado = false;
                                                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                                                {
                                                    entorno = objp[0].ValorParametro.ToString();
                                                    publicado = entorno.Equals("1") == true ? true : false;
                                                }
                                                if (publicado == false)
                                                {
                                                    #region Si estas local
                                                    double val;
                                                    if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                                                    {
                                                        string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                                                    }
                                                    valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                                                    _Cantidad = valor.Replace("$", "");
                                                    _Cantidad = _Cantidad.Replace(",", "");
                                                    _Cantidad = convierteMoneyTKPM(_Cantidad);
                                                    #endregion Si estas local
                                                }
                                                else
                                                {
                                                    #region        En el Servidor
                                                    _Cantidad = valor.Replace(".", ",");
                                                    //_Cantidad = _Cantidad.Replace(".", "");
                                                    //_Cantidad = _Cantidad.Replace(",", ".");
                                                    #endregion En el Servidor
                                                }
                                                #endregion Adecua formato moneda
                                                recepcion.Importe_Documento = _Cantidad;

                                                //Con moneda alineada
                                                //recepcion.Importe_Documento = valor;
                                            }

                                            if (desdeSAP.Campo_SQLServer.Equals("Moneda") == true)
                                              recepcion.Moneda = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("IndicadorHD") == true)
                                              recepcion.IndicadorHD = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("YearDocumentoRef") == true)
                                          {
                                              //Se asume es la última columna a mapear, importante por el indicador posiciones que enumera las líneas a traves de dar valor a IdRecepciones
                                              recepcion.YearDocumentoRef = valor;
                                              posiciones++;
                                          }

                                          if (desdeSAP.Campo_SQLServer.Equals("Documento_Referencia") == true)
                                              recepcion.Documento_Referencia = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Posicion_DocumentoRef") == true)
                                              recepcion.Posicion_DocumentoRef = valor;
                                          if (desdeSAP.Campo_SQLServer.Equals("Cantidad_Medida_Pedido") == true)
                                              recepcion.Cantidad_Medida_Pedido = valor;
                                          #endregion Pasa la información
                                      }
                                  }//######################################################################################################################
                              }

                              //Agregando el nuevo renglón a Detalles de Orden de Compra tabla virtual
                              recepciones.Add(recepcion);
                          }
                          #endregion Llenando de las línea de los Detalles de Orden de Compra
                      }
                      #endregion PO_ITEMS
                  }
              }
          }
          #endregion Poblando la estructuras SAP-SQL Server
          #endregion Extrayendo Información de la Orden de Compra
          #endregion Recupera la información desde el Conector SAP

          #region Información básica
          //recepcion.IdRecepcion = "1000";
          //recepcion.Orden_Compra = OrdenCompra;
          //recepcion.Posicion_Orden_Compra = "00010";
          //recepcion.Numero_ActualImput = "00";
          //recepcion.Clase_Operacion = "1";
          //recepcion.Year_Documento = "2017";
          //recepcion.Numero_Documento = "5002838433";
          //recepcion.Posicion_Documento = "0001";
          //recepcion.Tipo_Movimiento = "E";
          //recepcion.Clave_Movimiento = "101";
          //recepcion.Fecha_Contable = "20170313";
          //recepcion.Cantidad = "1";
          //recepcion.Importe_Local = "10000.00";
          //recepcion.Importe_Documento = "10000.00";
          //recepcion.Moneda = "MXN";
          //recepcion.IndicadorHD = "Null";
          //recepcion.YearDocumentoRef = "2017";
          //recepcion.Documento_Referencia = "5002838433";
          //recepcion.Posicion_DocumentoRef = "0001";
          //recepcion.Cantidad_Medida_Pedido = "1.000";
          //recepciones.Add(recepcion);
          #endregion Información básica

          #region        Pasando a  List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones>
          //ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones dtOC = new ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones();
          List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones> ListadtOC = new List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones>();
          foreach (var reg in recepciones)
          {
              ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones dtOC = new ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones();
              dtOC.IdRecepcion = Convert.ToInt32(reg.IdRecepcion);
              dtOC.Orden_Compra = reg.Orden_Compra;
              dtOC.Posicion_OrdenCompra = reg.Posicion_OrdenCompra!=null?complementaCeros(reg.Posicion_OrdenCompra):"";
              dtOC.Numero_ActualImput = reg.Numero_ActualImput!=null?reg.Numero_ActualImput:"";
              dtOC.Clase_Operacion = reg.Clase_Operacion!=null?reg.Clase_Operacion:"";
              dtOC.YearDocumento = reg.YearDocumento!=null?reg.YearDocumento:"";
              dtOC.Numero_Documento = reg.Numero_Documento!=null?reg.Numero_Documento:"";
              dtOC.Posicion_Documento = reg.Posicion_Documento!=null? complementaCerosWe(reg.Posicion_Documento):"";
              dtOC.Tipo_Movimiento = reg.Tipo_Movimiento!=null?reg.Tipo_Movimiento:"";
              dtOC.Clave_Movimiento = reg.Clave_Movimiento!=null?reg.Clave_Movimiento:"";
              dtOC.Fecha_Contable = reg.Fecha_Contable!=null?reg.Fecha_Contable:"";
              dtOC.Cantidad = reg.Cantidad!=null?reg.Cantidad:"";
              dtOC.Importe_Local = reg.Importe_Local!=null?reg.Importe_Local:"";
              dtOC.Importe_Documento = reg.Importe_Documento!=null?reg.Importe_Documento:"";
              dtOC.Moneda = reg.Moneda!=null?reg.Moneda:"";
              dtOC.IndicadorHD = reg.IndicadorHD!=null?reg.IndicadorHD:"";
              dtOC.YearDocumentoRef = reg.YearDocumentoRef!=null?reg.YearDocumentoRef:"";
              dtOC.Documento_Referencia =  reg.Documento_Referencia!=null? reg.Documento_Referencia:"";
              dtOC.Posicion_DocumentoRef = reg.Posicion_DocumentoRef!=null? complementaCerosWe(reg.Posicion_DocumentoRef) :"";
              dtOC.Cantidad_Medida_Pedido = reg.Cantidad_Medida_Pedido!=null?reg.Cantidad_Medida_Pedido:"";
              ListadtOC.Add(dtOC);
          }
          #endregion Pasando a  List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra>

          return ListadtOC;
          #endregion Tabla de recepciones Hardcodeada
      }

      public ClickFactura_Entidades.BD.Modelos.TablaGeneralModel viewRecepciones_RecepcionesSeleccionadas(string ordenCompra, ref List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> facturas, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> objFacturasAPasivos, out List<string> mensajes)
      {
          //public ClickFactura_Entidades.BD.Modelos.TablaGeneralModel RecepcionesSeleccionadas(string ordenCompra, List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<Genericos.objLeidoFactura> facturas, ref List<Genericos.obj_facturaAPasivo> objFacturasAPasivos, out List<string> mensajes)
          mensajes = new List<string>();
          try
          {
              Dictionary<string, Type> columnas = new Dictionary<string, Type>();
              columnas.Add("Orden de Compra", typeof(string));
              columnas.Add("No Recepción", typeof(string));
              columnas.Add("Pos. Recepción", typeof(string));
              columnas.Add("Pos. Referencia", typeof(string));
              columnas.Add("Pos. Doc. Material", typeof(string));
              columnas.Add("Facturas(xml)", typeof(string));
              columnas.Add("Importe linea", typeof(double));
              columnas.Add("Pasivo", typeof(string));
              columnas.Add("Observaciones", typeof(string));
              columnas.Add("Impuesto", typeof(string));
                string formato = "";

                #region configura Importes
                adT_Parametros adp = new adT_Parametros();
                List<objT_Parametros> objp = new List<objT_Parametros>();
                int result = 0;
                #region Adecua formato moneda
                string entorno = "";
                bool publicado = false;
                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                {
                    entorno = objp[0].ValorParametro.ToString();
                    publicado = entorno.Equals("1") == true ? true : false;
                }
                if (publicado == false)
                {
                    #region Si estas local
                    formato = "#: kendo.format('{0:c}', R7) #";
                    #endregion Si estas local
                }
                else
                {
                    #region        En el Servidor

                    #endregion En el Servidor
                }
                #endregion Adecua formato moneda
                #endregion configura Importes
                string[] template = { "", "", "", "", "", "", formato, "<img class=\"img-circle\" style=\"width:30px;\" src=\"/Images/bafar/#:R8#\" />", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" };
              bool[] filtros = { false, false, true, true, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false, false, false };
              bool[] ocultos = { true, true, false, false, false, false, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false, false };


              string[] AnchoColumna = { "180px", "130px", "150px", "150px", "150px", "250px", "150px", "100px", "150px", "150px", "150px", "100px", "100px", "100px", "150px" };
              ClickFactura_Entidades.BD.Modelos.TablaGeneralModel tabla = new ClickFactura_Entidades.BD.Modelos.TablaGeneralModel();
              tabla.Seleccionar = false;
              tabla.NombreCreate = "Crear";
              tabla.NombreUpdate = "Actualizar";
              //tabla.Control = "OrdenyRecepcion";
              tabla.Control = "facturasXML";
              tabla._Edicion = "onEdit";
              tabla._Guardar = "onSave";
              tabla.NombreExcel = "excel.xlsx";
              tabla.NombreGrid = "GridRecepciones";
              tabla.Agrupar = true;
              tabla.Numerico = false;
              var combo = "<select onchange=\"Combo2()\">";
              string opciones = "<option value='0'>Seleccione</option>";
              foreach (var item in facturas)
              {
                  if (facturas.Count == 1)
                  {
                      opciones += "<option selected value='" + item.Archivo + "'>" + item.Archivo + "</option>";
                      break;
                  }
                  else
                  {
                      opciones += "<option value='" + item.Archivo + "'>" + item.Archivo + "</option>";
                  }

              }
              combo += opciones + "</select>";
              template[5] = combo;

              int x = 1;
              foreach (var col in columnas)
              {
                  tabla.Columnas.Add(new ClickFactura_Entidades.BD.Modelos.Columna()
                  {
                      Nombre = col.Key,
                      Tipo = col.Value,
                      oculto = col.Key.Contains("Id") ? true : ocultos[x - 1],
                      filtreable = false,
                      Ancho = AnchoColumna[x - 1],
                      ClientTemplate = template[x - 1]
                  });
                  tabla.NombresModel.Add("R" + x);
                  x += 1;
              }
              tabla.CamposAgrupados = new Dictionary<string, Type>();
              tabla.CamposAgrupados.Add("R1", tabla.Columnas[0].Tipo);
              tabla.CamposAgrupados.Add("R2", tabla.Columnas[1].Tipo);
              objFacturasAPasivos = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo>();  //List<Genericos.obj_facturaAPasivo>();
              x=0;
                foreach (var item in registros)
                {
                    if (item.R15.ToString() != "Q")
                    { 
                        #region registrando Renglon
                        if (facturas.Count == 1)
                        {
                            item.R18 = facturas[0].Archivo;
                            registros[x].R5 = ordenCompra;
                        }
                        else
                        {
                            item.R18 = "";
                            registros[x].R5 = ordenCompra;
                        }
                    //Genericos.obj_facturaAPasivo obje = new Genericos.obj_facturaAPasivo();
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo obje = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo();
                    //Aqui el problema de campos mezclados!!
                    obje.OrdenCompra = ordenCompra;
                    obje.Posicion = item.R1.ToString();
                    obje.NoRecepcion = item.R2.ToString();
                    obje.NoItem = item.R4.ToString() == "Q" ? item.R15.ToString() : item.R3.ToString();
                    obje.Posicion_Documento_Material = item.R3.ToString();
                    obje.FechaFactura = item.R5.ToString();
                    obje.Piezas = item.R6.ToString();
                    obje.Importe = item.R7.ToString();
                    obje.Impuesto = item.R9.ToString();
                    obje.Año = item.R4.ToString() == "Q" ? item.R15.ToString() : item.R13.ToString();
                    obje.Documento_Referencia = item.R16.ToString();
                    obje.ImporteUnitario = Convert.ToDouble(item.R17);
                    obje.NombreArchivo = item.R18 != null ? item.R18.ToString() : "";
                    obje.EsdocumentoReferencia = item.R4.ToString() == "Q" ? "S" : "N";
                    obje.DiferenciaImportes = 0;
                    obje.UnidadMedidaSAP = item.R11.ToString();
                    #region Actualizacion del viejo al nuevo Portal GRD 5 Dic 2016
                    if (facturas != null && facturas.Count() > 0)
                    {
                        var existeFactura = from f in facturas where f.NombreArchivo.Equals(obje.NombreArchivo) == true select f;
                        if (existeFactura != null && existeFactura.Count() > 0)
                        {
                            obje.ImporteDocumento = Convert.ToDouble(facturas[0].SubTotal);
                            obje.IvaTrasladadoTotal = facturas[0].ImporteTrasladado;
                        }
                    }

                    #endregion Actualizacion del viejo al nuevo Portal GRD 5 Dic 2016
                    objFacturasAPasivos.Add(obje);
                    List<object> reg = new List<object>();
                    reg.Add(ordenCompra);
                    reg.Add(obje.NoRecepcion);                  //R2
                    reg.Add(obje.Posicion);                     //R1
                    reg.Add(obje.NoItem);                       //R3
                    reg.Add(obje.Posicion_Documento_Material);  //R3
                    reg.Add(obje.NombreArchivo);                //Factura
                    reg.Add(obje.Importe);                      //R7
                    reg.Add("reloj.png");
                    reg.Add("En espera...");
                    reg.Add(obje.Impuesto);                     //R9
                    tabla.Registros.Add(new ClickFactura_Entidades.BD.Modelos.Registros().MapeaDatos(reg));
                    x += 1;
                    #endregion
                     }
                }

              return tabla;
          }
          catch (Exception ex)
          {
              mensajes.Add(ex.Message);
              return null;
          }
      }

        /// <summary>
        /// Tabla Detalle: Estructra HTML que se carga para mostrar las Recepciones
        /// existentes
        /// La cadena es interpretada y cargada como HTML directo en la vista.
        /// </summary>
        /// <param name="DsTabla"> Dentro del DataSet "DsTabla" en la Tabla[0] viene la tabla con los datos obtenidos de SAP</param>
        /// <returns></returns>
        /// 
          public string TablaDetalle(DataSet  DsTabla)//DataTable tabla)
          {
              DataTable tabla = DsTabla.Tables[0];
              try
              {
                  string tablaDetalle = "<table class=\"table table-bordered table-striped\">"
                          + "<thead>"
                              + "<tr>"
                                  + "<th>#</th>"
                                  + "<th>Descripción</th>"
                                  + "<th>Posición</th>"
                                  //+ "<th>Fecha</th>"
                                  + "<th>Cantidad</th>"
                                  + "<th>Importe</th>"
                                  + "<th>Moneda</th>"
                                  + "<th>Doc. Pasivo</th>"
                                  + "<th>Doc. Cancelación</th>"
                                  + "<th>No. Material </th>"
                                  + "<th>Ind. impuesto </th>"
                              + "</tr>"
                          + "</thead>"
                          + "<tbody>";
                  int x = 1;
                  string registros = "";
                  foreach (DataRow item in tabla.Rows)
                  {
                      registros += "<tr>";
                      registros += "<td>" + x + "</td>";
                      registros += "<td>" + item["Descripcion"].ToString() + "</td>";
                      //Obsoleto 12 Julio 2017 registros += "<td>" + item["Pos_Doc_Mov"].ToString() + "</td>";
                      registros += "<td>" + item["Posicion_OC"].ToString() + "</td>";
                      //registros += "<td>" + item["Fecha_Contable"].ToString() + "</td>";
                      string _cantidad = item["Cantidad"].ToString();
                      _cantidad = String.Format("{0:0.##}", _cantidad);
                      registros += "<td>" +_cantidad + "</td>";
                      string _importe = item["Importe"].ToString();
                      _importe = String.Format("{0:C}",_importe);                                                                                        // ("C", new System.Globalization.CultureInfo("es-MX"));
                      registros += "<td>" + _importe + "</td>"; // item["Importe"].ToString() + "</td>";
                      registros += "<td>" + item["Moneda"].ToString() + "</td>";
                      registros += "<td>" + item["Numero_Pasivo"].ToString() + "</td>";
                      registros += "<td>" + item["Numero_Cancelacion"].ToString() + "</td>";
                      registros += "<td>" + item["Numero_Material"].ToString() + "</td>";
                      if(item["Indicador_IVA"].ToString().Contains("rror")==false)
                          registros += "<td>" + item["Indicador_IVA"].ToString() + "</td>";
                      else
                        registros += "<td style='background-color:#FF0000;color:#FFFFFF;font - weight:bold'> " + item["Indicador_IVA"].ToString() + "</td>";
                       registros += "</tr>";
                      x += 1;
                  }
                  tablaDetalle += registros + "</tbody></table>";
                  return tablaDetalle;
              }
              catch (Exception ex)
              {
                  return "<strong>No se pudo crear la tabla de detalles de la orden de compra</strong><br>Error: " + ex.Message;
              }
          }

          #endregion Grid de Recepciones (Vista)

      #endregion Implementación y operaciones de Recepciones #################################################################################################

      #region       Implementación y operaciones con las Facturas XML

          #region     Carga y lectura de Facturas XML

          //Dictionary<string, string> FacturasCargadas = new Dictionary<string, string>();
          public Dictionary<string, string> FacturasCargadas
          {
              get;
              set;
          }
          public DataTable Tabla
          {
              get;
              set;
          }

          /// <summary>
          /// Identifica el Número de Proveedor asignado a una orden de Compra 
          /// </summary>
          /// <param name="orden"></param>
          /// <returns></returns>
          public string ObtenerNumProveedor(string orden)
          {
              string oc = "";
              using (var ctx = new Desarrollo_CF())
              {
                  IList<ClickFactura_Entidades.BD.Entidades.SP_Info_OrdenCompra_Result> Oc = ctx.SP_Info_OrdenCompra(orden).ToList<ClickFactura_Entidades.BD.Entidades.SP_Info_OrdenCompra_Result>();
                  oc = Oc != null ? Oc[0].Num_Proveedor : "";
              }
              return oc;
          }
          public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_DescomprimirPaquete(string oc, string ruta, string nombre, List<string> datos, out List<List<string>> lsMensajes)
          {
              try
              {
                  lsMensajes = new List<List<string>>();
                  //List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> facturas = new List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura>();
                  List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> facturas = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura>();
                  using (Ionic.Zip.ZipFile zip = Ionic.Zip.ZipFile.Read(ruta))
                  {
                      var rutaTmp = ruta.Substring(0, ruta.Length - (nombre.Length + 1));
                      zip.ExtractExistingFile = Ionic.Zip.ExtractExistingFileAction.OverwriteSilently;
                      zip.ExtractAll(rutaTmp);
                      var archivos = System.IO.Directory.GetFiles(rutaTmp);
                      datos.Insert(0, "XML");

                      foreach (var item in archivos)
                      {
                          if (item.Contains(".xml"))
                          {
                              List<string> mensajes = new List<string>();
                              var i = item.LastIndexOf('\\') + 1;
                              var nom = item.Substring(i);
                              string rfcF;
                              List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> v = factXML_ValidarFactura(oc, item, nom, datos, out rfcF, out mensajes);
                              if (v != null)
                                  facturas.Add(v[0]);
                              mensajes.Insert(0, nom);
                              lsMensajes.Add(mensajes);
                          }
                      }

                  }
                  return facturas;
              }
              catch (Exception ex)
              {
                  lsMensajes = new List<List<string>>();
                  List<string> m = new List<string>();
                  m.Add("Error: " + ex.Message);
                  lsMensajes.Add(m);
                  throw;
              }
          }

          public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_ValidarFactura(string oc, string rutaArchivo, string nombre, List<string> datos, out string rfcfactura, out List<string> mensajes)
          {
              var ctx = new Desarrollo_CF();
              mensajes = new List<string>();
              string[] listaErrores = { };
              List<KeyValuePair<string,string>> infoProveedor=new List<KeyValuePair<string,string>>();
              try
              {
                  bool resultadodeesteXML = false;
                  //List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> listado = new List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura>();
                  List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listado = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura>();
                  rfcfactura = "";
                  string RFCEmisor = "";
                  string RFCReceptor = "";
                  string _UUID = "";
                  string _FolioFactura = "";
                  string RFC_PROV = "";
                  string idProveedor = "";
                  bool esXML = datos[0].Contains("XML") ? true : false;
                  string usuario = datos[1];
                  string numProveedor = datos[2];
                  string ordenCompra = datos[4];
                  string sociedad = (from t in ctx.Relacion_Proveedores where t.Num_Proveedor == numProveedor select t.Num_Sociedad).FirstOrDefault();
                  int idProv = -1;
                  bool seAdmon = true;
                  #region Obten información generica del proveedor
                 infoProveedor= factXML_obtenDatosProveedor("Num_Proveedor",datos[2].ToString());//"100263");
                  var _rfc=from r in infoProveedor where r.Key.Equals("Num_Proveedor")==true select r;

                  #endregion Obten información generica del proveedor
                  seAdmon=ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.EsAdministradorBafar(usuario);
                  //if (cliente.EsAdministradorBafar(usuario))
                  if (seAdmon)
                  {
                      RFC_PROV = infoProveedor[1].Value;// _rfc.FirstOrDefault().Value;// "AAA010101AAA";// Genericos.cs_Estaticos.ObtenRFCProveedor(numProveedor, out idProv); //OFI920113KZ8
                      idProveedor = idProv.ToString();
                      if (RFC_PROV == "")
                      {
                          mensajes.Add("0No existe el proveedor en la base de datos, consulte con el administrador para actualizar los datos del proveedor.");
                          return null;
                      }
                  }
                  //Valido por SAT
                  bool valido = false;
                  bool validaBD = false;
                  if (esXML)
                  {
                      valido = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura().Lectura_FacturaExpress33(nombre, ref listado, rutaArchivo, ref resultadodeesteXML, ref RFCEmisor, ref RFCReceptor, ref _UUID, ref _FolioFactura,ref listaErrores);
                      rfcfactura = RFCEmisor;
                      foreach (var item in listado)
                      {
                          if (item.Error == "Factura válida.")
                              mensajes.Add("1" + item.Error + " </br> La validación de la factura se realizo correctamente.");
                          else
                          {
                              mensajes.Add("0" + item.Error);
                              if (listaErrores != null)
                              {
                                  int pos = 1;
                                  foreach (string err in listaErrores)
                                  {
                                      mensajes.Add("Error " + pos.ToString() + " " + err);
                                      pos++;
                                  }
                              }
                          }
                      }
                      if (valido)
                      {
                          string tmpRFC = string.Empty;
                          if (usuario.Length > 12)
                              tmpRFC = usuario.Substring(0, 12);
                          //Validar en BD
                          if(seAdmon==true)
                          {
                              RFC_PROV = RFCEmisor;
                          }
                          if (usuario.Equals(RFCEmisor) || RFC_PROV.Equals(RFCEmisor) || tmpRFC.Equals(RFCEmisor))
                          {
                              string mensaje = "";
                            foreach(var fac in listado)
                            {
                                if(fac.NombreArchivo.Equals(nombre) == true)
                                {
                                    if(fac.Version.Equals("3.2") == true)
                                    {
                                        validaBD = true;
                                    }
                                    else
                                    {
                                        validaBD = true;
                                    }
                                    break;
                                }
                            }
                              //var _mifacturaActual=from fac in listado where fac.NombreArchivo.Equals(nombre)==true && fac.Version.Equals("3.2")==true select fac;
                              //if (_mifacturaActual != null && _mifacturaActual.Count()>0)
                              //{
                              //        //ClickFactura_Facturacion.wsBafar.IServicio_ClickFactura wsbafar;
                              //       // wsbafar = null;
                              //    validaBD = true;// existelaFacturaPreviamente(_mifacturaActual);// wsbafar.VerificarFacturaBD(out oc, RFCReceptor, numProveedor, sociedad, mensaje);
                              //}
                              //else
                              //{
                              //    //falta validar que exista en la base de datos de verificación
                              //    validaBD = true;
                              //}
                              if (validaBD)
                              {
                                  if (mensaje != string.Empty)
                                      mensajes.Add("1" + mensaje);
                                  else
                                      mensajes.Add("1Información validada correctamente");

                                  return listado;
                              }
                              mensajes.Add("0" + mensaje);
                              return null;
                          }
                          else
                          {
                              string rfc_ = RFC_PROV != "" ? RFC_PROV : tmpRFC != string.Empty ? tmpRFC : usuario;
                              mensajes.Add("0El RFC del emisor '" + RFCEmisor + "' no coincide con el RFC: '" + rfc_ + "' del registro seleccionado.");
                              return null;
                          }
                      }
                      else
                      {
                          mensajes.Add("0La factura '" + nombre + "' no es válido para SAT.\nVerifique el archivo no este dañado o alterado.");
                          return null;
                      }
                  }
                  else
                  {
                      mensajes.Add("0La factura '" + nombre + "' no es una arhivo XML.");
                      return null;
                  }

              }
              catch (Exception ex)
              {
                  rfcfactura = "";
                  if(listaErrores!=null)
                  {
                      int pos = 1;
                      foreach(string err in listaErrores)
                      {
                          mensajes.Add("Error "+pos.ToString()+" "+ err);
                          pos++;
                      }
                  }
                  mensajes.Add("0Error: " + ex.Message);
                  return null;
              }
          }
          public List<objNotaCredito32> factXML_ValidarNotaCredito(string ruta, string nombre, out List<string> mensajes)
          {
              mensajes = new List<string>();
              try
              {
                  //Carga Notas de Credito
                  #region 23
                  bool resultadoUltimo = false;

                  List<objNotaCredito32> notascredito = new List<objNotaCredito32>();
                  cs_Factura leerXML = new cs_Factura();
                  string Tipo = "NotaCredito";
                  string RFC_Emisor = "";
                  string RFC_Receptor = "";
                  leerXML.Lectura_NotaCreditoExpress(nombre, ref notascredito, ruta, Tipo, ref resultadoUltimo, ref RFC_Emisor, ref RFC_Receptor, -1);


                  return notascredito;
                  #endregion 23

              }
              catch (Exception ex)
              {
                  mensajes.Add(ex.Message);
                  return null;
              }
          }

          public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_FusionarFacturas(List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> lista1, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> lista2)
          {
            List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> lista3 = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura>();
            string num_proveedor = System.Web.HttpContext.Current.Session["Num_Proveedor"] as string;
              foreach (var item in lista1)
              {
                  var existe = (from t in lista2 where t.Archivo.Equals(item.Archivo)==true && t.RFC.Equals(num_proveedor)==true select t.Archivo).FirstOrDefault();
                  if (existe == null)
                  {
                            lista2.Add(item);
                  }
              }
              return lista2;
          }

          public string factXML_VistaCompararImportes(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> FacturasLeidas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> NotasC, List<ClickFactura_Entidades.BD.Modelos.Registros> session_TablaRecepcionesAPasivo)
          {
              try
              {
                  string mensaje = "";
                  registros = ConvertirRegistros(registros);
                  var lista = factXML_CompararImportes(registros, FacturasLeidas, NotasC, out mensaje);
                  session_TablaRecepcionesAPasivo = registros;
                  string elemento = "";
                  List<string> etiquetado = new List<string>();
                  bool correcto = false;
                  foreach (var item in lista)
                  {
                      correcto = Convert.ToBoolean(item.Value);
                      if (correcto)
                          elemento = "<div class=\"alert alert-success alert-dismissable\">";
                      else
                          elemento = "<div class=\"alert alert-danger alert-dismissable\">";
                      var msg = item.Key.Split('|');
                      foreach (var etiqueta in msg)
                      {
                          if (etiqueta != "")
                          {
                              var lbl = etiqueta.Split('*');
                              if (lbl.Length > 1 || etiqueta.Contains(".xml"))
                              {
                                  elemento += "<p class=\"text-justify\"><ul>";
                                  foreach (var we in lbl)
                                  {
                                      elemento += "<li>" + we + "</li>";
                                  }
                                  elemento += "</ul></p>";
                              }
                              else
                              {
                                  elemento += "<p class=\"text-justify\">" + etiqueta + "</p>";
                              }
                          }
                      }
                      elemento += "</div>";
                      etiquetado.Add(elemento);
                  }

                  JavaScriptSerializer a = new JavaScriptSerializer();

                  return a.Serialize(new 
                  {
                      lista = etiquetado,
                      correcto = correcto
                  });
              }
              catch (Exception ex)
              {
                  JavaScriptSerializer a = new JavaScriptSerializer();
                  return a.Serialize(ex.Message);
              }
          }

         public List<ClickFactura_Entidades.BD.Modelos.Registros> configurandoCantidades(List<ClickFactura_Entidades.BD.Modelos.Registros> cuantosWE)
        {
            List<ClickFactura_Entidades.BD.Modelos.Registros> modificado = new List<ClickFactura_Entidades.BD.Modelos.Registros>();
            foreach(ClickFactura_Entidades.BD.Modelos.Registros editando in cuantosWE)
            {
                string cantidadOriginal = editando.R7.ToString();

                #region      configura Importes R7
                adT_Parametros adp = new adT_Parametros();
                List<objT_Parametros> objp = new List<objT_Parametros>();
                int result = 0;
                string cultura = "es-MX";
                string valor = cantidadOriginal;
                #region Adecua formato moneda
                string entorno = "";
                string _Cantidad = "";
                bool publicado = false;
                objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
                {
                    entorno = objp[0].ValorParametro.ToString();
                    publicado = entorno.Equals("1") == true ? true : false;
                }
                if (publicado == false)
                {
                    #region Si estas local
                    //double val;
                    //if (double.TryParse(valor, System.Globalization.NumberStyles.Float, new System.Globalization.CultureInfo(cultura), out val))
                    //{
                    //    string valInGermanFormat = val.ToString(new System.Globalization.CultureInfo(cultura));
                    //}
                    //valor = val.ToString("C", new System.Globalization.CultureInfo("es-MX"));
                    //_Cantidad = valor.Replace("$", "");
                    //_Cantidad = _Cantidad.Replace(",", "");
                    //_Cantidad = convierteMoneyTKPM(_Cantidad);
                    #endregion Si estas local
                }
                else
                {
                    #region        En el Servidor
                    _Cantidad = valor;
                    int posComa = _Cantidad.LastIndexOf(",");
                    int largo = _Cantidad.Length;
                    int nuevaUbicacion = 0;
                    if (posComa > 0)
                    {
                        nuevaUbicacion = largo - posComa;
                    }
                    if (nuevaUbicacion > 0)
                    {
                        string parcial = _Cantidad;
                        string nuevaCadena = "";
                        string nu = "";
                        for (int i = 0; i < largo; i++)
                        {
                            nu = parcial[i].ToString();
                            if ((posComa - 2) == i)
                            {
                                nuevaCadena = nuevaCadena + "." + nu;
                            }
                            else
                            {
                                if (nu.Equals(",") == false)
                                    nuevaCadena = nuevaCadena + nu;
                            }
                        }
                        _Cantidad = nuevaCadena;
                    }
                     editando.R7 = _Cantidad;
                    #endregion En el Servidor
                }
                #endregion Adecua formato moneda

                #endregion configura Importes R7

                modificado.Add(editando);
            }
            return modificado;
        }
          public List<KeyValuePair<string, string>> factXML_CompararImportes(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> facturas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> listadoNC, out string mensajeEx, bool esOrden = true)
          {
              //List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> FacturasLeidas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> NotasC
              List<KeyValuePair<string, string>> listaresultados = new List<KeyValuePair<string, string>>();

            adT_Parametros adp = new adT_Parametros();
            List<objT_Parametros> objp = new List<objT_Parametros>();
            int resul_t = 0;
            string entorno = "";
            bool publicado = false;
            objp = adp.mABCT_Parametros(out resul_t, 0, "Publicado", "Vacio", true, "ConsultaValor");
            {
                entorno = objp[0].ValorParametro.ToString();
                publicado = entorno.Equals("1") == true ? true : false;
            }

            try
              {
                  mensajeEx = "";
                  #region 21 Evaluando Montos
                  //Protegemos disparos de algo que no procediera

                  //Tenemos una Factura y almenos un Item recepción cargados??
                  if (facturas.Count > 0 && registros.Count > 0)
                  {
                      #region Corre proceso evaluar Montos si hay al menos una Factura cargada
                      #region Es Usuario valido
                      #region Indica los pondra en Procesamiento posicion Original

                      string valorFacturaesTotal = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["valorFacturaesTotal"];
                      bool porValorFacturaTotal = valorFacturaesTotal.Equals("S") == true ? true : false;
                      #endregion Indica los pondra en Procesamiento posicion Original

                      string monedaRecepcion = "";
                      double _subtotal = 0;
                      var consultaOrden = "RecuperarInformacionOrdenCompra"; //;contexto.SP_InformacionOrdenCompra(0, registros[0].R1.ToString(), "porOrdenCompra").FirstOrDefault();
                      #region Organizando Informacion
                      foreach (var factura in facturas)
                      {
                          string monedaFactura = "";
                          string subtotal = "";
                          string subtotalNatural = "";
                          string Wes = "";
                          string subtotalSoloconIVA = "";
                          List<decimal> importes = new List<decimal>();
                          List<decimal> importesLimpio = new List<decimal>();
                          bool recepcionTieneT2 = false;
                          monedaFactura = factura.Moneda == null ? " Factura no especifica MONEDA " : factura.Moneda;
                          var cuantosWE = registros.Where(item => item.R18.ToString().Contains(factura.Archivo) == true).ToList();//6.ToString().Contains(factura.Archivo) == true).ToList();
                          //cuantosWE = configurandoCantidades(cuantosWE);
                          if (cuantosWE != null && cuantosWE.Count() > 0)
                          {
                              if (porValorFacturaTotal == false)
                              {
                                  #region desde punto de vista Valor Factura es Subtotal en deshuso
                                  if (cuantosWE.Count() > 1)
                                  {
                                      var grupoWE = cuantosWE.GroupBy(u => u.R2).Select(grp => grp.FirstOrDefault()).ToList();
                                      Wes = "";
                                      foreach (var we in grupoWE)
                                      {
                                          Wes += we.R2.ToString() + "*";
                                      }
                                      Wes = "|" + Wes.Substring(0, Wes.Length - 1);
                                  }
                                  else
                                      Wes = cuantosWE.ElementAt(0).R2.ToString();
                                  var groupedList = (from ol in cuantosWE
                                                     group ol by ol.R6
                                                         into grp
                                                         select new ClickFactura_Facturacion.Clases.paraVerificacionFactura.obj_facturaAPasivo//Genericos.obj_facturaAPasivo
                                                         {
                                                             Importe = Convert.ToString(grp.Sum(ex => Convert.ToDouble(ex.R7))),
                                                         }
                                                          ).ToList();
                                  subtotal = groupedList.First().Importe;
                                //if(publicado==true)
                                //{
                                //    subtotal = (Convert.ToDouble(subtotal) / 100).ToString();
                                //}
                                  #endregion desde punto de vista Valor Factura es Subtotal en deshuso
                              }
                              else
                              {
                                  #region desde punto de vista Valor Factura es Total
                                  if (cuantosWE.Count() > 1)
                                  {
                                      Wes = "";
                                      var grupoWE = cuantosWE.GroupBy(u => u.R2).Select(grp => grp.FirstOrDefault()).ToList();
                                      foreach (var we in grupoWE)
                                      {
                                          Wes += we.R2.ToString() + "*";
                                      }
                                      Wes = "|" + Wes.Substring(0, Wes.Length - 1);
                                  }
                                  else
                                      Wes = cuantosWE.ElementAt(0).R2.ToString();
                                //Calculando el valor de la línea incluyendo su Impuesto
                                //List<decimal> importes = new List<decimal>();
                                #region Importe exactamenteIgual Recepción
                                foreach (var item in cuantosWE)
                                  {
                                      double importe = 0;
                                     importe = Convert.ToDouble(convierteMoneyTKPM(item.R7.ToString()));
                                    //if (publicado == true)
                                    //{
                                    //    importe = Convert.ToDouble(importe) / 100;
                                    //}
                                    importes.Add(Convert.ToDecimal(importe));
                                  }
                                  subtotalNatural = importes.Sum().ToString();
                                  importes.Clear();
                                  #endregion Importe exactamenteIgual Recepción
                                  #region Importes solo con IVA- Sobre los cuales se prorratea solamente

                                  foreach (var item in cuantosWE)
                                  {

                                    //Correcion dejando el indicador de IVA que me aparece en la posición 10 -- 7 Dic 2017
                                    if(item.R9.ToString().Contains("espera")==false)
                                    {
                                          //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10 -- 3 Jul 2017
                                          item.R10 = item.R9;
                                          //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10
                                    }
                                    else
                                       item.R10 = item.R10;
                                    //Correcion dejando el indicador de IVA que me aparece en la posición10
                                    double importe = 0;
                                      if (item.R10.Equals("V0") == false)
                                          importe = Convert.ToDouble(convierteMoneyTKPM(item.R7.ToString()));// *(item.IndicadorIVA.Equals("V0") == true ? 0 : 1.16);
                                            //if (publicado == true)
                                            //{
                                            //    importe = Convert.ToDouble(importe) / 100;
                                            //}
                                    importes.Add(Convert.ToDecimal(importe));
                                  }
                                  subtotalSoloconIVA = importes.Sum().ToString();
                                  importes.Clear();
                                  #endregion Importes solo con IVA- Sobre los cuales se prorratea solamente
                                  foreach (var item in cuantosWE)
                                  {
                                    //Correcion dejando el indicador de IVA que me aparece en la posición 10 -- 7 Dic 2017
                                        if (item.R9.ToString().Contains("espera") == false)
                                        {
                                            //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10 -- 3 Jul 2017
                                            item.R10 = item.R9;
                                            //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10
                                        }
                                        else
                                            item.R10 = item.R10;
                                    //Correcion dejando el indicador de IVA que me aparece en la posición10
                                    double importe = 0;
                                      if (item.R10.Equals("V0") == false)
                                      {
                                        importe = Convert.ToDouble(convierteMoneyTKPM(item.R7.ToString())) * (item.R10.Equals("V0") == true ? 0 : 1.16);
                                     }
                                      else
                                        importe = Convert.ToDouble(convierteMoneyTKPM(item.R7.ToString()));
                                        //if (publicado == true)
                                        //{
                                        //    importe = Convert.ToDouble(importe) / 100;
                                        //}
                                        importes.Add(Convert.ToDecimal(importe));
                                  }
                                  subtotal = importes.Sum().ToString();
                                  // Acotando a 2 decimales 
                                  subtotal = Convert.ToString(Convert.ToDecimal(Math.Round(Convert.ToDecimal(subtotal) * 1.00m, 2, MidpointRounding.AwayFromZero)));
                                  //Acotando a 2 decimales      
                                  #region        Identificar si Orden de Compra presenta algun T2
                                  foreach (var item in cuantosWE)
                                  {
                                    //Correcion dejando el indicador de IVA que me aparece en la posición 10 -- 7 Dic 2017
                                            if (item.R9.ToString().Contains("espera") == false)
                                            {
                                                //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10 -- 3 Jul 2017
                                                item.R10 = item.R9;
                                                //Parche pasando el indicador de IVA que me aparece en la posición 9 a la 10
                                            }
                                            else
                                                item.R10 = item.R10;
                                    //Correcion dejando el indicador de IVA que me aparece en la posición10
                                    if (item.R10.Equals("T2") == true || item.R10.Equals("V3") == true)
                                      {
                                          recepcionTieneT2 = true;
                                      }
                                  }
                                  #endregion  Identificar si Orden de Compra presenta algun T2
                                  #endregion desde punto de vista Valor Factura es Total
                              }
                          }
                          //SubtotalRangos=SUMA DE LOS IMPORTES DE LO RECEPCIONADO
                          //double subTotalRangos = 0;

                          decimal v = new decimal();
                          try
                          {
                            if (publicado == true)
                            {
                                subtotal = (Convert.ToDouble(subtotal) / 100).ToString();
                            }
                            v = Convert.ToDecimal(subtotal);
                          }
                          catch
                          {
                              v = 0;
                          }
                          //SubtotalRangos=SUMA DE LOS IMPORTES DE LO RECEPCIONADO
                          double subTotalRangos = Convert.ToDouble(v);
                          string valorFactura = "0";

                          if (subtotal == "")
                              subTotalRangos = 0;
                          else
                              subTotalRangos = Convert.ToDouble(subtotal);

                          decimal diferenciaRealFacturaRecepcion = 0;
                          if (porValorFacturaTotal == false)
                          {
                              valorFactura = factura.SubTotal;
                          }
                          else
                          {
                              bool congruente = false;
                              valorFactura = calculaValorFactura(factura, ref congruente, ref _subtotal);
                              factura.TipoFactura = "Normal";
                          }

                          #region Localizando y aplicando si hay importes en contra por Notas de Credito

                          #region       A revisión desde el 25 de Nov 2016 GRD

                          double miImporteNotaCredito = 0;
                          string miImporteNotaCreditoLetra = "|(Nota: El importe original de la factura " + Convert.ToDouble(valorFactura).ToString("C") + " ya fue afectado por un valor de substituir por Nota de Credito o Complementaria)";

                          // --> Localicemos el importe de esta factura
                          var miNotaCredito = listadoNC.Where(item => item.FolioFacturaOrigen.Contains(factura.Archivo) == true);
                          foreach (var importeNC in miNotaCredito)
                          {
                              //--> Extraer el valor
                              miImporteNotaCredito = miImporteNotaCredito + Convert.ToDouble(importeNC.Importe);
                          }
                          miImporteNotaCreditoLetra = miImporteNotaCreditoLetra.Replace("substituir", miImporteNotaCredito.ToString("C"));

                          #endregion A revision desde el Obsoleto el 25 de Nov 2016 GRD

                          #endregion Localizando y aplicando si hay importes en contra por Notas de Credito

                          bool esRetail = false;

                          if (!esOrden)
                          {
                              esRetail = true;
                              factura.TipoFactura = "Ticket";
                          }

                          System.Uri url = System.Web.HttpContext.Current.Request.UrlReferrer;
                          if (url.ToString().Contains("Tickets") == true)
                          {
                              esRetail = true;
                              factura.TipoFactura = "Ticket";
                          }

                          if (esRetail == false)
                          {
                              string esRFCMoral = factura.RFC.Length > 12 == true ? "Fisica" : "Moral";
                              bool WSIguales = true;// System.Web.Configuration.WebConfigurationManager.AppSettings["igualesWSProductivoQAs"].Equals("S") == true ? true : false;//04 Agosto para Fletes
                              if (WSIguales == true)
                              {
                                  #region        Original y absoleto al 25 de Nov de 2016  GRD
                                  #region Analizando Impuestos Escenarios Fletes-Rentas
                                  ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos = factura.Impuestos33;
                                  string _importeISRRenta = "";
                                  string _importeIVARenta = "";
                                  string _posibleTipo = "";
                                  string _importeTotalTrasladados = "";
                                  bool siCuentaTrasladados = false;
                                  List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto> impuestos = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto>();//new   List<ClickFactura_Facturacion.Genericos.objImpuesto>();
                                  //Conectar VPN
                                  obtenRetencionesRenta(_Impuestos, ref _importeISRRenta, ref _importeIVARenta, ref _posibleTipo, ref  _importeTotalTrasladados, ref siCuentaTrasladados, ref impuestos);
                                  if (esRFCMoral.Equals("Moral") == true)
                                  {
                                      #region quizas es obsoleto
                                      string parcial = Convert.ToString(Convert.ToDecimal(valorFactura) - Convert.ToDecimal(_importeTotalTrasladados));
                                      decimal _valorFactura = Convert.ToDecimal(Math.Round(Convert.ToDecimal(subTotalRangos) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                      decimal _parcial = Convert.ToDecimal(Math.Round(Convert.ToDecimal(parcial) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                      double diferencia = Convert.ToDouble(_valorFactura - _parcial);
                                      factura.TipoFactura = "Moral";
                                      if (diferencia >= 0 && diferencia <= 0.999999)
                                          valorFactura = parcial;
                                      #endregion quizas es obsoleto
                                      #region Validar las Retenciones Personas Morales
                                      //Es una persona Moral pero puede tener Retenciones
                                      //Revisemos si tiene ISR
                                      var siRetenciones = from _Retenciones in impuestos where _Retenciones.Tipo.Equals("Retencion") == true select _Retenciones;
                                      if (siRetenciones != null)
                                          if (siRetenciones.Count() > 0 && siRetenciones.Count() <= 1)
                                          {
                                              #region Tienes  1 Retencion
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Honorarios";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  subTotalRangos = subTotalRangos - Convert.ToDouble(valorRetenciones);
                                              else
                                              {
                                                  //Buscar si es una Orden de Compra Flete
                                                  var q = from _Retenidos in impuestos where _Retenidos.Tipo.Equals("Retencion") == true select _Retenidos;
                                                  if (q != null)
                                                      if (q.Count() > 0)
                                                      {
                                                          //SI encuentras una retencion con etiqueta ISR ya no puede ser un Flete por que solo debe tener una etiqueta IVA
                                                          var r = from imp in q where imp.Etiqueta.Equals("ISR") == true select imp;
                                                          if (r.Count() < 1)
                                                          {
                                                              valorFactura = calculaValorFacturaFlete(factura, ref _subtotal);
                                                              factura.TipoFactura = "Flete";
                                                          }
                                                      }
                                              }
                                              #endregion Tienes 1  Retencion
                                          }
                                          else
                                          {
                                              #region 2 Retenciones
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Renta";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  subTotalRangos = subTotalRangos - Convert.ToDouble(valorRetenciones);
                                              #endregion 2 Retenciones
                                          }
                                      #endregion Validar las Retenciones Personas Morales
                                  }
                                  else
                                  {
                                      #region Retenciones Personas Fisicas
                                      //es una persona Fisica
                                      //Revisemos si tiene ISR
                                      var siRetenciones = from _Retenciones in impuestos where _Retenciones.Tipo.Equals("Retencion") == true select _Retenciones;
                                      if (siRetenciones != null)
                                          if (siRetenciones.Count() > 0 && siRetenciones.Count() <= 1)
                                          {
                                              #region Tienes  1 Retencion
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Honorarios";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  subTotalRangos = subTotalRangos - Convert.ToDouble(valorRetenciones);
                                              else
                                              {
                                                  //Buscar si es una Orden de Compra Flete
                                                  var q = from _Retenidos in impuestos where _Retenidos.Tipo.Equals("Retencion") == true select _Retenidos;
                                                  if (q != null)
                                                      if (q.Count() > 0)
                                                      {
                                                          //SI encuentras una retencion con etiqueta ISR ya no puede ser un Flete por que solo debe tener una etiqueta IVA
                                                          var r = from imp in q where imp.Etiqueta.Equals("ISR") == true select imp;
                                                          if (r.Count() < 1)
                                                          {
                                                              valorFactura = calculaValorFacturaFlete(factura, ref _subtotal);
                                                              factura.TipoFactura = "Flete";
                                                          }
                                                      }
                                              }
                                              #endregion Tienes 1  Retencion
                                          }
                                          else
                                          {
                                              #region 2 Retenciones
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Renta";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  subTotalRangos = subTotalRangos - Convert.ToDouble(valorRetenciones);
                                              #endregion 2 Retenciones
                                          }
                                      #endregion Retenciones Personas Fisicas
                                  }
                                  #endregion Analizando Impuestos  Escenarios Fletes-Rentas
                                  #endregion  Original y absoleto al 25 de Nov de 2016 GRD

                                  #region        Cambio el 25 de Nov 2016 GRD
                                  #region Analizando Impuestos Escenarios Fletes-Rentas
                                  //ComprobanteImpuestos _Impuestos = factura.Impuestos;
                                  //string _importeISRRenta = "";
                                  //string _importeIVARenta = "";
                                  //string _posibleTipo = "";
                                  //string _importeTotalTrasladados = "";
                                  //bool siCuentaTrasladados = false;
                                  //List<Genericos.objImpuesto> impuestos = new List<Genericos.objImpuesto>();
                                  obtenRetencionesRenta(_Impuestos, ref _importeISRRenta, ref _importeIVARenta, ref _posibleTipo, ref  _importeTotalTrasladados, ref siCuentaTrasladados, ref impuestos);
                                  System.Web.HttpContext.Current.Session["impuestosDetectados"] = impuestos;
                                  if (esRFCMoral.Equals("Moral") == true)
                                  {
                                      #region quizas es obsoleto
                                      string parcial = Convert.ToString(Convert.ToDecimal(valorFactura) - Convert.ToDecimal(_importeTotalTrasladados));
                                      decimal _valorFactura = Convert.ToDecimal(Math.Round(Convert.ToDecimal(v) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                      decimal _parcial = Convert.ToDecimal(Math.Round(Convert.ToDecimal(parcial) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                      double diferencia = Convert.ToDouble(_valorFactura - _parcial);
                                      factura.TipoFactura = "Moral";
                                      if (diferencia >= 0 && diferencia <= 0.999999)
                                          valorFactura = parcial;
                                      #endregion quizas es obsoleto
                                      #region Validar las Retenciones Personas Morales
                                      //Es una persona Moral pero puede tener Retenciones
                                      //Revisemos si tiene ISR
                                      var siRetenciones = from _Retenciones in impuestos where _Retenciones.Tipo.Equals("Retencion") == true select _Retenciones;
                                      if (siRetenciones != null)
                                          if (siRetenciones.Count() > 0 && siRetenciones.Count() <= 1)
                                          {
                                              #region Tienes  1 Retencion
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Honorarios";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  v = v - valorRetenciones;
                                              else
                                              {
                                                  //Buscar si es una Orden de Compra Flete
                                                  #region Obsoleta
                                                  //DataContext.DataClasses2DataContext contexto = new DataContext.DataClasses2DataContext(Genericos.Configuracion.CadenaConexion);//DataContext(Genericos.Configuracion.CadenaConexion);
                                                  //Table<DataContext.Detalle_OrdenCompra> detalleordencompra = contexto.GetTable<DataContext.Detalle_OrdenCompra>();
                                                  //var q = from detalle in detalleordencompra where detalle.Orden_Compra.Equals(WEs[0].Orden)==true && detalle.Grupo_Articulos.Equals("FLET")==true select detalle;
                                                  #endregion Obsoleta
                                                  var q = from _Retenidos in impuestos where _Retenidos.Tipo.Equals("Retencion") == true select _Retenidos;
                                                  if (q != null)
                                                      if (q.Count() > 0)
                                                      {
                                                          //SI encuentras una retencion con etiqueta ISR ya no puede ser un Flete por que solo debe tener una etiqueta IVA
                                                          var r = from imp in q where imp.Etiqueta.Equals("ISR") == true select imp;
                                                          if (r.Count() < 1 && r != null)
                                                          {
                                                              //Genericos.Configuracion f = new Genericos.Configuracion();
                                                              valorFactura = calculaValorFacturaFlete(factura, ref _subtotal);
                                                              factura.TipoFactura = "Flete";
                                                          }
                                                      }
                                              }
                                              #endregion Tienes 1  Retencion
                                          }
                                          else
                                          {
                                              #region 2 Retenciones
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Renta";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  v = v - valorRetenciones;
                                              #endregion 2 Retenciones
                                          }
                                      #endregion Validar las Retenciones Personas Morales
                                  }
                                  else
                                  {
                                      #region Retenciones Personas Fisicas
                                      //es una persona Fisica
                                      //Revisemos si tiene ISR
                                      var siRetenciones = from _Retenciones in impuestos where _Retenciones.Tipo.Equals("Retencion") == true select _Retenciones;
                                      if (siRetenciones != null)
                                          if (siRetenciones.Count() > 0 && siRetenciones.Count() <= 1)
                                          {
                                              #region Tienes  1 Retencion
                                              //bool siTraiaISR = false;
                                              //decimal valorRetenciones=0;
                                              //foreach(var impuesto in siRetenciones)
                                              //{
                                              //    valorRetenciones = valorRetenciones + impuesto.Importe;
                                              //    if (impuesto.Etiqueta.Equals("ISR") == true)
                                              //    {
                                              //        siTraiaISR = true;
                                              //        factura.TipoFactura = "Renta";
                                              //    }
                                              //}
                                              //if (siTraiaISR == true)
                                              //    v = v - valorRetenciones;
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Honorarios";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  v = v - valorRetenciones;
                                              else
                                              {
                                                  //Buscar si es una Orden de Compra Flete
                                                  #region Obsoleta
                                                  //DataContext.DataClasses2DataContext contexto = new DataContext.DataClasses2DataContext(Genericos.Configuracion.CadenaConexion);//DataContext(Genericos.Configuracion.CadenaConexion);
                                                  //Table<DataContext.Detalle_OrdenCompra> detalleordencompra = contexto.GetTable<DataContext.Detalle_OrdenCompra>();
                                                  //var q = from detalle in detalleordencompra where detalle.Orden_Compra.Equals(WEs[0].Orden)==true && detalle.Grupo_Articulos.Equals("FLET")==true select detalle;
                                                  #endregion Obsoleta
                                                  var q = from _Retenidos in impuestos where _Retenidos.Tipo.Equals("Retencion") == true select _Retenidos;
                                                  if (q != null)
                                                      if (q.Count() > 0)
                                                      {
                                                          //SI encuentras una retencion con etiqueta ISR ya no puede ser un Flete por que solo debe tener una etiqueta IVA
                                                          var r = from imp in q where imp.Etiqueta.Equals("ISR") == true select imp;
                                                          if (r.Count() < 1)//&& r!=null)
                                                          {
                                                              //Genericos.Configuracion f = new Genericos.Configuracion();
                                                              valorFactura = calculaValorFacturaFlete(factura, ref _subtotal);
                                                              factura.TipoFactura = "Flete";
                                                          }
                                                      }
                                              }
                                              #endregion Tienes 1  Retencion
                                          }
                                          else
                                          {
                                              #region 2 Retenciones
                                              bool siTraiaISR = false;
                                              decimal valorRetenciones = 0;
                                              foreach (var impuesto in siRetenciones)
                                              {
                                                  valorRetenciones = valorRetenciones + impuesto.Importe;
                                                  if (impuesto.Etiqueta.Equals("ISR") == true)
                                                  {
                                                      siTraiaISR = true;
                                                      factura.TipoFactura = "Renta";
                                                  }
                                              }
                                              if (siTraiaISR == true)
                                                  v = v - valorRetenciones;
                                              #endregion 2 Retenciones
                                          }
                                      #endregion Retenciones Personas Fisicas
                                  }
                                  #endregion Analizando Impuestos  Escenarios Fletes-Rentas
                                  #endregion Cambio el 25 de Nov 2016 GRD
                              }
                          }
                          else
                          {
                              #region Calculando importes para Retail exclusivamente

                              ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos = factura.Impuestos33;
                              double impuestoRecepcion = 0;
                              double valorRealRecepcion = 0;
                              //GRD 18 Enero se comenta línea para calcular correctamente los valores de la factura, "v" es el valor calculado de la Recpecion por eso no debia ser alterado
                              //v = Convert.ToDecimal(valorFactura);
                              double impuestoTrasladadoRealFactura = Convert.ToDouble(factura.ImporteTrasladado);// 0;
                              if (Convert.ToDecimal(_Impuestos.TotalImpuestosTrasladados) > 0 == true)
                              {
                                  //GRD 18 Enero por revisipon de como se calculaba el valor de los trasladados
                                  //impuestoRecepcion = (Convert.ToDouble(v))  * .16;
                                  impuestoRecepcion = ((Convert.ToDouble(valorFactura)) / 1.16) * .16;
                                  valorRealRecepcion = Convert.ToDouble(valorFactura) - impuestoRecepcion;
                                  //GRD 18 Enero por revisipon de como se calculaba el valor de los trasladados
                                  //impuestoTrasladadoRealFactura = Convert.ToDouble(_Impuestos.totalImpuestosTrasladados) * .16;
                                  diferenciaRealFacturaRecepcion = Convert.ToDecimal(factura.SubTotal) - Convert.ToDecimal(valorRealRecepcion);
                                  diferenciaRealFacturaRecepcion = Math.Round(Convert.ToDecimal(diferenciaRealFacturaRecepcion) * 1.00m, 2, MidpointRounding.AwayFromZero);
                                  //GRD 18 Se agrega tras modificar el calculo de los impuestos trasladados
                                  //impuestoTrasladadoRealFactura = diferenciaRealFacturaRecepcion;
                              }
                              diferenciaRealFacturaRecepcion = Math.Round(Convert.ToDecimal(Convert.ToDecimal(factura.SubTotal) - Convert.ToDecimal(valorRealRecepcion)) * 1.00m, 2, MidpointRounding.AwayFromZero);
                              diferenciaRealFacturaRecepcion = diferenciaRealFacturaRecepcion - Convert.ToDecimal(impuestoTrasladadoRealFactura);
                              diferenciaRealFacturaRecepcion = Convert.ToDecimal(Convert.ToDouble(valorFactura) - subTotalRangos);
                              factura.DiferenciaImportes = Convert.ToDouble(diferenciaRealFacturaRecepcion);

                              #endregion Calculando importes para Retail exclusivamente
                          }
                          valorFactura = Convert.ToString(Convert.ToDecimal(valorFactura) + Convert.ToDecimal(miImporteNotaCredito));
                          monedaFactura = monedaFactura + (miImporteNotaCreditoLetra.Contains("substituir") == true ? "" : miImporteNotaCreditoLetra);
                          string _UUID_enProceso = "";
                          _UUID_enProceso = factura.UUID;

                          #region Determinemos si los impuestos calculados en la factura corresponden con los valores de la Recepcion
                          string comentarios = "";
                        bool _congruente = true;// candadoIVAFacturaRecepcion(factura, recepcionTieneT2, ref comentarios); Rehabilitar 17 Octubre 2017
                          if (_congruente == false)
                          {
                              valorFactura = "-100000";
                          }
                          #endregion Determinemos si los impuestos calculados en la factura corresponden con los valores de la Recepcion

                          if (subTotalRangos == Convert.ToDouble(valorFactura))//  27/07/2015 + Convert.ToDecimal(miImporteNotaCredito))
                          {
                              //hdf_ValidacionImportes.Value = "1";

                              //KeyValuePair<string, string> result = (new KeyValuePair<string, string>(" WE( " + Wes + " )  importe $" + subtotal + " y  Factura '" + factura.Archivo + "' de importe total de $" + factura.Timporte + ":", "true"));
                              KeyValuePair<string, string> result = (new KeyValuePair<string, string>("La(s) Recepción(es) (" + cuantosWE.Count().ToString() + " líneas) con un monto de " + subTotalRangos.ToString("C") + Wes + "|" + monedaRecepcion + "|VS  La(s) Factura(s) con un monto por " + Convert.ToDouble(valorFactura).ToString("C") + "|" + factura.Archivo + "|" + monedaFactura + " son IGUALES", "true"));
                              listaresultados.Add(result);
                              #region       Original  Se cambia 25 Nov 2016 GRD
                              //factura.ImportesFueron = "Iguales";
                              //factura.ReglasAplicadas = "Ninguna, importes fueron iguales.";
                              //factura.AplicaraProrrateo = false;// miImporteNotaCredito == 0 == true ? false : true;
                              //factura.DiferenciaImportes = miImporteNotaCredito != 0 == true ? miImporteNotaCredito : 0;
                              //factura.ImporteRecepcionOrigen = Convert.ToDouble(subtotalNatural);
                              //factura.ImporteArticulosconIVA = Convert.ToDouble(subtotalSoloconIVA);
                              //factura.RecepcionValia = Convert.ToDouble(subTotalRangos);
                              //factura.NotasCredito = miImporteNotaCredito;
                              #endregion Original Se cambia 25 Nov 2016 GRD

                              #region        Actualizacion al 25 Nov 2016 GRD
                              string estado = "Iguales";
                              string reglasaplicadas = "Ninguna, importes fueron iguales.";
                              bool _aplicarprorrateo = false;
                              if (System.Web.HttpContext.Current.Session["valoresNotasCredito"] != null)
                              {
                                  estado = "Diferentes (Factura es mayor)";
                                  reglasaplicadas = "Iguales x Notade Credito";
                                  _aplicarprorrateo = true;
                              }
                              factura.ImportesFueron = estado;
                              factura.ReglasAplicadas = reglasaplicadas;
                              factura.AplicaraProrrateo = _aplicarprorrateo;// false;
                              factura.DiferenciaImportes = miImporteNotaCredito != 0 == true ? miImporteNotaCredito : 0;
                              factura.ImporteRecepcionOrigen = Convert.ToDouble(subtotalNatural);
                              factura.ImporteArticulosconIVA = Convert.ToDouble(subtotalSoloconIVA);
                              factura.RecepcionValia = Convert.ToDouble(v);
                              factura.NotasCredito = miImporteNotaCredito;
                              #endregion Actualizacion al 25 Nov 2016 GRD
                          }
                          else
                          {
                              if (esRetail == false)
                              {//Cálculo NORMAL
                                  //                                                                                                                               N          O           R       M       A       L               //////////////////////////////////////////////////////////////////////////////
                                  #region        Orginal al 25 Nov 2016 GRD
                                  #region Validaciones Importes por las 3 reglas
                                  #endregion Validaciones Importes por las 3 reglas
                                  #endregion Original al 25 Nov 2016 GRD

                                  #region        Actualizacion al 25 Nov 2016 GRD
                                  #region Validaciones Importes por las 3 reglas
                                  string resultadoEvaluaciones = "";
                                  //System.Data.Linq.Table<ClickFactura_Entidades.BD.Entidades.Cat_AcuerdosComerciales> acuerdos = contexto.GetTable<ClickFactura_Entidades.BD.Entidades.Cat_AcuerdosComerciales>();
                                  //Conectar VPN
                                  DataTable acuerdos=ClickFactura_Facturacion.Clases.cs_Estaticos.existeCreaAcuerdoComercial(factura.RFC);
                                  var q = from acu in acuerdos.AsEnumerable() where acu.Field<string>("RFC").Equals(factura.RFC) == true select acu;
                                  if (q != null)
                                      if (q.Count() > 0)
                                      {
                                          resultadoEvaluaciones = " La(s) Recepción(es)  " + Wes + " con un monto total de $" + (factura.TipoFactura.Equals("Renta") == true || factura.TipoFactura.Equals("Flete") == true ? v.ToString() : subTotalRangos.ToString()) + " " + monedaRecepcion + "  y la(s) Factura(s) '" + factura.Archivo + "' con un monto de $" + valorFactura + " " + monedaFactura + " " + " tienen importes ";
                                          //Cambio de importes Factura
                                          //double ImporteFactura = Convert.ToDouble(Convert.ToDecimal(factura.Timporte));
                                          double ImporteFactura = Convert.ToDouble(Convert.ToDecimal(valorFactura));// + Convert.ToDecimal(miImporteNotaCredito));
                                          //ImporteFactura = IMPORTE SUBTOTAL AHORA YA CON EL AUMENTO O DISMINUCION DE DOCUMENTOS ADICIONALES
                                          foreach (var f in q)
                                          {
                                              double desviacionDirecta = 0;
                                              try
                                              {
                                                  desviacionDirecta =Convert.ToDouble(f.Field<string>("desviacionDinero"));//desviacionDinero);
                                              }
                                              catch
                                              {
                                                  desviacionDirecta = f.Field<double>("desviacionDinero");
                                              }
                                              double upDirecto;
                                              double donwDirecto;
                                              subTotalRangos = factura.TipoFactura.Equals("Renta") == false ? subTotalRangos : Convert.ToDouble(v);
                                              upDirecto = subTotalRangos + desviacionDirecta;
                                              donwDirecto = subTotalRangos - desviacionDirecta;
                                              #region    P R I M E R A              Validación +- Dinero Directo
                                              if (ImporteFactura > donwDirecto && ImporteFactura < upDirecto)
                                              {
                                                  #region Dentro del rango
                                                  //hdf_ValidacionImportes.Value = "1";
                                                  //KeyValuePair<string, string> result = (new KeyValuePair<string, string>(resultadoEvaluaciones + " diferentes por un valor  de $" + Convert.ToString(subTotalRangos - (ImporteFactura + Convert.ToDouble(miImporteNotaCredito))) + " pero se APROBARA por la regla de +$ " + desviacionDirecta.ToString() + "' ó -$ '" + desviacionDirecta.ToString() + ".", "true"));//+ factura.SubTotal.ToString() + (miImporteNotaCreditoLetra.Contains("substituir") == true ? "" : miImporteNotaCreditoLetra), "true"));
                                                  KeyValuePair<string, string> result = (new KeyValuePair<string, string>(resultadoEvaluaciones + " diferentes por un valor  de $" + Convert.ToString(Convert.ToDouble(Math.Round(Convert.ToDecimal((ImporteFactura - subTotalRangos)) * 1.00m, 2, MidpointRounding.AwayFromZero))) + " pero se APROBARA por la regla de +$ " + desviacionDirecta.ToString() + "' ó -$ '" + desviacionDirecta.ToString() + ".", "true"));//+ factura.SubTotal.ToString() + (miImporteNotaCreditoLetra.Contains("substituir") == true ? "" : miImporteNotaCreditoLetra), "true"));
                                                  listaresultados.Add(result);
                                                  if (ImporteFactura > subTotalRangos)
                                                      factura.ImportesFueron = "Diferentes (Factura es mayor)";
                                                  else
                                                      factura.ImportesFueron = "Diferentes (Recepción es mayor)";
                                                  factura.ReglasAplicadas = "Se permite verificación por criterio de cantidad de dinero directo + -  $" + desviacionDirecta.ToString() + " como diferencia permitida.";
                                                  //factura.AplicaraProrrateo si es false=Factura estuvo arriba pasa Recepción, true= Factura estuvo abajo y se debe ajustar
                                                  factura.DiferenciaImportes = Convert.ToDouble(Math.Round(Convert.ToDecimal((ImporteFactura - subTotalRangos)) * 1.00m, 4, MidpointRounding.AwayFromZero));// (ImporteFactura - subTotalRangos); 
                                                  #region recalculanod Diferencias
                                                  bool diferenciaExacta = false;
                                                  if (Convert.ToDouble(subtotalSoloconIVA) != 0)
                                                  {
                                                      factura.DiferenciaImportes = Convert.ToDouble(Math.Round(Convert.ToDecimal((_subtotal - Convert.ToDouble(subtotalSoloconIVA))) * 1.00m, 4, MidpointRounding.AwayFromZero));
                                                      diferenciaExacta = true;
                                                  }

                                                  #endregion Recalculando Diferencias
                                                  factura.AplicaraProrrateo = factura.DiferenciaImportes > 0 ? false : true;// ImporteFactura > subTotalRangos == true ? true : false;
                                                  //Cambio cuando la factura es menor y si hay que forzar ha hacer algún prorrateo sobre la Rececpción
                                                  if (factura.ImportesFueron.Contains("ecepci") == true && ((Convert.ToDouble(Math.Round(Convert.ToDecimal((ImporteFactura - subTotalRangos)) * 1.00m, 4, MidpointRounding.AwayFromZero))) < 0))
                                                  {
                                                      factura.AplicaraProrrateo = true;
                                                      if (diferenciaExacta == false)
                                                          factura.DiferenciaImportes = Convert.ToDouble(Math.Round(Convert.ToDecimal((ImporteFactura - subTotalRangos)) * 1.00m, 4, MidpointRounding.AwayFromZero));
                                                  }
                                                  //Cambio cuando la factura es menor y si hay que forzar ha hacer algún prorrateo
                                                  factura.ImporteRecepcionOrigen = Convert.ToDouble(subtotalNatural);
                                                  factura.ImporteArticulosconIVA = Convert.ToDouble(subtotalSoloconIVA);
                                                  factura.RecepcionValia = Convert.ToDouble(v);
                                                  factura.NotasCredito = miImporteNotaCredito;
                                                  #endregion Dentro del rango
                                              }
                                              else
                                              {
                                                  factura.ReglasAplicadas = "No se permite verificación por criterio de cantidad de dinero directo + -  $" + desviacionDirecta.ToString() + " como diferencia estaba fuera de rangos y no será permitida.";
                                                  factura.ImportesFueron = "NO PROCESAR";
                                                  #region indica NO podra avanzar
                                                  string desviacionDinero = "";
                                                  try
                                                  {
                                                      desviacionDinero = Convert.ToString(f.Field<string>("desviacionDinero"));//desviacionDinero);
                                                  }
                                                  catch
                                                  {
                                                      desviacionDinero = Convert.ToString(f.Field<double>("desviacionDinero")); 
                                                  }
                                                  KeyValuePair<string, string> result = (new KeyValuePair<string, string>(resultadoEvaluaciones + " diferentes por un valor  de $" + Convert.ToString(subTotalRangos - (ImporteFactura)) + " pero sobre todo ESTA FUERA DEL RANGO DE DIFERENCIA permitida ( +$" + desviacionDinero.ToString() + ".00 hasta -$" + desviacionDinero.ToString() + ".00 ) y NO se permitirá AVANZAR en la carga de esta Factura.", "false"));
                                                  listaresultados.Add(result);
                                                  #endregion indica NO podra avanzar
                                              }
                                              #endregion    P R I M E R A          Validación +- Dinero Directo
                                          }
                                      }
                                      else
                                      {
                                          //Disparar autoconfiguración de agregar el proveedor
                                          ClickFactura_Facturacion.Clases.cs_Estaticos.creaAcuerdoComercial(factura.RFC);
                                          //Genericos.cs_Estaticos.creaAcuerdoComercial(factura.RFC);
                                          //sendAcuerdosComerciales(factura.RFC, "Investigar");
                                          //Notificacion("Estimado usuario, cierre esta ventana y vuelva a presionar el botón de Comparar", "Primer comparación de importes", "info");
                                      }
                                  #endregion Validaciones Importes por las 3 reglas
                                  #endregion Actualización al 25 de Nov 2016 GRD
                                  //                                                                                                                               N          O           R       M       A       L               //////////////////////////////////////////////////////////////////////////////
                              }
                              else
                              {//Cálculo solo Retail
                                  //                                                                                                                                R           E               T           A           I           L!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
                                  //                                                                                                                                R           E               T           A           I           L ////////////////////////////////////////////////////////////////////////
                                  #region         Original al 25 de Nov 2016 GRD
                                  #endregion  Original al 25 de Nov 2016 GRD

                                  #region            Actualización al 25 Nov 2016 GRD
                                  #region Validaciones Importes por las 3 reglas pero para Retail
                                  string resultadoEvaluaciones = "";
                                  //System.Data.Linq.Table<Cat_AcuerdosComerciales> acuerdos = contexto.GetTable<Cat_AcuerdosComerciales>();
                                  //System.Data.Linq.Table<ClickFactura_Entidades.BD.Entidades.Cat_AcuerdosComerciales> acuerdos = new System.Data.Linq.Table<ClickFactura_Entidades.BD.Entidades.Cat_AcuerdosComerciales>();
                                  DataTable _acuerdos = ClickFactura_Facturacion.Clases.cs_Estaticos.existeCreaAcuerdoComercial(factura.RFC);
                                  var q = from acu in _acuerdos.AsEnumerable() where acu.Field<string>("RFC").Equals(factura.RFC) == true select acu;
                                  if (q != null)
                                      if (q.Count() > 0)
                                      {
                                          resultadoEvaluaciones = " La(s) Recepción(es)  " + Wes + " con un monto total de $" + subTotalRangos.ToString() + " " + monedaRecepcion + "  y la(s) Factura(s) '" + factura.Archivo + "' con un monto de $" + valorFactura + " " + monedaFactura + " " + " tienen importes ";
                                          //Cambio de importes Factura
                                          double ImporteFactura = Convert.ToDouble(v + diferenciaRealFacturaRecepcion);
                                          ImporteFactura = ImporteFactura + (miImporteNotaCredito != 0 ? miImporteNotaCredito : 0);
                                          subTotalRangos = Convert.ToDouble(v);
                                          //ImporteFactura = IMPORTE SUBTOTAL AHORA YA CON EL AUMENTO O DISMINUCION DE DOCUMENTOS ADICIONALES
                                          foreach (var f in q)
                                          {
                                              double desviacionDirecta = Convert.ToDouble(f.Field<string>("desviacionDinero"));
                                              double upDirecto;
                                              double donwDirecto;
                                              upDirecto = subTotalRangos + desviacionDirecta;
                                              donwDirecto = subTotalRangos - desviacionDirecta;
                                              #region    P R I M E R A              Validación +- Dinero Directo
                                              if (ImporteFactura > donwDirecto && ImporteFactura < upDirecto)
                                              {
                                                  //hdf_ValidacionImportes.Value = "1";
                                                  //KeyValuePair<string, string> result = (new KeyValuePair<string, string>(resultadoEvaluaciones + " diferentes por un valor  de $" + Convert.ToString(subTotalRangos - (ImporteFactura + Convert.ToDouble(miImporteNotaCredito))) + " pero se APROBARA por la regla de +$ " + desviacionDirecta.ToString() + "' ó -$ '" + desviacionDirecta.ToString() + ".", "true"));//+ factura.SubTotal.ToString() + (miImporteNotaCreditoLetra.Contains("substituir") == true ? "" : miImporteNotaCreditoLetra), "true"));
                                                  KeyValuePair<string, string> result = (new KeyValuePair<string, string>(resultadoEvaluaciones + " diferentes por un valor  de $" + Convert.ToString(subTotalRangos - (ImporteFactura)) + " pero se APROBARA por la regla de +$ " + desviacionDirecta.ToString() + "' ó -$ '" + desviacionDirecta.ToString() + ".", "true"));//+ factura.SubTotal.ToString() + (miImporteNotaCreditoLetra.Contains("substituir") == true ? "" : miImporteNotaCreditoLetra), "true"));
                                                  listaresultados.Add(result);
                                                  if (ImporteFactura > subTotalRangos)
                                                      factura.ImportesFueron = "Diferentes (Factura es mayor)";
                                                  else
                                                      factura.ImportesFueron = "Diferentes (Recepción es mayor)";
                                                  factura.ReglasAplicadas = "Se permite verificación por criterio de cantidad de dinero directo + -  $" + desviacionDirecta.ToString() + " como diferencia permitida.";
                                                  //factura.AplicaraProrrateo si es false=Factura estuvo arriba pasa Recepción, true= Factura estuvo abajo y se debe ajustar
                                                  factura.DiferenciaImportes = (ImporteFactura - subTotalRangos) / 1.16; //GRD 18 de Enero para correguir y ser conguente con cambios de arriba * .16; //ImporteFactura - subTotalRangos;
                                                  #region Es Retail
                                                  try
                                                  {
                                                      if (factura.TipoFactura == "Ticket")
                                                      {
                                                          if (Convert.ToDouble(factura.Timporte) != Convert.ToDouble(factura.SubTotal))
                                                              factura.DiferenciaImportes = factura.DiferenciaImportes;
                                                      }
                                                  }
                                                  catch
                                                  {

                                                  }
                                                  #endregion Es Retail
                                                  //false = Recepcion debera pasar integra
                                                  //true Habra que bajar la Recepción
                                                  factura.AplicaraProrrateo = Math.Abs(factura.DiferenciaImportes) > 0 ? true : false;//false : true;
                                                  factura.ImporteRecepcionOrigen = Convert.ToDouble(subtotalNatural);
                                                  factura.ImporteArticulosconIVA = Convert.ToDouble(subtotalSoloconIVA);
                                                  factura.RecepcionValia = Convert.ToDouble(v);
                                                  factura.NotasCredito = miImporteNotaCredito;
                                              }
                                              #endregion    P R I M E R A          Validación +- Dinero Directo
                                          }
                                      }
                                      else
                                      {
                                          //Disparar autoconfiguración de agregar el proveedor
                                          //Genericos.cs_Estaticos.creaAcuerdoComercial(factura.RFC);
                                          ClickFactura_Facturacion.Clases.cs_Estaticos.creaAcuerdoComercial(factura.RFC);
                                      }
                                  #endregion Validaciones Importes por las 3 reglas  pero para Retail
                                  #endregion     Actualización al 25 Nov 2016 GRD

                                  //                                                                                                                                R           E               T           A           I           L////////////////////////////////////////////////////////////////////////
                                  //                                                                                                                                R           E               T           A           I           L////////////////////////////////////////////////////////////////////////  
                              }
                          }
                      }
                      #endregion Organizando Informacion
                      //string script = "$(document).ready(function () { $('[id*=botonDisparaPasivo]').click(); });";
                      //Page.ClientScript.RegisterStartupScript(this.GetType(), "load", script, true);
                      foreach (var wes in listaresultados)
                      {
                          foreach (var item in registros)
                          {
                              if (wes.Key.Contains(item.R2.ToString()) == true)
                              {
                                  item.R11 = Convert.ToBoolean(wes.Value);
                              }
                          }
                      }

                      #endregion Es Usuario valido
                      #endregion Corre proceso evaluar Montos si hay al menos una Factura cargada
                  }
                //else
                //{
                //    botonDisparaPasivo.Attributes.Add("hidden", "hidden");
                //    botonDisparaPasivo.Visible = false;
                //    lblResultados.InnerHtml = "No hay cargada ninguna Factura y/o al menos una Recepción con las cuáles realizar una comparación de importes. Revise por favor.";
                //    lblResultados.DataBind();
                //}

                #region       Forzar o cancelar el prorrateo

                int _result = 0;
                //ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros adp = new ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros();
                //List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros> objp = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros>();
                //
                bool forzarProrrateo = false;
                objp = adp.mABCT_Parametros(out _result, 0, "forzarProrrateo", "Vacio", true, "ConsultaValor");
                {
                    forzarProrrateo = objp[0].ValorParametro.ToString().Equals("0")==true?false:true;
                    if(forzarProrrateo==false)
                    {
                        KeyValuePair<string, string> advertenciaProrrateo = new KeyValuePair<string, string>(" ATENCIÓN  La configuración indica que no se permite el prorrateo, por tanto la informaciónse enviará exactamente como las líneas de Recepción seleccionadas en montos y cantidades.", listaresultados[0].Value.ToString());
                       listaresultados.Add(advertenciaProrrateo);
                    }
                        
                }
               foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura factura in facturas)
                    {
                        factura.AplicaraProrrateo = forzarProrrateo;
                    }
                #endregion Forzar o cancelar el prorrateo

                return listaresultados;
                  #endregion 21 Evaluando Montos
              }
              catch (Exception ex)
              {
                  mensajeEx = ex.Message;
                  listaresultados.Add(new KeyValuePair<string, string>("Error", mensajeEx));
                  return null;
              }
          }

        private string convierteMoneyTKPM(string textoCantidad)
        {
            //En virtud que las cantidades vienen con un formato 3350,00 y la coma es un problema se debe reformatear el numero
            //19 Octubre 2017 GRD
            string salida = "0";
            adT_Parametros adp = new adT_Parametros();
            List<objT_Parametros> objp = new List<objT_Parametros>();
            int result = 0;
            #region Adecua formato moneda
            string entorno = "";
            bool publicado = false;
            objp = adp.mABCT_Parametros(out result, 0, "Publicado", "Vacio", true, "ConsultaValor");
            {
                entorno = objp[0].ValorParametro.ToString();
                publicado = entorno.Equals("1") == true ? true : false;
            }
            if (publicado == false)
            {
                salida = Convert.ToDouble(textoCantidad, new System.Globalization.NumberFormatInfo { NumberDecimalSeparator = ".", NumberGroupSeparator = "," }).ToString();
            }
            else
            {
                int punto = textoCantidad.LastIndexOf(".");
                int coma = textoCantidad.IndexOf(",");

                if(coma>0)
                    if(coma>punto)
                          salida = textoCantidad.Replace(",",".");
                    else
                    {
                        if(punto>0)
                        {
                        textoCantidad = textoCantidad.Replace(".", "");
                        textoCantidad = textoCantidad.Replace(",", ".");
                        }
                    }
            }
            #endregion Adecua formato moneda
            return salida;
            //return string.Format("{0:#.00}", Convert.ToDecimal(textoCantidad) / 100).Replace(",",".");
        }

          private bool candadoIVAFacturaRecepcion(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura factura, bool recepcionTieneIva, ref string comentarios)
          {
              //recepcionTieneIva  True = hay al menos un T2 False = Todo es V0
              bool ivaCongrunte = false;
              decimal IVATrasladado = Convert.ToDecimal(factura.ImporteTrasladado);
              if (recepcionTieneIva == true)// Encontro al menos un producto con T2
              {
                  if (IVATrasladado == 0)
                  {
                      //Tiene Iva mayor a Cero y se reporta en Orden no hay T2
                      ivaCongrunte = false;
                      comentarios = " Problema : La orden presenta al menos 1 producto con T2 o V2 y la factura no reporta IVA";
                  }
                  else
                  {
                      if (IVATrasladado > 0)
                      {
                          ivaCongrunte = true;
                          comentarios = "";// "  La orden presenta al menos 1 producto con T2 y la factura tiene IVA Trasladodo con valor $" + IVATrasladado.ToString();
                      }
                  }
              }
              else
              {
                  if (IVATrasladado == 0)//Se reporto que no habia ningun T2
                  {
                      ivaCongrunte = true;
                      comentarios = "";// " La orden presenta no tiene productos con T2 y la factura no eporta IVA tambien";
                  }
                  else
                      if (IVATrasladado > 0)
                      {
                          ivaCongrunte = false;
                          comentarios = "Problema:  La orden NO tiene algún producto con T2 o V2 y la factura tiene IVA Trasladado con valor $" + IVATrasladado.ToString();
                      }
              }
              return ivaCongrunte;
          }
          private void obtenRetencionesRenta(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos, ref string _importeISRRenta, ref string _importeIVARenta, ref  string _posibleTipo, ref string _importeTrasladados, ref bool siCuentaTrasladados, ref  List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto> impuestos)
          {
              int cuantosR = 0;
              int cuantosT = 0;
              List<KeyValuePair<string, string>> impuestosDetectados = new List<KeyValuePair<string, string>>();
              ClickFactura_WebServiceCF.Service.Clases.ad_CatalogosmySQL_ClickFactura catalogoImpuestos = new ClickFactura_WebServiceCF.Service.Clases.ad_CatalogosmySQL_ClickFactura();
              List<string> campos = new List<string>();
              campos.Add("c_Impuesto");
              campos.Add("Descripcion");
              Dictionary<string, string> equivalencias = catalogoImpuestos.consultaCatalogo("cat_33_Impuesto", campos);
              #region Retenidos
              try
              {
                  if (_Impuestos.Retenciones != null)
                  {
                      cuantosR = _Impuestos.Retenciones.Count() > 0 ? _Impuestos.Retenciones.Count() : 0;
                      siCuentaTrasladados = true;
                      //Original cuantosT= _Impuestos.Traslados.Count() > 0 ? _Impuestos.Traslados.Count() : 0;
                      if (_Impuestos.Traslados != null)
                          cuantosT = _Impuestos.Traslados.Count() > 0 ? _Impuestos.Traslados.Count() : 0;
                      else
                          cuantosT = 0;
                  }
                  else
                  {
                      //No hay Sub etiquetas de Retencion
                      cuantosR = 0;
                      siCuentaTrasladados = true;
                      //Original cuantosT = _Impuestos.Traslados.Count() > 0 ? _Impuestos.Traslados.Count() : 0;
                      if (_Impuestos.Traslados != null)
                          cuantosT = _Impuestos.Traslados.Count() > 0 ? _Impuestos.Traslados.Count() : 0;
                      else
                          cuantosT = 0;
                  }
              }
              catch
              {
                  cuantosR = 0;
                  siCuentaTrasladados = false;
                  if (_Impuestos.Traslados != null)
                      cuantosT = _Impuestos.Traslados.Count() > 0 ? _Impuestos.Traslados.Count() : 0;
                  else
                      cuantosT = 0;
              }
              #endregion Retenidos
              double subtotalImpuestosRetenidos = 0;
              try
              {
                  //GRD 20 Enero linea encuentraDescripcion posicion original
                  //List<KeyValuePair<string,string>> impuestosDetectados = new List<KeyValuePair<string,string>>();
                  for (int i = 1; i <= cuantosR; i++)
                  {
                      //KeyValuePair<string, string> impues = new KeyValuePair<string, string>(_Impuestos.Retenciones[i - 1].Impuesto.ToString(), _Impuestos.Retenciones[i - 1].Importe.ToString());
                      //impuestosDetectados.Add(impues);
                      string buscado = _Impuestos.Retenciones[i - 1].Impuesto.ToString();
                      string equivalencia = equivalenciaCatalogoEtiquetaImpuesto(buscado, equivalencias);
                      KeyValuePair<string, string> impues = new KeyValuePair<string, string>(equivalencia, _Impuestos.Retenciones[i - 1].Importe.ToString());
                      impuestosDetectados.Add(impues);
                      subtotalImpuestosRetenidos = subtotalImpuestosRetenidos + Convert.ToDouble(_Impuestos.Retenciones[i - 1].Importe.ToString());
                  }
                  if (_Impuestos.TotalImpuestosRetenidos > 0)
                  {
                      foreach (KeyValuePair<string, string> imp in impuestosDetectados)
                      {
                          string _impuesto = imp.Key;
                          if (_impuesto.Equals("ISR") == true)
                          {
                              _importeISRRenta = imp.Value;
                              _posibleTipo = "ISR";
                              impuestos.Add(new ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto("Retencion", "ISR", Convert.ToDecimal(imp.Value)));
                          }
                          if (_impuesto.Equals("IVA") == true)
                          {
                              _importeIVARenta = imp.Value;
                              impuestos.Add(new ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto("Retencion", "IVA", Convert.ToDecimal(imp.Value)));
                              if (_importeISRRenta != "")
                              {
                                  _posibleTipo = "Renta";
                              }
                              else
                              {
                                  _posibleTipo = "Flete";
                              }
                          }
                      }
                  }
                  // if(_Impuestos.totalImpuestosTrasladados>0)
                  try
                  {
                      impuestosDetectados.Clear();
                      for (int i = 1; i <= cuantosT; i++)
                      {
                          //KeyValuePair<string, string> impues = new KeyValuePair<string, string>(_Impuestos.Traslados[i - 1].Impuesto.ToString(), _Impuestos.Traslados[i - 1].Importe.ToString());
                          //impuestosDetectados.Add(impues);
                          string buscado = _Impuestos.Traslados[i - 1].Impuesto.ToString();
                          string equivalencia = equivalenciaCatalogoEtiquetaImpuesto(buscado, equivalencias);
                          KeyValuePair<string, string> impues = new KeyValuePair<string, string>(equivalencia, _Impuestos.Traslados[i - 1].Importe.ToString());
                          impuestosDetectados.Add(impues);
                      }
                      foreach (KeyValuePair<string, string> imp in impuestosDetectados)
                      {
                          string _impuesto = imp.Key;
                          if (_impuesto.Equals("IVA") == true)
                          {
                              _importeISRRenta = imp.Value;
                              _posibleTipo = "IVA";
                              impuestos.Add(new ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto("Traslado", "IVA", Convert.ToDecimal(imp.Value)));
                          }
                      }
                      _importeTrasladados = _Impuestos.TotalImpuestosTrasladados.ToString();
                      if (_posibleTipo.Equals("Flete") == false)
                          if (_posibleTipo.Equals("Renta") == false)
                              if (_posibleTipo.Equals("ISR") == false)
                                  _posibleTipo = "Solo Trasladados";
                  }
                  catch
                  {
                      _importeTrasladados = "0";
                  }
              }
              catch
              {
                  #region solo tare Trasladados
                  if (_Impuestos.TotalImpuestosTrasladados > 0)
                  {
                      _importeTrasladados = _Impuestos.TotalImpuestosTrasladados.ToString();
                      _posibleTipo = "Solo Trasladados";
                  }
                  else
                  {
                      _importeTrasladados = "0";
                  }
                  //Nuevo
                  impuestosDetectados.Clear();
                  for (int i = 1; i <= cuantosT; i++)
                  {
                      KeyValuePair<string, string> impues = new KeyValuePair<string, string>(_Impuestos.Traslados[i - 1].Impuesto.ToString(), _Impuestos.Traslados[i - 1].Importe.ToString());
                      impuestosDetectados.Add(impues);
                  }
                  foreach (KeyValuePair<string, string> imp in impuestosDetectados)
                  {
                      string _impuesto = imp.Key;
                      if (_impuesto.Equals("IVA") == true)
                      {
                          _importeISRRenta = imp.Value;
                          _posibleTipo = "IVA";
                          impuestos.Add(new ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto("Traslado", "IVA", Convert.ToDecimal(imp.Value)));
                      }
                  }
                  //Nuevo
                  #endregion  solo trae Trasladados
              }
          }
          private string equivalenciaCatalogoEtiquetaImpuesto(string buscado, Dictionary<string, string> listado)
          {
              string etiqueta = "error";
              bool encontrado = false;
              foreach (KeyValuePair<string, string> etiq in listado)
              {
                  if (etiq.Key == buscado)
                  {
                      etiqueta = etiq.Value;
                      encontrado = true;
                      break;
                  }
              }
              if(encontrado==false)
                {
                    foreach (KeyValuePair<string, string> etiq in listado)
                    {
                        if (etiq.Value== buscado)
                        {
                            etiqueta = etiq.Value;
                            break;
                        }
                    }
                }
              return etiqueta;
          }

          //private string calculaValorFacturaFlete(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura factura, ref double _Subtotal)//Genericos.objLeidoFactura factura, ref double _Subtotal)
          private string calculaValorFacturaFlete(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura factura, ref double _Subtotal)//Genericos.objLeidoFactura factura, ref double _Subtotal)
          {
              double subTotal = 0;
              double Trasladados = Convert.ToDouble(factura.ImporteTrasladado);
              double Retenidos = 0;
              try
              {
                  Retenidos = Convert.ToDouble(factura.ImporteRetenido);
              }
              catch
              {
                  Retenidos = 0;
              }
              double TrasladadoCalculadoxSubtotal = 0;
              subTotal = Convert.ToDouble(factura.SubTotal);
              _Subtotal = subTotal;
              subTotal = subTotal - Convert.ToDouble(factura.Descuento);
              TrasladadoCalculadoxSubtotal = subTotal * 0.16;
              TrasladadoCalculadoxSubtotal = Convert.ToDouble(Math.Round(Convert.ToDecimal(TrasladadoCalculadoxSubtotal) * 1.00m, 2, MidpointRounding.AwayFromZero));
              if (TrasladadoCalculadoxSubtotal != Trasladados)
              {
                  if (Convert.ToDecimal(Trasladados) == 0)
                      TrasladadoCalculadoxSubtotal = 0;
                  else
                  {
                      #region administra diferencias
                      if ((TrasladadoCalculadoxSubtotal - Trasladados) <= 0.01999999999999999999999)
                          Trasladados = TrasladadoCalculadoxSubtotal;
                      #endregion administra diferencias
                      TrasladadoCalculadoxSubtotal = Trasladados;
                  }
              }
              subTotal = Convert.ToDouble(Math.Round(Convert.ToDecimal(subTotal) * 1.00m, 2, MidpointRounding.AwayFromZero)) + TrasladadoCalculadoxSubtotal;
              return subTotal.ToString();
          }
          private string calculaValorFactura(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura factura, ref bool congruente, ref double _Subtotal)
          {
              string valor = "";
              double subTotal = 0;
              double Total = 0;
              double Trasladados = Convert.ToDouble(factura.ImporteTrasladado);
              double Retenidos = 0;
              try
              {
                  Retenidos = Convert.ToDouble(factura.ImporteRetenido);
              }
              catch
              {
                  Retenidos = 0;
              }
              double TrasladadoCalculadoxSubtotal = 0;
              subTotal = Convert.ToDouble(factura.SubTotal);
              _Subtotal = subTotal;
              subTotal = subTotal - Convert.ToDouble(factura.Descuento);
              TrasladadoCalculadoxSubtotal = subTotal * 0.16;
              TrasladadoCalculadoxSubtotal = Convert.ToDouble(Math.Round(Convert.ToDecimal(TrasladadoCalculadoxSubtotal) * 1.00m, 2, MidpointRounding.AwayFromZero));
              if (TrasladadoCalculadoxSubtotal == Trasladados)
              {
                  congruente = true;
              }
              else
              {

                  if (Convert.ToDecimal(Trasladados) == 0)
                      TrasladadoCalculadoxSubtotal = 0;
                  else
                  {
                      #region administra diferencias
                      if ((TrasladadoCalculadoxSubtotal - Trasladados) <= 0.01999999999999999999999)
                          Trasladados = TrasladadoCalculadoxSubtotal;
                      #endregion administra diferencias
                      TrasladadoCalculadoxSubtotal = Trasladados;
                  }
              }
              subTotal = Convert.ToDouble(Math.Round(Convert.ToDecimal(subTotal) * 1.00m, 2, MidpointRounding.AwayFromZero)) + TrasladadoCalculadoxSubtotal;
              if (Retenidos > 0)
                  subTotal = subTotal - Retenidos;
              Total = subTotal;
              valor = Total.ToString();
              return valor;
          }

          public bool factXML_GenerarPasivo(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> facturas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> listadoNC, out List<KeyValuePair<string, string>> resultados, bool esExterno, int idUsuario, out string NumeroPasivoGenerado, bool esOrden = true)
          {
              resultados = new List<KeyValuePair<string, string>>();
              List<KeyValuePair<string, string>> resultadosPasivos = new List<KeyValuePair<string, string>>();
              NumeroPasivoGenerado = "";
              List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
              try
              {
                  #region 15
                  bool correcto = false;
                  int intentosExitosos = 0;
                  int intentosFallidos = 0;
                  string importeTotalFinal = "";
                  string mensajesAdicionales = "Proceso terminado. ";
                  var msg = new KeyValuePair<string, string>("idUsuario", idUsuario.ToString());
                  resultadosPasivos.Add(msg);
                  var contexto = ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.ConvertDataTableaLista<Cat_Usuario>(genericos_consultaCualquierTabla("Select IdUsuario, Usuario from Cat_Usuario Where Idusuario=" + idUsuario.ToString()));
                  var usuario = (from t in contexto where t.IdUsuario == idUsuario select t).FirstOrDefault();
                  if (usuario != null)
                  {
                      msg = new KeyValuePair<string, string>("usuario", usuario.Usuario);
                      resultadosPasivos.Add(msg);
                  }
                  try
                  {
                      if (facturas != null)
                      {
                          // Si hay información para procesar
                          #region dispara Pasivo
                          string NoItem = "";
                          string NoOrdenCompra;
                          string RFC_del_Emisor = "";
                          string RFC_del_Receptor = "";
                          string Serie = "";
                          int totaldeLineas = facturas.Count;
                          //--------------------------------------------------------------------------
                          ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado HPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado();
                          ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle DPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle();
                          //Pasivo_Detalle[] LDPasivo = new Pasivo_Detalle[];
                          //-----> 28 Agosto 2015  Pasivo_GeneradoP GPasivo = new Pasivo_GeneradoP();

                          ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[] GPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[30];
                          List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto>();
                          //-------------------------------------------------------------------------
                          #region Agrupando por cada Factura
                          var facturasAgrupadas = facturas
                              .GroupBy(u => u.NombreArchivoXML)
                              .Select(grp => grp.ToList())
                              .ToList();
                          #endregion Agrupando por cada Factura

                          if (facturasAgrupadas != null)
                          {
                              if (facturasAgrupadas.Count > 0)
                              {
                                  string facturaenCurso = "";
                                  string fechaMasReciente = "";
                                  int signo = 0;
                                  int y = 0;

                                  #region        Ampliacion códigos 22 Nov 2016 GRD
                                  //---------------------------------------------------------------------------------------------------------- >##############################################
                                  DataTable tabla = new DataTable();
                                  Boolean error = false;
                                  Boolean disparoIniciado = false;
                                  string avanzado = "";
                                  string leyenda = "";

                                  string texto_XML_NotaCredito = "";
                                  string entorno = System.Web.Configuration.WebConfigurationManager.AppSettings["environment"];

                                  //---------------------------------------------------------------------------------------------------------- >##############################################
                                  #endregion Ampliacion códigos 22 Nov 2016 GRD

                                  #region VERIFICACIÓN DE UNA F A C T U R A
                                  var _agregar = new KeyValuePair<string, string>("msg_1", "Verificacion de factura");
                                  resultadosPasivos.Add(_agregar);
                                  foreach (List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> OrdenCompra in facturasAgrupadas)
                                  {//########################################################################################################################################################################
                                      int tipoPasivo = 0;
                                      bool aplicarFactor = false;
                                      double factor = 0;
                                      string quienFueMayor = "";
                                      string informacionComplementaria = "";
                                      bool esRetail = false;
                                      bool diferenciaDirecta = false;
                                      double factorRetail = 0;
                                      string _Importe = "0";
                                      string _NoRecepcion = "0";
                                      string _Posicion = "0";
                                      double ImporteNotasdeCredito = 0;
                                      _agregar = new KeyValuePair<string, string>("msg_l1", "Identificando lineas");
                                      resultadosPasivos.Add(_agregar);
                                      DataTable _Detalle_Recepciones = new DataTable();
                                      ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.identificaLineaMayor(facturasAgrupadas, ref _Importe, ref _NoRecepcion, ref _Posicion, ref  totaldeLineas,_Detalle_Recepciones);
                                      _agregar = new KeyValuePair<string, string>("msg_l2", "Lineas encontradas " + totaldeLineas);
                                      resultadosPasivos.Add(_agregar);
                                      #region Es Retail
                                      if (OrdenCompra[0].TipoFactura.Equals("Ticket") == true)//!esOrden)
                                      {
                                          esRetail = true;
                                      }
                                      #endregion Es Retail
                                      #region Determinamos si se va a aplicar ajustes o prorrateo como producto de diferencias entre Facturas y Recepciones
                                      quienFueMayor = OrdenCompra[0].ImportesFueron;
                                    if (OrdenCompra[0].AplicaraProrrateo == true)
                                      {
                                          #region calculando ajuste-prorrateo
                                          var v = (from t in listadoNC where t.Archivo == OrdenCompra[0].NombreArchivo select t.TieneIVA).FirstOrDefault();
                                          //factor = calculaFactor(OrdenCompra, Convert.ToDouble(OrdenCompra[0].Importe), OrdenCompra[0].NombreArchivo, v, ref aplicarFactor, ref signo, ref factorRetail, ref diferenciaDirecta, OrdenCompra[0].NotasCredito);
                                          recepcionesAnalisadas = (List<KeyValuePair<string, string>>)System.Web.HttpContext.Current.Session["recepcionesAnalisadas"];
                                          factor = calculaFactor(OrdenCompra, Convert.ToDouble(OrdenCompra[0].Importe), OrdenCompra[0].NombreArchivo, v, ref aplicarFactor, ref signo, ref factorRetail, ref diferenciaDirecta, OrdenCompra[0].NotasCredito, listadoNC, recepcionesAnalisadas);
                                          #endregion calculando ajuste-prorrateo
                                      }
                                      ImporteNotasdeCredito = OrdenCompra[0].NotasCredito;
                                      string quepasaProrrateo = OrdenCompra[0].AplicaraProrrateo == true ? " si se realizaría." : " no sería necesario.";
                                      bool siProrrateoporImportes = OrdenCompra[0].AplicaraProrrateo;
                                      informacionComplementaria = " .Factura(s) y Recepción(es) : " + OrdenCompra[0].ImportesFueron + " .Excepciones aplicadas: " + OrdenCompra[0].ReglasAplicadas + " , se calculo una diferencia entre Factura(s) y Recepcion(es) que fue de " + OrdenCompra[0].DiferenciaImportes.ToString("C") + " por ello se determino que aplicar el ajuste " + quepasaProrrateo;
                                      double diferenciaArrastradaentreFacturaRecepcion = OrdenCompra[0].DiferenciaImportes;
                                      double factorAjusteDiferenciaFacturaRecepcion = diferenciaArrastradaentreFacturaRecepcion < 0 == true ? -1 : 1;
                                      #endregion Determinamos si se va a aplicar ajustes o prorrateo como producto de diferencias entre Facturas y Recepciones
                                      _agregar = new KeyValuePair<string, string>("msg_l3", quepasaProrrateo + " " + informacionComplementaria);
                                      resultadosPasivos.Add(_agregar);
                                      ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] LDPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[OrdenCompra[0].Conceptos.Count()];
                                      #region Identifica si ya tiene un Pasivo
                                      //Cambio 
                                      //var enDetalleOrdenes = from reg in contexto.Detalle_OrdenCompra where reg.Orden_Compra.Equals(OrdenCompra[0].OrdenCompra) select reg;
                                      //if (enDetalleOrdenes != null)
                                      //    if (enDetalleOrdenes.Count() > 0)
                                      //    {
                                      //        #region Buscar si algun item de la Orden tiene ya un Pasivo
                                      //        //foreach(var renDetalle in enDetalleOrdenes)
                                      //        //{
                                      //        //    try
                                      //        //    {
                                      //        //        if (renDetalle.Numero_Pasivo.Equals("") == false)
                                      //        //        {
                                      //        //            tienePasivoDoc = renDetalle.Numero_Pasivo;
                                      //        //            tienePasivo = true;
                                      //        //        }
                                      //        //    }
                                      //        //    catch
                                      //        //    {
                                      //        //        tienePasivoDoc = "";
                                      //        //        tienePasivo = false;
                                      //        //    }
                                      //        //    try
                                      //        //    {
                                      //        //        if (renDetalle.Numero_Cancelacion.Equals("") == false)
                                      //        //        {
                                      //        //            tieneCancelacionDoc = renDetalle.Numero_Cancelacion;
                                      //        //            tieneCancelacion = true;
                                      //        //        }
                                      //        //    }
                                      //        //    catch
                                      //        //    {
                                      //        //        tieneCancelacionDoc = "";
                                      //        //        tieneCancelacion = false;
                                      //        //    }
                                      //        //}
                                      //        #endregion Buscar si algun item de la Orden tiene ya un Pasivo
                                      //    }
                                      #endregion Identifica si ya tiene un Pasivo
                                      //NO PROCESAR indica que los importes NO CUADRARON Y POR NINGUN MOTIVO DE SER ENVIADA A VERIFICAR
                                      //Si NOPROCESAR es
                                      //      false ENVIARA disparo
                                      //      true  ABORTARA disparo
                                      //if(tienePasivo==false && tieneCancelacion==false)
                                      if (OrdenCompra[0].ImportesFueron.Equals("NO PROCESAR") == false)
                                      {
                                          #region disparo para una Factura de sus Recepciones
                                          //Leyendo datos por Orden de Compra incluyendo todas las lineas subidas
                                          #region preparando datos para actualizar información en la Orden de Compra
                                          List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objetoActualizarOrdenCompra> listaUpdateOrdenCompra = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objetoActualizarOrdenCompra>();
                                          #endregion preparando datos para actualizar información en la Orden de Compra
                                          _agregar = new KeyValuePair<string, string>("msg_l4", "Preparando informacion para actualizar oc");
                                          resultadosPasivos.Add(_agregar);
                                          #region Datos de Encabezado
                                          HPasivo.CargoPosterior = false;
                                          HPasivo.ClaseDoc = "RE";
                                          HPasivo.Factura = true;
                                          #region Estableciendo las fechas
                                          _agregar = new KeyValuePair<string, string>("msg_l5", "Factura en curso: " + facturaenCurso);
                                          resultadosPasivos.Add(_agregar);
                                          if (facturaenCurso.Equals(OrdenCompra[0].FolioFactura) == false)
                                          {
                                              _agregar = new KeyValuePair<string, string>("msg_l6", "Folio factura " + OrdenCompra[0].FolioFactura);
                                              resultadosPasivos.Add(_agregar);
                                              fechaMasReciente = OrdenCompra[0].FechaFactura;
                                              _agregar = new KeyValuePair<string, string>("msg_l7", "Fecha factura " + OrdenCompra[0].FechaFactura);
                                              resultadosPasivos.Add(_agregar);
                                              var feActual = (from w in facturas orderby w.FechaFactura descending where w.OrdenCompra.Equals(OrdenCompra[0].OrdenCompra) == true select w).FirstOrDefault();
                                              fechaMasReciente = feActual != null ? feActual.FechaFactura : "";
                                              _agregar = new KeyValuePair<string, string>("msg_l8", "Fechas " + fechaMasReciente);
                                              resultadosPasivos.Add(_agregar);
                                              facturaenCurso = OrdenCompra[0].FolioFactura;
                                          }
                                          #endregion Estableciendo las fechas
                                          var fe = fechaMasReciente == "" ? OrdenCompra[0].FechaFactura.Replace('/', '.') : fechaMasReciente.Replace('/', '.');
                                          _agregar = new KeyValuePair<string, string>("msg_f0", "Convertir fecha" + fe);
                                          resultadosPasivos.Add(_agregar);
                                          HPasivo.FechaFactura = fe;//Genericos.cs_Estaticos.ConfigFecha(fechaMasReciente == "" ? Convert.ToDateTime(OrdenCompra[0].FechaFactura) : Convert.ToDateTime(fechaMasReciente), ".");//OrdenCompra.FechaFactura);
                                          HPasivo.FechaPedimento = "";
                                          HPasivo.FolioFactura = OrdenCompra[0].FolioFactura;
                                          _agregar = new KeyValuePair<string, string>("msg_f", "Estableciendo Fechas " + HPasivo.FechaFactura);
                                          resultadosPasivos.Add(_agregar);
                                          //HPasivo.Importe = OrdenCompra[0].Importe;
                                          decimal importe = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].SubTotalXML) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                          decimal trasladado = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].IvaTrasladadoTotal) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                          decimal retenidos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                          decimal descuentos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].Descuento) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                          HPasivo.Importe = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito)));//OrdenCompra[0].Importe;
                                          importeTotalFinal = HPasivo.Importe;
                                          HPasivo.Proveedor_Diferente = "";
                                          #region Nueva recuperacion de datos del Proveedor
                                          ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra datosOrdenCompra = System.Web.HttpContext.Current.Session["Encabezado_" + OrdenCompra[0].OrdenCompra] as ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra; 
                                          #endregion Nueva recuperacion de datos del Proveedor
                                          string _Num_Proveedor = "";
                                          int _idproveedor = 0;
                                         HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
                                          string _Sociedad = datosOrdenCompra.Sociedad;
                                          HPasivo.Moneda = datosOrdenCompra.Moneda;
                                          //_Sociedad = System.Web.HttpContext.Current.Session["sociedadVerificar"] as String;  //Obtener del Sistema!! Genericos.cs_Estaticos.buscaSociedadxOrdenCompra(OrdenCompra[0].OrdenCompra, ref _Num_Proveedor, ref _idproveedor);
                                          HPasivo.Sociedad = _Sociedad;
                                          HPasivo.Proveedor_Diferente = datosOrdenCompra.Proveedor;
                                          _Num_Proveedor = datosOrdenCompra.Proveedor; 
                                          HPasivo.ClaseDoc = datosOrdenCompra.PMNTTRMS;
                                          string modoPruebas = System.Web.Configuration.WebConfigurationManager.AppSettings["ModoPruebasUUID"];
                                          if (modoPruebas.Equals("S") == true)
                                              OrdenCompra[0].UUID = "UUIDEditadoporPrueba_" + DateTime.Now.Ticks;
                                          HPasivo.UUID = OrdenCompra[0].UUID;
                                          HPasivo.CalculaImpuesto = true;
                                          bool WSIguales = System.Web.Configuration.WebConfigurationManager.AppSettings["igualesWSProductivoQAs"].Equals("S") == true ? true : false;//04 Agosto para Fletes
                                          string _importeISRRenta = "";
                                          string _importeIVARenta = "";
                                          string _posibleTipo = "";
                                          string _importeTotalTrasladados = "";
                                          bool siCuentaTrasladados = false;
                                          string esRFCMoral = OrdenCompra[0].RFC.Length > 12 == true ? "Fisica" : "Moral";
                                          if (WSIguales == true)
                                          {
                                              #region Analizando Impuestos Escenarios Fletes-Rentas
                                              ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
                                              ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32 Impuestos = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32();
                                              if (OrdenCompra[0].Impuestos!=null)
                                              {
                                                  Impuestos = OrdenCompra[0].Impuestos;
                                              }
                                              else
                                              {
                                                  _Impuestos = OrdenCompra[0].Impuestos33;
                                              }

                                              List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto> impuestos = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto>();
                                              obtenRetencionesRenta(_Impuestos, ref _importeISRRenta, ref _importeIVARenta, ref _posibleTipo, ref  _importeTotalTrasladados, ref siCuentaTrasladados, ref impuestos);
                                              string tipoFactura = OrdenCompra[0].TipoFactura;
                                              if (tipoFactura.Equals("Normal") == false)
                                              {
                                                  #region Es Renta
                                                  if (tipoFactura.Equals("Renta") == true)
                                                  {
                                                      var retenciones = from retencion in impuestos where retencion.Tipo.Equals("Retencion") == true select retencion;
                                                      if (retenciones != null)
                                                          if (retenciones.Count() > 0)
                                                          {
                                                              foreach (var reten in retenciones)
                                                              {
                                                                  if (reten.Etiqueta.Equals("ISR") == true)
                                                                  {
                                                                      HPasivo.RetencionISRRenta = reten.Importe.ToString();
                                                                  }
                                                                  if (reten.Etiqueta.Equals("IVA") == true)
                                                                  {
                                                                      HPasivo.RetencionIVARenta = reten.Importe.ToString();
                                                                  }
                                                              }
                                                          }
                                                      HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
                                                  }
                                                  #endregion Es Renta
                                                  #region Es Flete
                                                  if (tipoFactura.Equals("Flete") == true)
                                                  {
                                                      HPasivo.ImporteRetencionFlete = _importeIVARenta;
                                                      HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
                                                  }
                                                  #endregion Es Flete
                                                  #region Es Honorario
                                                  if (tipoFactura.Equals("Honorarios") == true)
                                                  {
                                                      HPasivo.RetencionISRRenta = _importeISRRenta;
                                                      HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
                                                  }
                                                  #endregion Es Honorario
                                                  #region Es Moral
                                                  if (tipoFactura.Equals("Moral") == true)
                                                  {
                                                      HPasivo.Importe = Convert.ToString(Convert.ToDecimal(HPasivo.Importe) - Convert.ToDecimal(_importeTotalTrasladados));
                                                  }
                                                  #endregion Es Moral
                                              }
                                              #endregion Analizando Impuestos  Escenarios Fletes-Rentas
                                          }
                                          NoItem = OrdenCompra[0].NoRecepcion;
                                          NoOrdenCompra = OrdenCompra[0].OrdenCompra;
                                          RFC_del_Emisor = OrdenCompra[0].RFC;
                                          RFC_del_Receptor = OrdenCompra[0].RFC_Receptor;
                                          Serie = OrdenCompra[0].Serie;
                                          NoItem = "";
                                          #endregion Datos de  Encabezado
                                          #region Obtener valores de Nota(s) de Credito
                                          double miImporteNotaCredito = 0;
                                          //if (Session["valoresNotasCredito"] != null)
                                          if (listadoNC != null && siProrrateoporImportes == true)
                                          {
                                              if (listadoNC.Count > 0)
                                              {
                                                  //Localicemos el imprte de esta factura
                                                  var miNotaCredito = (from t in listadoNC where t.Archivo == OrdenCompra[0].NombreArchivo select t).ToList();
                                                  if (miNotaCredito != null)
                                                      if (miNotaCredito.Count() > 0)
                                                      {
                                                          //Si existio al menos una Nota de Credito para esta Factura
                                                          foreach (var importeNC in miNotaCredito)
                                                          {
                                                              //Extraer el valor
                                                              miImporteNotaCredito = miImporteNotaCredito + Convert.ToDouble(importeNC.Importe);
                                                          }
                                                      }
                                              }
                                          }
                                          #endregion Obtener valores de Nota(s) de Credito

                                          //Indicador de lineas
                                          int pos = 0;
                                          //Indicador de lineas

                                          int elementos = OrdenCompra.Count;
                                          int posInc = 0;
                                          bool cuadrarconSAP = false;
                                          if (OrdenCompra.Count() > 0)
                                          {
                                              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] LDPasivoAlter = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[totaldeLineas > 1 ? totaldeLineas : 1];//OrdenCompra.Count()];
                                              LDPasivo = LDPasivoAlter;
                                          }
                                          bool yaCalculadoProrrateo = false;
                                          bool yaCalculadoDescuento = false;
                                          decimal porProrratearDescuento = 0;
                                          bool prorrateoAplicadoseRealizo = false;
                                          #region Toda la Generacion Pasivo
                                          foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo porAplicar in OrdenCompra)//listado)
                                          {
                                              //Indicador de lineas
                                              //int pos = 0;
                                              //Indicador de lineas
                                              y = y + 150;
                                              ClickFactura_WebServiceCF.AccesoBD.Genericos.objetoActualizarOrdenCompra updateOrdenCompra = new ClickFactura_WebServiceCF.AccesoBD.Genericos.objetoActualizarOrdenCompra();
                                              #region Validando que el Numero de Conceptos sea igual a las líneas de Recepción
                                              int noConceptosFactura = porAplicar.Conceptos.Count;
                                              if (noConceptosFactura != OrdenCompra.Count)
                                                  cuadrarconSAP = true;
                                              cuadrarconSAP = true;
                                              #endregion Validando que el Numero de Conceptos sea igual a las líneas de Recepción
                                              if (NoItem.Equals(porAplicar.NoRecepcion) != true)
                                              {
                                                  //Estamos hablando de otra Recepcion y  se actualiza
                                                  NoItem = porAplicar.NoRecepcion; // OrdenCompra[0].NoRecepcion;
                                              }
                                              #region Aplicar descuento prorrateado
                                              if (quienFueMayor.Contains("Iguales") == false)
                                              {
                                                  if (quienFueMayor.Contains("Factura") == false)
                                                  {
                                                      //Si es de hecho la factura la que viene arriba, quiere decir que la recpeción debe pasar como esta!!
                                                      string _aplicarProrrateoSegundaFase = System.Web.Configuration.WebConfigurationManager.AppSettings["aplicarProrrateoSegundaFase"];
                                                      bool aplicarProrrateoSegundaFase = _aplicarProrrateoSegundaFase.Equals("true") == true ? true : false;
                                                      if (aplicarProrrateoSegundaFase == true)
                                                          porProrratearDescuento = (yaCalculadoProrrateo == false && yaCalculadoDescuento == false) == true ? porAplicar.Descuento : porProrratearDescuento;
                                                  }
                                              }

                                              #region Es Retail
                                              if (esRetail == true)
                                              {
                                                  if (quienFueMayor.Contains("Factura") == false)
                                                  {
                                                      porProrratearDescuento = (yaCalculadoProrrateo == false && yaCalculadoDescuento == false) == true ? Convert.ToDecimal(diferenciaArrastradaentreFacturaRecepcion < 0 ? 0 : Math.Abs(diferenciaArrastradaentreFacturaRecepcion)) : 0;
                                                  }
                                                  else
                                                  {
                                                      porProrratearDescuento = 0;
                                                  }
                                              }
                                              #endregion Es Retail
                                              if (elementos > 0)
                                              {
                                                  if (quienFueMayor.Contains("Iguales") == false)
                                                      if (yaCalculadoProrrateo == false)
                                                      {

                                                          porProrratearDescuento = porProrratearDescuento / elementos;
                                                          yaCalculadoProrrateo = true;
                                                      }
                                              }
                                              #endregion Aplicar descuento prorrateado
                                              #region Aplicar el importe de Nota de Credito
                                              if (elementos > 0)
                                              {
                                                  if (quienFueMayor.Contains("Iguales") == false)
                                                      if (yaCalculadoDescuento == false)
                                                      {
                                                          miImporteNotaCredito = miImporteNotaCredito / elementos;
                                                          //Se comenta por que al parecer aplicar el descuento de la Nota de Credito ya seria redundante ya que faltan criterios para determinar si hay que 
                                                          //aplicarlo forzosamente 2 de Diciembre 2015
                                                          //porProrratearDescuento = porProrratearDescuento + Math.Abs(Convert.ToDecimal(miImporteNotaCredito));
                                                          yaCalculadoDescuento = true;
                                                      }
                                              }
                                              #endregion Aplicar el importe de Nota de Credito
                                              #region Carga de cada Linea-Concepto
                                              //for (int pos = 0; pos <= (totaldeLineas); pos++)//porAplicar.Conceptos.Count - 1); pos++)
                                              //{
                                              LDPasivo[pos] = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle();
                                              if (cuadrarconSAP == true)
                                              {
                                                  #region Aplicando Descuento
                                                  //GridDataItem item = localizaItem(NoItem, porAplicar.NoItem.Equals("0000") == true ? porAplicar.Posicion : porAplicar.NoItem, OrdenCompra[0].NombreArchivo); 
                                                  //--> 30 Nov 2105 La posicion referencia es erronea por que se repetia GridDataItem item = localizaItem(NoItem, porAplicar.Posicion, OrdenCompra[0].NombreArchivo); 
                                                  var item = (from t in registros
                                                              where t.R5.Equals(porAplicar.Posicion_Documento_Material)
                                                              && t.R18.Equals(OrdenCompra[0].NombreArchivo)
                                                              && t.R2.Equals(NoItem)
                                                              select t).FirstOrDefault();
                                                  //localizaItem(NoItem, porAplicar.Posicion_Documento_Material, OrdenCompra[0].NombreArchivo, porAplicar.OrdenCompra);
                                                  Decimal importeRecepcion = 0;
                                                  bool importeAlterado = false;
                                                  if (porProrratearDescuento != 0)// > 0)
                                                  {
                                                      //Extrae valores DIRECTO del grid de Recepcionados  a Facturar
                                                      // item = rg.MasterTableView.Items[pos];
                                                      string porImporteUnitario = System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                      if (porImporteUnitario.Equals("S") == true)
                                                          importeRecepcion = Convert.ToDecimal(porAplicar.ImporteUnitario);//14 Sep  Convert.ToDecimal(item["columnImporte"].Text.Replace("$", ""));
                                                      else
                                                          importeRecepcion = Convert.ToDecimal(item.R7);
                                                      //-----------------------------------------------------------------------
                                                      porAplicar.Conceptos[0].Importe = importeRecepcion - porProrratearDescuento; //Convert.ToDecimal(porAplicar.Importe) - porProrratearDescuento;// .Conceptos[0].importe - porProrratearDescuento;
                                                      importeAlterado = true;
                                                      //if (porProrratearDescuento > 0)
                                                      //{
                                                      //    double _importe = 0;
                                                      //    double importeBruto = Convert.ToDouble(porAplicar.Conceptos[0].importe);
                                                      //    double porDescontar = Convert.ToDouble(porProrratearDescuento);
                                                      //    _importe = importeBruto - porDescontar;
                                                      //    porAplicar.Conceptos[0].importe = Convert.ToDecimal(Math.Round(Convert.ToDecimal(_importe) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                      //}
                                                  }
                                                  if (importeAlterado == false)
                                                  {
                                                      //Extrae valores del grid de Recepcionados  a Facturar
                                                      string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                      if (porImporteUnitario.Equals("S") == true)
                                                          importeRecepcion = Convert.ToDecimal(porAplicar.ImporteUnitario); //14 Sep Convert.ToDecimal(item["columnImporte"].Text.Replace("$", ""));
                                                      else
                                                          importeRecepcion = Convert.ToDecimal(item.R7);
                                                      //-----------------------------------------------------------------------
                                                      porAplicar.Conceptos[0].Importe = importeRecepcion;
                                                  }
                                                  #endregion Aplicando Descuento
                                                  LDPasivo[pos].CantidadConcepto = Convert.ToDecimal(OrdenCompra[pos].Piezas) == Convert.ToDecimal(porAplicar.Piezas) ? porAplicar.Piezas.ToString() : OrdenCompra[pos].Piezas.ToString();
                                                  if (aplicarFactor == true)
                                                  {
                                                      //                                                                                PRORRATEO POR PORCENTAJE
                                                      //if(importeAlterado==false)
                                                      #region Modificacion para determinar si una factuira es Mixta y se debe o no aplicar el prorrateo 20 Diciembre GRD
                                                      bool esMixta = false;
                                                      //List<Genericos.obj_facturaAPasivo>
                                                      var listadoOrdenCompra = from filtrando in OrdenCompra where filtrando.OrdenCompra.Equals(OrdenCompra[0].OrdenCompra) == true select filtrando;

                                                      Int32 cuatosSon = listadoOrdenCompra.Count();
                                                      var elementosV0 = from todos in listadoOrdenCompra where todos.Impuesto.Contains("V0") == true select todos;
                                                      var elementosT2 = from todos in listadoOrdenCompra where todos.Impuesto.Contains("T2") == true || todos.Impuesto.Contains("V2") == true select todos;
                                                      if (elementosT2 != null)
                                                      {
                                                          if (elementosT2.Count() > 0)
                                                          {
                                                              if (elementosT2.Count() == cuatosSon)
                                                                  esMixta = false;
                                                              else
                                                              {
                                                                  esMixta = true;
                                                              }
                                                          }
                                                          else
                                                          {
                                                              if (elementosV0 != null)
                                                              {
                                                                  if (elementosV0.Count() > 0)
                                                                  {
                                                                      if (elementosV0.Count() == cuatosSon)
                                                                          esMixta = false;
                                                                      else
                                                                          esMixta = true;
                                                                  }
                                                              }
                                                          }

                                                      }
                                                      #endregion Modificacion para determinar si una factuira es Mixta y se debe o no aplicar el prorrateo 20 Diciembre GRD
                                                      //14 Sep se pone Convert.ToDecimal(porAplicar.ImporteUnitario); en lugar de porAplicar.Conceptos[0].importe.ToString()
                                                      //LDPasivo[pos].ImporteConcepto = Convert.ToString(Convert.ToDouble(porAplicar.Conceptos[0].importe.ToString()) + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor*signo)));//--> (factor)));//--> Original porAplicar.Conceptos[0].importe.ToString();// _importe;// porAplicar.Conceptos[pos].importe.ToString();
                                                      #region Prorrateo por PORCENTAJE
                                                      string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                      if (porImporteUnitario.Equals("S") == true)
                                                      {
                                                          if (porAplicar.Impuesto != "V0")
                                                              LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString()) * factor) / 100);//+ (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));
                                                          else
                                                          {
                                                              if (esMixta == true)
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString())));
                                                              else
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString()) * factor) / 100);
                                                          }
                                                      }
                                                      else
                                                      {
                                                          if (porAplicar.Impuesto != "V0")
                                                              LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.Conceptos[0].Importe.ToString()) * factor) / 100);// + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));
                                                          else
                                                          {
                                                              if (esMixta == true)
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString())));
                                                              else
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString()) * factor) / 100);
                                                          }
                                                      }

                                                      #region Prorrateo por PORCENTAJE
                                                  }
                                                  else
                                                  {
                                                      //                                                                                 PRORRATEO DIRECTO A UNA LINEA

                                                      //14 Sep LDPasivo[pos].ImporteConcepto = porAplicar.Conceptos[0].importe.ToString();
                                                      string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                      if (porImporteUnitario.Equals("S") == true)
                                                          LDPasivo[pos].ImporteConcepto = porAplicar.ImporteUnitario.ToString();
                                                      else
                                                          LDPasivo[pos].ImporteConcepto = porAplicar.Conceptos[0].Importe.ToString();
                                                      //Obteniendo el Importe mayor -------------------------------------------------------------------
                                                      var objetoImporteMayor = porAplicar.Conceptos.OrderByDescending(_item => _item.Importe).First();
                                                      double importeMayor = Convert.ToDouble(objetoImporteMayor.Importe);
                                                      //Obteniendo el Importe mayor --------------------------------------------------------------------
                                                      if ((Convert.ToDouble(LDPasivo[pos].ImporteConcepto) == Convert.ToDouble(_Importe) && porAplicar.NoRecepcion.Equals(_NoRecepcion) == true) && diferenciaDirecta == true)
                                                      {
                                                          LDPasivo[pos].ImporteConcepto = Convert.ToString(Convert.ToDouble(LDPasivo[pos].ImporteConcepto) - Math.Abs(diferenciaArrastradaentreFacturaRecepcion));
                                                          prorrateoAplicadoseRealizo = true;
                                                      }
                                                  }
                                                  #region Aplicando el nuevo Ajuste por existir Impuestos Retenidos
                                                  //string segundoAjuste = System.Web.Configuration.WebConfigurationManager.AppSettings["ajusteImportesFactWE"];
                                                  //bool ajustarDiferencia = segundoAjuste.Equals("S") == true ? true : false;
                                                  //if (ajustarDiferencia==true) //diferenciaArrastradaentreFacturaRecepcion > 0 == true && Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) > 0 == true)
                                                  //{
                                                  //    factorAjusteDiferenciaFacturaRecepcion = diferenciaArrastradaentreFacturaRecepcion / elementos;
                                                  //    int signofactorAjusteDiferenciaFacturaRecepcion = factorAjusteDiferenciaFacturaRecepcion >= 0 == true ? 1 : -1;
                                                  //    LDPasivo[pos].ImporteConcepto = Convert.ToString(Convert.ToDouble(LDPasivo[pos].ImporteConcepto) + ((factorAjusteDiferenciaFacturaRecepcion * signofactorAjusteDiferenciaFacturaRecepcion)));
                                                  //}
                                                  #endregion Aplicando el nuevo Ajuste por existir Impuestos Retenidos
                                                  //}
                                                      #endregion Para varias Recepciones de una sola linea
                                                      #endregion En uso para forzar enviar SIEMPRE INFORMACIÓN COMO VIENE DE LA RECEPCIÓN
                                              }
                                              else
                                              {
                                                  #region Enviando información exacta como viene la RECEPCIÓN
                                                  //Hay que empatar el renglon de la Recepcion con el Concepto que le corresponde
                                                  //14 Sep cambia porAplicar.Conceptos[pos].importe por porAplicar.ImporteUnitario
                                                  if (porProrratearDescuento > 0)
                                                  {
                                                      // 14 Sep porAplicar.Conceptos[pos].importe = Convert.ToDecimal(porAplicar.Conceptos[pos].importe) - porProrratearDescuento;
                                                      string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                      if (porImporteUnitario.Equals("S") == true)
                                                      {
                                                          porAplicar.Conceptos[pos].Importe = Convert.ToDecimal(porAplicar.ImporteUnitario) - porProrratearDescuento;
                                                      }
                                                      else
                                                      {
                                                          porAplicar.Conceptos[pos].Importe = Convert.ToDecimal(porAplicar.Conceptos[pos].Importe);// 09 Octubre Descuento de más??  -porProrratearDescuento;
                                                      }
                                                  }
                                                  LDPasivo[pos].CantidadConcepto = Convert.ToDecimal(OrdenCompra[pos].Piezas) == Convert.ToDecimal(porAplicar.Conceptos[pos].Cantidad) ? porAplicar.Conceptos[pos].Cantidad.ToString() : OrdenCompra[pos].Piezas.ToString();
                                                  //Si factor es mayor a Cero, entonces Factura era mayor y hay que pasar la Recepcion como viene!!
                                                  if (aplicarFactor == true)
                                                      if (factor < 0)
                                                      {

                                                          //14 Sep LDPasivo[pos].ImporteConcepto = Convert.ToString(Convert.ToDouble(porAplicar.Conceptos[pos].importe.ToString()) + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));// _importe;// porAplicar.Conceptos[pos].importe.ToString(); -->Original porAplicar.Conceptos[pos].importe.ToString()
                                                          string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                          //Determinar si ya se aplico prorrateo Directo
                                                          if (diferenciaDirecta == false)
                                                          {
                                                              #region Aplicando Prorrateo por PORCENTAJE
                                                              if (porImporteUnitario.Equals("S") == true)
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString()) * factor) / 100);// + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));
                                                              else
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.Conceptos[pos].Importe.ToString()) * factor) / 100);// + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));
                                                              #endregion Aplicando Prorrateo por PORCENTAJE
                                                          }
                                                          else
                                                          {
                                                              #region Pasar INTEGRO el Importe
                                                              if (porImporteUnitario.Equals("S") == true)
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.ImporteUnitario.ToString()) * 100) / 100);// + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));
                                                              else
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString((Convert.ToDouble(porAplicar.Conceptos[pos].Importe.ToString()) * 100) / 100);// + (Convert.ToDouble(LDPasivo[pos].CantidadConcepto) * (factor * signo)));                                                                                                                                       
                                                              #endregion Pasar INTEGRO el Importe
                                                          }
                                                      }
                                                      else
                                                      {
                                                          #region Prorrateo DIRECTO a una línea
                                                          //Obteniendo el Importe mayor -------------------------------------------------------------------
                                                          var objetoImporteMayor = porAplicar.Conceptos.OrderByDescending(item => item.Importe).First();
                                                          double importeMayor = Convert.ToDouble(objetoImporteMayor.Importe);
                                                          //Obteniendo el Importe mayor --------------------------------------------------------------------
                                                          //14 Sep LDPasivo[pos].ImporteConcepto = porAplicar.Conceptos[pos].importe.ToString();
                                                          string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                                                          if (porImporteUnitario.Equals("S") == true)
                                                          {
                                                              LDPasivo[pos].ImporteConcepto = porAplicar.ImporteUnitario.ToString();// porAplicar.Conceptos[pos].importe.ToString();
                                                          }
                                                          else
                                                          {
                                                              if ((Convert.ToDouble(LDPasivo[pos].ImporteConcepto) == Convert.ToDouble(_Importe) && porAplicar.NoRecepcion.Equals(_NoRecepcion) == true) && diferenciaDirecta == true)
                                                                  LDPasivo[pos].ImporteConcepto = Convert.ToString(Convert.ToDouble(porAplicar.Conceptos[pos].Importe) - Math.Abs(diferenciaArrastradaentreFacturaRecepcion));
                                                              else
                                                                  LDPasivo[pos].ImporteConcepto = porAplicar.Conceptos[pos].Importe.ToString();
                                                          }
                                                          #endregion Prorrateo DIRECTO a una línea
                                                      }
                                                  //OrdenCompra[pos].Piezas.Equals(porAplicar.Conceptos[pos].cantidad.ToString()) == true ? porAplicar.Conceptos[pos].cantidad.ToString() : OrdenCompra[pos].Piezas.ToString();
                                                  //porAplicar.Conceptos[pos].cantidad.ToString();
                                                  #endregion Enviando información exacta como viene la RECEPCIÓN
                                              }
                                              //Ajustando el valor de la línea a 2 decimales
                                              //23 de Diciembre por la Orden 0300965039 que por redondear a 2 decimales se comía un centavo se cometa esta línea
                                              // LDPasivo[pos].ImporteConcepto = Convert.ToString(Math.Round(Convert.ToDecimal(LDPasivo[pos].ImporteConcepto) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                              //---------------------------------------------------------------
                                              #region Ajuste al Prorrateo directo si tiene impuesto T2
                                              if ((porAplicar.NoItem.Equals(_Posicion) == true && porAplicar.NoRecepcion.Equals(_NoRecepcion) == true) && diferenciaDirecta == true)
                                              {
                                                  double _importeconIVA = 0;
                                                  double _importeBruto = 0;
                                                  double _nuevoImporte = 0;
                                                  _importeBruto = Convert.ToDouble(porAplicar.Conceptos[0].Importe);
                                                  if (porAplicar.Impuesto.Equals("T2") == true || porAplicar.Impuesto.Equals("V3") == true)
                                                  {
                                                      _importeconIVA = _importeBruto * 1.16;
                                                      _nuevoImporte = _importeconIVA - Math.Abs(diferenciaArrastradaentreFacturaRecepcion);
                                                      _nuevoImporte = _nuevoImporte / 1.16;
                                                      //LDPasivo[pos].ImporteConcepto = Convert.ToString(Math.Round(Convert.ToDecimal(_nuevoImporte) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                  }
                                              }
                                              #endregion Ajuste al Prorrateo directo si tiene impuesto T2
                                              LDPasivo[pos].ClaseCondicion = OrdenCompra[pos].UnidadMedidaSAP;// "";
                                              LDPasivo[pos].Impuesto = porAplicar.Impuesto;
                                              LDPasivo[pos].NumeroRecepcion = porAplicar.Documento_Referencia;
                                              LDPasivo[pos].PosicionRecepcion = OrdenCompra[pos].NoItem.Equals("0000") == true ? null : OrdenCompra[pos].NoItem;
                                              LDPasivo[pos].YearWE = OrdenCompra[pos].Año.Equals("0000") == true ? null : OrdenCompra[pos].Año;
                                              #region identificando si se deben enviar valores de Documento de Referencia
                                              //try
                                              //{
                                              //    if (OrdenCompra[pos].EsdocumentoReferencia.Equals("N") == true)
                                              //    {
                                              //        LDPasivo[pos].NumeroRecepcion = null;// "5001289062";
                                              //        LDPasivo[pos].PosicionRecepcion = null;// listado[pos].NoItem;
                                              //        LDPasivo[pos].YearWE = null;// listado[pos].Año;
                                              //    }
                                              //}
                                              //catch (Exception ex)
                                              //{
                                              //    string _mensajeDeReferencia = ex.Message;
                                              //}
                                              #endregion identificando si se deben enviar valores de Documento de Referencia
                                              LDPasivo[pos].PosicionOrden = OrdenCompra[pos].Posicion;
                                              LDPasivo[pos].PosicionFactura = Convert.ToString(posInc + 1);
                                              LDPasivo[pos].OrdenCompra = porAplicar.OrdenCompra;
                                              #region Envio a Almacenar
                                              //PP_Bafar.Genericos.adT_Ubicacion_Documento g = new Genericos.adT_Ubicacion_Documento();
                                              //Genericos.adT_Ubicacion_Documento guardar = new Genericos.adT_Ubicacion_Documento();
                                              //Dictionary<string, string> listaSufijos = new Dictionary<string, string>();
                                              //listaSufijos.Add("RFC_", porAplicar.RFC);//listacomprobantes[indice].Comprobante._Receptor.rfc);
                                              //listaSufijos.Add("Mes_", DateTime.Now.Month.ToString());
                                              ////prefijo recuperara la ruta donde quedo el XML
                                              //prefijo = porAplicar.OrdenCompra + "_" + porAplicar.NoItem + "_";
                                              //guardar.guardaArchivoDirecto(porAplicar.Path, "XML", 1, listaSufijos, ref prefijo);
                                              //Información para actualizar la Orden de Compra        
                                              //updateOrdenCompra.Orden = LDPasivo[pos].OrdenCompra;
                                              //updateOrdenCompra.Cantidad = Convert.ToDecimal(LDPasivo[pos].CantidadConcepto);
                                              //updateOrdenCompra.Importe = Convert.ToDecimal(LDPasivo[pos].ImporteConcepto);
                                              //updateOrdenCompra.Posicion = LDPasivo[posInc].PosicionOrden;
                                              //listaUpdateOrdenCompra.Add(updateOrdenCompra);
                                              #endregion Envio a Almacenar
                                              posInc++;
                                              pos++;
                                              //}
                                              #endregion Carga de cada Linea-Concepto
                                          }//DEL FOREACH ORIGINAL
                                          #endregion Toda la Generacion Pasivo
                                          //Datos leidos por Orden de Compra incluyendo todas las lineas subidas
                                          bool hubodisparo = false;
                                          #region DISPARAR PASIVO
                                          _agregar = new KeyValuePair<string, string>("msg_2", "Se va a disparar pasivo");
                                          resultadosPasivos.Add(_agregar);
                                          //  D I S P A R A   P A S I V O ##########################################
                                          //eliminaBasura(ref LDPasivo);
                                          string permitirDisparos = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["permitirGeneracionPasivos"];
                                          string importeEnviadoaPasivo = "0";
                                          string importeCalculadoRecepcion = "0";
                                          decimal lineasSuman = 0;
                                          ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[LDPasivo.Count()];
                                          detallesPasivos = eliminaBasura(LDPasivo);
                                          if (permitirDisparos.Equals("S") == true)
                                          {
                                              #region ultima revision de Prorrateo directo aplicado
                                              //Este cambio se hace el 14 de Diciembre por que al intentar localizar la línea con mayor valor
                                              //algunas veces el producto de las cantidades por el importe unitario no arrojaban el mismo valor que lo que SAP ya habia reportado como 
                                              //posible y esperado valor de la línea, y si no s elocalizaba dicha línea no se aplicaba el prorrateo, por ello
                                              //se decide aplicarlo arbitraiamente a la primera línea
                                              if (prorrateoAplicadoseRealizo == false && diferenciaDirecta == true && quienFueMayor.Contains("Factura") == true)
                                              {
                                                  detallesPasivos[0].ImporteConcepto = Convert.ToString(Convert.ToDouble(detallesPasivos[0].ImporteConcepto) - Math.Abs(diferenciaArrastradaentreFacturaRecepcion));

                                              }
                                              #endregion ultima revision de Prorrateo directo aplicado
                                              lineasSuman = sumaValorRecepciones(detallesPasivos, true);
                                              lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                              if ((diferenciaArrastradaentreFacturaRecepcion == 0) == true)
                                              {
                                                  //De hecho podria ya haber cuadrado pero se revisara no vayan a ocurrir diferencias
                                                  //entre lo enviado y SAP menores a 1 peso!
                                                  decimal importeAEnviar = Convert.ToDecimal(HPasivo.Importe);
                                                  if ((importeAEnviar - lineasSuman) < 1)
                                                      HPasivo.Importe = lineasSuman.ToString();
                                              }
                                              else
                                              {
                                                  //if (((diferenciaArrastradaentreFacturaRecepcion > 0) && (diferenciaArrastradaentreFacturaRecepcion < 0.999999)) == true && siProrrateoporImportes == true)
                                                  if (((diferenciaArrastradaentreFacturaRecepcion > 0) && (diferenciaArrastradaentreFacturaRecepcion <= 0.999999)) == true && siProrrateoporImportes == true)
                                                  {
                                                      //De hecho podria ya haber cuadrado pero se revisara no vayan a ocurrir diferencias
                                                      //entre lo enviado y SAP menores a 1 peso!
                                                      decimal importeAEnviar = Convert.ToDecimal(HPasivo.Importe);
                                                      HPasivo.Importe = lineasSuman.ToString();
                                                  }
                                              }
                                              #region Identificando y tratando Iva Retenido
                                              //Tiene impuestos Retenidos??
                                              //Si sí,entonces se debe sumar el Subtotal mas el valor del impuesto Retenido DIRECTO y ese es el NUEVO valor de la FACTURA
                                              //Valor Factura=Subtotal+Impuesto Retenido
                                              if (Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) > 0)
                                              {
                                                  if (_posibleTipo.Equals("Flete") == true)
                                                  {
                                                      HPasivo.Importe = Convert.ToString(Convert.ToDecimal(OrdenCompra[0].Importe) + Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido));
                                                      informacionComplementaria = informacionComplementaria + " Se identifico que la factura traia Iva Retenido (Posible escenario Flete) asi que de nuevo de altero el Valor de la Factura sumando al Importe Total de la Factura de " + Convert.ToDouble(OrdenCompra[0].Importe).ToString("C") + " + " + Convert.ToDouble(OrdenCompra[0].ImpuestoRetenido).ToString("C") + " = " + Convert.ToDouble(HPasivo.Importe).ToString("C");
                                                  }
                                                  else
                                                  {
                                                      informacionComplementaria = informacionComplementaria + " Se identifico que la factura traia Iva e ISR Retenido  (Posible escenario Rentas) asi que de nuevo de altero el Valor de la Factura sumando al Importe Total de la Factura de " + Convert.ToDouble(OrdenCompra[0].Importe).ToString("C") + " + " + Convert.ToDouble(OrdenCompra[0].ImpuestoRetenido).ToString("C") + " = " + Convert.ToDouble(HPasivo.Importe).ToString("C");
                                                      if (Convert.ToDecimal(_importeTotalTrasladados) > 0)
                                                      {
                                                          if (esRFCMoral == "Fisica")
                                                          {
                                                              if (Convert.ToDecimal(HPasivo.Importe) != lineasSuman)
                                                              {
                                                                  decimal posibleTotal = (Convert.ToDecimal(HPasivo.Importe) + Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido));
                                                                  posibleTotal = Convert.ToDecimal(Math.Round(Convert.ToDecimal(posibleTotal) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                                                  decimal _lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 1, MidpointRounding.AwayFromZero));
                                                                  if (posibleTotal == _lineasSuman)
                                                                  {
                                                                      HPasivo.Importe = lineasSuman.ToString();
                                                                      informacionComplementaria = informacionComplementaria + " de persona Física ";
                                                                  }
                                                              }
                                                              else
                                                              {
                                                                  HPasivo.Importe = lineasSuman.ToString();
                                                              }
                                                          }
                                                      }
                                                  }
                                              }
                                              else
                                              {
                                                  if (esRFCMoral == "Moral" && siCuentaTrasladados == false && _posibleTipo.Equals("Solo Trasladados") == true)
                                                  {
                                                      decimal _HPasivoImporte = Convert.ToDecimal(Math.Round(Convert.ToDecimal(HPasivo.Importe) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                      decimal _lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                      if (_HPasivoImporte != _lineasSuman)
                                                      {
                                                          if (diferenciaDirecta == false)
                                                          {
                                                              HPasivo.Importe = Convert.ToString(Convert.ToDecimal(HPasivo.Importe) - Convert.ToDecimal(_importeTotalTrasladados));
                                                              informacionComplementaria = informacionComplementaria + " de persona Moral ";
                                                          }
                                                      }
                                                      else
                                                      {
                                                          HPasivo.Importe = lineasSuman.ToString();
                                                      }
                                                  }
                                              }
                                              #endregion Identificando y tratando Iva Retenido
                                              #region Ultimo ajuste de diferencias entre Importe Facturas- Importe recepcion
                                              _agregar = new KeyValuePair<string, string>("msg_3", "Ajuste de importes de la factura");
                                              resultadosPasivos.Add(_agregar);
                                              string segundoAjuste = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["ajusteImportesFactWE"];
                                              bool ajustarDiferencia = segundoAjuste.Equals("S") == true ? true : false;
                                              #region Checando si aplicar la Nota de Credito
                                              //if (OrdenCompra[0].DiferenciaImportes != 0) //diferenciaArrastradaentreFacturaRecepcion > 0 == true && Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) > 0 == true)
                                              //{
                                              //    //Si factura es mayor
                                              //    if (OrdenCompra[0].ImportesFueron.Contains("Factur") == true)
                                              //    {
                                              //        if (diferenciaDirecta == false)
                                              //        {
                                              //            int signofactorAjusteDiferenciaFacturaRecepcion = factorAjusteDiferenciaFacturaRecepcion >= 0 == true ? -1 : 1;
                                              //            //Si la factura es MAYOR entonces el importe a facturar es la lo que valga la RECEPCIÓN
                                              //            //HPasivo.Importe = Convert.ToString(Convert.ToDouble(HPasivo.Importe) - Math.Abs(OrdenCompra[0].DiferenciaImportes)); //Camboado el 22 de Dic 2106
                                              //            HPasivo.Importe = Convert.ToString(Convert.ToDouble(OrdenCompra[0].RecepcionValia) - Math.Abs(OrdenCompra[0].DiferenciaImportes));
                                              //        }
                                              //        else
                                              //        {
                                              //            decimal _lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                              //            HPasivo.Importe = _lineasSuman.ToString();
                                              //        }
                                              //    }
                                              //}
                                              #endregion Checando si aplicar la Nota de Credito
                                              #region Checando si aplicar Diferencia de Importes
                                              if (OrdenCompra[0].DiferenciaImportes != 0) //diferenciaArrastradaentreFacturaRecepcion > 0 == true && Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) > 0 == true)
                                              {
                                                  //Si factura es mayor
                                                  if (OrdenCompra[0].ImportesFueron.Contains("Factur") == true)
                                                  {
                                                      //Implica que elementos importe ajustarDiferencia verificar esExterno la RECEPCIÓN
                                                      if (diferenciaDirecta == false)
                                                      {
                                                          int signofactorAjusteDiferenciaFacturaRecepcion = factorAjusteDiferenciaFacturaRecepcion >= 0 == true ? -1 : 1;
                                                          //HPasivo.Importe = Convert.ToString(Convert.ToDouble(HPasivo.Importe) - Math.Abs(OrdenCompra[0].DiferenciaImportes));

                                                          //Si la factura es MAYOR entonces el importe a facturar es la lo que valga la RECEPCIÓN
                                                          //HPasivo.Importe = Convert.ToString(Convert.ToDouble(HPasivo.Importe) - Math.Abs(OrdenCompra[0].DiferenciaImportes)); //Cambiado el 22 de Dic 2106
                                                          //Remodificado el 23 Dic GRD 2016 pues aplica prorrateo al importe de la Recepcion que de hecho es la que debe mantenerse
                                                          //26 de Diciembre se regresa a HPasivo.Importe
                                                          //HPasivo.Importe = Convert.ToString(Convert.ToDouble(OrdenCompra[0].RecepcionValia) - Math.Abs(OrdenCompra[0].DiferenciaImportes)); 
                                                          HPasivo.Importe = Convert.ToString(Convert.ToDouble(HPasivo.Importe) - Math.Abs(OrdenCompra[0].DiferenciaImportes));
                                                      }
                                                      else
                                                      {
                                                          decimal _lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                          HPasivo.Importe = _lineasSuman.ToString();
                                                      }
                                                  }
                                              }
                                              #endregion Checando si aplicar Diferencia de Importes
                                              #endregion Ultimo ajuste de diferencias entre Importe Facturas- Importe recepcion
                                              if (esRetail == true)
                                              {
                                                  //En este punto ya viene ajustado por lo tanto es valida la asignación directa
                                                  decimal _lineasSuman = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                  HPasivo.Importe = _lineasSuman.ToString();//.Remove(_lineasSuman.ToString().Length - 1);
                                                  tipoPasivo = 1;
                                                  informacionComplementaria = informacionComplementaria + " fue un Retail.";
                                              }
                                              if (esRetail == false)
                                              {
                                                  #region Ultima revision
                                                  //Desactivado el 19 Septiembre 2015
                                                  decimal _HPasivoImporteF = Convert.ToDecimal(Math.Round(Convert.ToDecimal(HPasivo.Importe) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                  decimal _lineasSumanF = Convert.ToDecimal(Math.Round(Convert.ToDecimal(lineasSuman) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                  if (_HPasivoImporteF == _lineasSumanF)
                                                      HPasivo.Importe = lineasSuman.ToString();
                                                  else
                                                  {
                                                      //Factura es mayor!  Se envía todo como la Recepción!!!
                                                      if (Math.Abs(OrdenCompra[0].DiferenciaImportes) > 0)
                                                          if (OrdenCompra[0].ImportesFueron.Contains("Factur") == true)
                                                          {
                                                              HPasivo.Importe = lineasSuman.ToString();
                                                          }
                                                      if (OrdenCompra[0].ImportesFueron.Contains("guale") == true)
                                                      {
                                                          HPasivo.Importe = lineasSuman.ToString();
                                                      }
                                                  }
                                                  #endregion Ultima revision
                                              }
                                              importeEnviadoaPasivo = HPasivo.Importe;
                                              importeCalculadoRecepcion = OrdenCompra[0].RecepcionValia.ToString();// lineasSuman.ToString();
                                              #region Verificando no se realicen varios disparos sobre Recepciones ya verificadas
                                              bool esUnico = false;
                                              string mensajeVerificacion = "";
                                              bool? _existe = false;
                                              using (var ctx = new Desarrollo_CF())
                                              {
                                                  System.Data.Entity.Core.Objects.ObjectParameter existe = new System.Data.Entity.Core.Objects.ObjectParameter("existe", typeof(Boolean));
                                                  System.Data.Entity.Core.Objects.ObjectParameter _mensajeVerificacion= new System.Data.Entity.Core.Objects.ObjectParameter("mensaje", typeof(string));
                                                  //IList<ClickFactura_Entidades.BD.Entidades.SP_checarRecepcionesVerifivcadas_Result> Oc = ctx.SP_checarRecepcionesVerifivcadas(OrdenCompra[0].NoRecepcion, OrdenCompra[0].OrdenCompra, existe,mensajeVerificacion, "checarRecepcionVerificada").ToList<ClickFactura_Entidades.BD.Entidades.SP_checarRecepcionesVerifivcadas_Result>();
                                                  ctx.SP_checarRecepcionesVerifivcadas(OrdenCompra[0].NoRecepcion, OrdenCompra[0].OrdenCompra, existe, _mensajeVerificacion, "checarRecepcionVerificada");
                                                  //oc = Oc != null ? Oc[0].Num_Proveedor : "";
                                                  if (existe != null)
                                                      _existe =(bool?) existe.Value;
                                                  if (_mensajeVerificacion != null)
                                                      mensajeVerificacion = _mensajeVerificacion.Value.ToString();
                                              }
                                              esUnico = true;
                                              if(esUnico==true)
                                              {
                                                  //string mensajeVerificacion = "";
                                                  //bool? existe = false;
                                                  //contexto.SP_checarRecepcionesVerifivcadas(OrdenCompra[0].NoRecepcion, OrdenCompra[0].OrdenCompra, ref existe, ref mensajeVerificacion, "checarRecepcionVerificada");
                                                  _agregar = new KeyValuePair<string, string>("msg_4", "msg verificacion: " + mensajeVerificacion);
                                                  resultadosPasivos.Add(_agregar);
                                                  if (_existe == false)
                                                  {
                                                      HPasivo.Importe = Convert.ToString(Math.Round(Convert.ToDecimal(HPasivo.Importe) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                      //bool puedeDisparar = (bool)Session["impideDisparo"];
                                                      //if (puedeDisparar == false)// GRD 18 Enero Protección de no enviar a verificar si la diferencia esta fuera del rango permitido!!
                                                      //{
                                                      double ImporteMaximo = 0;
                                                      if (OrdenCompra[0].ImportesFueron.Contains("Factura") == true)
                                                      {
                                                          ImporteMaximo = Convert.ToDouble(OrdenCompra[0].RecepcionValia);// -Convert.ToDouble(OrdenCompra[0].DiferenciaImportes);
                                                      }
                                                      else
                                                          if (OrdenCompra[0].ImportesFueron.Contains("Recepc") == true)
                                                          {
                                                              ImporteMaximo = Convert.ToDouble(OrdenCompra[0].RecepcionValia);
                                                              if (OrdenCompra[0].TipoFactura.Equals("Flete") == true)
                                                              {
                                                                  ImporteMaximo = ImporteMaximo + Convert.ToDouble(OrdenCompra[0].IvaTrasladadoTotal);
                                                              }
                                                              if (OrdenCompra[0].TipoFactura.Equals("Ticket") == true)
                                                              {
                                                                  ImporteMaximo = ImporteMaximo + Convert.ToDouble(OrdenCompra[0].DiferenciaImportes);
                                                              }
                                                              if (OrdenCompra[0].TipoFactura.Equals("Moral") == true)
                                                              {
                                                                  ImporteMaximo = Convert.ToDouble(lineasSuman);
                                                              }
                                                          }
                                                          else
                                                              ImporteMaximo = Convert.ToDouble(lineasSuman);
                                                      ImporteMaximo = Convert.ToDouble(Math.Round(Convert.ToDecimal(ImporteMaximo) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                                      HPasivo.Importe = ImporteMaximo.ToString();
                                                      importeEnviadoaPasivo = HPasivo.Importe;
                                                      //if (Convert.ToDouble(lineasSuman) <= ImporteMaximo)
                                                      {
                                                          //_agregar = new KeyValuePair<string, string>("msg_5", "Antes de generar pasivo al servicio web.");
                                                          resultadosPasivos.Add(_agregar);
                                                          //HPasivo.Importe = importeTotalFinal;
                                                          HPasivo.Factura = true;
                                                          HPasivo.CalculaImpuesto = true;
                                                          #region ########################### B A P I      M   I    R    0     #############################
                                                          //GPasivo = bafar.Genera_Pasivo(HPasivo, detallesPasivos, tipoPasivo);      Versión 1 -- 2016
                                                          //GPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[1];  Versión 2 -- 2017
                                                          datos=factXML_construyeBAPIMIRO(HPasivo, detallesPasivos);
                                                          GPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[1];
                                                          hubodisparo = true;
                                                          #endregion ########################### B A P I      M   I    R    0     #############################
                                                          //_agregar = new KeyValuePair<string, string>("msg_6", "Se ejecuto la funcion de generar pasivos");
                                                          if(datos!=null)
                                                          {
                                                              resultadosPasivos.Clear();
                                                              foreach(KeyValuePair<string,string> dat in datos)
                                                              {
                                                                resultadosPasivos.Add(new KeyValuePair<string,string>(dat.Key,dat.Value));
                                                              }
                                                              datos.Add(new KeyValuePair<string, string>("OrdenCompra", detallesPasivos[0].OrdenCompra));
                                                              resultadosPasivos.Add(new KeyValuePair<string,string>("OrdenCompra",detallesPasivos[0].OrdenCompra));
                                                          }
                                                      }
                                                      //else
                                                      //{
                                                      //    //Notificacion("El importe monetario ( $" + lineasSuman.ToString() + " ) que se enviaría a verificar rebasa el máximo permitido para esta Factura, comentelo a su contacto Bafar para atender esta situación. ", "No se acepto la Factura", "deny", 330, y);
                                                      //    hubodisparo = false;
                                                      //}
                                                      //}
                                                      //else
                                                      //{
                                                      //    //GRD 18 Enero  Se informa que no se enviará a verificar por diferencia de Importes
                                                      //    hubodisparo = false;
                                                      //    KeyValuePair<string, string> _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " La Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " NO PROCEDÍO. Si usted ve este mensaje la evaluación de importes ya habia determinado que NO era válido enviar a verificar esta Factura, pero por alguna razón el navegador le permitio avanzar equivocadamente, puede comentarlo con su contacto en BAFAR");
                                                      //    resultadosPasivos.Add(_agregar);
                                                      //}
                                                  }
                                                  else
                                                  {
                                                      //La Recepción ya esta verificada
                                                      resultadosPasivos = new List<KeyValuePair<string, string>>();
                                                      mensajesAdicionales = mensajesAdicionales + mensajeVerificacion + ". ";
                                                      _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " La Recepción " + OrdenCompra[0].NoRecepcion + " de la Orden de Compra " + OrdenCompra[0].OrdenCompra + " ya ha sido verificada anteriormente");
                                                      resultadosPasivos.Add(_agregar);
                                                  }
                                              }
                                              #endregion Verificando no se realicen varios disparos sobre Recepciones ya verificadas
                                          }
                                          //  D I S P A R A   P A S I V O ##########################################
                                          //#######################################################################################################################################################
                                          //  ADMINISTRA RESULTADOS         D I S P A R A   P A S I V O        ##################################################################################################
                                          //#######################################################################################################################################################
                                          if (hubodisparo == true)
                                          {

                                              string _mensajes = "";
                                              try
                                              {
                                                  foreach (var gPasivo in GPasivo)
                                                  {
                                                      if (gPasivo.Tipo_Error != null)
                                                          if (gPasivo.Tipo_Error.Equals("") == false)
                                                              _mensajes = _mensajes + "No. Error: " + gPasivo.Tipo_Error + "- Descripción:" + gPasivo.Mensaje_Error;
                                                  }
                                              }
                                              catch (Exception ex)
                                              {
                                                  ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[] pasivo=new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado[1];
                                                  pasivo[0] = new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado();
                                                  pasivo[0].Tipo_Error="false";
                                                  pasivo[0].FolioFactura = "";
                                                  pasivo[0].Mensaje_Error = "";
                                                  pasivo[0].NumeroOrden = "";
                                                  pasivo[0].NumeroPasivo = "";
                                                  pasivo[0].YearFiscal = "0000";
                                                  string _mensajeNoHuboErrores = ex.Message;
                                                  if(datos.Count>0)
                                                  {
                                                      string mensa="";
                                                      bool fueErroneo=false;
                                                      foreach(KeyValuePair<string,string> resultado in datos)
                                                      {
                                                          mensa= mensa + " "+ resultado.Value;
                                                          if(resultado.Key.Equals("E")==true || resultado.Key.Equals("Error")==true)
                                                          {
                                                              pasivo[0].Tipo_Error = "E";
                                                              pasivo[0].Mensaje_Error = mensa;
                                                              fueErroneo=true;
                                                          }
                                                          if (resultado.Key.Equals("OrdenCompra") == true)
                                                          {
                                                              pasivo[0].NumeroOrden = resultado.Value;
                                                          }
                                                      }
                                                      if(fueErroneo==false)
                                                      {
                                                                   foreach(KeyValuePair<string,string> resultado in datos)
                                                                  {
                                                                          if(resultado.Key.Equals("INVOICEDOCNUMBER")==true)
                                                                          {
                                                                              pasivo[0].Tipo_Error = null;
                                                                              pasivo[0].Mensaje_Error = null;
                                                                              pasivo[0].NumeroPasivo = resultado.Value;
                                                                          }
                                                                          else
                                                                          {
                                                                               if(resultado.Key.Equals("FISCALYEAR")==true)
                                                                                  {
                                                                                      pasivo[0].Tipo_Error = null;
                                                                                      pasivo[0].Mensaje_Error = null;
                                                                                      pasivo[0].YearFiscal = resultado.Value;
                                                                                  }
                                                                          }
                                                                  }
                                                      }
                                                  }
                                                  if(pasivo!=null)
                                                  {
                                                      GPasivo[0] = new ClickFactura_Entidades.BD.Modelos.Pasivo_Generado();
                                                      GPasivo[0].FolioFactura = pasivo[0].FolioFactura;
                                                      GPasivo[0].Mensaje_Error = pasivo[0].Mensaje_Error;
                                                      GPasivo[0].NumeroOrden = pasivo[0].NumeroOrden;
                                                      GPasivo[0].NumeroPasivo = pasivo[0].NumeroPasivo;
                                                      GPasivo[0].Tipo_Error = pasivo[0].Tipo_Error;
                                                      GPasivo[0].YearFiscal = pasivo[0].YearFiscal;
                                                  }

                                              }

                                              #region Disparo realizado y Bitacorar
                                              try
                                              {
                                                  if ((GPasivo[0].Tipo_Error != null && GPasivo[0].Tipo_Error.Equals("E") == true) || GPasivo[0].NumeroPasivo == null)
                                                  {
                                                      resultadosPasivos = new List<KeyValuePair<string, string>>();
                                                      #region Reporta resultados Erroneos
                                                      intentosFallidos++;
                                                      _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue fallida.");
                                                      resultadosPasivos.Add(_agregar);
                                                      string msj = "";
                                                      if (!esExterno)
                                                          msj = "Configuración SAP respondío: " + _mensajes;////GPasivo.Mensaje_Error;
                                                      else
                                                          msj = "Los datos ingresados no son suficientes o son incorrectos para aceptar la actual operación, por favor verifique o contacte a su Comprador para más información.";
                                                      _agregar = new KeyValuePair<string, string>("E", msj);
                                                      resultadosPasivos.Add(_agregar);
                                                      #region BitacoraOperaciones
                                                      ad_T_BitacoraOperaciones bitacorar = new ad_T_BitacoraOperaciones();
                                                      objT_BitacoraOperaciones obj = new objT_BitacoraOperaciones();
                                                      obj.IdUsuario = idUsuario;
                                                      obj.Num_Proveedor = _Num_Proveedor;// (string)Session["Num_Proveedor"];
                                                      obj.Sociedad = _Sociedad;// (string)Session["Num_Sociedad"];
                                                      obj.IdProveedor = _idproveedor;// Convert.ToInt32((string)Session["IdProveedor"]);
                                                      obj.OrdenCompra = NoOrdenCompra;
                                                      obj.NumRecepcion = NoItem;
                                                      obj.Posicion = OrdenCompra[0].Posicion;
                                                      obj.operacionExitosa = false;
                                                      obj.FacturaValida = true;
                                                      obj.Error = "Configuración SAP respondío: " + OrdenCompra[0].TipoFactura + " " + _mensajes;// GPasivo.Mensaje_Error;//+". Portal CSC documentó: "+ informacionComplementaria;
                                                      obj.Flujo = "BAPI_MIRO";
                                                      obj.Archivo_Factura = OrdenCompra[0].TextoXML;//prefijo;
                                                      obj.FolioFactura = OrdenCompra[0].FolioFactura;
                                                      obj.Mensaje = "Configuración SAP respondío : Para la orden " + NoOrdenCompra + " y la recepcion " + NoItem + " ocurrío un problema bajo el concepto de " + _mensajes + ". Portal CSC  documento la siguiente información : " + informacionComplementaria + " Emisor " + usuario.Usuario;//GPasivo.Mensaje_Error + ". Portal CSC  documento la siguiente información : " + (lblTituloFlujo.InnerHtml.ToString().Length > 0 == true ? lblTituloFlujo.InnerHtml.ToString() : "Carga Manual") + informacionComplementaria  + " Emisor " + (string)Session["Usuario"];
                                                      obj.FechaFactura = OrdenCompra[0].FechaFactura;
                                                      obj.UUID = OrdenCompra[0].UUID;
                                                      obj.Fecha = DateTime.Now.ToString();
                                                      obj.ImporteFactura = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito))); //OrdenCompra[0].ImporteDocumento.ToString();
                                                      obj.ImportePasivo = importeEnviadoaPasivo;
                                                      obj.ImporteRecepcion = importeCalculadoRecepcion;
                                                      obj.RFCEmisor = OrdenCompra[0].RFC;
                                                      obj.RFC_Recepctor = RFC_del_Receptor;
                                                      obj.Serie = Serie;
                                                      obj.Moneda = OrdenCompra[0].Moneda;
                                                      obj.PasivoGenerado = "No se genero";
                                                      bitacorar.registrarEvento(obj, "Insertar");
                                                      #endregion BitacoraOperaciones
                                                      #endregion Reporta resultados Erroneos
                                                      correcto = false;
                                                  }
                                                  else
                                                  {
                                                      #region Pasivo Generado
                                                      intentosExitosos++;
                                                      resultadosPasivos = new List<KeyValuePair<string, string>>();
                                                      //resultadosPasivos.Add(OrdenCompra[0].OrdenCompra, " Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue exitoso.");
                                                      _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue exitosa.</br>Se genero el pasivo con el número: " + GPasivo[0].NumeroPasivo);
                                                      resultadosPasivos.Add(_agregar);
                                                      //PASIVO GENERADO
                                                      #region BitacoraOperaciones
                                                      ad_T_BitacoraOperaciones bitacorar = new ad_T_BitacoraOperaciones();
                                                      objT_BitacoraOperaciones obj = new objT_BitacoraOperaciones();
                                                      obj.IdUsuario = idUsuario;
                                                      obj.Num_Proveedor = _Num_Proveedor;// (string)Session["Num_Proveedor"];
                                                      obj.Sociedad = _Sociedad;//(string)Session["Num_Sociedad"];
                                                      obj.IdProveedor = _idproveedor; //Convert.ToInt32((string)Session["IdProveedor"]);
                                                      obj.OrdenCompra = OrdenCompra[0].OrdenCompra;
                                                      obj.NumRecepcion = OrdenCompra[0].NoRecepcion;
                                                      obj.Posicion = OrdenCompra[0].Posicion;
                                                      obj.operacionExitosa = true;
                                                      obj.Error = "Sin errores y se genero un pasivo con documento de referencia " + GPasivo[0].NumeroPasivo + (cuadrarconSAP == true ? " pero se forzo el empate enviando con  base a los datos como se tenian en Recepcion " + NoItem : "." + informacionComplementaria);// GPasivo.Mensaje_Error;
                                                      obj.Mensaje = "Portal: Para la orden " + NoOrdenCompra + " y la recepcion " + NoItem + " (" + OrdenCompra[0].TipoFactura + ") " + " si fue generado un pasivo correctamente. Generación  Pasivo - " + GPasivo[0].NumeroPasivo + " " + informacionComplementaria + " Emisor  ";// 15 Agosto Pendiente identificar al  +usuario.Usuario;
                                                      obj.Flujo = "BAPI_MIRO";
                                                      obj.Archivo_Factura = OrdenCompra[0].TextoXML;//prefijo;
                                                      obj.FolioFactura = OrdenCompra[0].FolioFactura;
                                                      obj.FacturaValida = true;
                                                      obj.FechaFactura = OrdenCompra[0].FechaFactura;
                                                      obj.Fecha = DateTime.Now.ToString();
                                                      obj.ImporteFactura = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito))); //OrdenCompra[0].ImporteDocumento.ToString();
                                                      obj.ImportePasivo = importeEnviadoaPasivo;
                                                      obj.ImporteRecepcion = importeCalculadoRecepcion;
                                                      obj.RFCEmisor = OrdenCompra[0].RFC;
                                                      obj.UUID = OrdenCompra[0].UUID;
                                                      obj.RFC_Recepctor = RFC_del_Receptor;
                                                      obj.Serie = Serie;
                                                      obj.Moneda = OrdenCompra[0].Moneda;
                                                      obj.PasivoGenerado = GPasivo[0].NumeroPasivo;
                                                      NumeroPasivoGenerado = GPasivo[0].NumeroPasivo;
                                                      bitacorar.registrarEvento(obj, "Insertar");
                                                      #endregion BitacoraOperaciones
                                                      try
                                                      {
                                                          #region Envia correo Proveedor
                                                          //var prov = (from t in contexto.Cat_Proveedor where t.IdProveedor.Equals(_idproveedor) select t).FirstOrDefault();
                                                          ////enviaCorreogeneraPasivo(string _IdProveedor,string _IdUsuario, string _Usuario, string _Proveedor,string resultadoVerificacion,string _OrdenCompra,string _Recepcion, string _Cuerpo)
                                                          //string _IdProveedor = _idproveedor.ToString();// (string)Session["IdProveedor"];
                                                          ////string _IdUsuario = (string)Session["idUsuario"];
                                                          ////string _Usuario =  (string)Session["Usuario"];
                                                          //string _Proveedor = prov.Nombre;
                                                          //var us = prov.Cat_Usuario;

                                                          //string resultadoVerificacion = obj.operacionExitosa == true ? " exitosa " : " fallida ";
                                                          //string _OrdenCompra = OrdenCompra[0].OrdenCompra;
                                                          //string _Recepcion = OrdenCompra[0].NoRecepcion;
                                                          //string _Cuerpo = "Estimado " + obj.RFCEmisor + "  su Orden de Compra " + _OrdenCompra + " y la Recepción " + _Recepcion + " fue verificada " + resultadoVerificacion + " el " + DateTime.Now.ToLongDateString() + " para la Empresa " + _Proveedor + ". Su factura fue verificada y aceptada con el no. de referencia " + GPasivo[0].NumeroPasivo + ".  Nota: Este no. de referencia indica que su factura fue recepcionada correctamente.";
                                                          //enviaCorreogeneraPasivo(_IdProveedor, usuario.IdUsuario.ToString(), usuario.Usuario, _Proveedor, resultadoVerificacion, _OrdenCompra, _Recepcion, _Cuerpo);
                                                          #endregion Envia correo Proveedor
                                                      }
                                                      catch
                                                      {

                                                      }

                                                      #endregion Pasivo Generado
                                                      correcto = true;
                                                  }
                                              }
                                              catch (Exception)
                                              {
                                                  resultadosPasivos = new List<KeyValuePair<string, string>>();
                                                  if (GPasivo[0].Tipo_Error != null)
                                                  {
                                                      #region Pasivo con Error
                                                      intentosFallidos++;
                                                      //resultadosPasivos.Add(OrdenCompra[0].OrdenCompra, "Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue fallida. ");
                                                      _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue fallida.");
                                                      resultadosPasivos.Add(_agregar);
                                                      string msj = "";
                                                      if (!esExterno)
                                                          msj = "Configuración SAP respondío: " + _mensajes;//GPasivo.Mensaje_Error;
                                                      else
                                                          msj = "Los datos ingresados no son suficientes o son incorrectos para aceptar la actual operación, por favor verifique o contacte a su Comprador para más información.";

                                                      //Mi version de bitacorar
                                                      #region BitacoraOperaciones
                                                      ad_T_BitacoraOperaciones bitacorar = new ad_T_BitacoraOperaciones();
                                                      objT_BitacoraOperaciones obj = new objT_BitacoraOperaciones();
                                                      obj.IdUsuario = idUsuario;
                                                      obj.Num_Proveedor = _Num_Proveedor;// (string)Session["Num_Proveedor"];
                                                      obj.Sociedad = _Sociedad;// (string)Session["Num_Sociedad"];
                                                      obj.IdProveedor = _idproveedor;// Convert.ToInt32((string)Session["IdProveedor"]);
                                                      obj.OrdenCompra = OrdenCompra[0].OrdenCompra;
                                                      obj.NumRecepcion = OrdenCompra[0].NoRecepcion;
                                                      obj.Posicion = OrdenCompra[0].Posicion;
                                                      obj.operacionExitosa = false;
                                                      obj.Error = "Intento fallido configuración SAP respondío: " + OrdenCompra[0].TipoFactura + " " + GPasivo[0].Mensaje_Error;//(GPasivo.Mensaje_Error!=null?" configuración SAP respondío: " + GPasivo.Mensaje_Error+". ":"" )+  " Portal CSC documentó:  " + informacionComplementaria;
                                                      obj.Mensaje = "Portal CSC documentó : Intento fallido de carga de factura " + OrdenCompra[0].NombreArchivoXML + " realizada por el Proveedor " + OrdenCompra[0].RFC + " para compesar su Orden de Compra  " + NoOrdenCompra + " y la recepción " + NoItem + informacionComplementaria;
                                                      obj.Flujo = "BAPI_MIRO";
                                                      obj.FacturaValida = true;
                                                      obj.Archivo_Factura = OrdenCompra[0].TextoXML;//prefijo;
                                                      obj.FolioFactura = OrdenCompra[0].FolioFactura;
                                                      obj.FechaFactura = OrdenCompra[0].FechaFactura;
                                                      obj.Fecha = DateTime.Now.ToString();
                                                      obj.UUID = OrdenCompra[0].UUID;
                                                      obj.ImporteFactura = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito)));// OrdenCompra[0].ImporteDocumento.ToString();
                                                      obj.ImportePasivo = importeEnviadoaPasivo;
                                                      obj.ImporteRecepcion = importeCalculadoRecepcion;
                                                      obj.RFCEmisor = OrdenCompra[0].RFC;
                                                      obj.RFC_Recepctor = RFC_del_Receptor;
                                                      obj.Serie = Serie;
                                                      obj.Moneda = OrdenCompra[0].Moneda;
                                                      obj.PasivoGenerado = "No se genero";
                                                      bitacorar.registrarEvento(obj, "Insertar");
                                                      #endregion BitacoraOperaciones
                                                      #endregion Pasivo con Error
                                                      correcto = false;
                                                  }
                                                  else
                                                  {
                                                      #region Pasivo Generado
                                                      //PASIVO GENERADO
                                                      intentosExitosos++;
                                                      //resultadosPasivos.Add(OrdenCompra[0].OrdenCompra, "Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue exitosa. ");
                                                      _agregar = new KeyValuePair<string, string>(OrdenCompra[0].OrdenCompra, " Recepción " + OrdenCompra[0].NoRecepcion + " - Orden de Compra " + OrdenCompra[0].OrdenCompra + " fue exitosa.</br>Se genero el pasivo con el número: " + GPasivo[0].NumeroPasivo);
                                                      resultadosPasivos.Add(_agregar);
                                                      #region Bitacorar
                                                      ad_T_BitacoraOperaciones bitacorar = new ad_T_BitacoraOperaciones();
                                                      objT_BitacoraOperaciones obj = new objT_BitacoraOperaciones();
                                                      obj.IdUsuario = idUsuario;
                                                      obj.Num_Proveedor = _Num_Proveedor;// (string)Session["Num_Proveedor"];
                                                      obj.Sociedad = _Sociedad;// (string)Session["Num_Sociedad"];
                                                      obj.IdProveedor = _idproveedor;// Convert.ToInt32((string)Session["IdProveedor"]);
                                                      obj.OrdenCompra = OrdenCompra[0].OrdenCompra;
                                                      obj.NumRecepcion = OrdenCompra[0].NoRecepcion;
                                                      obj.Posicion = OrdenCompra[0].Posicion;
                                                      obj.operacionExitosa = true;
                                                      obj.Error = "Portal: Se Genero un Pasivo con referencia " + GPasivo[0].NumeroPasivo + (cuadrarconSAP == true ? " pero se forzo el empate enviando con  base a los datos como se tenian en Recepcion " + NoItem : "." + informacionComplementaria);// +pasivogenerado.NumeroOrden;// GPasivo.Mensaje_Error;
                                                      obj.Mensaje = "Para la orden " + NoOrdenCompra + " y la recepcion " + NoItem + " (" + OrdenCompra[0].TipoFactura + ") " + " si fue generado un pasivo correctamente. Generación  Pasivo -" + GPasivo[0].NumeroPasivo + " " + informacionComplementaria + " Emisor ";// 15 Agosto Pendiente identificar al  +usuario.Usuario;
                                                      obj.Flujo = "BAPI_MIRO";
                                                      obj.FacturaValida = true;
                                                      obj.Archivo_Factura = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito))); //OrdenCompra[0].TextoXML;//prefijo;
                                                      obj.FolioFactura = OrdenCompra[0].FolioFactura;
                                                      obj.FechaFactura = OrdenCompra[0].FechaFactura;
                                                      obj.UUID = OrdenCompra[0].UUID;
                                                      obj.Fecha = DateTime.Now.ToString();
                                                      obj.ImportePasivo = HPasivo.Importe;
                                                      obj.ImporteFactura = OrdenCompra[0].ImporteDocumento.ToString();
                                                      obj.ImportePasivo = importeEnviadoaPasivo;
                                                      obj.ImporteRecepcion = importeCalculadoRecepcion;
                                                      obj.RFCEmisor = OrdenCompra[0].RFC;
                                                      obj.RFC_Recepctor = RFC_del_Receptor;
                                                      obj.Serie = Serie;
                                                      obj.Moneda = OrdenCompra[0].Moneda;
                                                      obj.PasivoGenerado = GPasivo[0].NumeroPasivo;
                                                      NumeroPasivoGenerado = GPasivo[0].NumeroPasivo;
                                                      bitacorar.registrarEvento(obj, "Insertar");
                                                      #endregion Bitacorar
                                                      try
                                                      {
                                                          #region Envia correo Proveedor
                                                          ////enviaCorreogeneraPasivo(string _IdProveedor,string _IdUsuario, string _Usuario, string _Proveedor,string resultadoVerificacion,string _OrdenCompra,string _Recepcion, string _Cuerpo)
                                                          //string _IdProveedor = _idproveedor.ToString();// (string)Session["IdProveedor"];
                                                          //var prov = (from t in contexto.Cat_Proveedor where t.IdProveedor.Equals(_idproveedor) select t).FirstOrDefault();
                                                          //string resultadoVerificacion = obj.operacionExitosa == true ? " exitosa " : " fallida ";
                                                          //string _OrdenCompra = OrdenCompra[0].OrdenCompra;
                                                          //string _Recepcion = OrdenCompra[0].NoRecepcion;
                                                          //string _Cuerpo = "Estimado " + obj.RFCEmisor + " su Orden de Compra " + _OrdenCompra + " y la Recepción " + _Recepcion + " fue verificada " + resultadoVerificacion + " el " + DateTime.Now.ToLongDateString() + " para la Empresa " + prov.Nombre + ". Su factura fue verificada y aceptada con el no. de referencia " + GPasivo[0].NumeroPasivo + ".  Nota: Este no. de referencia indica que su factura fue recepcionada correctamente.";
                                                          //enviaCorreogeneraPasivo(_IdProveedor, usuario.IdUsuario.ToString(), usuario.Usuario, prov.Nombre, resultadoVerificacion, _OrdenCompra, _Recepcion, _Cuerpo);
                                                          #endregion Envia correo Proveedor
                                                      }
                                                      catch
                                                      {

                                                      }
                                                      #endregion Pasivo Generado
                                                      correcto = true;
                                                  }
                                              }
                                              #endregion Disparo realizado y Bitacorar

                                          }

                                          // ADMINISTRA RESULTADOS D I S P A R A   P A S I V 0 ###################################################################################################################################
                                          //#########################################################################################################################################################
                                          //##########################################################################################################################################################
                                          #endregion DISPARAR PASIVO
                                          //break;
                                          #endregion disparo para una Factura de sus Recepciones
                                      }
                                      else
                                      {
                                      }
                                  }//########################################################################################################################################################################
                                  #endregion VERIFICACIÓN DE UNA F A C T U R A
                              }
                          }
                          #endregion dispara Pasivo

                      }//del if (Session["estructuraAlmacenada"] != null)
                      else
                      {
                          // No habia información disponible para procesar
                          //Page.ClientScript.RegisterStartupScript(this.GetType(), "Sin Informacion", "alert('No hay información para procesar!!. Intente nuevamente desde la comparación de importes.');", true);
                      }
                  }

                  catch (Exception ex)
                  {
                      #region Problemas de conectividad
                      //Notificacion("Upps!, tenemos un problema durante el envio del pasivo : " + leyenda + ex.Message + ", " + ex.InnerException, "Ocurrío un error", "deny");
                      #region Bitacora
                      ad_T_BitacoraOperaciones b = new ad_T_BitacoraOperaciones();
                      objBitacora obj = new objBitacora();
                      obj.IdBitacora = 0;
                      obj.Descripcion = "Ocurrío un problema " + ex.Message + ", " + ex.InnerException;
                      obj.Fecha = DateTime.Now;
                      obj.Operacion = "Problema disparando Pasivo";
                      obj.Usuario = usuario.Usuario;
                      //b.registrarBitacora(obj);
                      #endregion Bitacora
                      #endregion Problemas de conectividad
                      var _agregar = new KeyValuePair<string, string>("msg_E1", "Excepcion: " + ex.Message + " InnerException: " + ex.InnerException.Message);
                      resultadosPasivos.Add(_agregar);
                  }
                  #endregion 15
                 foreach(KeyValuePair<string,string> _err in datos)
                {
                    if(_err.Key.ToUpper().Contains("ERROR")==true || _err.Key.Contains("OrdenCompra") == true)
                    {
                        resultadosPasivos.Add(new KeyValuePair<string, string>("msg_E1", "Error: " + _err.Value));
                    }
                }
                  resultados = resultadosPasivos;
                  return correcto;
              }
              catch (Exception ex)
              {
                  resultados = new List<KeyValuePair<string, string>>();
                  var msg = new KeyValuePair<string, string>("Error", "Excepción: " + ex.Message);
                  resultadosPasivos.Add(msg);
                  resultados = resultadosPasivos;
                  return false;
              }
          }

          public void factXML_IdentificaImpuestos(ref ClickFactura_Entidades.BD.Modelos.objAnalizarImpuestos objImpuestos)
          {
              string _importeISRRenta="";
              string _importeIVARenta="";
              string _posibleTipo="";
              string _importeTotalTrasladados="";
              bool siCuentaTrasladados = false;
              string RetencionISRRenta="";
              string RetencionIVARenta="";
              string SubTotalXml = "";
              string ImporteRetencionFlete = "";
              string Importe = "";
              bool calculaImpuesto = false;

            if (objImpuestos.version!="")//=="3.3")
            {
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante();
                Factura33.Impuestos = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos)objImpuestos.Factura33;
              #region Analizando Impuestos Escenarios Fletes-Rentas
              ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
              ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32 Impuestos = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32();
                if(Factura33.Impuestos!=null)
                {
                      _Impuestos = Factura33.Impuestos;
                }
              List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto> impuestos = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto>();
              obtenRetencionesRenta(_Impuestos, ref _importeISRRenta, ref _importeIVARenta, ref _posibleTipo, ref  _importeTotalTrasladados, ref siCuentaTrasladados, ref impuestos);
              string tipoFactura = _posibleTipo;// OrdenCompra[0].TipoFactura;
              if (tipoFactura.Equals("Normal") == false)
              {
                  #region Es Renta
                  if (tipoFactura.Equals("Renta") == true)
                  {
                      var retenciones = from retencion in impuestos where retencion.Tipo.Equals("Retencion") == true select retencion;
                      if (retenciones != null)
                          if (retenciones.Count() > 0)
                          {
                              foreach (var reten in retenciones)
                              {
                                  if (reten.Etiqueta.Equals("ISR") == true)
                                  {
                                      RetencionISRRenta = reten.Importe.ToString();
                                  }
                                  if (reten.Etiqueta.Equals("IVA") == true)
                                  {
                                      RetencionIVARenta = reten.Importe.ToString();
                                  }
                              }
                              calculaImpuesto = true;
                          }
                      //HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
                      SubTotalXml=objImpuestos.subTotalXml;
                  }
                  #endregion Es Renta
                  #region Es Flete
                  if (tipoFactura.Equals("Flete") == true)
                  {
                      ImporteRetencionFlete = _importeIVARenta;
                      SubTotalXml = objImpuestos.subTotalXml;
                      calculaImpuesto = true;
                  }
                  #endregion Es Flete
                  #region Es Honorario
                  if (tipoFactura.Equals("Honorarios") == true)
                  {
                      RetencionISRRenta = _importeISRRenta;
                      SubTotalXml = objImpuestos.subTotalXml;
                      calculaImpuesto = true;
                  }
                  #endregion Es Honorario
                  #region Es Moral
                  if (tipoFactura.Equals("Moral") == true)
                  {
                      Importe = Convert.ToString(Convert.ToDecimal(objImpuestos.Importe) - Convert.ToDecimal(_importeTotalTrasladados));
                      calculaImpuesto = true;
                  }
                  #endregion Es Moral
              }
              #endregion Analizando Impuestos  Escenarios Fletes-Rentas
                #region        Pasa Valores
              objImpuestos._importeISRRenta = RetencionISRRenta;
              objImpuestos._importeIVARenta = RetencionIVARenta;
              objImpuestos._posibleTipo = _posibleTipo;
              objImpuestos.tipoFactura = _posibleTipo;
              objImpuestos._importeTotalTrasladados = _importeTotalTrasladados;
              objImpuestos.calculaImpuesto = calculaImpuesto;
              //objImpuestos.siCuentaTrasladados = siCuentaTrasladados;
              //objImpuestos.RetencionISRRenta = "";
              //objImpuestos.RetencionIVARenta = "";
              //objImpuestos.SubTotalXml = "";
              //objImpuestos.ImporteRetencionFlete = "";
              objImpuestos.Importe = "";
                #endregion Pasa Valores
            }

          }

       public List<KeyValuePair<string, string>>  factXML_construyeBAPIMIRO(ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado HPasivo, ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos)
        {
            ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado _HPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado();
            ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle _DPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle();
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            datos=MIRO_dispara_BAPI_INCOMINGINVOICE_CREATE(HPasivo, detallesPasivos);
            return datos;
        }

        public List<KeyValuePair<string, string>> Hardcore_construyeBAPIMIRO()
        {
            ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado _HPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado();
            ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle _DPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle();
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            datos = MIRO_dispara_BAPI_INCOMINGINVOICE_CREATE(null,null);
            return datos;
        }

        /// <summary>
        /// factXML_obtenDatosProveedor
        /// Sirve para recuperar la información de Cat_Proveedores por medio de cualquiera de los datos de tipo  de Texto
        /// </summary>
        /// <param name="campo"></param>
        /// <param name="valor"></param>
        /// <returns></returns>
        public List<KeyValuePair<string,string>> factXML_obtenDatosProveedor(string campo, string valor)
       {
                      List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> proveedoresConsulta = new List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor>();
                      List<KeyValuePair<string,string>> datos=new List<KeyValuePair<string,string>>();
             #region Consultando datos de Cat_Proveedor solo 1
                      using (var ctx = new Desarrollo_CF())
                      {
                          ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                          #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                          var _proveedor = generico.genericos_consultaCualquierTabla( "Select * From Cat_Proveedor Where "+ campo +"='" + valor + "'");
                          #endregion
                          if (_proveedor != null)
                          {
                              if (_proveedor.Rows.Count > 0)
                              {
                                  foreach (DataRow p in _proveedor.AsEnumerable())
                                  {
                                      #region recuperacion y carga de la información
                                      ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                      proveedor.IdProveedor = p.Field<int>("IdProveedor");
                                      proveedor.Nombre = p.Field<string>("Nombre");
                                      proveedor.Num_Sociedad = p.Field<string>("Num_Sociedad");
                                      proveedor.Num_Proveedor = p.Field<string>("Num_Proveedor");
                                      proveedor.Sociedad = p.Field<string>("Sociedad");
                                      proveedor.Pais = p.Field<string>("Pais");
                                      proveedor.Direccion = p.Field<string>("Direccion");
                                      proveedor.GrupoCA = p.Field<string>("GrupoCA");
                                      proveedor.RFC = p.Field<string>("RFC");
                                      proveedor.CPD = p.Field<string>("CPD");
                                      proveedor.GrupoCCPD = p.Field<string>("GrupoCCPD");
                                      proveedor.Correo = p.Field<string>("Correo");
                                      proveedor.Activo = p.Field<bool>("Activo");
                                      proveedor.P_General = p.Field<decimal>("P_General");
                                      proveedor.P_Comercial = p.Field<decimal>("P_Comercial");
                                      proveedor.RFC2 = p.Field<string>("RFC2");
                                      proveedor.Poblacion = p.Field<string>("Poblacion");
                                      datos.Add(new KeyValuePair<string,string>("Nombre",p.Field<string>("Nombre")));
                                      datos.Add(new KeyValuePair<string, string>("RFC", p.Field<string>("RFC")));
                                      datos.Add(new KeyValuePair<string, string>("Sociedad", p.Field<string>("Sociedad")));
                                      datos.Add(new KeyValuePair<string, string>("Num_Proveedor", p.Field<string>("Num_Proveedor")));
                                      //proveedoresConsulta.Add(proveedor);
                                      break;
                                      #endregion recuperacion y carga de la información
                                  }
                              }
                          }
                      }
                 #endregion Consultando datos de Cat_Proveedor solo 1
           return datos;
       }
          private decimal sumaValorRecepciones(ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] detallesPasivos, bool conImpuesto)
          {
              double Importe = 0;
              decimal nuevoImporte = 0;
              //bool esMixta = false;
              //Int32 cuatosSon = detallesPasivos.Count();
              //var elementosV0 = from todos in detallesPasivos where todos.Impuesto.Contains("V0") == true select todos;
              //var elementosT2 = from todos in detallesPasivos where todos.Impuesto.Contains("T2") == true select todos;
              //if(elementosT2!=null && elementosT2.Count()>0)
              //{
              //    if (elementosT2.Count() == cuatosSon)
              //        esMixta = false;
              //    else
              //    {
              //        if (elementosV0 != null && elementosV0.Count() > 0)
              //        {
              //            if (elementosV0.Count() == cuatosSon)
              //                esMixta = false;
              //            else
              //                esMixta = true;
              //        }
              //        else
              //            esMixta = true;
              //    }
              //}
              foreach (var linea in detallesPasivos)
              {
                  string porImporteUnitario = "S";// System.Web.Configuration.WebConfigurationManager.AppSettings["porImporteUnitario"];
                  #region         Modificado para procesar correctamente las lineas 20 Diciembre 2016 GRD
                  //if (conImpuesto == true)
                  //{
                  //    double valorImpuesto = linea.Impuesto.Equals("V0") == true ? 0 : 1.16;
                  //    if (valorImpuesto > 0)
                  //        Importe = Importe + ((Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto))) * Convert.ToDouble(valorImpuesto));
                  //    else
                  //        Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto)));
                  //}
                  //else
                  //{
                  //    Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto)));
                  //}
                  #endregion Modificando para procesar correctamente las lineas 20 de Diciembre 2016 GRD

                  #region Original al 20 de Diciembre de 2016 GRD
                  if (porImporteUnitario.Equals("S") == true)
                  {
                      if (conImpuesto == true)
                      {
                          double valorImpuesto = linea.Impuesto.Equals("V0") == true ? 0 : 1.16;
                          //Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * Convert.ToDouble(valorImpuesto));
                          if (valorImpuesto > 0)
                              Importe = Importe + ((Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto))) * Convert.ToDouble(valorImpuesto));
                          else
                              Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto)));// (Convert.ToDouble(linea.ImporteConcepto));
                      }
                      else
                      {
                          Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * (Convert.ToDouble(linea.CantidadConcepto)));// (Convert.ToDouble(linea.ImporteConcepto));
                      }
                  }
                  else
                  {
                      if (conImpuesto == true)
                      {
                          double valorImpuesto = linea.Impuesto.Equals("V0") == true ? 0 : 1.16;
                          //Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * Convert.ToDouble(valorImpuesto));
                          if (valorImpuesto > 0)
                              Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto) * Convert.ToDouble(valorImpuesto));
                          else
                              Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto));
                      }
                      else
                      {
                          Importe = Importe + (Convert.ToDouble(linea.ImporteConcepto));
                      }
                  }
                  #endregion Original al 20 de Diciembre de 2016
              }
              nuevoImporte = Convert.ToDecimal(Importe);
              return nuevoImporte;
          }
          private ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] eliminaBasura(ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] Pasivos)
          {
              int cuantos = Pasivos.Count();
              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] PasivosSalida = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[cuantos];
              int pos = 0;
              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle DPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle();
              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] LDPasivo = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[cuantos];
              foreach (var pasivo in Pasivos)
              {
                  if (pasivo != null)
                  {
                      LDPasivo[pos] = pasivo;
                  }
                  pos++;
              }
              #region Preparando cuantos son NO Nulos
              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] saberCuantos = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[pos > 1 ? pos : 1];
              pos = 0;
              int cuantosFinal = 0;
              foreach (var pasivo in Pasivos)
              {
                  if (pasivo != null)
                  {
                      saberCuantos[pos] = pasivo;
                      cuantosFinal++;
                  }
                  pos++;
              }

              #endregion Preparando cuantos son NO Nulos
              ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[] LDPasivoFinal = new ClickFactura_Entidades.BD.Modelos.Pasivo_Detalle[cuantosFinal > 1 ? cuantosFinal : 1];
              pos = 0;
              foreach (var pasivo in Pasivos)
              {
                  if (pasivo != null)
                  {
                      LDPasivoFinal[pos] = pasivo;
                  }
                  pos++;
              }
              Pasivos = LDPasivoFinal;
              return PasivosSalida = Pasivos;
          }
          private double calculaFactor(List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> facturasAgrupadas, Double importeFactura, String nombreFactura, bool tieneIVA, ref bool aplicarFactor, ref int signo, ref double factorSoloIVA, ref bool diferenciaDirecta, double NotaCredito, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> NotaC, List<KeyValuePair<string, string>> susRecepcionesValidasEnVista)
          {
              #region Vigente hasta 22 Nov 2016 GRD
              //string prorrateoPorImporte = System.Web.Configuration.WebConfigurationManager.AppSettings["prorrateoPorImporte"];
              //double factor = 0;
              //Double cantidad = 0;
              //double diferencia = 0;
              //string subtotal = "";
              //double _subtotalFactura = 0;
              //double _valorFacturaTotal = 0;
              //double lineasSuman = 0;
              //bool calculaEdit = true;
              //aplicarFactor = false;
              //if (prorrateoPorImporte.Equals("N") == true)
              //{
              //    #region Original
              //    var u = (from t in facturasAgrupadas where t.NombreArchivo.Equals(nombreFactura) == true select t);
              //    var Subtotal = (from ol in u
              //                    group ol by ol.NombreArchivo
              //                        into grp
              //                        select new Genericos.obj_facturaAPasivo
              //                        {
              //                            Importe = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Importe.Replace("$", "")))),
              //                        }
              //                ).ToList();
              //    #endregion Original
              //    lineasSuman = facturasAgrupadas[0].ImporteRecepcionOrigen;
              //    factorSoloIVA = facturasAgrupadas[0].ImporteArticulosconIVA;
              //    subtotal = Subtotal.First().Importe;
              //    //Importe de la Factura
              //    #region Calcula no articulos con IVA
              //    var y = (from t in facturasAgrupadas where t.Impuesto.Equals("T2") == true select t);
              //    factorSoloIVA = factorSoloIVA / y.Count();
              //    #endregion Calcula no articulos con IVA
              //    if (calculaEdit == true)
              //    {
              //        _valorFacturaTotal = Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
              //        _subtotalFactura = _valorFacturaTotal - Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);

              //        diferencia = _subtotalFactura - lineasSuman;
              //        //diferencia = diferencia - (diferencia * .16);
              //    }
              //    else
              //    {
              //        #region Original
              //        subtotal = Subtotal.First().Importe;
              //        diferencia = (importeFactura - 0) - Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
              //        #endregion Original
              //    }
              //    if (diferencia != 0)
              //    {
              //        if (diferencia > 0)
              //            signo = -1;
              //        else
              //            signo = 1;
              //        aplicarFactor = true;
              //        var groupedList = (from ol in u
              //                           group ol by ol.NombreArchivo.Equals(nombreFactura) == true
              //                               into grp
              //                               select new Genericos.obj_facturaAPasivo
              //                               {
              //                                   Piezas = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Piezas))),
              //                               }
              //                        ).ToList();
              //        cantidad = Convert.ToDouble(groupedList.First().Piezas);
              //        factor = (diferencia / cantidad);
              //    }
              //}
              //else
              //{
              //    #region Original
              //    var u = (from t in facturasAgrupadas where t.NombreArchivo.Equals(nombreFactura) == true select t);
              //    var Subtotal = (from ol in u
              //                    group ol by ol.NombreArchivo
              //                        into grp
              //                        select new Genericos.obj_facturaAPasivo
              //                        {
              //                            Importe = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Importe.Replace("$", "")))),
              //                        }
              //                ).ToList();
              //    #endregion Original
              //    lineasSuman = facturasAgrupadas[0].ImporteRecepcionOrigen;
              //    factorSoloIVA = facturasAgrupadas[0].ImporteArticulosconIVA;
              //    subtotal = Subtotal.First().Importe;
              //    #region Obteniendo info de la NC

              //    bool NCTieneIVA = tieneIVA;

              //    #endregion Obteniendo info de la NC
              //    //Importe de la Factura
              //    #region Calcula no articulos con IVA
              //    var y = (from t in facturasAgrupadas where t.Impuesto.Equals("T2") == true select t);
              //    factorSoloIVA = factorSoloIVA / y.Count();
              //    #endregion Calcula no articulos con IVA
              //    if (calculaEdit == true)
              //    {
              //        _valorFacturaTotal = Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
              //        _subtotalFactura = _valorFacturaTotal - Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);
              //        _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
              //        if (facturasAgrupadas[0].TipoFactura.Equals("Renta") == true)
              //        {
              //            _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML); //+ Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal) - Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
              //            _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
              //        }
              //        if (facturasAgrupadas[0].TipoFactura.Equals("Flete") == true)
              //        {
              //            _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);// +Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);// -Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
              //            _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
              //        }
              //        if (facturasAgrupadas[0].TipoFactura.Equals("Honorarios") == true)
              //        {
              //            _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);// +Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);// -Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
              //            _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
              //        }
              //        diferencia = _subtotalFactura - lineasSuman;
              //        #region Buscando importe de Prorrateo Directo maximo permitido
              //        var dato = (from t in contexto.T_Parametros where t.descParametro == "prorrateoDirecto" select t.valorParametro).FirstOrDefault();
              //        double rangoDirecto = dato != null ? Convert.ToDouble(dato) : 0;
              //        diferenciaDirecta = Math.Abs(diferencia) <= rangoDirecto ? true : false;
              //        #endregion Buscando importe de Prorrateo Directo maximo permitido
              //        //lineasSuman      =  Recepcion
              //        //subTotalFactura =  Importe Factura
              //        double Recepcion = lineasSuman;
              //        double Factura = _subtotalFactura;
              //        //                                                     IGUALES
              //        if (Recepcion == Factura)
              //            factor = 100;
              //        else
              //            if (Recepcion > Factura)
              //            {
              //                //                                    FACTURA PASA
              //                factor = (Factura * 100) / Recepcion;
              //                if (diferencia > 0)
              //                    signo = -1;
              //                else
              //                    signo = 1;
              //                if (diferenciaDirecta == false)
              //                    aplicarFactor = true;
              //                else
              //                    aplicarFactor = false;
              //            }
              //            else
              //            {
              //                //                                 RECEPCION PASA
              //                if (Recepcion < Factura)
              //                {
              //                    factor = ((Recepcion * 100) / Factura);
              //                    if (diferencia > 0)
              //                        signo = -1;
              //                    else
              //                        signo = 1;
              //                    aplicarFactor = true;
              //                }
              //            }

              //        //diferencia = diferencia - (diferencia * .16);
              //    }
              //    else
              //    {
              //        #region Original
              //        subtotal = Subtotal.First().Importe;
              //        diferencia = (importeFactura - 0) - Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
              //        #endregion Original
              //    }

              //}
              //return factor;
              #endregion Vigente hasta 22 Nov 2016 GRD
              //##################################################################################################################################
              #region        Modificacion 22 Nov 2016 GRD
              string prorrateoPorImporte = System.Web.Configuration.WebConfigurationManager.AppSettings["prorrateoPorImporte"];
              double factor = 0;
              Double cantidad = 0;
              double diferencia = 0;
              string subtotal = "";
              double _subtotalFactura = 0;
              double _valorFacturaTotal = 0;
              double lineasSuman = 0;
              bool calculaEdit = true;
              aplicarFactor = false;
              List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> listadoNC = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito>();
              //facturasAgrupadas[0].DiferenciaImportes = facturasAgrupadas[0].DiferenciaImportes / 1.16;

              if (prorrateoPorImporte.Equals("N") == true)
              {
                  #region Sin Prorrateo
                  #region Original
                  var u = (from t in facturasAgrupadas where t.NombreArchivo.Equals(nombreFactura) == true select t);

                  var Subtotal = (from ol in u
                                  group ol by ol.NombreArchivo
                                      into grp
                                      select new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo
                                      {
                                          Importe = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Importe.Replace("$", "")))),
                                      }
                              ).ToList();
                  #endregion Original
                  lineasSuman = facturasAgrupadas[0].ImporteRecepcionOrigen;
                  factorSoloIVA = facturasAgrupadas[0].ImporteArticulosconIVA * 0.16;
                  int posi = 0;
                  foreach (var fac in facturasAgrupadas)
                  {
                      facturasAgrupadas[posi].IvaTrasladadoTotal = factorSoloIVA.ToString();
                      posi++;
                  }

                  subtotal = Subtotal.First().Importe;
                  //Importe de la Factura
                  #region Calcula no articulos con IVA
                  var y = (from t in facturasAgrupadas where t.Impuesto.Equals("T2") == true || t.Impuesto.Equals("V2") == true select t);
                  factorSoloIVA = factorSoloIVA / y.Count();
                  #endregion Calcula no articulos con IVA
                  if (calculaEdit == true)
                  {
                      _valorFacturaTotal = Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
                      _subtotalFactura = _valorFacturaTotal - Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);

                      diferencia = _subtotalFactura - lineasSuman;
                      //diferencia = diferencia - (diferencia * .16);
                  }
                  else
                  {
                      #region Original
                      subtotal = Subtotal.First().Importe;
                      diferencia = (importeFactura - 0) - Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
                      #endregion Original
                  }
                  if (diferencia != 0)
                  {
                      if (diferencia > 0)
                          signo = -1;
                      else
                          signo = 1;
                      aplicarFactor = true;
                      var groupedList = (from ol in u
                                         group ol by ol.NombreArchivo.Equals(nombreFactura) == true
                                             into grp
                                             select new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo
                                             {
                                                 Piezas = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Piezas))),
                                             }
                                      ).ToList();
                      cantidad = Convert.ToDouble(groupedList.First().Piezas);
                      factor = (diferencia / cantidad);
                  }
                  #endregion Sin Prorrateo
              }
              else
              {
                  double Mayor = 0;
                  double menor = 0;

                  #region Original
                  var u = (from t in facturasAgrupadas where t.NombreArchivo.Equals(nombreFactura) == true select t);
                  var Subtotal = (from ol in u
                                  group ol by ol.NombreArchivo
                                      into grp
                                      select new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo
                                      {
                                          Importe = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.Importe.Replace("$", "")))),
                                      }
                              ).ToList();
                  var Subtotal_WE = (from ol in u
                                     group ol by ol.NombreArchivo
                                         into grp
                                         select new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo
                                         {
                                             Importe = Convert.ToString(grp.Sum(ex => Convert.ToDecimal(ex.ImporteDocumento))),
                                         }
                                           ).ToList();
                  #region        Parche para igualar proceso con portal viejo
                  if (Convert.ToDouble(Subtotal[0].RecepcionValia) == 0)
                  {
                      Subtotal[0].RecepcionValia = facturasAgrupadas[0].RecepcionValia + facturasAgrupadas[0].DiferenciaImportes;
                  }
                  #endregion Parche para igualar proceso con portal viejo

                  #endregion Original
                  lineasSuman = facturasAgrupadas[0].ImporteRecepcionOrigen;

                  factorSoloIVA = facturasAgrupadas[0].ImporteArticulosconIVA;
                  subtotal = Subtotal.First().Importe;    //Lo que vale la Factura

                  double subtotalWE;
                  #region Parche para igualar proceso con portal viejo
                  Int64 cuantos = u.Count();
                  Double subtotalAcumulado = Convert.ToDouble(subtotal) * cuantos;
                  subtotal = subtotalAcumulado.ToString();
                  subtotalWE = Convert.ToDouble(Convert.ToDouble(subtotal) / cuantos);//Subtotal_WE.First().Importe);      //Lo que vale la Recepción
                  #endregion Parche para igualar proceso con portal viejo

                  //subtotalWE = Convert.ToDouble(Subtotal_WE.First().Importe);      //Lo que vale la Recepción

                  #region Obteniendo info de la NC
                  bool NCTieneIVA = false;
                  if (NotaC != null && NotaC.Count > 0)
                      listadoNC = NotaC;// (List<Genericos.objNotaCredito>)Session["NotasCredito"];
                  try
                  {
                      ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito NC = listadoNC[0];
                      NCTieneIVA = true;// NC.TieneIVA;
                  }
                  catch
                  {
                      NCTieneIVA = false;
                  }
                  #endregion Obteniendo info de la NC

                  #region       Identificando posibles diferencias de IVA por que existan articulos que apliquen o no IVA
                  decimal subTotalmenosNCmenosDescuento = Convert.ToDecimal(Convert.ToDouble(facturasAgrupadas[0].SubTotalXML)) + Convert.ToDecimal(Convert.ToDouble(facturasAgrupadas[0].NotasCredito)) - Convert.ToDecimal(Convert.ToDouble(facturasAgrupadas[0].Descuento));
                  //if (Convert.ToDouble(Math.Round(Convert.ToDecimal(Convert.ToDouble(facturasAgrupadas[0].SubTotalXML) * .16) * 1.00m, 2, MidpointRounding.AwayFromZero)) != Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal))
                  if (Convert.ToDouble(Math.Round(Convert.ToDecimal(Convert.ToDouble(subTotalmenosNCmenosDescuento) * .16) * 1.00m, 2, MidpointRounding.AwayFromZero)) != Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal))
                  {
                      if (Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal) == 0)
                      {
                          if (facturasAgrupadas[0].IvaTrasladadoTotal != null)
                          {
                              //Nos aseguramos que en efecto niguna linea en la Recepción se le iba a aplicar IVA
                              List<KeyValuePair<string, string>> _susRecepcionesValidasEnVista = new List<KeyValuePair<string, string>>();
                              _susRecepcionesValidasEnVista = susRecepcionesValidasEnVista;
                              if (_susRecepcionesValidasEnVista != null)
                                  if (_susRecepcionesValidasEnVista.Count() > 0)
                                  {
                                      double soloIVA = 0;
                                           double impuesto = (recepcion_a_ValorImpuestos(_susRecepcionesValidasEnVista, facturasAgrupadas[0].OrdenCompra, facturasAgrupadas[0].NoRecepcion, ref soloIVA));
                                      impuesto = Convert.ToDouble(Convert.ToDouble(impuesto) + Convert.ToDouble(Math.Round(Convert.ToDecimal(Convert.ToDouble(facturasAgrupadas[0].DiferenciaImportes) * 1.16) * 1.00m, 2, MidpointRounding.AwayFromZero)));  //Convert.ToDouble(Math.Round(Convert.ToDecimal((facturasAgrupadas[0].DiferenciaImportes)) * 1.00m, 2, MidpointRounding.AwayFromZero));
                                      if (impuesto != Convert.ToDouble(subTotalmenosNCmenosDescuento))
                                      {
                                          //No empatan el valor de las lineas de la recepcion con el Subtotal entonces hay NO HAY IVA
                                          if (soloIVA != Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal))
                                          {
                                              // IVA reportado es diferente del calculado tomandolo de line por linea de la Recepcion, entonces recalculo mi IVA
                                              facturasAgrupadas[0].IvaTrasladadoTotal = Convert.ToDouble(Math.Round(Convert.ToDecimal(Convert.ToDouble(subTotalmenosNCmenosDescuento) * .16) * 1.00m, 2, MidpointRounding.AwayFromZero)).ToString();
                                          }
                                      }
                                  }
                          }
                      }
                  }

                  #endregion Identificando posibles diferencias de IVA por que existan articulos que apliquen o no IVA

                  //Importe de la Factura
                  //#region Calcula no articulos con IVA
                  //var y = (from t in facturasAgrupadas where t.Impuesto.Equals("T2") == true select t);
                  //if(y!=null && y.Count()>0)
                  //{
                  //    double cuanto = 0;
                  //    foreach(var paraSumar in y)
                  //    {
                  //        cuanto = cuanto+Convert.ToDouble(paraSumar.Importe);
                  //    }
                  //    facturasAgrupadas[0].IvaTrasladadoTotal = cuanto.ToString();
                  //}
                  //factorSoloIVA = factorSoloIVA / y.Count();
                  //#endregion Calcula no articulos con IVA
                  if (calculaEdit == true)
                  {
                      #region Importes de la Recepcion
                      _valorFacturaTotal = Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
                      _subtotalFactura = _valorFacturaTotal - Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);
                      //_subtotalFactura = Convert.ToDouble(subtotal);
                      #endregion Importes de la Recepcion

                      //Parche 21 Dic 2016 GRD Subtotal se puede quedar en Ceros si _valorFacturaTota = facturasAgrupadas[0].IvaTrasladadoTotal
                      if (_subtotalFactura == 0)
                      {
                          _subtotalFactura = _valorFacturaTotal;
                      }

                      if (Convert.ToDecimal(facturasAgrupadas[0].IvaTrasladadoTotal) == 0)
                          NCTieneIVA = false;
                      _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      if (facturasAgrupadas[0].TipoFactura.Equals("Renta") == true)
                      {
                          _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML); //+ Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal) - Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
                          _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      }
                      if (facturasAgrupadas[0].TipoFactura.Equals("Flete") == true)
                      {
                          _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);// +Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);// -Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
                          _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      }
                      if (facturasAgrupadas[0].TipoFactura.Equals("Honorarios") == true)
                      {
                          _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);// +Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);// -Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
                          _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      }
                      #region se agrega para obtener valor de la Factura XML siendo Ticket
                      if (facturasAgrupadas[0].TipoFactura.Equals("Ticket") == true)
                      {
                          _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);// +Convert.ToDouble(facturasAgrupadas[0].IvaTrasladadoTotal);// -Convert.ToDouble(facturasAgrupadas[0].ImpuestoRetenido);
                          _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      }
                      if (facturasAgrupadas[0].TipoFactura.Equals("Moral") == true)
                      {
                          _subtotalFactura = Convert.ToDouble(facturasAgrupadas[0].SubTotalXML);
                          _subtotalFactura = _subtotalFactura - Math.Abs(NCTieneIVA == true ? NotaCredito / 1.16 : NotaCredito);
                      }
                      #endregion se agrega para obtener valor de la Factura XML siendo Ticket
                      if (Math.Abs(facturasAgrupadas[0].DiferenciaImportes) < 0.9999999999)
                      {
                          diferencia = _subtotalFactura - lineasSuman;
                          if (diferencia == 0)
                          {
                              diferencia = facturasAgrupadas[0].DiferenciaImportes;
                          }
                      }
                      else
                      {
                          if (facturasAgrupadas[0].ImportesFueron.Contains("Recep") == false)
                              diferencia = facturasAgrupadas[0].DiferenciaImportes;
                          else
                          {
                              if (Math.Abs(facturasAgrupadas[0].DiferenciaImportes) == 0)
                                  diferencia = 0;
                              else
                              {
                                  if (facturasAgrupadas[0].ImportesFueron.Contains("Recep") == false)
                                  {
                                      //Version original diferencia = _subtotalFactura - lineasSuman;
                                      //Modificacion 6 Diciembre para igual con Portal viejo
                                      diferencia = (_subtotalFactura + facturasAgrupadas[0].DiferenciaImportes) - lineasSuman;
                                      //Modificacion 26 Diciembre para igual con Portal viejo
                                      diferencia = (_subtotalFactura) - lineasSuman;
                                  }
                                  else
                                  {
                                      diferencia = (_subtotalFactura + Math.Abs(facturasAgrupadas[0].DiferenciaImportes) - lineasSuman);
                                      diferencia = (_subtotalFactura) - lineasSuman;
                                  }

                              }

                          }

                      }

                      facturasAgrupadas[0].DiferenciaImportes = diferencia;
                      #region Buscando importe de Prorrateo Directo maximo permitido
                      int result = 0;
                      ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros adp = new ClickFactura_WebServiceCF.AccesoBD.Genericos.adT_Parametros();
                      List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros> objp = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objT_Parametros>();
                      //Busca cantidad de prorrateo Directo permitido
                      double rangoDirecto = 0;
                      objp = adp.mABCT_Parametros(out result, 0, "prorrateoDirecto", "Vacio", true, "ConsultaValor");
                      {
                          rangoDirecto = Convert.ToDouble(objp[0].ValorParametro.ToString());
                      }
                      diferenciaDirecta = Math.Abs(diferencia) <= rangoDirecto ? true : false;
                      #endregion Buscando importe de Prorrateo Directo maximo permitido

                      string facturaVale = valorFacturaVerificacion(facturasAgrupadas);

                      //lineasSuman       =   Recepcion                  ===> Aqui se le nombro Factura
                      //subTotalFactura =  Importe Factura        ===> Aqui se le nombro Recepción 
                      double Recepcion = Convert.ToDouble(subtotalWE); //lineasSuman;
                      double Factura = _subtotalFactura; // lineasSuman;//
                      if (facturasAgrupadas[0].ImportesFueron.Contains("Factura") == true)
                      {
                          if (NotaC != null)
                          {
                              if (facturasAgrupadas[0].ReglasAplicadas.Contains("Iguales x Notade Credito") == false)
                              {
                                  Factura = Math.Abs(NCTieneIVA == true ? Factura * 1.16 : Factura + NotaCredito);
                              }
                              else
                              {
                                  //Factura debe quedar igual pues lienas arriba ya se habria determinado su valor correcto
                                  //Factura = Math.Abs(NCTieneIVA == true ? Factura * 1.16 : (Factura<=(Recepcion+0.02) || Factura>=(Recepcion-0.02)) ? Factura: Factura+NotaCredito);
                                  //Modificado 27 Julio 2016 GRD
                                  Factura = Math.Abs(NCTieneIVA == true ? Factura : (Factura <= (Recepcion + 0.02) || Factura >= (Recepcion - 0.02)) ? Factura : Factura + NotaCredito);
                                  diferencia = 0;
                              }
                          }
                      }
                      if (diferencia != 0)
                      {
                          if (Recepcion < Factura)
                              if (facturasAgrupadas[0].ImportesFueron.Contains("Factura") == false)  // La Factura es mayor hay que descontarle la diferencia
                                  Factura = Factura + (diferencia < 0 == true ? Math.Abs(diferencia) : diferencia);
                      }
                      double adicional = 0;

                      #region Parche de empate logica antiguo Portal se cambian importes
                      //double aux = Factura;
                      //Factura = Recepcion;
                      //Recepcion = aux;
                      #endregion Parche de empate logica antiguo Portal se cambian importes

                      //   IGUALES
                      if (Recepcion == Factura)
                          factor = 100;
                      else
                          if (Recepcion > Factura)
                          {
                              //                                    FACTURA PASA
                              factor = (Factura * 100) / Recepcion;
                              if (diferencia > 0)
                                  signo = -1;
                              else
                                  signo = 1;
                              if (diferenciaDirecta == false)
                                  aplicarFactor = true;
                              else
                                  aplicarFactor = false;
                          }
                          else
                          {
                              //                                 RECEPCION PASA
                              if (Recepcion < Factura)
                              {
                                  factor = ((Recepcion * 100) / Factura);
                                  if (diferencia > 0)
                                      signo = -1;
                                  else
                                      signo = 1;
                                  //aplicarFactor = true;
                                  aplicarFactor = false;
                              }
                          }

                      //diferencia = diferencia - (diferencia * .16);
                  }
                  else
                  {
                      #region Original
                      subtotal = Subtotal.First().Importe;
                      diferencia = (importeFactura - 0) - Convert.ToDouble(Convert.ToDouble(subtotal) / u.Count());
                      #endregion Original
                  }

              }
              #region Calcula no articulos con IVA
              //var yY = (from t in facturasAgrupadas where t.Impuesto.Equals("T2") == true select t);
              //if (yY != null && yY.Count() > 0)
              //{
              //    double cuanto = 0;
              //    foreach (var paraSumar in yY)
              //    {
              //        cuanto = cuanto + Convert.ToDouble(paraSumar.Importe);
              //    }
              //    facturasAgrupadas[0].IvaTrasladadoTotal = Convert.ToString(cuanto*0.16);//cuanto.ToString();
              //}
              #endregion Calcula no articulos con IVA

              return factor;

              #endregion Modificacion 22 Nov 2016 GRD
          }
          public double recepcion_a_ValorImpuestos(List<KeyValuePair<string, string>> _susRecepcionesValidasEnVista, string _ordencompra, string _recepcion, ref double soloIVA)
          {
              double importe = 0;
              if (_susRecepcionesValidasEnVista != null)
                  if (_susRecepcionesValidasEnVista.Count() > 0)
                  {
                      string mensajeLineas = "";
                      foreach (KeyValuePair<string, string> _subRecepcion in _susRecepcionesValidasEnVista)
                      {
                          #region Carga todas las posiciones-lineas de una Recepción
                          _recepcion = _subRecepcion.Key;
                          string posicion = _subRecepcion.Value;
                          using (Desarrollo_CF contexto = new Desarrollo_CF())
                          {
                                  var bitacoras = from b in contexto.Detalle_Recepciones select b;
                                  #region Filtrando
                                  //BAFAR.Models.DatosBafarDataContext contexto = new BAFAR.Models.DatosBafarDataContext(Genericos.Configuracion.CadenaConexion);
                                  //System.Data.Linq.Table<BAFAR.Models.Detalle_Recepciones> todaslasRecepciones = contexto.GetTable<BAFAR.Models.Detalle_Recepciones>();
                                  var todaslasRecepciones = bitacoras;
                                  var q = from _susRecepciones in todaslasRecepciones where _susRecepciones.Orden_Compra.Equals(_ordencompra) == true && _susRecepciones.Numero_Documento.Equals(_recepcion) == true && _susRecepciones.Posicion_Documento.Equals(posicion) == true select _susRecepciones;
                                  if (q != null)
                                      try
                                      {
                                          if (q.Count() > 0)
                                          {//-----------
                                              try
                                              {
                                                  foreach (var reg in q)
                                                  {
                                                      ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo obje = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo();
                                                      obje.Importe = reg.Importe_Documento;
                                                      obje.Posicion = reg.Posicion_OrdenCompra;
                                                      string miImpuesto = "";// encuentraImpuesto(obje.OrdenCompra, obje.Posicion);
                                                      obje.Impuesto = miImpuesto.Equals("") == true ? "V0" : miImpuesto;
                                                      obje.ImporteUnitario = obje.Impuesto.Equals("V0") == true ? Convert.ToDouble(obje.Importe) : Convert.ToDouble(obje.Importe) * 1.16;
                                                      soloIVA = soloIVA + (obje.Impuesto.Equals("V0") == true ? Convert.ToDouble(0) : Convert.ToDouble(obje.Importe) * 0.16);
                                                      importe = importe + obje.ImporteUnitario;
                                                  }
                                              }
                                              catch (Exception ex)
                                              {
                                                  mensajeLineas = mensajeLineas + "Ocurrío el siguiente error extrayendo las líneas de información de la Recepción, error " + ex.Message;
                                              }
                                          }//---
                                      }
                                      catch (Exception ex)
                                      {
                                          if (ex.Message.Contains(" Se agotó el tiempo de espera del sem") == true)
                                          {
                                              string mensaje1 = "La conexión de internet esta muy lenta o se ha cortado, intente de nuevo por favor";
                                          }
                                          else
                                          {
                                              string mensaje2 = "Ocurrío un problema";
                                          }
                                      }
                                  #endregion Filtrando
                          }
                          #endregion Carga todas las posiciones-lineas de una Recepción
                      }
                  }
              return importe;
          }
          private string valorFacturaVerificacion(List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> OrdenCompra)
          {
              string valorFactura = "0.0";
              decimal importe = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].SubTotalXML) * 1.00m, 2, MidpointRounding.AwayFromZero));
              decimal trasladado = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].IvaTrasladadoTotal) * 1.00m, 2, MidpointRounding.AwayFromZero));
              decimal retenidos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) * 1.00m, 2, MidpointRounding.AwayFromZero));
              decimal descuentos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].Descuento) * 1.00m, 2, MidpointRounding.AwayFromZero));
              double ImporteNotasdeCredito = OrdenCompra[0].NotasCredito;
              valorFactura = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito)));//OrdenCompra[0].Importe;
              return valorFactura;
          }
          private List<ClickFactura_Entidades.BD.Modelos.Registros> ConvertirRegistros(List<ClickFactura_Entidades.BD.Modelos.Registros> registros)
          {
              try
              {
                  foreach (var item in registros)
                  {
                      item.R1 = item.R1 != null ? (item.R1 as string[])[0] : "";
                      item.R2 = item.R2 != null ? (item.R2 as string[])[0] : "";
                      item.R3 = item.R3 != null ? (item.R3 as string[])[0] : "";
                      item.R4 = item.R4 != null ? (item.R4 as string[])[0] : "";
                      item.R5 = item.R5 != null ? (item.R5 as string[])[0] : "";
                      item.R6 = item.R6 != null ? (item.R6 as string[])[0] : "";
                      item.R7 = item.R7 != null ? (item.R7 as string[])[0] : "";
                      item.R8 = item.R8 != null ? (item.R8 as string[])[0] : "";
                      item.R9 = item.R9 != null ? (item.R9 as string[])[0] : "";
                      item.R10 = item.R10 != null ? (item.R10 as string[])[0] : "";
                      item.R11 = item.R11 != null ? (item.R11 as string[])[0] : "";
                      item.R12 = item.R12 != null ? (item.R12 as string[])[0] : "";
                      item.R13 = item.R13 != null ? (item.R13 as string[])[0] : "";
                      item.R14 = item.R14 != null ? (item.R14 as string[])[0] : "";
                      item.R15 = item.R15 != null ? (item.R15 as string[])[0] : "";
                      item.R16 = item.R16 != null ? (item.R16 as string[])[0] : "";
                      item.R17 = item.R17 != null ? (item.R17 as string[])[0] : "";
                      item.R18 = item.R18 != null ? (item.R18 as string[])[0] : "";
                      item.R19 = item.R19 != null ? (item.R19 as string[])[0] : "";
                      item.R20 = item.R20 != null ? (item.R20 as string[])[0] : "";
                  }
                  return registros;
              }
              catch (Exception)
              {
                  return new List<ClickFactura_Entidades.BD.Modelos.Registros>();
                  throw;
              }
          }

         public void CreaEncabezadoMIRO(ref  ClickFactura_Entidades.BD.Modelos.Pasivo_Encabezado HPasivo)
          {
              //#region Datos de Encabezado
              //HPasivo.CargoPosterior = false;
              //HPasivo.ClaseDoc = "RE";
              //HPasivo.Factura = true;
              //#region Estableciendo las fechas
              //_agregar = new KeyValuePair<string, string>("msg_l5", "Factura en curso: " + facturaenCurso);
              //resultadosPasivos.Add(_agregar);
              //if (facturaenCurso.Equals(OrdenCompra[0].FolioFactura) == false)
              //{
              //    _agregar = new KeyValuePair<string, string>("msg_l6", "Folio factura " + OrdenCompra[0].FolioFactura);
              //    resultadosPasivos.Add(_agregar);
              //    fechaMasReciente = OrdenCompra[0].FechaFactura;
              //    _agregar = new KeyValuePair<string, string>("msg_l7", "Fecha factura " + OrdenCompra[0].FechaFactura);
              //    resultadosPasivos.Add(_agregar);
              //    var feActual = (from w in facturas orderby w.FechaFactura descending where w.OrdenCompra.Equals(OrdenCompra[0].OrdenCompra) == true select w).FirstOrDefault();
              //    fechaMasReciente = feActual != null ? feActual.FechaFactura : "";
              //    _agregar = new KeyValuePair<string, string>("msg_l8", "Fechas " + fechaMasReciente);
              //    resultadosPasivos.Add(_agregar);
              //    facturaenCurso = OrdenCompra[0].FolioFactura;
              //}
              //#endregion Estableciendo las fechas
              //var fe = fechaMasReciente == "" ? OrdenCompra[0].FechaFactura.Replace('/', '.') : fechaMasReciente.Replace('/', '.');
              ////_agregar = new KeyValuePair<string, string>("msg_f0", "Convertir fecha" + fe);
              ////resultadosPasivos.Add(_agregar);
              //HPasivo.FechaFactura = fe;//Genericos.cs_Estaticos.ConfigFecha(fechaMasReciente == "" ? Convert.ToDateTime(OrdenCompra[0].FechaFactura) : Convert.ToDateTime(fechaMasReciente), ".");//OrdenCompra.FechaFactura);
              //HPasivo.FechaPedimento = "";
              //HPasivo.FolioFactura = OrdenCompra[0].FolioFactura;
              //_agregar = new KeyValuePair<string, string>("msg_f", "Estableciendo Fechas " + HPasivo.FechaFactura);
              //resultadosPasivos.Add(_agregar);
              //decimal importe = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].SubTotalXML) * 1.00m, 2, MidpointRounding.AwayFromZero));
              //decimal trasladado = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].IvaTrasladadoTotal) * 1.00m, 2, MidpointRounding.AwayFromZero));
              //decimal retenidos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].ImpuestoRetenido) * 1.00m, 2, MidpointRounding.AwayFromZero));
              //decimal descuentos = Convert.ToDecimal(Math.Round(Convert.ToDecimal(OrdenCompra[0].Descuento) * 1.00m, 2, MidpointRounding.AwayFromZero));
              //HPasivo.Importe = Convert.ToString((((importe + trasladado) - retenidos) - descuentos) - Convert.ToDecimal(Math.Abs(ImporteNotasdeCredito)));//OrdenCompra[0].Importe;
              //importeTotalFinal = HPasivo.Importe;
              //HPasivo.Proveedor_Diferente = "";
              //#region Nueva recuperacion de datos del Proveedor
              //ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra datosOrdenCompra = System.Web.HttpContext.Current.Session["Encabezado_" + OrdenCompra[0].OrdenCompra] as ClickFactura_Entidades.BD.Modelos.EncabezadoOrdenCompra;
              //#endregion Nueva recuperacion de datos del Proveedor
              //string _Num_Proveedor = "";
              //int _idproveedor = 0;
              //string _Sociedad = datosOrdenCompra.Sociedad;
              //HPasivo.Moneda = datosOrdenCompra.Moneda;
              ////_Sociedad = System.Web.HttpContext.Current.Session["sociedadVerificar"] as String;  //Obtener del Sistema!! Genericos.cs_Estaticos.buscaSociedadxOrdenCompra(OrdenCompra[0].OrdenCompra, ref _Num_Proveedor, ref _idproveedor);
              //HPasivo.Sociedad = _Sociedad;
              //HPasivo.Proveedor_Diferente = datosOrdenCompra.Proveedor;
              //_Num_Proveedor = datosOrdenCompra.Proveedor;
              //HPasivo.ClaseDoc = datosOrdenCompra.PMNTTRMS;
              //string modoPruebas = System.Web.Configuration.WebConfigurationManager.AppSettings["ModoPruebasUUID"];
              //if (modoPruebas.Equals("S") == true)
              //    OrdenCompra[0].UUID = "UUIDEditadoporPrueba_" + DateTime.Now.Ticks;
              //HPasivo.UUID = OrdenCompra[0].UUID;
              //HPasivo.CalculaImpuesto = true;
              //bool WSIguales = System.Web.Configuration.WebConfigurationManager.AppSettings["igualesWSProductivoQAs"].Equals("S") == true ? true : false;//04 Agosto para Fletes
              //string _importeISRRenta = "";
              //string _importeIVARenta = "";
              //string _posibleTipo = "";
              //string _importeTotalTrasladados = "";
              //bool siCuentaTrasladados = false;
              //string esRFCMoral = OrdenCompra[0].RFC.Length > 12 == true ? "Fisica" : "Moral";
              //if (WSIguales == true)
              //{
              //    #region Analizando Impuestos Escenarios Fletes-Rentas
              //    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
              //    ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos Impuestos = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos();
              //    if (OrdenCompra[0].Impuestos != null)
              //    {
              //        Impuestos = OrdenCompra[0].Impuestos;
              //    }
              //    else
              //    {
              //        _Impuestos = OrdenCompra[0].Impuestos33;
              //    }

              //    List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto> impuestos = new List<ClickFactura_WebServiceCF.AccesoBD.Genericos.objImpuesto>();
              //    obtenRetencionesRenta(_Impuestos, ref _importeISRRenta, ref _importeIVARenta, ref _posibleTipo, ref  _importeTotalTrasladados, ref siCuentaTrasladados, ref impuestos);
              //    string tipoFactura = OrdenCompra[0].TipoFactura;
              //    if (tipoFactura.Equals("Normal") == false)
              //    {
              //        #region Es Renta
              //        if (tipoFactura.Equals("Renta") == true)
              //        {
              //            var retenciones = from retencion in impuestos where retencion.Tipo.Equals("Retencion") == true select retencion;
              //            if (retenciones != null)
              //                if (retenciones.Count() > 0)
              //                {
              //                    foreach (var reten in retenciones)
              //                    {
              //                        if (reten.Etiqueta.Equals("ISR") == true)
              //                        {
              //                            HPasivo.RetencionISRRenta = reten.Importe.ToString();
              //                        }
              //                        if (reten.Etiqueta.Equals("IVA") == true)
              //                        {
              //                            HPasivo.RetencionIVARenta = reten.Importe.ToString();
              //                        }
              //                    }
              //                }
              //            HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
              //        }
              //        #endregion Es Renta
              //        #region Es Flete
              //        if (tipoFactura.Equals("Flete") == true)
              //        {
              //            HPasivo.ImporteRetencionFlete = _importeIVARenta;
              //            HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
              //        }
              //        #endregion Es Flete
              //        #region Es Honorario
              //        if (tipoFactura.Equals("Honorarios") == true)
              //        {
              //            HPasivo.RetencionISRRenta = _importeISRRenta;
              //            HPasivo.SubTotalXml = OrdenCompra[0].SubTotalXML;
              //        }
              //        #endregion Es Honorario
              //        #region Es Moral
              //        if (tipoFactura.Equals("Moral") == true)
              //        {
              //            HPasivo.Importe = Convert.ToString(Convert.ToDecimal(HPasivo.Importe) - Convert.ToDecimal(_importeTotalTrasladados));
              //        }
              //        #endregion Es Moral
              //    }
              //    #endregion Analizando Impuestos  Escenarios Fletes-Rentas
              //}
              //NoItem = OrdenCompra[0].NoRecepcion;
              //NoOrdenCompra = OrdenCompra[0].OrdenCompra;
              //RFC_del_Emisor = OrdenCompra[0].RFC;
              //RFC_del_Receptor = OrdenCompra[0].RFC_Receptor;
              //Serie = OrdenCompra[0].Serie;
              //NoItem = "";
              //#endregion Datos de  Encabezado
          }

          #region Testing
          public List<string> test(List<string> entrada)
          {
              List<string> salida = new List<string>();
              salida = entrada;
              return salida;
          }

          public List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> testdesdeBD(List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> entrada)
          {
              List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> salida = new List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto>();
              salida = entrada;
              return salida;
          }

          public List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> testdesdeBDCombinado(List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> _objLeidoFactura, List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> _comprobanteconcepto)
          {
              List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> olf = new List<T_objLeidoFactura>();
              List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> cc = new List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto>();

              ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto _cc = new T_ComprobanteConcepto();
              _cc = _comprobanteconcepto[0];
              string original = "<";
              string finalcadena = ">";
              string separador = "|";
              foreach (var reg in _comprobanteconcepto)
              {

                  original = original + reg + separador;
              }
              original = original + finalcadena;
              _objLeidoFactura[0].Conceptos = original;
              olf = _objLeidoFactura;
              return olf;

          }

          public _ComprobanteConcepto testComprobante(_ComprobanteConcepto comprobanteconcepto)
          {
              _ComprobanteConcepto salida = new _ComprobanteConcepto();
              salida = comprobanteconcepto;
              return salida;
          }

          #endregion Testing

          [DataContract]
          public class _ComprobanteConcepto
          {
              public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos   //.paraVerificacionFactura.ComprobanteConceptos[] Conceptos
              {
                  get;
                  set;
              }

          }

          #endregion     Carga y lectura de Facturas XML

        #endregion Implementación y operaciones con las Facturas XML

        #region     AdministracionController
        public bool Administracion_cat_Proveedores_registroProveedorBasico(string numproveedor,ClickFactura_Entidades.BD.Entidades.Cat_Proveedor nuevoProveedor,ref string mensajes)
        {
             bool resultado = false;
             using (var ctx = new Desarrollo_CF())
                          {
                                ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = ctx.Cat_Proveedor.FirstOrDefault(c => c.Num_Proveedor == numproveedor);
                                if (proveedor == null)
                                {
                                    ctx.Cat_Proveedor.Add(nuevoProveedor);
                                    ctx.SaveChanges();
                                    resultado = true;
                                    mensajes = "El registro básico del Proveedor fue exitoso.";
                                }
                                else
                                {
                                    nuevoProveedor = proveedor;
                                    resultado = false;
                                    mensajes = "El proveedor ya existía previamente.";
                                }
                          }
            return resultado;
        }
        public bool Administracion_CargaProveedores(string numProveedor, string fecha, out List<string> mensajes)
        {
            string[] msgs = new string[1];
            mensajes = new List<string>();
            try
            {
                var r = CargaProveedores(numProveedor, fecha, out msgs)!=null?true:false;
                mensajes = msgs.ToList();
                string resultado = mensajes[mensajes.Count()-1];
                return r;
            }
            catch (Exception ex)
            {
                if (msgs.Count() > 1)
                {
                    mensajes = msgs.ToList();
                }
                mensajes.Add(ex.Message);
                return false;
            }
        }

        public bool Administracion_CargaProveedoresdesdeSAP(string numProveedor, out List<string> mensajes,int Tipo)
        {
            string[] msgs = new string[1];
            mensajes = new List<string>();
            bool r = true;
            List<KeyValuePair<string, string>> datos = new List<KeyValuePair<string, string>>();
            string datosSalida=" ";
            string S = "I";
            string OP = "EQ";
            string Vendor_Low = numProveedor;
            string Vendor_High = "";
            try
            {
                switch (Tipo)
                {
                    case 1:
                            #region Funcion Z recupera información del Proveedor desde SAP
                                S = "I";
                                OP = "EQ";
                                Vendor_Low = numProveedor;
                                Vendor_High = "";
                                datos.Clear();
                                datos = BAPIZ_dispara_obtenInformacionProveedoresGral_ZMF_CFS_PROVEEDOR_PP(S, OP, Vendor_Low, Vendor_High,Tipo);
                                r = true;
                                var huboerrores = from err in datos where err.Key.Contains("Error") == true select err;
                                if (huboerrores != null && huboerrores.Count() > 0)
                                {
                                    //datos.Clear();
                                    try
                                    {
                                    foreach(var data in huboerrores)
                                      {
                                          datos.Add(new KeyValuePair<string, string>("Error", "Error :  El no. de proveedor " + Vendor_Low + " especificado no fue localizado , " + data.Value + " , verifique directamente en SAP. "));
                                          datosSalida= datosSalida+" "+data.Value;
                                      }
                                    }
                                    catch(Exception _k)
                                    {

                                    }
                                }
                                if (datosSalida.Length>3)//datos[0].Key.Equals("Error")==true)
                                {
                                    msgs[0] = "E " +datosSalida;// datos[0].Value;
                                    r = false;
                                }
                            #endregion Funcion Z recupera información del Proveedor desde SAP
                    break;
                    case 2:
                                #region Funcion Z recupera información de las retenciones del Proveedor desde SAP
                                                    S = "I";
                                                    OP = "EQ";
                                                    Vendor_Low = numProveedor;
                                                    Vendor_High = "";

                                                    datos = BAPIZ_dispara_obtenInformacionProveedoresGral_ZMF_CFS_PROVEEDOR_PP(S, OP, Vendor_Low, Vendor_High, Tipo);
                                                    r = true;
                                                    var huboerrores2 = from err in datos where err.Key.Equals("Error") == true select err;
                                                    if (huboerrores2 != null && huboerrores2.Count() > 0)
                                                    {
                                                        datos.Clear();
                                                        datos.Add(new KeyValuePair<string, string>("Error", "Error :  No se logro ubicar las Retenciones específicas del no. de proveedor " + Vendor_Low + "  , verifique directamente en SAP si esto es correcto."));
                                                    }
                                                    if (datos[0].Key.Equals("Error") == true)
                                                    {
                                                        msgs[0] = datos[0].Value;
                                                        r = false;
                                                    }
                               #endregion Funcion Z recupera información de las retenciones del Proveedor desde SAP
                    break;
                    case 3:
                              #region Funcion Z recupera todos los Proveedores desde SAP
                                                            S = "I";
                                                            OP = "EQ";
                                                            Vendor_Low = numProveedor;
                                                            Vendor_High = "";

                                                            datos = BAPIZ_dispara_obtenInformacionProveedoresGral_ZMF_CFS_PROVEEDOR_PP(S, OP, Vendor_Low, Vendor_High, Tipo);
                                                            r = true;
                                                            foreach(KeyValuePair<string, string> data in datos)
                                                            {
                                                                mensajes.Add(data.Key + " : " + data.Value);
                                                            }
                                                            //var huboerrores3 = from err in datos where err.Key.Equals("Error") == true select err;
                                                            //if (huboerrores3 != null && huboerrores3.Count() > 0)
                                                            //{
                                                            //    datos.Clear();
                                                            //    datos.Add(new KeyValuePair<string, string>("Error", "Error :  No se logro ubicar las Retenciones específicas del no. de proveedor " + Vendor_Low + "  , verifique directamente en SAP si esto es correcto."));
                                                            //}
                                                            //if (datos[0].Key.Equals("Error") == true)
                                                            //{
                                                            //    msgs[0] = datos[0].Value;
                                                            //    r = false;
                                                            //}
                            #endregion Funcion Z recupera todos los Proveedores desde SAP
                    break;
                }
                string resultado = "";
                if(Tipo!=3)
                {
                mensajes = msgs.ToList();
                resultado = mensajes[mensajes.Count() - 1];
                }
                return r;
            }
            catch (Exception ex)
            {
                if (msgs.Count() > 1)
                {
                    mensajes = msgs.ToList();
                }
                mensajes.Add(ex.Message);
                return false;
            }
        }

       private List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> CargaProveedores(string numProveedor, string fecha, out string[] msgs)
        {
            List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> proveedores = new List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor>();
            List<string> mensajes=new List<string>();
            mensajes.Add("Proceso iniciado "+DateTime.Now.ToLongDateString()+ DateTime.Now.ToLongTimeString());
            using (var ctx = new Desarrollo_CF())
            {
                ClickFactura_Facturacion.Genericos.Genericos generico=new ClickFactura_Facturacion.Genericos.Genericos();
                #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                       var _proveedor = generico.genericos_consultaCualquierTabla(numProveedor.Count() == 0 ? "Select * From Cat_Proveedor " : "Select * From Cat_Proveedor Where Num_Proveedor='"+numProveedor+"'");
                #endregion 
                 if (_proveedor != null)
                {
                    if (_proveedor.Rows.Count > 0)
                    {
                            foreach(DataRow p in _proveedor.AsEnumerable())
                            {
                            try
                            {
                                #region recuperacion y carga de la información
                                ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                                proveedor.IdProveedor= p.Field<int>("IdProveedor");
                                proveedor.Nombre= p.Field<string>("Nombre");
                                proveedor.Num_Sociedad= p.Field<string>("Num_Sociedad");
                                proveedor.Num_Proveedor= p.Field<string>("Num_Proveedor");
                                proveedor.Sociedad= p.Field<string>("Sociedad");
                                proveedor.Pais= p.Field<string>("Pais");
                                proveedor.Direccion= p.Field<string>("Direccion");
                                proveedor.GrupoCA = p.Field<string>("GrupoCA");
                                proveedor.RFC= p.Field<string>("RFC");
                                proveedor.CPD = p.Field<string>("CPD");
                                proveedor.GrupoCCPD= p.Field<string>("GrupoCCPD");
                                proveedor.Correo = p.Field<string>("Correo");
                                proveedor.Activo = p.Field<bool>("Activo");
                                try
                                {
                                  proveedor.P_General = p.Field<decimal>("P_General");
                                }
                                catch
                                {
                                    proveedor.P_General = 0;
                                }
                                try
                                {
                                   proveedor.P_Comercial= p.Field<decimal>("P_Comercial");
                                }
                                catch
                                {
                                    proveedor.P_Comercial = 0;
                                }
                                proveedor.RFC2 = p.Field<string>("RFC2");
                                proveedor.Poblacion = p.Field<string>("Poblacion");
                                proveedores.Add(proveedor);
                                #endregion recuperacion y carga de la información
                            }
                            catch(Exception ex)
                            {
                                string miError = ex.Message;
                            }
                            }
                            mensajes.Add("Se han encontrado "+ proveedores.Count().ToString() + " proveedores actualmente registrados en el Portal.");
                    }
                    else
                    {
                        mensajes.Add("No existen proveedores registrados en el Portal actualmente.");
                    }
                }
                else
                {
                    mensajes.Add("No existen proveedores registrados en el Portal actualmente.");
                 }
            }
           if(proveedores.Count()==0)
           {
               mensajes.Clear();
               mensajes.Add("Proceso iniciado " + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString());
               mensajes.Add("No existen el número de proveedor registrado en SAP Manofactura. Verifíque por favor!");
               proveedores = null;
           }
          msgs = mensajes.ToArray();
          return proveedores;
        }
       public List<ClickFactura_Entidades.BD.Modelos.InformacionSAP> Administracion_ObtenerProveedores(string proveedor, string fecha, out string mensaje)
       {
           try
           {
               mensaje = "";
               var lista = ConsultarProveedoresSAP(proveedor, fecha, out mensaje);
               if (lista == null)
               {
                   return new List<ClickFactura_Entidades.BD.Modelos.InformacionSAP>();
               }
               return lista.ToList();
           }
           catch (Exception ex)
           {
               mensaje = ex.Message;
               return null;
           }
       }
        private List<ClickFactura_Entidades.BD.Modelos.InformacionSAP> ConsultarProveedoresSAP(string proveedor,string  fecha, out string mensaje)
        {
            List<ClickFactura_Entidades.BD.Modelos.InformacionSAP> sapSalida = new List<ClickFactura_Entidades.BD.Modelos.InformacionSAP>();

            #region        Busca la información de los Proveedores
            List<string> mensajes = new List<string>();
            mensajes.Add("Proceso iniciado " + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString());
            string[] msgs = mensajes.ToArray();
            mensaje = msgs[0];
             List<ClickFactura_Entidades.BD.Entidades.Cat_Proveedor> prov=  CargaProveedores(proveedor, fecha, out msgs);
            #endregion Busca la información de los Proveedores

            foreach(var origen in prov)
            {
                ClickFactura_Entidades.BD.Modelos.InformacionSAP destino = new ClickFactura_Entidades.BD.Modelos.InformacionSAP();
                #region Configuraciones
                //Estructura en la vista
                //Num_Proveedor
                //País
                //Nombre
                //Población
                //Dirección
                //Indicador
                //RFC
                //RFC2
                //destino.R1 = origen.IdProveedor.ToString();
                //destino.R2 = origen.Nombre.ToString();
                //destino.R3 = origen.Num_Sociedad.ToString();
                //destino.R4 = origen.Num_Proveedor.ToString();
                //destino.R5 = origen.Sociedad.ToString();
                //destino.R6 = origen.Pais.ToString();
                //destino.R7 = origen.Direccion.ToString();
                //destino.R8 = origen.GrupoCA.ToString();
                //destino.R9 = origen.RFC.ToString();
                //destino.R10 = origen.CPD.ToString();
                //destino.R11 = origen.GrupoCCPD.ToString();
                //destino.R12 = origen.Correo.ToString();
                //destino.R13 = origen.Activo.ToString();
                //destino.R14 = origen.P_General.ToString();
                //destino.R15 = origen.P_Comercial.ToString();
                //destino.R16 = origen.RFC2.ToString();
                //destino.R17 = origen.Poblacion.ToString();
                #endregion Configuraciones
                try
                {
                destino.R1 = origen.Num_Proveedor.ToString();
                destino.R2 = origen.Pais.ToString();
                destino.R3 = origen.Nombre.ToString();
                destino.R4 = origen.Poblacion!=null? origen.Poblacion.ToString():"No registrado en SAP";
                destino.R5 = origen.Direccion.ToString();
                destino.R6 = origen.Activo.Equals(true)==true?"Si":"No";
                destino.R7 = origen.RFC.ToString();
                destino.R8 = origen.RFC2!=null? origen.RFC2.ToString():"No registrado en SAP";
                destino.R9 = origen.IdProveedor.ToString();
                sapSalida.Add(destino);
                }
                catch(Exception ex)
                {
                    string mens = ex.Message;
                }
            }
            return sapSalida;
        }
        public bool Administracion_guardarCompletarRegistroProveedor(string numProveedor,string rfc,string correo,string correoSAP, out string[] msgs)
        {
            bool resultado = false;
            List<string> mensajes = new List<string>();
            mensajes.Add("Proceso iniciado " + DateTime.Now.ToLongDateString() + DateTime.Now.ToLongTimeString());

            using (var ctx = new Desarrollo_CF())
            {
                ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                var _proveedor = generico.genericos_consultaCualquierTabla("Select * From Cat_Proveedor Where IdProveedor='" + numProveedor + "'");
                #endregion
                if (_proveedor != null)
                {
                    if (_proveedor.Rows.Count > 0)
                    {
                        foreach (DataRow p in _proveedor.AsEnumerable())
                        {
                            #region recuperacion y carga de la información
                            int? id = Convert.ToInt32(numProveedor);
                            ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor = ctx.Cat_Proveedor.Single(c => c.IdProveedor == id);// new ClickFactura_Entidades.BD.Entidades.Cat_Proveedor();
                            //proveedor.IdProveedor = p.Field<int>("IdProveedor");
                            proveedor.Nombre = p.Field<string>("Nombre");
                            proveedor.Num_Sociedad = p.Field<string>("Num_Sociedad");
                            proveedor.Num_Proveedor = p.Field<string>("Num_Proveedor");
                            proveedor.Sociedad = p.Field<string>("Sociedad");
                            proveedor.Pais = p.Field<string>("Pais");
                            proveedor.Direccion = p.Field<string>("Direccion");
                            proveedor.GrupoCA = p.Field<string>("GrupoCA");
                            proveedor.RFC = rfc;// p.Field<string>("RFC");
                            proveedor.CPD = p.Field<string>("CPD");
                            proveedor.GrupoCCPD = p.Field<string>("GrupoCCPD");
                            proveedor.Correo = correoSAP;// p.Field<string>("Correo");
                            proveedor.Activo = p.Field<bool>("Activo");
                            proveedor.P_General = p.Field<decimal>("P_General");
                            proveedor.P_Comercial = p.Field<decimal>("P_Comercial");
                            proveedor.RFC2 = p.Field<string>("RFC2");
                            proveedor.Poblacion = p.Field<string>("Poblacion");
                            try
                            {
                                  ctx.SaveChanges();
                                  mensajes.Add("Se ha actualizado la información en el Portal.");
                                  string men = "";
                                  disparaCreaUsuarioPortal(proveedor,correo,ref men);
                                  mensajes.Add(men);
                            }
                            catch(Exception ex)
                            {
                                mensajes.Add("La información no fue actualizada por: "+ex.Message);
                            }
                            #endregion recuperacion y carga de la información
                        }
                    }
                    else
                    {
                        mensajes.Add("No existe este proveedor registrado en el Portal actualmente.");
                    }
                }
                else
                {
                    mensajes.Add("No existe proveedor registrado en el Portal actualmente.");
                }
            }
            msgs = mensajes.ToArray();
            return resultado;
        }

        /// <summary>
        /// Metodo solo para complementar el registro Inicial y crear un perfíl que perimta ya ingresar al Portal
        /// </summary>
        /// <param name="proveedor">Objeto o registro completo del proveedor en la tabla Cat_Proveedor</param>
        /// <param name="correo">Correo proporcionado desde el registro del proveedor al cual se enviarán los correos desde el Portal</param>
        /// <returns></returns>
        private bool disparaCreaUsuarioPortal(ClickFactura_Entidades.BD.Entidades.Cat_Proveedor proveedor,string correo, ref string mensaje)
        {
            bool resultado = false;
            #region        Cheando exista
            ClickFactura_Facturacion.Genericos.Genericos generico = new ClickFactura_Facturacion.Genericos.Genericos();
                        #region         Ejecuta extracción de todos los proveedores de la tabla Cat_Proveedor
                        var _usuario = generico.genericos_consultaCualquierTabla("Select * From Cat_Usuario Where IdProveedor=" + proveedor.IdProveedor.ToString() + " And Usuario='"+ proveedor.RFC.ToString() +"'");
                        #endregion
            #endregion Checando exista

            if(_usuario!=null)
            {
                if(_usuario.Rows.Count==0)
                {
                        using (var ctx = new Desarrollo_CF())
                        {
                            ClickFactura_Entidades.BD.Entidades.Cat_Usuario newUsuario = new Cat_Usuario();
                            newUsuario.Activo = true;
                            newUsuario.Usuario = proveedor.RFC;
                            newUsuario.Password = proveedor.RFC;
                            newUsuario.IdProveedor = proveedor.IdProveedor;
                            newUsuario.Correo = correo;
                            newUsuario.IdPerfil = 3;
                            DateTime? fecha = Convert.ToDateTime(convierteFechaBaseDatos(DateTime.Now.ToLongDateString(), DateTime.Now.ToLongTimeString()));
                            newUsuario.fechaSolicitud = fecha;
                            try
                            {
                                            ctx.Cat_Usuario.Add(newUsuario);
                                            ctx.SaveChanges();
                                            resultado = true;
                                            mensaje = "Inserción del nuevo Usuario para " + proveedor.RFC + " se realizo con éxito";
                             }
                            catch(Exception ex)
                            {
                                string error = ex.Message;
                                resultado = false;
                                mensaje = "Ocurrío un error en la inserción del nuevo Usuario para " + proveedor.RFC + " : "+ error;
                            }
                        }
                }
                else
                {
                    //Actualización
                    using (var ctx = new Desarrollo_CF())
                    {
                        int? id = Convert.ToInt32(proveedor.IdProveedor);
                        ClickFactura_Entidades.BD.Entidades.Cat_Usuario newUsuario = ctx.Cat_Usuario.Single(c => c.IdProveedor == id && c.Usuario == proveedor.RFC);
                        newUsuario.Correo = correo;
                        try
                        {
                            //ctx.Cat_Usuario.Add(newUsuario);
                            ctx.SaveChanges();
                            resultado = true;
                            mensaje = "Actualización del nuevo Usuario para " + proveedor.RFC + " con ID " + id.ToString() + " se realizo con éxito";
                        }
                        catch (Exception ex)
                        {
                            string error = ex.Message;
                            resultado = false;
                            mensaje = "Ocurrío un error en la actualización del nuevo Usuario para " + proveedor.RFC + " : " + error;
                        }
                    }
                }
            }
            else
            {
                //Actualización
                using (var ctx = new Desarrollo_CF())
                {
                    int? id = Convert.ToInt32(proveedor.IdProveedor);
                    ClickFactura_Entidades.BD.Entidades.Cat_Usuario newUsuario = ctx.Cat_Usuario.Single(c => c.IdProveedor == id && c.Usuario == proveedor.RFC);
                    newUsuario.Correo = correo;
                    try
                    {
                        ctx.Cat_Usuario.Add(newUsuario);
                        ctx.SaveChanges();
                        resultado = true;
                        mensaje = "Actualización del nuevo Usuario para " + proveedor.RFC + " con ID " +id.ToString() + " se realizo con éxito";
                    }
                    catch (Exception ex)
                    {
                        string error = ex.Message;
                        resultado = false;
                        mensaje = "Ocurrío un error en la actualización del nuevo Usuario para " + proveedor.RFC + " : " + error;
                    }
                }
            }
            return resultado;
        }

        #endregion AdministracionController

        #region MIGO

         public bool MIGO_creaLineaMIGO(ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon, ref List<KeyValuePair<string, string>> datos,ref string mensajes)
        {
            bool resultado = false;
            datos= dispara_BAPI_GOODSMVT_CREATE(renglon);
            if (datos != null)
            {
                if(datos.Count()>0)
                {
                    var errores = from error in datos where error.Key.Equals("Error") == true select error;
                    if(errores!=null)
                        if(errores.Count()<=0)
                        {
                              resultado = true;
                        }
                        else
                        {
                            foreach(KeyValuePair<string,string> error in datos)
                            {
                                mensajes = mensajes + error.Key + " : " + error.Value;
                            }
                            resultado = false;
                        }
                }
            }
            return resultado;
        }

        public bool MIGO_almacenarenBD_MIGO(List<ClickFactura_Entidades.BD.Modelos.Mercancias_Recepcionadas>  Recepcionados)
        {
            bool insertado = false;
            if(Recepcionados!=null)
            {
                if (Recepcionados.Count() > 0)
                {
                    var dbContext = new Desarrollo_CF();
                    var Contexto = ((System.Data.Entity.Infrastructure.IObjectContextAdapter)dbContext).ObjectContext;
                    csBaseSAPNET cs = new csBaseSAPNET();
                    foreach(ClickFactura_Entidades.BD.Modelos.Mercancias_Recepcionadas recepcion in Recepcionados)
                    {
                        #region Enviar a la tabla de la Base de Datos de SQL Server Detalle_OrdenCompra
                        //ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra doc = new Detalle_OrdenCompra();
                        ////recepcion.Hora_Inicio;
                        //DateTime fecha = DateTime.ParseExact(recepcion.Fecha_Inicio, "yyyy-MM-dd HH:mm:ss,fff", System.Globalization.CultureInfo.InvariantCulture);
                        //doc.Fecha_Contable = convierteFechaBaseDatos(recepcion.Fecha_Inicio,recepcion.Hora_Operacion); 
                        ////recepcion.Transaccion_Confirmada;
                        //doc.Orden_Compra=recepcion.OrdenCompra;
                        //doc.Posicion_OC=recepcion.Posicion_OC;
                        //doc.Cantidad=recepcion.Cantidad.ToString();
                        //doc.Unidad_Medida=recepcion.Unidad_Medida;
                        ////recepcion.Num_Proveedor;
                        ////recepcion.Usuario;
                        //doc.Almacen=recepcion.Almacen;
                        //doc.Planta=recepcion.Planta;
                        //doc.Orden_Compra=recepcion.Tipo_OrdenCompra;
                        //doc.Doc_Ref=recepcion.Numero_Recepcion;
                        //doc.Pos_Doc_Ref = recepcion.Posicion_OC;
                        //doc.Ejercicio=recepcion.Año_Recepcion;
                        #endregion Enviar a la tabla de la Base de Datos de SQL Server Detalle_OrdenCompra
                        try
                        {
                                string s = recepcion.Fecha_Inicio;
                                DateTime dt = DateTime.ParseExact(s, "dd/MM/yyyy", System.Globalization.CultureInfo.InvariantCulture);
                                #region Ingresando OrdenesCompra ENCABEZADO
                                    OrdenesCompra oc = new OrdenesCompra();
                                    string _Num_Proveedor_Hardcodeado = "006004";
                                    DataTable idprovee = genericos_consultaCualquierTabla("Select IdProveedor from Cat_Proveedor Where Num_Proveedor='" + _Num_Proveedor_Hardcodeado+"'");
                                    int _idprovee = idprovee == null ? Convert.ToInt32(1) : Convert.ToInt32(idprovee.Rows[0].ItemArray[0].ToString());
                                    oc.IdProveedor =(int?)_idprovee;//Buscar el IdProveedor con el Num_proveedor
                                    oc.Num_Proveedor=recepcion.Num_Proveedor;
                                    oc.OrdCompra = recepcion.OrdenCompra;
                                    oc.Fecha_Registro = cs.convierteFormatoSAP(dt, "BAPI_INCOMINGINVOICE_CREATE");
                                    oc.Num_Sociedad = "006004";// Hay que recuperar este Dato
                                    List<OrdenesCompra> objoc = new List<OrdenesCompra>();
                                    adT_Parametros adp = new adT_Parametros();
                                    int result=0;
                                    objoc = adp.mABCOrdenesCompra(out result,  oc.IdOrden, Convert.ToInt16(oc.IdProveedor), oc.OrdCompra, oc.Tipo_Doc,oc.Clase_Doc, oc.Fecha_Registro, oc.Num_Proveedor, oc.Num_Sociedad, oc.Moneda, oc.TipoCambio, oc.Items, oc.Importe, oc.Borrado, oc.Condicion_Pago, oc.Organizacion_Compra, oc.Condicion_Documento, oc.Grupo_Compras, oc.Numero_Documento, "Agrega");
                                    {
                                        try
                                        {
                                        string alcanzado = objoc[0].IdOrden.ToString();
                                        }
                                        catch
                                        {

                                        }
                                    }
                                    #endregion Ingresando OrdenesCompra ENCABEZADO


                                #region     Ingresando Detalle_OrdenCompra  DETALLES ORDEN COMPRA
                                    Detalle_OrdenCompra doc = new Detalle_OrdenCompra();
                                    doc.Fecha_Contable = cs.convierteFormatoSAP(dt, "BAPI_INCOMINGINVOICE_CREATE"); 
                                    doc.Orden_Compra=recepcion.OrdenCompra;
                                    doc.Posicion_OC=recepcion.Posicion_OC;
                                    doc.Cantidad=recepcion.Cantidad.ToString();
                                    doc.Unidad_Medida=recepcion.Unidad_Medida;
                                    doc.Almacen=recepcion.Almacen;
                                    doc.Planta=recepcion.Planta;
                                    doc.Orden_Compra=recepcion.OrdenCompra;
                                    doc.Doc_Ref=recepcion.Numero_Recepcion;
                                    doc.Pos_Doc_Ref = Convert.ToInt16(recepcion.Posicion_OC).ToString();
                                    doc.Ejercicio=recepcion.Año_Recepcion;
                                    doc.Descripcion = recepcion.Descripcion;
                                    doc.Importe = recepcion.Importe;
                                    doc.Numero_Material = recepcion.Numero_Material;
                                    doc.Indicador_IVA = recepcion.Indicador_IVA;
                                    doc.Item = "BAPI_MIGO";
                                                            doc.Tipo_Mov = "E";
                                                            doc.Clase_Mov = "101";
                                    List<Detalle_OrdenCompra> objdoc = new List<Detalle_OrdenCompra>();
                                    result = 0;
                                    var existeDetalleOrdenCompra = from edoc in dbContext.Detalle_Recepciones where edoc.Orden_Compra.Equals(recepcion.OrdenCompra) == true && edoc.Posicion_OrdenCompra.Equals(recepcion.Posicion_OC) == true select edoc;
                                    if(existeDetalleOrdenCompra!=null)
                                        if(existeDetalleOrdenCompra.Count()==0)
                                        {
                                            try
                                            {
                                                objdoc = adp.mABCDetalle_OrdenCompra(out result, doc.IDDetalleOrden, doc.Orden_Compra, doc.Item, doc.Descripcion,doc.Codigo_Producto, doc.Doc_Mov, doc.Pos_Doc_Mov, doc.Tipo_Mov, doc.Clase_Mov,doc.Fecha_Contable,doc.Cantidad,doc.Importe,doc.Moneda,doc.Indicador_HD,doc.Ejercicio,doc.Doc_Ref,doc.Pos_Doc_Ref,doc.Posicion_OC,doc.Numero_Material, doc.Planta, doc.Almacen, doc.Unidad_Medida, doc.Indicador_IVA,"Agrega");
                                                {
                                                    string alcanzado = objdoc[0].IDDetalleOrden.ToString();
                                                }
                                            }
                                            catch(Exception _ex)
                                            {
                                                string error = _ex.Message;
                                            }
                                        }

                                #endregion Ingresando Detalle_OrdenCompra DETALLES ORDEN COMPRA

                                    #region     Ingresando Detalle_Recepciones  DETALLES RECEPCIONES
                                    Detalle_Recepciones dr = new Detalle_Recepciones();
                                    try
                                    {
                                            dr.Fecha_Contable = cs.convierteFormatoSAP(dt, "BAPI_INCOMINGINVOICE_CREATE");
                                            dr.Orden_Compra = recepcion.OrdenCompra;
                                            dr.Posicion_OrdenCompra = recepcion.Posicion_OC;
                                            dr.Cantidad = recepcion.Cantidad.ToString();
                                            dr.Numero_Documento = recepcion.Numero_Recepcion;
                                            dr.Posicion_Documento = Convert.ToInt16(recepcion.Posicion_OC).ToString();
                                            dr.YearDocumento = recepcion.Año_Recepcion;
                                            dr.Documento_Referencia = recepcion.Numero_Recepcion;
                                            dr.Posicion_DocumentoRef = Convert.ToInt16(recepcion.Posicion_OC).ToString();
                                            dr.YearDocumentoRef = recepcion.Año_Recepcion;
                                            dr.Moneda= recepcion.Moneda;
                                            dr.Clase_Operacion = "1";
                                            dr.Tipo_Movimiento = "E";
                                            dr.IndicadorHD = "BAPI_MIGO";
                                            dr.Clave_Movimiento = "101";
                                            List<Detalle_Recepciones> objdr = new List<Detalle_Recepciones>();
                                            result = 0;
                                            //objdoc = adp.mABCDetalle_OrdenCompra(out result, doc.IDDetalleOrden, doc.Orden_Compra, doc.Item, doc.Descripcion, doc.Codigo_Producto, doc.Doc_Mov, doc.Pos_Doc_Mov, doc.Tipo_Mov, doc.Clase_Mov, doc.Fecha_Contable, doc.Cantidad, doc.Importe, doc.Moneda, doc.Indicador_HD, doc.Ejercicio, doc.Doc_Ref, doc.Pos_Doc_Ref, doc.Posicion_OC, doc.Numero_Material, doc.Planta, doc.Almacen, doc.Unidad_Medida, doc.Indicador_IVA, "Agrega");
                                            //{
                                            //    string alcanzado = objdoc[0].IDDetalleOrden.ToString();
                                            //}
                                    }
                                    catch(Exception _exe)
                                    {
                                        string mm = _exe.Message;
                                    }
                                    #endregion Ingresando Detalle_Recepciones  DETALLES RECEPCIONES

                        }
                        catch(Exception ex)
                        {
                            string error = ex.Message;
                        }
                    }
                }
                else
                    insertado = false;
            }


            return insertado;
        }

        #endregion MIGO

        #region MIGOMIRO

       public bool MIGO_Administra_WorkFlow(string oc, ref string observaciones, List<string> parametros)
        {
            bool aprobacion = false;
           Int64 _oc=Convert.ToInt64(oc);
           short? idwf=(short?)(Convert.ToInt16(parametros[0]));           
           short? idusuariowf=(short?)(Convert.ToInt16(parametros[1]));  
           short? idestadowf=(short?)(Convert.ToInt16(parametros[2]));
           bool aprobado=Convert.ToBoolean(parametros[3]);
           string ordencompra=parametros[4];
           string recepcion=parametros[5];
           long? idfacturaservicios = (long?)Convert.ToInt64(parametros[6]);

           System.Data.Entity.Core.Objects.ObjectParameter estatus = new System.Data.Entity.Core.Objects.ObjectParameter("estatus", typeof(Boolean));
           System.Data.Entity.Core.Objects.ObjectParameter _observaciones = new System.Data.Entity.Core.Objects.ObjectParameter("observaciones", typeof(string));

           if(_oc>0)
           {
                  using(var ctx = new Desarrollo_CF())
                  {
                      var courseList = ctx.SP_BitacoraWF(idwf,idusuariowf,idestadowf,aprobado,ordencompra,recepcion,estatus,_observaciones,idfacturaservicios,"Registrar");//  .GetCoursesByStudentId(1).ToList<Course>();
                      aprobacion = (bool)estatus.Value;
                  }
           }
            return aprobacion;
        }

        public List<ClickFactura_Entidades.BD.Entidades.T_FacturasServicios> MIGOMIRO_recuperaXMLServicios(ref List<ClickFactura_Entidades.BD.Modelos.CestaMigoMiro> cestaMIGOMIRO, string oc, string NumProveedor,string servicio)
        {
            List<ClickFactura_Entidades.BD.Entidades.T_FacturasServicios> lista_tfacturasservicios = new List<ClickFactura_Entidades.BD.Entidades.T_FacturasServicios>();
           #region Extrae informacion del XML
            List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listado = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura>();
            bool resultadodeesteXML=false;
            string RFCEmisor = "";
            string RFCReceptor = "";
            string _UUID = "";
            string _FolioFactura = "";
            string[] listaErrores = { };
            System.Data.DataTable tabla = new DataTable();
            #region Recupera el Id del registro del XML registrado
                            string mes = (System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.GetMonthName(DateTime.Now.Month)).ToUpper();
                            string _servicio = servicio;
                            string procesado = "0";
                            ClickFactura_WebServiceCF.AccesoBD.Genericos.cs_SQL csFactura = new ClickFactura_WebServiceCF.AccesoBD.Genericos.cs_SQL();
                            int rv = 0;
                            object[] ListaBuscando = { "idFacturasServicios=0", "ordenCompra=" + oc, "numProveedor=" + NumProveedor, "usuario= " + "cualquiera", "mes= " + mes + "", "nombreArchivo= " + "ninguno" + "", "rutacompleta= " + "ninguna", "_XML= '", "fechaCarga=" + DateTime.Now.ToString() + "", "procesado=" + procesado, "servicio=" + _servicio, "P_Opcion=ExisteXML" };
                            csFactura.ExecutarSPUnValor<ClickFactura_Entidades.BD.Modelos.T_FacturasServicios>(out rv, "SP_T_FacturasServicios", ListaBuscando);
                            if (rv > 0)
                            {
                                System.Web.HttpContext.Current.Session["idFacturasServicios"] = rv.ToString();
                            }
            #endregion Recupera el Id del registro del XML registrado
            string idfacturasservicios = System.Web.HttpContext.Current.Session["idFacturasServicios"] as string;
            #region        Recupera información almacenada del XML y quedan almacenadas las facturas procesadas en la lista lista_tfacturasservicios
            string consulta = "Select ordenCompra,numProveedor,usuario,mes,nombreArchivo,rutaCompleta,_XML,fechaCarga,procesado,servicio From T_FacturasServicios  Where idFacturasServicios=" + idfacturasservicios.ToString();
            tabla.Clear();
            tabla= genericos_consultaCualquierTabla(consulta);
            if(tabla.Rows!=null)
            {
                if(tabla.Rows.Count>0)
                {
                    foreach(DataRow ren in tabla.Rows)
                    {
                        ClickFactura_Entidades.BD.Entidades.T_FacturasServicios tfacturasservicios = new ClickFactura_Entidades.BD.Entidades.T_FacturasServicios();
                        tfacturasservicios.ordenCompra= ren.Field <string> ("ordenCompra").ToString();
                        tfacturasservicios.numProveedor = ren.Field<string>("numProveedor").ToString();
                        tfacturasservicios.usuario = ren.Field<string>("usuario").ToString();
                        tfacturasservicios.mes = ren.Field<string>("mes").ToString();
                        tfacturasservicios.nombreArchivo= ren.Field<string>("nombreArchivo").ToString();
                        tfacturasservicios.rutaCompleta = ren.Field<string>("rutaCompleta").ToString();
                        tfacturasservicios.C_XML= ren.Field<string>("_XML").ToString();
                        tfacturasservicios.fechaCarga = ren.Field<string>("fechaCarga").ToString();
                        tfacturasservicios.procesado = ren.Field<bool>("procesado");
                        tfacturasservicios.servicio = ren.Field<string>("servicio").ToString();
                        lista_tfacturasservicios.Add(tfacturasservicios);
                    }
                }
            }
            else
            {
                //No encontro registro en T_ServiciosFacturas
            }
            bool valido = false;
            if (lista_tfacturasservicios.Count>0)
            {
                foreach( ClickFactura_Entidades.BD.Entidades.T_FacturasServicios tfs in lista_tfacturasservicios)
                {
                    #region Procesando el registro de la Factura de Servicios almacenada

                         valido = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura().Lectura_FacturaExpress33(tfs.nombreArchivo, ref listado, tfs.rutaCompleta, ref resultadodeesteXML, ref RFCEmisor, ref RFCReceptor, ref _UUID, ref _FolioFactura, ref listaErrores);
                          foreach(var cesta in cestaMIGOMIRO)
                          {
                              if(cesta.OrdenCompra.Equals(oc)==true)
                              {
                                  cesta.XMLAdjuntoValido = valido;
                              }
                          }
                    #endregion Procesando el registro de la Factura de Servicios almacenada
                }
            }
            #endregion Recupera información almacenada del XML y quedan almacenadas las facturas procesadas en la lista lista_tfacturasservicios
           #endregion Extrae informacion del XML

           return  lista_tfacturasservicios;
        }

        public KeyValuePair<string,DataTable> MIGOMIRO_recuperaRecepcionesServicios(string oc)
        {
            //List<KeyValuePair<string, DataTable>> estructurasRecepcion = new List<KeyValuePair<string, DataTable>>();
            #region       Declarando los Tablas que recibiran la información de SAP
            DataSet tablas = new DataSet();
            DataTable IncrementablesfromSAP = new DataTable();
            IncrementablesfromSAP.TableName = "Incrementables";
            DataTable RecepcionadosfromSAP = new DataTable();
            RecepcionadosfromSAP.TableName = "Recepciones";
            DataTable TipoD = new DataTable();
            TipoD.TableName = "TipoD";
            int NoRegistrosOrdenCompra = 0;
            int NoregistrosRecepcionados = 0;
            List<KeyValuePair<string, string>> mensajes = new List<KeyValuePair<string, string>>();
            int posicionesFactura = 0;
            System.Data.DataTable tablaDetalleOrdenCompra = new DataTable();
            List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones> ListRecepciones = new List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones>();
            // Se obtiene todos los registros de Historial de recepciones de la Orden de Compra
            ListRecepciones = Carga_Detalle_Recepciones(oc);
            //Se convierten estos registros a una DataTable
            RecepcionadosfromSAP = ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.ToDataTable(ListRecepciones);
            //Se analiza y recuperan todas las líneas disponibles para verificar y se vacian en "RecepcionadosfromSAP"
            #region Se recupera la información actualizada de la Orden de Compra nuevamente
            List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> _tablas = Carga_DetalleOrden(oc, ref mensajes);                            
            tablaDetalleOrdenCompra = ClickFactura_WebServiceCF.Service.Clases.cs_Estaticos.ToDataTable(_tablas);
            NoRegistrosOrdenCompra = tablaDetalleOrdenCompra.Rows.Count;
            #endregion Se recupera la información actualizada de la Orden de Compra nuevamente
            #region Secargan las tablas para iniciar su análisis
            tablas.Tables.Add(new DataTable());
            tablas.Tables.Add(IncrementablesfromSAP);
            tablas.Tables.Add(RecepcionadosfromSAP);
            tablas.Tables.Add(TipoD);
            #endregion Secargan las tablas para iniciar su análisis
            //DataTable listaRecepcionesAnalizadas = 
            VerificarExistenciaOrdenesVivas(tablas, tablaDetalleOrdenCompra, ref IncrementablesfromSAP, ref RecepcionadosfromSAP);
            KeyValuePair<string, DataTable> paraestructuras = new KeyValuePair<string, DataTable>(oc, RecepcionadosfromSAP);
            #endregion Declarando los Tablas que recibiran la información de SAP
            return paraestructuras;
        }

        public DataTable MIGOMIRO_obtenmisRecepciones(string oc ,List<KeyValuePair<string, DataTable>> estructurasRecepciones)
        {
            DataTable tabla=new DataTable();
            foreach(var _tabla in estructurasRecepciones)
            {
                string _oc = _tabla.Key;
                DataTable t = _tabla.Value;
                if(_oc.Equals(oc)==true)
                {
                    tabla = t;
                    break;
                }
            }
            return tabla;
        }
        #endregion MIGOMIRO

        #region Pruebas Bapis
        public void EjecutarBapis()
        {
            Clases.Monitoreo.EstadoDeCuenta.consultarCartera();
        }
        #endregion
    }

    [DataContract]
     public class AddValues
        {
            [DataMember]
            public int Value1 { get; set; }
            [DataMember]
            public int Value2 { get; set; }

            public AddValues()
            {
                Value1 = 0;
                Value2 = 0;
            }
        }

}
