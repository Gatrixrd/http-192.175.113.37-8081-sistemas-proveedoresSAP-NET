﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.Data;

namespace ClickFactura_WebServiceCF.Service
{
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    // 
    //
    //                                                                                                  Web Service Click Factura
    //
    // 1 Mayo de 2017 ver 1.
    // Para Proyecto  Thyssenkrupp Presta México
    // //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    /// <summary>
    /// Contiene todas las implementaciones y operaciones necesarias para el Portal de Proveedores de Click Factura Procurement SAP con .NET
    /// Secciones:
    ///                                                                                             Funcionalidades Configuración del Portal
    /// Que configura entorno del Portal:Menus,Activaciones de usuarios Internos, Carga de los Datos Maestros en cuanto a Proveedores
    ///  hacia el Portal,Correos SAP y Correos Internos, ABC Perfiles,ABC Menus, Menus visibles según Perfil, tablas de configuración interna
    ///   y todo lo que interactura con nuestra Base de Datos SQL Server.
    ///                    
    ///                                                                                             Implementación de los Conectores (ConecSAP)
    ///Absolutamente toda la colección de Conectores que consumirá el Portal a travez de las diferentes interfaces con base en diferentes Transacciones SAP
    ///
    ///                                                                                             Grid de Recepciones (gridRecep)
    /// Todos los  métodos necesarios para cargar en cualquier Vista el listado de registros obtenidos directo de las Recepciones SAP procesadas y lsiats para ser
    /// seleccionadas por el Proveedor. Comienza desde recibir el o. de Orden de Compra y va avanzando hasta recibir, analizar y calcular cuantas y cuales son 
    /// líneas "vivas" para ser facturadas.
    /// 
    ///                                                                                             Implementacion y operaciones con Facturas XML (factXML)
    ///  Métodos y funciones que obtienen, evaluán y extraen todo lo necesario de las facturas XML para el proceso de verificación.
    ///  Listado de métodos:
    ///  
    ///            DescomprimirPaquete: En caso de recibir un archivo ZIP un paquete de XML, aqui se descomprimen y preparan para su uso.
    ///     
    /// 
    /// </summary>

    [ServiceContract]
    public interface IService1
    {
        #region     Ejemplos
        [OperationContract]
        [WebInvoke(Method = "GET", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "DoWork")]
        String DoWork();

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "DoSquare")]
        int DoSquare(int value);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "DoAddValues")]
        int DoAddValues(AddValues addValues);
        #endregion Ejemplos

        #region        Genericos

        /// <summary>
        /// Metodo que consulta por medio de una sentencia SQL cualquier valor de la Base de Datos
        /// </summary>
        /// <param name="consulta">Query personalidado a ser enviado a la Base de Datos</param>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "genericos_consultaCualquierTabla")]
        DataTable genericos_consultaCualquierTabla(string consulta);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "formateaFechasSQL")]
        void formateaFechasSQL(ref string inicial, ref string final, ref string mensaje, string num_proveedor, string quienEntro);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "formatearfechaparaSAP")]
        string formatearfechaparaSAP(string fechaoriginal);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "primerDiaMes")]
        DateTime primerDiaMes();

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "primerDiaMes")]
        DateTime primerDiaMes(DateTime Fecha);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "ultimoDiaMes")]
        DateTime ultimoDiaMes();

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "ultimoDiaMes")]
        DateTime ultimoDiaMes(DateTime Fecha);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "EscribeLOG")]
        void EscribeLOG(List<string> errores, string origenes,string oc,string proceso);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "formatearCantidadesImportes")]
        string formatearCantidadesImportes(string posibleNumero);

        #endregion Genericos

        #region       Funcionalidades Configuración del Portal
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "ABCUsuario")]
        List<KeyValuePair<string, string>> ABCUsuario(ClickFactura_Entidades.BD.Entidades.Cat_Usuario usuario, ref List<KeyValuePair<string, string>> datos);

        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "misUsuarios")]
        List<KeyValuePair<string, string>> misUsuarios(string idproveedor);


        #endregion Funcionalidades Configuración del Portal

        #region        Implementacion de los Conectores

        /// <summary>
        /// disparaCargarAlmacenado
        /// Recupera la información almacenada en la BD acerca de los parametros necesarios para establecer 
        /// una conexión con el Servidor SAP
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "parametrosAlmacenados")]
        List<KeyValuePair<string, string>> parametrosAlmacenados();

        //[OperationContract]
        //[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "disparaCargarAlmacenado")]
        //List<KeyValuePair<string, string>> disparaCargarAlmacenado();

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "disparaCargarProveedorPrincipal")]
        List<KeyValuePair<string, string>> disparaCargarProveedorPrincipal(string companyid);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "conectores_obtenBAPI_PO_GETDETAIL")]
        System.Data.DataSet conectores_obtenBAPI_PO_GETDETAIL(SAP.Middleware.Connector.RfcDestination conector, string ordencompra, ref List<KeyValuePair<string, string>> datos, string estructura_SAP);


        #endregion Implementacion de los Conectores

        #region Implementación y operaciones de Recepciones

        #region Grid de Recepciones (Vista)
        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "TablaDetalle")]
        string TablaDetalle(DataSet DsTabla);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "ListadoOrdenesRecepciones")]
        ClickFactura_Entidades.BD.Modelos.TablaGeneralModel ListadoOrdenesRecepciones(ref string orden, string numProveedor, string tipoUsuario, string sociedadVerificar, out string tablaDetalle, out string mensaje, bool soloOrden = false, bool esAdmin = false);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "Carga_DetalleOrden")]
        List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> Carga_DetalleOrden(string OrdenCompra,ref List<KeyValuePair<string, string>> mensajes);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "Carga_Detalle_Recepciones")]
        List<ClickFactura_Entidades.BD.Entidades.Detalle_Recepciones> Carga_Detalle_Recepciones(string OrdenCompra);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "VerificarExistenciaOrdenesVivas")]
        DataTable VerificarExistenciaOrdenesVivas(DataSet tablas, DataTable tabla, ref DataTable Incrementables, ref DataTable Recepcionados);

        [OperationContract]
        [WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "RecepcionesSeleccionadas")]
        ClickFactura_Entidades.BD.Modelos.TablaGeneralModel viewRecepciones_RecepcionesSeleccionadas(string ordenCompra, ref List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> facturas, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> objFacturasAPasivos, out List<string> mensajes);

      #endregion Grid de Recepciones (Vista)

        #endregion Implementación y operaciones de Recepciones

        #region       Implementacion y operaciones con Facturas XML
        [OperationContract]
        string ObtenerNumProveedor(string orden);

        [OperationContract]
        List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_DescomprimirPaquete(string oc, string ruta, string nombre, List<string> datos, out List<List<string>> lsMensajes);

        [OperationContract]
        List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_ValidarFactura(string oc, string rutaArchivo, string nombre, List<string> datos, out string rfcfactura, out List<string> mensajes);

        [OperationContract]
        List<ClickFactura_Facturacion.Clases.paraVerificacionFactura.objNotaCredito32> factXML_ValidarNotaCredito(string ruta, string nombre, out List<string> mensajes);

        [OperationContract]
        List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> factXML_FusionarFacturas(List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> lista1, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> lista2);
        //List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> factXML_FusionarFacturas(List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> lista1, List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> lista2);

        [OperationContract]
        string factXML_VistaCompararImportes(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> FacturasLeidas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> NotasC, List<ClickFactura_Entidades.BD.Modelos.Registros> session_TablaRecepcionesAPasivo);

        [OperationContract]
        List<KeyValuePair<string, string>> factXML_CompararImportes(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> facturas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> listadoNC, out string mensajeEx, bool esOrden = true);

       [OperationContract]
        bool factXML_GenerarPasivo(List<ClickFactura_Entidades.BD.Modelos.Registros> registros, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.obj_facturaAPasivo> facturas, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objNotaCredito> listadoNC, out List<KeyValuePair<string, string>> resultados, bool esExterno, int idUsuario, out string NumeroPasivoGenerado, bool esOrden = true);

       [OperationContract]
       void factXML_IdentificaImpuestos(ref ClickFactura_Entidades.BD.Modelos.objAnalizarImpuestos objImpuestos);

        #region      Testing
        [OperationContract]
        List<string> test(List<string> entrada);

        [OperationContract]
        ClickFactura_WebServiceCF.Service.Service1._ComprobanteConcepto testComprobante(ClickFactura_WebServiceCF.Service.Service1._ComprobanteConcepto _comprobanteconcepto);

        [OperationContract]
        List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> testdesdeBD(List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> entrada);

        [OperationContract]
        List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> testdesdeBDCombinado(List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> _objLeidoFactura, List<ClickFactura_Entidades.BD.Entidades.T_ComprobanteConcepto> _comprobanteconcepto);
        #endregion Testing

        #endregion Implementación y operaciones con Facturas XML

        #region              AdministracionController

       [OperationContract]
        bool Administracion_cat_Proveedores_registroProveedorBasico(string numproveedor,ClickFactura_Entidades.BD.Entidades.Cat_Proveedor nuevoProveedor,ref string mensajes);

       [OperationContract]
       bool Administracion_CargaProveedores(string numProveedor, string fecha, out List<string> mensajes);

        #endregion        AdministracionController

        #region        MIGO
       [OperationContract]
       bool MIGO_creaLineaMIGO(ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra renglon, ref List<KeyValuePair<string, string>> datos,ref string mensajes);

       [OperationContract]
       bool MIGO_almacenarenBD_MIGO(List<ClickFactura_Entidades.BD.Modelos.Mercancias_Recepcionadas> Recepcionados);
        #endregion MIGO

       #region       MIGOMIRO

      [OperationContract]
       bool MIGO_Administra_WorkFlow(string oc, ref string observaciones, List<string> parametros);

      [OperationContract]
       List<ClickFactura_Entidades.BD.Entidades.T_FacturasServicios> MIGOMIRO_recuperaXMLServicios(ref List<ClickFactura_Entidades.BD.Modelos.CestaMigoMiro> cestaMIGOMIRO, string oc, string NumProveedor, string servicio);

        [OperationContract]
      KeyValuePair<string, DataTable> MIGOMIRO_recuperaRecepcionesServicios(string oc);

        [OperationContract]
        DataTable MIGOMIRO_obtenmisRecepciones(string oc, List<KeyValuePair<string, DataTable>> estructurasRecepciones);

       #endregion MIGOMIRO

       #region        BAPIS Z

       [OperationContract]
       List<KeyValuePair<string, string>> BAPIZ_dispara_obtenInformacionProveedoresGral_ZMF_CFS_PROVEEDOR_PP(string S, string OP, string Vendor_Low, string Vendor_High,int Tipo);

        #endregion BAPIS Z

        #region Testeo variado
        [OperationContract]
        List<KeyValuePair<string, string>> Hardcore_construyeBAPIMIRO();
        #endregion Testeo variado

        #region Pruebas Bapis
        [OperationContract]
        void EjecutarBapis();
        #endregion

    }
}
