﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClickFactura_WebServiceCF.AccesoBD.Genericos
{
    public class objT_Parametros
    {

        int idParametro;

        public int IdParametro
        {
            get { return idParametro; }
            set { idParametro = value; }
        }
        string descParametro;

        public string DescParametro
        {
            get { return descParametro; }
            set { descParametro = value; }
        }
        string valorParametro;

        public string ValorParametro
        {
            get { return valorParametro; }
            set { valorParametro = value; }
        }
        bool bActivo;

        public bool BActivo
        {
            get { return bActivo; }
            set { bActivo = value; }
        }

        public objT_Parametros()
        {

        }

        public objT_Parametros(int _idParametro, string _descParametro, string _valorParametro, bool _bActivo)
        {
            IdParametro = _idParametro;
            DescParametro = _descParametro;
            ValorParametro = _valorParametro;
            BActivo = _bActivo;
        }

    }
}