﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_WebServiceCF.AccesoBD.Genericos
{
    public class objetoActualizarOrdenCompra
    {
        string orden;

        public string Orden
        {
            get { return orden; }
            set { orden = value; }
        }

        decimal cantidad;

        public decimal Cantidad
        {
            get { return cantidad; }
            set { cantidad = value; }
        }
        decimal importe;

        public decimal Importe
        {
            get { return importe; }
            set { importe = value; }
        }
        string posicion;

        public string Posicion
        {
            get { return posicion; }
            set { posicion = value; }
        }
        public objetoActualizarOrdenCompra()
        {

        }
        public objetoActualizarOrdenCompra(string orden, decimal cantidad, decimal importe, string posicion)
        {
            Orden = orden;
            Cantidad = cantidad;
            Importe = importe;
            Posicion = posicion;
        }
    }
}
