﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ClickFactura_WebServiceCF.AccesoBD.Genericos
{
    public class adT_Parametros
    {
        public List<objT_Parametros> mABCT_Parametros(out int VariableRetorno, int p_idParametro, string p_descParametro, string p_valorParametro, bool p_bActivo, string opcion)
        {
            List<objT_Parametros> Resultado = null;
            VariableRetorno = 0;
            string _error = " va a leer la clase cs_SQL ";
            using (cs_SQL dtx = new cs_SQL())
            {
                _error = " Inicia ejecutar  ExecutarSP desde mABCT_Parametros ";
                Resultado = dtx.ExecutarSP<objT_Parametros>(out VariableRetorno, "[dbo].[SP_T_Parametros]", ref _error,"@P_idParametro=" + p_idParametro, "@P_descParametro=" + p_descParametro, "@P_valorParametro=" + p_valorParametro, "@P_bActivo=" + p_bActivo, "@P_Opcion=" + opcion);
                if (Resultado == null)//Ocurrio un error
                    VariableRetorno = -1;
                else
                    if (Resultado.Count > 0) //Exitoso
                        VariableRetorno = 1;
                    else
                        VariableRetorno = 0;//No obtuvo nada
            }
            return Resultado;
        }

        public List<ClickFactura_Entidades.BD.Entidades.OrdenesCompra> mABCOrdenesCompra(out int VariableRetorno, int p_idOrden, int p_idProveedor, string p_OrdCompra, string p_Tipo_Doc, string p_Clase_Doc, string p_Fecha_Registro, string p_Num_Proveedor, string p_Num_Sociedad, string p_Moneda, string p_TipoCambio, string p_Items, string p_Importe, string p_Borrado, string p_Condicion_Pago, string p_Organizacion_Compra, string p_Condicion_Documento, string p_Grupo_Compras, string p_Numero_Documento, string opcion)
        {
            List<ClickFactura_Entidades.BD.Entidades.OrdenesCompra> Resultado = null;
            VariableRetorno = 0;
            using (cs_SQL dtx = new cs_SQL())
            {
                string _error = "";
                Resultado = dtx.ExecutarSP<ClickFactura_Entidades.BD.Entidades.OrdenesCompra>(out VariableRetorno, "[dbo].[SP_OrdenesCompra]", ref _error,"@IdOrden=" + p_idOrden, "@IdProveedor=" + p_idProveedor, "@OrdCompra=" + p_OrdCompra, "@Tipo_Doc=" + p_Tipo_Doc, "@Clase_Doc=" + p_Clase_Doc, "@Fecha_Registro=" + p_Fecha_Registro, "@Num_Proveedor=" + p_Num_Proveedor, "@Num_Sociedad=" + p_Num_Sociedad, "@Moneda=" + p_Moneda, "@TipoCambio=" + p_TipoCambio, "@Items=" + p_Items, "@Importe=" + p_Importe, "@P_Opcion=" + opcion);
                if (Resultado == null)//Ocurrio un error
                    VariableRetorno = -1;
                else
                    if (Resultado.Count > 0) //Exitoso
                        VariableRetorno = 1;
                    else
                        VariableRetorno = 0;//No obtuvo nada
            }
            return Resultado;
        }

        public List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> mABCDetalle_OrdenCompra(out int VariableRetorno, int p_IDDetalleOrden, string p_Orden_Compra, string p_Item, string p_Descripcion, string p_Codigo_Producto, string p_Doc_Mov, string p_Pos_Doc_Mov, string p_Tipo_Mov, string p_Clase_Mov, string p_Fecha_Contable, string p_Cantidad, string p_Importe, string p_Moneda, string p_Indicador_HD, string p_Ejercicio, string p_Doc_Ref, string p_Pos_Doc_Ref, string p_Posicion_OC, string p_Numero_Material, string p_Planta, string p_Almacen, string p_Unidad_Medida, string p_Indicador_IVA, string opcion)
        {
            List<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra> Resultado = null;
            VariableRetorno = 0;
            using (cs_SQL dtx = new cs_SQL())
            {
                string _error = "";
                Resultado = dtx.ExecutarSP<ClickFactura_Entidades.BD.Entidades.Detalle_OrdenCompra>(out VariableRetorno, "[dbo].[SP_Detalle_OrdenCompra]",ref _error, "@IDDetalleOrden=" + p_IDDetalleOrden, "@Orden_Compra=" + p_Orden_Compra, "@Item=" + p_Item, "@Descripcion=" + p_Descripcion, "@Codigo_Producto=" + p_Codigo_Producto, "@Doc_Mov=" + p_Doc_Mov, "@Pos_Doc_Mov=" + p_Pos_Doc_Mov, "@Tipo_Mov=" + p_Tipo_Mov, "@Clase_Mov=" + p_Clase_Mov, "@Fecha_Contable=" + p_Fecha_Contable, "@Cantidad=" + p_Cantidad, "@Importe=" + p_Importe, "@Moneda=" + p_Moneda, "@Indicador_HD=" + p_Indicador_HD, "@Ejercicio=" + p_Ejercicio, "@Doc_Ref=" + p_Doc_Ref, "@Pos_Doc_Ref=" + p_Pos_Doc_Ref, "@Posicion_OC =" + p_Posicion_OC, "@Numero_Material =" + p_Numero_Material, "@Planta =" + p_Planta, "@Almacen =" + p_Almacen, "@Unidad_Medida =" + p_Unidad_Medida, "@Indicador_IVA =" + p_Indicador_IVA, "@P_Opcion=" + opcion);
                if (Resultado == null)//Ocurrio un error
                    VariableRetorno = -1;
                else
                    if (Resultado.Count > 0) //Exitoso
                        VariableRetorno = 1;
                    else
                        VariableRetorno = 0;//No obtuvo nada
            }
            return Resultado;
        }

    }
}