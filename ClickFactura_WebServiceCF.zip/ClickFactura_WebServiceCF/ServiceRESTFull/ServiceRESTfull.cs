﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Text;

namespace ClickFactura_WebServiceCF.ServiceRESTFull
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de clase "ServiceRESTfull" en el código y en el archivo de configuración a la vez.
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [Serializable]
    public class ServiceRESTfull : IServiceRESTfull
    {
        public void DoWork()
        {
        }

        //public bool LecturaExpress33(String Archivo, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        //{
        //    bool valido = false;
        //    try
        //    {
        //        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura paraBAFARV33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura();
        //        paraBAFARV33.Lectura_FacturaExpress33(Archivo, ref listadoA, Ruta, ref resultadoUltimoEvaluado, ref RFCEmisor, ref  RFCReceptor, ref  _UUID, ref  _FolioFactura);
        //    }
        //    catch (Exception ex)
        //    {
        //        valido = false;
        //    }
        //    return valido;
        //}

        //public bool LecturaExpress(String Archivo, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        //{
        //    bool valido = false;
        //    try
        //    {
        //        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura paraBAFARV33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura();
        //        paraBAFARV33.Lectura_FacturaExpress(Archivo, ref listadoA, Ruta, ref resultadoUltimoEvaluado, ref RFCEmisor, ref  RFCReceptor, ref  _UUID, ref  _FolioFactura);
        //    }
        //    catch (Exception ex)
        //    {
        //        valido = false;
        //    }
        //    return valido;
        //}
    }
}
