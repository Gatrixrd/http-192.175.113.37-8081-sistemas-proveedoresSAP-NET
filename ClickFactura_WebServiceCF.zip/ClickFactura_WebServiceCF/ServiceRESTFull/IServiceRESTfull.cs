﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ClickFactura_WebServiceCF.ServiceRESTFull
{
    // NOTA: puede usar el comando "Rename" del menú "Refactorizar" para cambiar el nombre de interfaz "IServiceRESTfull" en el código y en el archivo de configuración a la vez.
    [ServiceContract]
    public interface IServiceRESTfull
    {
        [OperationContract]
        void DoWork();

        //[OperationContract]
        //[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "DoAddValues")]
        //bool LecturaExpress33(String Archivo, ref List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura);


        //[OperationContract]
        //[WebInvoke(Method = "POST", ResponseFormat = WebMessageFormat.Json, BodyStyle = WebMessageBodyStyle.Bare, UriTemplate = "DoAddValues")]
        //bool LecturaExpress(String Archivo, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura);

    }
}
