﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text;
using ClickFactura_Entidades.BD.Entidades;
using System.Configuration;
using System.Collections.Specialized;

namespace ClickFactura_Facturacion.Genericos
{
    class cs_SQL : IDisposable
    {
        SqlConnection Conn;

        public cs_SQL()
        {
            ///Lee la cadena de conexión que es detectada desde la capa de Entidades en la clase AccesoBD y trae la que este activa: Desarrollo, Qas o Productiva.
            Conn = new SqlConnection(ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion);//"Data Source=67.205.93.25;Initial Catalog=desa_TKPM;User Id=bafarv1;Password=154rfb$g");
        }

        public cs_SQL(string Conexion)
        {
            Conn = new SqlConnection(Conexion);
        }

        public void Dispose()
        {
            GC.SuppressFinalize(this);
        }

        class PropiedadesDeLista
        {
            public int index;
            public string Campo;
            public Type Tipo;
        }

        public T ExecutarSPUnValorXML<T>(out int rv, string NombreStore, string NombreVariableXML, string ContenidoXML, params object[] ListaVariables)
        {
            T Resultado = default(T);

            rv = 0;
            //Si esta abierta la conexion se cierra
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            try
            {
                //Abrir la conexion a la BD
                Conn.Open();
                if (Conn.State != ConnectionState.Open)
                {
                    rv = 0;
                }

                //Asociar la conexion al Comando
                using (SqlCommand Comando = new SqlCommand())
                {
                    Comando.CommandTimeout = 1200;
                    Comando.Connection = Conn;

                    //Expecificar el Store Procedure al Comando
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = NombreStore;

                    //Trabajamos los parámetros
                    if (ListaVariables != null)
                    {
                        foreach (object parValor in ListaVariables)
                        {
                            bool llaveNombre = true;
                            SqlParameter parametro = new SqlParameter();

                            foreach (object item in parValor.ToString().Split(new char[] { '=' }))
                            {
                                if (llaveNombre)
                                {
                                    llaveNombre = false;
                                    parametro.ParameterName = item.ToString();
                                }
                                else
                                {
                                    parametro.Value = item;
                                }
                            }
                            if (!string.IsNullOrEmpty(parametro.ParameterName))
                            {
                                Comando.Parameters.Add(parametro);
                            }
                        }
                    }
                    //Agregar variables Independientes
                    SqlParameter parametroSolo = new SqlParameter();
                    parametroSolo.ParameterName = NombreVariableXML;
                    parametroSolo.Value = ContenidoXML;
                    Comando.Parameters.Add(parametroSolo);

                    //Agregar valor de retorno
                    SqlParameter VariableRetorno = Comando.Parameters.Add("@return_value", SqlDbType.Int);
                    VariableRetorno.Direction = ParameterDirection.ReturnValue;

                    //Realizar la lectura en la BD
                    using (SqlDataReader dr = Comando.ExecuteReader())
                    {
                        //Crear los Ordinales
                        int col = 0;

                        int colCount = dr.FieldCount;
                        object[] values = new object[colCount];
                        while (dr.Read())
                        {
                            dr.GetValues(values);

                            Resultado = (T)values[col];
                        }
                    }

                    if (VariableRetorno.Value != null)
                    {
                        if (VariableRetorno.Value.Equals(0))
                        {
                            rv = 0;
                        }
                        else if (VariableRetorno.Value.Equals(-1))
                        {
                            rv = -1;
                        }
                        else if (!VariableRetorno.Value.Equals(1))
                        {
                            rv = (int)VariableRetorno.Value;
                        }
                        else
                        {
                            rv = 1;
                        }
                    }
                }
            }
            catch
            {
                rv = -1;
            }
            Conn.Close();
            return Resultado;
        }

        /// <summary>
        ///  
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="rv"></param>
        /// <param name="NombreStore"></param>
        /// <param name="ListaVariables"></param>
        /// <returns></returns>
        public T ExecutarSPUnValor<T>(out int rv, string NombreStore, params object[] ListaVariables)
        {
            T Resultado = default(T);

            rv = 0;
            //Si esta abierta la conexion se cierra
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            try
            {
                //Abrir la conexion a la BD
                Conn.Open();
                if (Conn.State != ConnectionState.Open)
                {
                    rv = 0;
                }

                //Asociar la conexion al Comando
                using (SqlCommand Comando = new SqlCommand())
                {
                    Comando.CommandTimeout = 1200;
                    Comando.Connection = Conn;

                    //Expecificar el Store Procedure al Comando
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = NombreStore;

                    //Trabajamos los parámetros
                    if (ListaVariables != null)
                    {
                        foreach (object parValor in ListaVariables)
                        {
                            bool llaveNombre = true;
                            SqlParameter parametro = new SqlParameter();

                            foreach (object item in parValor.ToString().Split(new char[] { '=' }))
                            {
                                if (llaveNombre)
                                {
                                    llaveNombre = false;
                                    parametro.ParameterName = item.ToString();
                                }
                                else
                                {
                                    parametro.Value = item;
                                }
                            }
                            if (!string.IsNullOrEmpty(parametro.ParameterName))
                            {
                                Comando.Parameters.Add(parametro);
                            }
                        }
                    }
                    //Agregar valor de retorno
                    SqlParameter VariableRetorno = Comando.Parameters.Add("@return_value", SqlDbType.Int);
                    VariableRetorno.Direction = ParameterDirection.ReturnValue;

                    //Realizar la lectura en la BD
                    using (SqlDataReader dr = Comando.ExecuteReader())
                    {
                        //Crear los Ordinales
                        int col = 0;

                        int colCount = dr.FieldCount;
                        object[] values = new object[colCount];
                        while (dr.Read())
                        {
                            dr.GetValues(values);

                            Resultado = (T)values[col];
                        }
                    }

                    if (VariableRetorno.Value != null)
                    {
                        if (VariableRetorno.Value.Equals(0))
                        {
                            rv = 0;
                        }
                        else if (VariableRetorno.Value.Equals(-1))
                        {
                            rv = -1;
                        }
                        else if (!VariableRetorno.Value.Equals(1))
                        {
                            rv = (int)VariableRetorno.Value;
                        }
                        else
                        {
                            rv = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                rv = -1;
            }
            Conn.Close();
            return Resultado;
        }

        /// <summary>
        /// Método Genérico para el Acceso a Base de Datos
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="rv">Variable de Retorno</param>
        /// <param name="NombreStore">Nombre del Procedimiento Almacenado</param>
        /// <param name="Tabla">Parámetro de Entrada tipo Tabla</param>
        /// <param name="ListaVariables">Lista de Parámetros de Entradas(NombreParametro=Valor)</param>
        /// <returns>List(T)</returns>
        public List<T> ExecutarSPConParametroTabla<T>(out int rv, string NombreStore, DataTable Tabla, params object[] ListaVariables)
            where T : new()
        {
            List<T> Resultado = new List<T>();
            List<PropiedadesDeLista> listaOrdinal = new List<PropiedadesDeLista>();
            int index = 0;

            rv = 0;
            //Si esta abierta la conexion se cierra
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            try
            {
                //Crear lista Ordinal,es decir tomar el nombre del campo
                T leer = new T();

                PropertyInfo[] propiedades = leer.GetType().GetProperties();
                foreach (PropertyInfo propiedad in propiedades)
                {
                    PropiedadesDeLista propLista = new PropiedadesDeLista();
                    propLista.Campo = propiedad.Name;
                    propLista.index = index++;
                    propLista.Tipo = propiedad.PropertyType;

                    listaOrdinal.Add(propLista);
                }

                //Abrir la conexion a la BD
                Conn.Open();
                if (Conn.State != ConnectionState.Open)
                {
                    rv = 0;
                }

                //Asociar la conexion al Comando
                using (SqlCommand Comando = new SqlCommand())
                {
                    Comando.CommandTimeout = 1200;
                    Comando.Connection = Conn;

                    //Expecificar el Store Procedure al Comando
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = NombreStore;

                    //Trabajamos los parámetros
                    if (ListaVariables != null)
                    {
                        foreach (object parValor in ListaVariables)
                        {
                            bool llaveNombre = true;
                            SqlParameter parametro = new SqlParameter();

                            foreach (object item in parValor.ToString().Split(new char[] { '=' }))
                            {
                                if (llaveNombre)
                                {
                                    llaveNombre = false;
                                    parametro.ParameterName = item.ToString().Trim();
                                }
                                else
                                {
                                    if ("Tabla" == item.ToString().Trim())
                                    {
                                        parametro.Value = Tabla;
                                        parametro.SqlDbType = SqlDbType.Structured;
                                    }
                                    else
                                    {
                                        parametro.Value = item;
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(parametro.ParameterName))
                            {
                                Comando.Parameters.Add(parametro);
                            }
                        }
                    }
                    //Agregar valor de retorno
                    SqlParameter VariableRetorno = Comando.Parameters.Add("@return_value", SqlDbType.Int);
                    VariableRetorno.Direction = ParameterDirection.ReturnValue;

                    //Realizar la lectura en la BD
                    using (SqlDataReader dr = Comando.ExecuteReader())
                    {
                        if (dr.FieldCount > 0)
                        {
                            //Crear los Ordinales
                            foreach (PropiedadesDeLista item in listaOrdinal)
                            {
                                item.index = dr.GetOrdinal("" + item.Campo + "");
                            }

                            int colCount = dr.FieldCount;
                            object[] values = new object[colCount];
                            while (dr.Read())
                            {
                                T row = new T();

                                dr.GetValues(values);


                                PropertyInfo[] detallesClase = row.GetType().GetProperties();
                                foreach (PropiedadesDeLista item in listaOrdinal)
                                {
                                    foreach (PropertyInfo p in detallesClase)
                                    {
                                        if (p.Name.Equals(item.Campo))
                                        {
                                            p.SetValue(row, values[item.index], null);
                                            break;
                                        }
                                    }
                                }
                                Resultado.Add(row);
                            }
                        }
                    }

                    if (VariableRetorno.Value != null)
                    {
                        if (VariableRetorno.Value.Equals(0))
                        {
                            rv = 0;
                        }
                        else if (VariableRetorno.Value.Equals(-1))
                        {
                            rv = -1;
                        }
                        else if (!VariableRetorno.Value.Equals(1))
                        {
                            rv = (int)VariableRetorno.Value;
                        }
                        else
                        {
                            rv = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Resultado = null;
            }
            Conn.Close();
            return Resultado;
        }


        public List<T> ExecutarSP<T>(out int rv, string NombreStore, ref string error, params object[] ListaVariables)
            where T : new()
        {
            List<T> Resultado = new List<T>();
            List<PropiedadesDeLista> listaOrdinal = new List<PropiedadesDeLista>();
            int index = 0;
            string messageError = " Inicia ExecutarSP ";

            rv = 0;
            messageError = messageError = " Va a probar si abre la conexión ";
            //Si esta abierta la conexion se cierra
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            try
            {
                //Crear lista Ordinal,es decir tomar el nombre del campo
                T leer = new T();

                PropertyInfo[] propiedades = leer.GetType().GetProperties();
                foreach (PropertyInfo propiedad in propiedades)
                {
                    PropiedadesDeLista propLista = new PropiedadesDeLista();
                    propLista.Campo = propiedad.Name;
                    propLista.index = index++;
                    propLista.Tipo = propiedad.PropertyType;

                    listaOrdinal.Add(propLista);
                }

                //Abrir la conexion a la BD
                Conn.Open();
                if (Conn.State != ConnectionState.Open)
                {
                    rv = 0;
                }

                //Asociar la conexion al Comando
                using (SqlCommand Comando = new SqlCommand())
                {
                    Comando.CommandTimeout = 1200;
                    Comando.Connection = Conn;

                    //Expecificar el Store Procedure al Comando
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = NombreStore;
                    messageError = messageError = " Va a consultar  " + NombreStore;

                    //Trabajamos los parámetros
                    if (ListaVariables != null)
                    {
                        foreach (object parValor in ListaVariables)
                        {
                            bool llaveNombre = true;
                            SqlParameter parametro = new SqlParameter();

                            foreach (object item in parValor.ToString().Split(new char[] { '=' }))
                            {
                                if (llaveNombre)
                                {
                                    llaveNombre = false;
                                    parametro.ParameterName = item.ToString();
                                }
                                else
                                {
                                    parametro.Value = item;
                                }
                            }
                            if (!string.IsNullOrEmpty(parametro.ParameterName))
                            {
                                Comando.Parameters.Add(parametro);
                            }
                        }
                    }
                    //Agregar valor de retorno
                    SqlParameter VariableRetorno = Comando.Parameters.Add("@return_value", SqlDbType.Int);
                    VariableRetorno.Direction = ParameterDirection.ReturnValue;

                    messageError = messageError = " Va a Realizar la lectura en la BD ";
                    //Realizar la lectura en la BD
                    using (SqlDataReader dr = Comando.ExecuteReader())
                    {
                        if (dr.FieldCount > 0)
                        {
                            //Crear los Ordinales
                            foreach (PropiedadesDeLista item in listaOrdinal)
                            {
                                item.index = dr.GetOrdinal("" + item.Campo + "");
                            }

                            int colCount = dr.FieldCount;
                            object[] values = new object[colCount];
                            while (dr.Read())
                            {
                                T row = new T();

                                dr.GetValues(values);


                                PropertyInfo[] detallesClase = row.GetType().GetProperties();
                                foreach (PropiedadesDeLista item in listaOrdinal)
                                {
                                    foreach (PropertyInfo p in detallesClase)
                                    {
                                        if (p.Name.Equals(item.Campo))
                                        {
                                            p.SetValue(row, values[item.index], null);
                                            break;
                                        }
                                    }
                                }
                                Resultado.Add(row);
                            }
                        }
                    }

                    if (VariableRetorno.Value != null)
                    {
                        if (VariableRetorno.Value.Equals(0))
                        {
                            rv = 0;
                        }
                        else if (VariableRetorno.Value.Equals(-1))
                        {
                            rv = -1;
                        }
                        else if (!VariableRetorno.Value.Equals(1))
                        {
                            rv = (int)VariableRetorno.Value;
                        }
                        else
                        {
                            rv = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                messageError = messageError = " Ocurrio el error en ExecutarSP  " + ex.Message;
                Resultado = null;
            }
            Conn.Close();
            return Resultado;
        }

        public T ExecutarSPUnValorConParametroTabla<T>(out int rv, string NombreStore, string NombreTabla, DataTable Tabla, params object[] ListaVariables)
        {
            T Resultado = default(T);

            rv = 0;
            //Si esta abierta la conexion se cierra
            if (Conn.State == ConnectionState.Open)
            {
                Conn.Close();
            }

            try
            {
                //Abrir la conexion a la BD
                Conn.Open();
                if (Conn.State != ConnectionState.Open)
                {
                    rv = 0;
                }

                //Asociar la conexion al Comando
                using (SqlCommand Comando = new SqlCommand())
                {
                    Comando.CommandTimeout = 1200;
                    Comando.Connection = Conn;

                    //Expecificar el Store Procedure al Comando
                    Comando.CommandType = CommandType.StoredProcedure;
                    Comando.CommandText = NombreStore;

                    //Trabajamos los parámetros
                    if (ListaVariables != null)
                    {
                        foreach (object parValor in ListaVariables)
                        {
                            bool llaveNombre = true;
                            SqlParameter parametro = new SqlParameter();

                            foreach (object item in parValor.ToString().Split(new char[] { '=' }))
                            {
                                if (llaveNombre)
                                {
                                    llaveNombre = false;
                                    parametro.ParameterName = item.ToString().Trim();
                                    parametro.TypeName = NombreTabla;
                                }
                                else
                                {
                                    if ("Tabla" == item.ToString().Trim())
                                    {
                                        parametro.Value = Tabla;
                                        parametro.SqlDbType = SqlDbType.Structured;
                                    }
                                    else
                                    {
                                        parametro.Value = item;
                                    }
                                }
                            }
                            if (!string.IsNullOrEmpty(parametro.ParameterName))
                            {
                                Comando.Parameters.Add(parametro);
                            }
                        }
                    }
                    //Agregar valor de retorno
                    SqlParameter VariableRetorno = Comando.Parameters.Add("@return_value", SqlDbType.Int);
                    VariableRetorno.Direction = ParameterDirection.ReturnValue;

                    //Realizar la lectura en la BD
                    using (SqlDataReader dr = Comando.ExecuteReader())
                    {
                        //Crear los Ordinales
                        int col = 0;

                        int colCount = dr.FieldCount;
                        object[] values = new object[colCount];
                        while (dr.Read())
                        {
                            dr.GetValues(values);

                            Resultado = (T)values[col];
                        }
                    }

                    if (VariableRetorno.Value != null)
                    {
                        if (VariableRetorno.Value.Equals(0))
                        {
                            rv = 0;
                        }
                        else if (VariableRetorno.Value.Equals(-1))
                        {
                            rv = -1;
                        }
                        else if (!VariableRetorno.Value.Equals(1))
                        {
                            rv = (int)VariableRetorno.Value;
                        }
                        else
                        {
                            rv = 1;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                rv = -1;
            }
            Conn.Close();
            return Resultado;
        }
    }
}
