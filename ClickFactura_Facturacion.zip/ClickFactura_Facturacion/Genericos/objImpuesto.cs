﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Genericos
{
    public class objImpuesto
    {
        string tipo;

        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }
        string etiqueta;

        public string Etiqueta
        {
            get { return etiqueta; }
            set { etiqueta = value; }
        }
        decimal importe;

        public decimal Importe
        {
            get { return importe; }
            set { importe = value; }
        }
        public objImpuesto()
        {

        }
        public objImpuesto(string _Tipo, string _Etiqueta, decimal _Importe)
        {
            Tipo = _Tipo;
            Etiqueta = _Etiqueta;
            Importe = _Importe;
        }
    }
}
