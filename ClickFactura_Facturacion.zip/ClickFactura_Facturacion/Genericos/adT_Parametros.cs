﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Genericos
{
    class adT_Parametros
    {
        public List<objT_Parametros> mABCT_Parametros(out int VariableRetorno, int p_idParametro, string p_descParametro, string p_valorParametro, bool p_bActivo, string opcion)
        {
            List<objT_Parametros> Resultado = null;
            VariableRetorno = 0;
            string _error = " va a leer la clase cs_SQL ";
            using (cs_SQL dtx = new cs_SQL())
            {
                _error = " Inicia ejecutar  ExecutarSP desde mABCT_Parametros ";
                Resultado = dtx.ExecutarSP<objT_Parametros>(out VariableRetorno, "[dbo].[SP_T_Parametros]", ref _error, "@P_idParametro=" + p_idParametro, "@P_descParametro=" + p_descParametro, "@P_valorParametro=" + p_valorParametro, "@P_bActivo=" + p_bActivo, "@P_Opcion=" + opcion);
                if (Resultado == null)//Ocurrio un error
                    VariableRetorno = -1;
                else
                    if (Resultado.Count > 0) //Exitoso
                    VariableRetorno = 1;
                else
                    VariableRetorno = 0;//No obtuvo nada
            }
            return Resultado;
        }
    }
}
