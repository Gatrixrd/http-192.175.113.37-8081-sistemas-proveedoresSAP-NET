﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Genericos
{
    public class Genericos
    {
        public DataTable genericos_consultaCualquierTabla(string consulta)
        {
            DataTable dt = new DataTable();
            string constring = ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion; //ConfigurationManager.ConnectionStrings[DataBase].ConnectionString.ToString();
            using (System.Data.SqlClient.SqlConnection con = new System.Data.SqlClient.SqlConnection(constring))
            {
                using (System.Data.SqlClient.SqlCommand cmd = new System.Data.SqlClient.SqlCommand(consulta, con))
                {
                    cmd.CommandType = CommandType.Text;
                    con.Open();
                    System.Data.SqlClient.SqlDataReader dr = cmd.ExecuteReader();
                    if (dr != null)
                    {
                        dt.Load(dr);
                    }
                    con.Close();
                }
            }
            return dt;
        }

        public DataTable executaSP_Generico(Dictionary<string, string> parametros, string P_Opcion, string tabla)
        {
            DataTable salida = null;
            try
            {
                string mensaje = "";
                System.Data.DataTable dtData = new System.Data.DataTable();
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                List<System.Data.SqlClient.SqlParameter> parameters = new List<System.Data.SqlClient.SqlParameter>();
                parameters = preparaQuerys(parametros, P_Opcion);
                dtData = ejecutarSPreturnDataTable(tabla, parameters, ref mensaje);
                if (dtData != null)
                    if (dtData.Rows.Count > 0)
                    {
                        salida = dtData;
                    }
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Problema actualizando " + tabla + " Opcion " + P_Opcion, ex);
            }
            return salida;
        }

        private List<System.Data.SqlClient.SqlParameter> preparaQuerys(Dictionary<string, string> parametros, string P_Opcion)
        {
            List<System.Data.SqlClient.SqlParameter> parameters = new List<System.Data.SqlClient.SqlParameter>();
            System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
            command.Parameters.Clear();
            foreach (KeyValuePair<string, string> param in parametros)
            {
                System.Data.SqlClient.SqlParameter param1 = new System.Data.SqlClient.SqlParameter(param.Key, param.Value);
                command.Parameters.Add(param1);
                parameters.Add(param1);
                command.Parameters.Clear();
            }
            if (P_Opcion != null)
            {
                System.Data.SqlClient.SqlParameter paramP_Opcion = new System.Data.SqlClient.SqlParameter("P_Opcion", P_Opcion);
                command.Parameters.Add(paramP_Opcion);
                parameters.Add(paramP_Opcion);
            }

            return parameters;
        }

        /// <summary>
        /// Metodo que ejecuta la intrucción SQL Genérica
        /// </summary>
        /// <param name="procedureName">Nombre del Store procedure a ejecutar</param>
        /// <param name="parameters">Lista de parametros requeridos por el Store Procedure</param>
        /// <returns></returns>
        public DataTable ejecutarSPreturnDataTable(string procedureName, List<SqlParameter> parameters, ref string mensaje)
        {
            DataTable dtData = new DataTable();
            string connectionString = ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion;
            using (SqlConnection sqlConn = new SqlConnection(connectionString))
                try
                {

                    {
                        using (SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConn))
                        {
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.Parameters.Clear();
                            if (parameters != null)
                            {
                                foreach (SqlParameter p in parameters)
                                {
                                    sqlCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                                }
                            }
                            using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                            {
                                sqlConn.Open();
                                sqlDataAdapter.Fill(dtData);
                                sqlConn.Close();
                                sqlDataAdapter.Dispose();
                                sqlCommand.Dispose();
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    mensaje = ex.Message;
                }
                finally
                {
                    sqlConn.Close();
                }
            return dtData;
        }


    }
}
