﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33
{
    class cs_Validaciones_ClickFactura
    {
            public void registraValidacion(obj_registraValidacion datos)
            {
                Dictionary<string, string> parametros = new Dictionary<string, string>();
                string tabla = "SP_registra_Validaciones_ClickFactura";
                DataTable t = new DataTable();
                parametros.Clear();

                parametros.Add("emisor", datos.emisor.ToString());
                parametros.Add("receptor", datos.receptor.ToString());
                parametros.Add("fechaValidacion", datos.fechaValidacion.ToString().Replace(datos.fechaValidacion.Contains("p. m.") ? "p. m." : "a. m.", ""));
                parametros.Add("fechaDocumento", datos.fechaDocumento.ToString().Replace(datos.fechaDocumento.Contains("p. m.") ? "p. m." : "a. m.", ""));
                parametros.Add("serie", datos.serie.ToString());
                parametros.Add("folio", datos.folio.ToString());
                parametros.Add("estatusSAT", datos.estatusSAT.ToString());
                parametros.Add("estatus", datos.estatus);
                string P_Opcion = "RegistraValidacion";
                DataTable table = new DataTable();
                table = executaSP_Generico(parametros, P_Opcion, tabla);
            }

            public DataTable executaSP_Generico(Dictionary<string, string> parametros, string P_Opcion, string tabla)
            {
                DataTable salida = null;
                try
                {
                    //string tabla = "SP_NotificacionesxUsuarioxProveedor";
                    string mensaje = "";
                    System.Data.DataTable dtData = new System.Data.DataTable();
                    System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                    List<System.Data.SqlClient.SqlParameter> parameters = new List<System.Data.SqlClient.SqlParameter>();
                    parameters = preparaQuerys(parametros, P_Opcion);
                    dtData = ejecutarSPreturnDataTable(tabla, parameters, ref mensaje);
                    if (dtData != null)
                        if (dtData.Rows.Count > 0)
                        {
                            salida = dtData;
                        }
                }
                catch (Exception ex)
                {
                    throw new ApplicationException("Problema actualizando " + tabla + " Opcion " + P_Opcion, ex);
                }
                return salida;
            }

            /// <summary>
            /// Metodo que ejecuta la intrucción SQL Genérica
            /// </summary>
            /// <param name="procedureName">Nombre del Store procedure a ejecutar</param>
            /// <param name="parameters">Lista de parametros requeridos por el Store Procedure</param>
            /// <returns></returns>
            public DataTable ejecutarSPreturnDataTable(string procedureName, List<SqlParameter> parameters, ref string mensaje)
            {
                DataTable dtData = new DataTable();
                string connectionString = ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion;
                using (SqlConnection sqlConn = new SqlConnection(connectionString))
                    try
                    {

                        {
                            using (SqlCommand sqlCommand = new SqlCommand(procedureName, sqlConn))
                            {
                                sqlCommand.CommandType = CommandType.StoredProcedure;
                                sqlCommand.Parameters.Clear();
                                if (parameters != null)
                                {
                                    foreach (SqlParameter p in parameters)
                                    {
                                        sqlCommand.Parameters.AddWithValue(p.ParameterName, p.Value);
                                    }
                                }
                                using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                                {
                                    sqlConn.Open();
                                    sqlDataAdapter.Fill(dtData);
                                    sqlConn.Close();
                                    sqlDataAdapter.Dispose();
                                    sqlCommand.Dispose();
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        mensaje = ex.Message;
                    }
                    finally
                    {
                        sqlConn.Close();
                    }
                return dtData;
            }

            private List<System.Data.SqlClient.SqlParameter> preparaQuerys(Dictionary<string, string> parametros, string P_Opcion)
            {
                List<System.Data.SqlClient.SqlParameter> parameters = new List<System.Data.SqlClient.SqlParameter>();
                System.Data.SqlClient.SqlCommand command = new System.Data.SqlClient.SqlCommand();
                command.Parameters.Clear();
                foreach (KeyValuePair<string, string> param in parametros)
                {
                    System.Data.SqlClient.SqlParameter param1 = new System.Data.SqlClient.SqlParameter(param.Key, param.Value);
                    command.Parameters.Add(param1);
                    parameters.Add(param1);
                    command.Parameters.Clear();
                }
                if (P_Opcion != null)
                {
                    System.Data.SqlClient.SqlParameter paramP_Opcion = new System.Data.SqlClient.SqlParameter("P_Opcion", P_Opcion);
                    command.Parameters.Add(paramP_Opcion);
                    parameters.Add(paramP_Opcion);
                }

                return parameters;
            }

        public class obj_registraValidacion
        {
            public string emisor { get; set; }
            public string receptor { get; set; }
            public string fechaValidacion { get; set; }
            public string fechaDocumento { get; set; }
            public string serie { get; set; }
            public string folio { get; set; }
            public string estatusSAT { get; set; }
            public string estatus { get; set; }
        }
    }
}
