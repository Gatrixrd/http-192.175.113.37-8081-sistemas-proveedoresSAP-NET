﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33
{
    class ad_CatalogosmySQL_ClickFactura
    {
        public Dictionary<string,string> consultaCatalogo(string Tabla,List<string> campos)
        {
            Dictionary<string, string> tabla = new Dictionary<string, string>();
            string _campos = "";
            bool elPrimero = true;
            foreach(string campo in campos)
            {
                if(elPrimero==true)
                {
                    _campos =  campo;
                    elPrimero = false;
                }
                else
                    _campos = _campos+ ", "+ campo;
            }
        string connString = "Server=192.175.113.37:3306;Database=test_clifactu_portal;Uid=clifactu_timbre4;Pwd=NR3k7zuxCUc5pFMs;";
        using (MySqlConnection mcon = new MySqlConnection(connString))
        using (MySqlCommand cmd = mcon.CreateCommand())
        {
            mcon.Open();
            cmd.CommandText = "SELECT "+_campos+" FROM "+Tabla;
            using (MySqlDataReader reader = cmd.ExecuteReader())
            {
                int posicion = 0;
                foreach(string campo in campos)
                {

                        while (reader.Read())
                        {
                            if(reader.GetName(posicion) ==campo)
                            {
                                tabla.Add(campo,reader.GetValue(posicion).ToString());
                            }
                            posicion++;
                        }
                }
            }
        }
        return tabla;
        }



    }
}
