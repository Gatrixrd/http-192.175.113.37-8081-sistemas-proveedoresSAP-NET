﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;
using System.Web.Script.Serialization;
using Newtonsoft.Json;
using System.Net;
using System.IO;
using ClickFactura_Facturacion.wsBafar;
using System.Xml.Linq;

namespace ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33
{
    public class cs_Factura
    {
        Servicio_ClickFacturaClient wsbafar;
        public cs_Factura()
        {
            //wsbafar = new Servicio_ClickFacturaClient();
        }
        public bool Lectura_FacturaExpress(String Archivo, ref List<objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        {
            try
            {
                System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante));
                bool seCargo = false;
                #region Modificaciones
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante();
                //bajaADiscoDuro(ref Ruta,ref seCargo);
                try
                {
                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaOriginal = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaOriginal;
                    Lector.Close();
                    //Lector.Dispose();
                }
                catch
                {
                    bajaADiscoDuro(ref Ruta, ref seCargo);
                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaModificada = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaModificada;
                    Lector.Close();
                   //Lector.Dispose();
                }

                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);

                #endregion Modificaciones

                #region Codigo Original
                //System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                //Comprobante Factura = (Comprobante)Serializer.Deserialize(Lector);
                //System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                //xdoc.Load(Ruta);
                #endregion Codigo Original

                #region extrae la Pieas o Cantidades
                System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                int i = 0;
                Decimal cantidad = 0;
                string concepto;
                Decimal importe = 0;
                Decimal cantidadGlobal = 0;
                Decimal importeGlobal = 0;
                string unidad = "";
                List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
                foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                {
                    ComprobanteConcepto Concepto = new ComprobanteConcepto();
                    try
                    {
                        cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                        cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                    }
                    catch
                    {
                        cantidadGlobal = cantidadGlobal + 0;
                        cantidad = 0;
                    }
                    try
                    {
                        concepto = NodoDetalladoConcepto[i].Attributes["descripcion"].Value;
                    }
                    catch
                    {
                        concepto = "No proporcionado";
                    }
                    try
                    {
                        importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                        importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                    }
                    catch
                    {
                        importeGlobal = importeGlobal + 0;
                        importe = 0;
                    }
                    try
                    {
                        unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
                    }
                    catch
                    {
                        unidad = "No proporcionado";
                    }
                    ComprobanteConcepto c = new ComprobanteConcepto();
                    c.Cantidad = cantidad;
                    c.Descripcion = concepto;
                    c.Importe = importe;
                    c.Unidad = unidad;
                    Conceptos.Add(c);
                    i++;
                }
                string UUID = "";
                foreach (XmlElement nodo in NodoSecundarioComplemento)
                {
                    try
                    {
                        UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                    }
                    catch
                    {
                        UUID = "No proporcionado";
                    }
                }
                _UUID = UUID;
                RFCEmisor = Factura.Emisor.Rfc;
                RFCReceptor = Factura.Receptor.Rfc;

                #region envia Almacenar
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura obj = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura();
                obj.Archivo = Archivo;
                string _serie = Factura.Serie;

                obj.Folio = Factura.Folio;

                if(_serie!=null)
                {
                    if(_serie.Length>0)
                    {
                        obj.Folio = obj.Folio + _serie;
                    }
                }

                _FolioFactura = Factura.Folio;
                obj.Fecha =ClickFactura_Facturacion.Clases.cs_Estaticos.ConfigFecha(Factura.Fecha, "/");
                obj.Timporte = Factura.Total.ToString();
                int canti = Convert.ToInt32(cantidadGlobal);
                obj.Tpiezas = canti.ToString(); ;
                obj.Concepto = "";
                obj.XmlaTexto = xdoc.InnerXml;

                System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
                string myString = myFile.ReadToEnd();
                myFile.Close();
                myFile.Dispose();
                obj.XmlaTexto = myString;


                #region valida el Documento
                wsbafar = new wsBafar.Servicio_ClickFacturaClient();//BAFAR.wsBafar.Servicio_ClickFacturaClient();
                bool xmlValido = false;
                bool xmlDocumento = false;
                System.Data.DataSet ds = new System.Data.DataSet();

                //Core.Seguridad security = new Core.Seguridad();

                //BAFAR.wsBafar.Cadena_XML Objeto_XML = new BAFAR.wsBafar.Cadena_XML();
                //BAFAR.wsBafar.Resultado_XML Resulta = new BAFAR.wsBafar.Resultado_XML();
                wsBafar.Cadena_XML Objeto_XML = new wsBafar.Cadena_XML();
                wsBafar.Resultado_XML Resulta = new wsBafar.Resultado_XML();
                String Code = Base64Encode(xdoc.InnerXml);

                Objeto_XML.Usuario = "demo";
                //Objeto_XML.RFC = "AAA010101AAA";
                Objeto_XML.Password = "DEMO";
                Objeto_XML.Factura_XML = Code;
                //Objeto_XML.Cadena = Code;
                try
                {
                    Resulta = wsbafar.Valida_XML(Objeto_XML);

                    String SAT = Resulta.Resultado_SAT;
                    if (Resulta.Correcta == true)
                    {
                        xmlValido = true;
                        xmlDocumento = true;
                        obj.Error = Resulta.Resultado == null ? "Factura válida." : "Factura válida";
                        _UUID = Resulta.UUID;
                        resultadoUltimoEvaluado = true;
                    }
                    else
                    {
                        if (Resulta.Resultado.Equals("Comentario: El sello del emisor es invalido ;") == true)
                        {
                            xmlValido = true;
                            xmlDocumento = true;
                            resultadoUltimoEvaluado = true;
                            obj.Error = "Se realiza la excepción de aceptar la factura a pesar del error: Comentario: El sello del emisor es invalido.";
                        }
                        else
                        {
                            xmlValido = false;
                            xmlDocumento = false;
                            resultadoUltimoEvaluado = false;
                            obj.Error = Resulta.Resultado;
                        }
                        _UUID = extraeUUID33(Factura);
                    }
                    obj.ImporteTrasladado = "0";// Resulta.Factura.impuestosField.totalImpuestosTrasladadosField.ToString();
                    obj.SubTotal = Factura.SubTotal.ToString();
                }
                catch (Exception ex)
                {
                    xmlValido = false;
                    xmlDocumento = false;
                    obj.Error = "Problema con el servicio : " + ex.Message;
                }

                //xmlValido = Resulta.Resultado;
                //xmlDocumento = cliente.Valida_Documento(xdoc.InnerXml);
                obj.EstructuraValida = xmlDocumento;
                obj.ValidoSAT = xmlValido;
                obj.Conceptos = Conceptos;
                obj.UUID = Resulta.UUID == null ? _UUID : Resulta.UUID;
                obj.RFC = Factura.Emisor.Rfc;
                obj.Moneda = "MXN";// Factura.Moneda;
                obj.Descuento = Factura.Descuento;
                obj.RFC_Receptor = Factura.Receptor.Rfc;
                obj.Serie = Factura.Serie;
                obj.Path = Ruta;
                obj.NombreArchivo = Archivo;
                obj.ImporteRetenido = Factura.Impuestos.TotalImpuestosRetenidos.ToString();
                try
                {
                    obj.ImporteTrasladado = Factura.Impuestos.TotalImpuestosTrasladados.ToString();
                    if (Factura.Impuestos.Traslados != null)
                    {
                        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                        {
                            if (impuestosTrasladados.Importe > 0)
                                obj.ImporteTrasladado = impuestosTrasladados.Importe.ToString();
                        }
                    }
                }
                catch
                {
                    obj.ImporteTrasladado = "0";
                }
                obj.Impuestos33 = Factura.Impuestos;

                #endregion valida el Documento

                adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
                listadoA = ad.agregaobjeLeido(obj, listadoA);
                #endregion envia Almacenar
                #endregion Extraelas piezas o cantidades

                return true;
            }
            catch (Exception ex)
            {
                objLeidoFactura obj = new objLeidoFactura();
                obj.EstructuraValida = false;
                obj.ValidoSAT = false;
                obj.Error = "Problema con la factura: " + ex.Message;
                adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
                listadoA = ad.agregaobjeLeido(obj, listadoA);
                //if (System.IO.File.Exists(Ruta))
                //{
                //    System.IO.File.Delete(Ruta);
                //}
                return false;
            }
        }

   //public bool Lectura_FacturaExpress33(String Archivo, ref List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        public bool Lectura_FacturaExpress33(String Archivo, ref List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura, ref  string[] listaErrores)
        {
            #region vieja
            //try
            //{
            //    //ClickFactura_Facturacion.Comprobante
            //    System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(Comprobante));
            //    //System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.Comprobante));
            //    bool seCargo = false;
            //    #region Modificaciones
            //    Comprobante Factura = new Comprobante();
            //    //bajaADiscoDuro(ref Ruta,ref seCargo);
            //    try
            //    {
            //        System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
            //        Comprobante FacturaOriginal = (Comprobante)Serializer.Deserialize(Lector);
            //        Factura = FacturaOriginal;
            //        Lector.Close();
            //        //Lector.Dispose();
            //    }
            //    catch
            //    {
            //        bajaADiscoDuro(ref Ruta, ref seCargo);
            //        System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
            //        Comprobante FacturaModificada = (Comprobante)Serializer.Deserialize(Lector);
            //        Factura = FacturaModificada;
            //        Lector.Close();
            //        //Lector.Dispose();
            //    }

            //    System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
            //    xdoc.Load(Ruta);

            //    #endregion Modificaciones


            //    #region Codigo Original
            //    //System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
            //    //Comprobante Factura = (Comprobante)Serializer.Deserialize(Lector);
            //    //System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
            //    //xdoc.Load(Ruta);
            //    #endregion Codigo Original

            //    #region extrae la Pieas o Cantidades
            //    System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
            //    System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
            //    System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
            //    XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
            //    int i = 0;
            //    Decimal cantidad = 0;
            //    string concepto;
            //    Decimal importe = 0;
            //    Decimal cantidadGlobal = 0;
            //    Decimal importeGlobal = 0;
            //    string unidad = "";
            //    List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
            //    foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
            //    {
            //        ComprobanteConcepto Concepto = new ComprobanteConcepto();
            //        try
            //        {
            //            cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
            //            cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
            //        }
            //        catch
            //        {
            //            cantidadGlobal = cantidadGlobal + 0;
            //            cantidad = 0;
            //        }
            //        try
            //        {
            //            concepto = NodoDetalladoConcepto[i].Attributes["descripcion"].Value;
            //        }
            //        catch
            //        {
            //            concepto = "No proporcionado";
            //        }
            //        try
            //        {
            //            importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
            //            importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
            //        }
            //        catch
            //        {
            //            importeGlobal = importeGlobal + 0;
            //            importe = 0;
            //        }
            //        try
            //        {
            //            unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
            //        }
            //        catch
            //        {
            //            unidad = "No proporcionado";
            //        }
            //        ComprobanteConcepto c = new ComprobanteConcepto();
            //        c.Cantidad = cantidad;
            //        c.Descripcion = concepto;
            //        c.Importe = importe;
            //        c.Unidad = unidad;
            //        Conceptos.Add(c);
            //        i++;
            //    }
            //    string UUID = "";
            //    foreach (XmlElement nodo in NodoSecundarioComplemento)
            //    {
            //        try
            //        {
            //            UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
            //        }
            //        catch
            //        {
            //            UUID = "No proporcionado";
            //        }
            //    }
            //    _UUID = UUID;
            //    RFCEmisor = Factura.Emisor.Rfc ;
            //    RFCReceptor = Factura.Receptor.Rfc;

            //    #region envia Almacenar
            //    //objLeidoFactura obj = new objLeidoFactura();
            //    ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura obj = new ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura();
            //    obj.Archivo = Archivo;
            //    obj.Folio = Factura.Folio;
            //    _FolioFactura = Factura.Folio;
            //    obj.Fecha = ClickFactura_Facturacion.Clases.cs_Estaticos.ConfigFecha(Factura.Fecha, "/");
            //    obj.Timporte = Factura.Total.ToString();
            //    int canti = Convert.ToInt32(cantidadGlobal);
            //    obj.Tpiezas = canti.ToString(); ;
            //    obj.Concepto = "";
            //    obj.XmlaTexto = xdoc.InnerXml;

            //    System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
            //    string myString = myFile.ReadToEnd();
            //    myFile.Close();
            //    myFile.Dispose();
            //    obj.XmlaTexto = myString;


            //    #region valida el Documento
            //    //wsbafar = new wsBafar.Servicio_ClickFacturaClient();
            //    ConexionWebServiceRestFull_33 wsbafar=new ConexionWebServiceRestFull_33();
            //    bool xmlValido = false;
            //    bool xmlDocumento = false;
            //    System.Data.DataSet ds = new System.Data.DataSet();

            //    //wsBafar.Cadena_XML Objeto_XML = new wsBafar.Cadena_XML();
            //    //wsBafar.Resultado_XML Resulta = new wsBafar.Resultado_XML();
            //    //String Code = Base64Encode(xdoc.InnerXml);

            //    //Objeto_XML.Usuario = "demo";
            //    //Objeto_XML.Password = "DEMO";
            //    //Objeto_XML.Factura_XML = Code;

            //    try
            //    {
            //        Dictionary<string,object> datos=new Dictionary<string,object>();
            //        Resultado Resulta=new Resultado();
            //        wsbafar.SendWebService33(datos,Ruta,1 ,ref Resulta);  //wsbafar.Valida_XML(Objeto_XML);

            //            #region Determinar si es válido o no
            //                                //String SAT = Resulta.Resultado_SAT;

            //                                //if (Resulta.Correcta == true)
            //                                //{
            //                                //    xmlValido = true;
            //                                //    xmlDocumento = true;
            //                                //    obj.Error = Resulta.Resultado == null ? "Factura válida." : "Factura válida";
            //                                //    _UUID = Resulta.UUID;
            //                                //    resultadoUltimoEvaluado = true;
            //                                //}
            //                                //else
            //                                //{
            //                                //    if (Resulta.Resultado.Equals("Comentario: El sello del emisor es invalido ;") == true)
            //                                //    {
            //                                //        xmlValido = true;
            //                                //        xmlDocumento = true;
            //                                //        resultadoUltimoEvaluado = true;
            //                                //        obj.Error = "Se realiza la excepción de aceptar la factura a pesar del error: Comentario: El sello del emisor es invalido.";
            //                                //    }
            //                                //    else
            //                                //    {
            //                                //        xmlValido = false;
            //                                //        xmlDocumento = false;
            //                                //        resultadoUltimoEvaluado = false;
            //                                //        obj.Error = Resulta.Resultado;
            //                                //    }
            //                                //    _UUID = extraeUUID(Factura);
            //                                //}


            //            #endregion Determinar si es válido o no



            //        obj.ImporteTrasladado = "0";// Resulta.Factura.impuestosField.totalImpuestosTrasladadosField.ToString();
            //        obj.SubTotal = Factura.SubTotal.ToString();
            //    }
            //    catch (Exception ex)
            //    {
            //        xmlValido = false;
            //        xmlDocumento = false;
            //        obj.Error = "Problema con el servicio : " + ex.Message;
            //    }

            //    //xmlValido = Resulta.Resultado;
            //    //xmlDocumento = cliente.Valida_Documento(xdoc.InnerXml);
            //    obj.EstructuraValida = xmlDocumento.ToString();
            //    obj.ValidoSAT = xmlValido.ToString();
            //    obj.Conceptos = aXMLConceptos(Factura.Conceptos);
            //    //obj.UUID = Resulta.UUID == null ? _UUID : Resulta.UUID;
            //    obj.RFC = Factura.Emisor.Rfc;
            //    obj.Moneda = "MXN";// Factura.Moneda;
            //    obj.Descuento = Factura.Descuento.ToString();
            //    obj.RFC_Receptor = Factura.Receptor.Rfc;
            //    obj.Serie = Factura.Serie;
            //    obj.Path = Ruta;
            //    obj.NombreArchivo = Archivo;
            //    obj.ImporteRetenido = Factura.Impuestos.TotalImpuestosRetenidos.ToString();
            //    try
            //    {
            //        obj.ImporteTrasladado = Factura.Impuestos.TotalImpuestosTrasladados.ToString();
            //        if (Factura.Impuestos.Traslados != null)
            //        {
            //            foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
            //            {
            //                if (impuestosTrasladados.Importe > 0)
            //                    obj.ImporteTrasladado = impuestosTrasladados.Importe.ToString();
            //            }
            //        }
            //    }
            //    catch
            //    {
            //        obj.ImporteTrasladado = "0";
            //    }
            //    obj.Impuestos = "";// Factura.Impuestos;

            //    #endregion valida el Documento

            //    adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
            //    //esta vigente a may 22 hay que modificarlo para TKPM listadoA = ad.agregaobjeLeido(obj, listadoA);
            //    #endregion envia Almacenar
            //    #endregion Extraelas piezas o cantidades

            //    return true;
            //}
            //catch (Exception ex)
            //{
            //    objLeidoFactura obj = new objLeidoFactura();
            //    obj.EstructuraValida = false;
            //    obj.ValidoSAT = false;
            //    obj.Error = "Problema con la factura: " + ex.Message;
            //    adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
            //    //esta vigente a may 22 hay que modificarlo para TKPM  listadoA = ad.agregaobjeLeido(obj, listadoA);
            //    //if (System.IO.File.Exists(Ruta))
            //    //{
            //    //    System.IO.File.Delete(Ruta);
            //    //}
            //    return false;
            //}
            #endregion vieja

            bool xmlValido = false;
            bool xmlDocumento = false;
            string[] _errores = null;
            string version = "3.3";
            Resultado_version33 _Resultado=new Resultado_version33();
                                       // ######################################################################  V E R S I O N    3. 3
            #region        VERSION 3.3
            try
            {
                System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante));
                //System.Xml.Serialization.XmlSerializer Serializer = _Serializer;
                bool seCargo = false;

                #region Recostruyendo el XML cargado
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante();
                try
                {
                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaOriginal = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaOriginal;
                }
                catch
                {
                    //                                                bajaADiscoDuro(ref Ruta, ref seCargo);

                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaModificada = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaModificada;
                }

                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);
                #endregion Recostruyendo el XML cargado

                #region Determinando la versión
                version3_3.Clases33.paraVerificacionFactura33.Seguridad security = new version3_3.Clases33.paraVerificacionFactura33.Seguridad();

                string texto = xdoc.InnerXml;
                texto = System.Text.RegularExpressions.Regex.Replace(texto, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                String Code = security.Base64Encode(texto);
                int largo = Code.Length;
                List<string> subXML = new List<string>();

                if (largo >= 6700)
                {
                    int chunkSize = 6700;
                    int stringLength = Code.Length;
                    for (int ii = 0; ii < stringLength; ii += chunkSize)
                    {
                        if (ii + chunkSize > stringLength) chunkSize = stringLength - ii;
                        subXML.Add(Code.Substring(ii, chunkSize));
                    }
                }

                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura csfactura = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Factura();
                ClickFactura_Facturacion.version3_3.Clases33.webserviceRESTFull3_3 version33 = new ClickFactura_Facturacion.version3_3.Clases33.webserviceRESTFull3_3();
                Resultado_version33 Result;//=new Resultado();
                int operacion = 1;
                try
                {
                    Result = version33.SendWebService33(Ruta, operacion, Code);
                    if(Result.version==null)
                    {
                        Result.estadoSAT = "Vigente";
                        Result.version = "3.2";
                        Result.resultado = true;
                        
                        throw new System.InvalidOperationException("La comunicación con el webservice de validación ha sido interrumpida!, Notifique a Soporte por favor.");
                    }
                    else
                    {
                        #region Comunicacion con el Validador
                                     _Resultado = Result;
                                    version = Result.version;
                                    if (version == "3.2")
                                    {
                                        goto Version32;
                                    }
                                    if (Result.version != "0.0" && Result.version != "3.2")
                                    {
                                        String SAT = Result.estadoSAT;
                                        //Result.resultado = true;
                                        if (Result.resultado == true)
                                        {
                                            xmlValido = true;
                                            xmlDocumento = true;
                                            //obj.Error = Result.tipoError == null ? "Factura válida." : "Factura válida";
                                            _UUID = csfactura.extraeUUID33(Factura);
                                            resultadoUltimoEvaluado = true;
                                            listaErrores = Result.errores;
                                        }
                                        else
                                        {
                                            xmlValido = false;
                                            xmlDocumento = false;
                                            resultadoUltimoEvaluado = false;
                                            //foreach(var s in Result.errores.ToList())
                                            // {
                                            //     obj.Error = obj.Error + s;
                                            // }
                                            _errores=Result.errores;
                                            listaErrores=_errores;
                                            _UUID = csfactura.extraeUUID33(Factura);
                                        }
                                    }
                                    else
                                    {
                                        if (Result.version != "3.2")
                                        {
                                            xmlValido = false;
                                            xmlDocumento = false;
                                            resultadoUltimoEvaluado = false;
                                            //foreach (var s in Result.errores.ToList())
                                            //{
                                            //    obj.Error = " ==> " + obj.Error + s;
                                            //}
                                            _UUID = extraeUUID33(Factura);
                                        }
                                        else
                                        {
                                            goto Version32;
                                        }
                                    }
                    #endregion Comunicacion con el Validador
                    }
                }
                catch (Exception ex)
                {
                    xmlValido = false;
                    xmlDocumento = false;

                    resultadoUltimoEvaluado = false;
                    //obj.Error = "Problema con el servicio : " + ex.Message;
                    if (ex.Message.Contains("There was no endpoint listening at"))
                    {
                        //obj.Error = "El servicio de validación de Facturas de Click Factura esta caido, por favor reporte a saclaracionescxp@bafar.com.mx en BAFAR o a Soporte del Portal BAFAR";
                    }
                    //There was no endpoint listening at http://192.175.113.36:8090/wsValidacion/validaXmlService that could accept the message. This is often caused by an incorrect address or SOAP action. See InnerException, if present, for more details.
                }

                #endregion Determinando la versión

                if(Factura.Emisor==null)
                {
                    return false;
                }

                #region Envio  a la validación RESTful 3.3

                #region        Contabiliza la validacion con el servicio Click Factura
                try
                {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura contabiliza = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura();
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura.obj_registraValidacion porEnviar = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura.obj_registraValidacion();
                    porEnviar.emisor = Factura.Emisor.Rfc;
                    porEnviar.receptor = Factura.Receptor.Rfc;
                    porEnviar.fechaValidacion = DateTime.UtcNow.ToString();
                    porEnviar.fechaDocumento = Factura.Fecha.ToString();
                    porEnviar.serie = Factura.Serie;
                    porEnviar.folio = Factura.Folio;
                    porEnviar.estatusSAT = "Pendiente";// Resulta.Resultado_SAT;
                    porEnviar.estatus = "Pendiente";// Resulta.Correcta.ToString();
                    //contabiliza.registraValidacion(porEnviar);
                }
                catch (Exception ex)
                {

                }
                #endregion Contabiliza la validacion con el servicio Click Factura

                #endregion Envio a la validación RESTful 3.3

                #region Extrayendo las Piezas o Cantidades
                System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                int i = 0;
                Decimal cantidad = 0;
                string concepto;
                Decimal importe = 0;
                Decimal cantidadGlobal = 0;
                Decimal importeGlobal = 0;
                string unidad = "";
                Decimal valorUnitario = 0;
                string claveUnidad = "";
                string claveProdServ = "";
                string noIdentificacion = "";
                List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
                foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                {
                    ComprobanteConcepto Concepto = new ComprobanteConcepto();
                    try
                    {
                        cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Cantidad"].Value), 2);
                        cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Cantidad"].Value), 2);
                    }
                    catch
                    {
                        cantidadGlobal = cantidadGlobal + 0;
                        cantidad = 0;
                    }
                    try
                    {
                        concepto = NodoDetalladoConcepto[i].Attributes["Descripcion"].Value;
                    }
                    catch
                    {
                        concepto = "No proporcionado";
                    }
                    try
                    {
                        importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Importe"].Value), 2);
                        importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Importe"].Value), 2);
                    }
                    catch
                    {
                        importeGlobal = importeGlobal + 0;
                        importe = 0;
                    }
                    try
                    {
                        unidad = NodoDetalladoConcepto[i].Attributes["Unidad"].Value;
                    }
                    catch
                    {
                        unidad = "No proporcionado";
                    }
                    try
                    {
                        valorUnitario = Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["ValorUnitario"].Value);
                    }
                    catch
                    {
                        valorUnitario = 0;
                    }
                    try
                    {
                        claveUnidad = NodoDetalladoConcepto[i].Attributes["ClaveUnidad"].Value;
                    }
                    catch
                    {
                        claveUnidad = "Error";
                    }
                    try
                    {
                        claveProdServ = NodoDetalladoConcepto[i].Attributes["ClaveProdServ"].Value;
                    }
                    catch
                    {
                        claveProdServ = "";
                    }
                    try
                    {
                        noIdentificacion = NodoDetalladoConcepto[i].Attributes["NoIdentificacion"].Value;
                    }
                    catch
                    {
                        noIdentificacion = "";
                    }
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto c = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                    c.Cantidad = cantidad;
                    c.Descripcion = concepto;
                    c.Importe = importe;
                    c.Unidad = unidad;
                    c.ClaveUnidad = claveUnidad;
                    c.ValorUnitario = valorUnitario;
                    c.NoIdentificacion = noIdentificacion;
                    c.ClaveProdServ = claveProdServ;
                    Conceptos.Add(c);
                    i++;
                }
                #endregion Extrayendo las Piezas o Cantidades

                #region Intentando extraer el UUID
                if (_UUID == "")
                {
                    string UUID = "";
                    foreach (XmlElement nodo in NodoSecundarioComplemento)
                    {
                        try
                        {
                            UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                        }
                        catch
                        {
                            UUID = "No proporcionado";
                        }
                    }
                    _UUID = UUID;
                }
                #endregion Intentando extraer el UUID

                #region Extrayendo el IEPS
                string IEPS = "No proporcionado";
                try
                {
                    foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado imp in Factura.Impuestos.Traslados)
                    {
                        decimal importeIEPS = 0;
                        try
                        {
                            if (imp.Impuesto.ToString().Contains("IEPS") == true || imp.Impuesto.ToString().Contains("Ieps") == true || imp.Impuesto.ToString().Contains("ieps") == true)
                            {
                                IEPS = imp.Impuesto.ToString();
                                importeIEPS = imp.Importe;
                                if (importeIEPS <= 0)
                                {
                                    IEPS = "No proporcionado";
                                }
                            }
                        }
                        catch
                        {
                            IEPS = "No proporcionado";
                        }
                    }
                }
                catch
                {
                    IEPS = "No proporcionado";
                }
                #endregion Extrayendo el IEPS

                RFCEmisor = Factura.Emisor.Rfc;
                RFCReceptor = Factura.Receptor.Rfc;

                #region        Construyendo el Objeto Factura de SALIDA

                #region recopilando priemra sección de Información del XML
                objLeidoFactura obj = new objLeidoFactura();
                obj.Archivo = Archivo;
                obj.Folio = Factura.Folio;
                _FolioFactura = Factura.Folio;
                obj.Fecha = Factura.Fecha.ToString();
                obj.Timporte = Factura.Total.ToString();
                int canti = Convert.ToInt32(cantidadGlobal);
                obj.Tpiezas = canti.ToString(); ;
                obj.Concepto = "";
                obj.XmlaTexto = xdoc.InnerXml;
                if (resultadoUltimoEvaluado == false)
                {
                    if(_errores!=null)
                    {
                        foreach(string error in _errores)
                        {
                            obj.Error =obj.Error+ error + "   ";
                        }
                    }
                    else
                        obj.Error = _errores == null ? "Factura válida." : "Factura válida";
                }

                System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
                string myString = myFile.ReadToEnd();
                obj.XmlaTexto = myString;

                System.Data.DataSet ds = new System.Data.DataSet();
                #endregion recopilando priemra sección de Información del XML

                #region recolilando la segunda Seccion de informacion del XML
                obj.ImporteTrasladado = "0";
                obj.SubTotal = Factura.SubTotal.ToString();
                obj.EstructuraValida = xmlDocumento;
                obj.ValidoSAT = xmlValido;
                obj.Conceptos = Conceptos;
                obj.UUID =_UUID != null ? _UUID : "No extraido de XML";
                obj.RFC = Factura.Emisor.Rfc;
                obj.Moneda = "MXN"; //Obsoleto 14 Junio 2017 GRD Factura.Moneda;
                obj.Descuento = Factura.Descuento == null ? 0 : Factura.Descuento;
                obj.RFC_Receptor = Factura.Receptor.Rfc;
                obj.Serie = Factura.Serie;
                obj.Path = Ruta;
                obj.NombreArchivo = Archivo;
                obj.ImporteRetenido = Factura.Impuestos.TotalImpuestosRetenidos.ToString();
                if (ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("desa_TKPM") == true || ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("qu_HANA_bafar") == true)
                    obj.UUID = "DePruebas" + Convert.ToString((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                double acumulado = 0;
                try
                {
                    obj.ImporteTrasladado = Factura.Impuestos.TotalImpuestosTrasladados.ToString();
                    if (Factura.Impuestos.Traslados != null)
                    {

                        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                        {
                            if (impuestosTrasladados.Importe > 0)
                                acumulado = acumulado + Convert.ToDouble(impuestosTrasladados.Importe.ToString());
                        }
                    }
                }
                catch
                {
                    acumulado = 0;
                }
                obj.ImporteTrasladado = acumulado.ToString();
                obj.Impuestos33 = Factura.Impuestos; //Obsoleto 14 Junio 2017 GRD Factura.Impuestos;
                obj.Impuestos = null;
                obj.Version = version;
                adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
                listadoA = ad.agregaobjeLeido(obj, listadoA);
                #endregion recolilando la segunda Seccion de informacion del XML

                #endregion Construyendo el Objeto Factura de SALIDA

            }
            catch (Exception ex)
            {
                //Genericos.objLeidoFactura obj = new Genericos.objLeidoFactura();
                //obj.EstructuraValida = false;
                //obj.ValidoSAT = false;
                //obj.Error = "Problema con la factura: " + ex.Message;
                //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                //listadoA = ad.agregaobjeLeido(obj, listadoA);
            }
            #endregion VERSION 3.3
        // ######################################################################  V E R S I O N    3. 2
            #region      VERSION 3.2

            Version32:
                if (version == "3.2")
                {
                    #region Sobre operaciones con Version 3.2
                    try
                    {
                        #region VERSION 3.2
                        System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_2.CFDI32.Comprobante));
                        bool seCargo = false;
                        #region Modificaciones
                        ClickFactura_Facturacion.version3_2.CFDI32.Comprobante Factura32 = new ClickFactura_Facturacion.version3_2.CFDI32.Comprobante();
                        //bajaADiscoDuro(ref Ruta,ref seCargo);
                        try
                        {
                            //using (StreamReader reader = new StreamReader(Ruta))
                            //{
                            //    Comprobante FacturaOriginal = (Comprobante)Serializer.Deserialize(reader);
                            //    Factura = FacturaOriginal;
                            //}
                            System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                            ClickFactura_Facturacion.version3_2.CFDI32.Comprobante FacturaOriginal = (ClickFactura_Facturacion.version3_2.CFDI32.Comprobante)Serializer.Deserialize(Lector);
                            Factura32 = FacturaOriginal;
                        }
                        catch
                        {
                            //if(File.Exists(Ruta)==false)
                            //{
                                try
                                {
                                bajaADiscoDuro(ref Ruta, ref seCargo);
                                using (StreamReader reader = new StreamReader(Ruta, Encoding.UTF8, true))
                                {
                                    System.Xml.Serialization.XmlSerializer serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_2.CFDI32.Comprobante));

                                    string line = "";
                                    string xy = "";
                                    while ((line = reader.ReadLine()) != null)
                                    {
                                        xy = xy + System.Text.RegularExpressions.Regex.Replace(line, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                    }

                                    //   xy = System.Text.RegularExpressions.Regex.Replace(xy, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);
                                       XmlReader xmlReader = XmlReader.Create(new StringReader(xy));
                                       ClickFactura_Facturacion.version3_2.CFDI32.Comprobante FacturaModificada = (ClickFactura_Facturacion.version3_2.CFDI32.Comprobante)Serializer.Deserialize(xmlReader);
                                       Factura32 = FacturaModificada;

                                    //object result = serializer.Deserialize(reader);

                                }


                                System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                                ClickFactura_Facturacion.version3_2.CFDI32.Comprobante _FacturaModificada = (ClickFactura_Facturacion.version3_2.CFDI32.Comprobante)Serializer.Deserialize(Lector);
                                Factura32 = _FacturaModificada;
                                }
                                catch(Exception miex)
                                {
                                    string _miex = miex.GetBaseException().ToString();
                                }
                            //}

                        }

                        System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                        xdoc.Load(Ruta);
                        #endregion Modificaciones

                        #region extrae la Pieas o Cantidades
                        System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                        System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                        System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                        XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                        int i = 0;
                        Decimal cantidad = 0;
                        string concepto;
                        Decimal importe = 0;
                        Decimal cantidadGlobal = 0;
                        Decimal importeGlobal = 0;
                        string unidad = "";

                        List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto> Conceptos = new List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto>();
                        foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                        {
                            ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto Concepto = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto();
                            try
                            {
                                cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                                cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                            }
                            catch
                            {
                                cantidadGlobal = cantidadGlobal + 0;
                                cantidad = 0;
                            }
                            try
                            {
                                concepto = NodoDetalladoConcepto[i].Attributes["descripcion"].Value;
                            }
                            catch
                            {
                                concepto = "No proporcionado";
                            }
                            try
                            {
                                importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                                importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                            }
                            catch
                            {
                                importeGlobal = importeGlobal + 0;
                                importe = 0;
                            }
                            try
                            {
                                unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
                            }
                            catch
                            {
                                unidad = "No proporcionado";
                            }
                            ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto c = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto();
                            c.cantidad = cantidad;
                            c.descripcion = concepto;
                            c.importe = importe;
                            c.unidad = unidad;
                            Conceptos.Add(c);
                            i++;
                        }
                        string UUID = "";
                        foreach (XmlElement nodo in NodoSecundarioComplemento)
                        {
                            try
                            {
                                UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                            }
                            catch
                            {
                                UUID = "No proporcionado";
                            }
                        }
                        _UUID = UUID;
                        string IEPS = "No proporcionado";
                        try
                        {
                            foreach (ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestosTraslado imp in Factura32.Impuestos.Traslados)
                            {
                                decimal importeIEPS = 0;
                                try
                                {
                                    if (imp.impuesto.ToString().Contains("IEPS") == true || imp.impuesto.ToString().Contains("Ieps") == true || imp.impuesto.ToString().Contains("ieps") == true)
                                    {
                                        IEPS = imp.impuesto.ToString();
                                        importeIEPS = imp.importe;
                                        if (importeIEPS <= 0)
                                        {
                                            IEPS = "No proporcionado";
                                        }
                                    }
                                }
                                catch
                                {
                                    IEPS = "No proporcionado";
                                }
                            }
                        }
                        catch
                        {
                            IEPS = "No proporcionado";
                        }


                        RFCEmisor = Factura32.Emisor.rfc;
                        RFCReceptor = Factura32.Receptor.rfc;

                        #region envia Almacenar
                        ClickFactura_Facturacion._3_2.CFDI32.objLeidoFactura obj = new ClickFactura_Facturacion._3_2.CFDI32.objLeidoFactura();
                        obj.Archivo = Archivo;
                        obj.Folio = Factura32.folio;
                        _FolioFactura = Factura32.folio;
                        obj.Fecha = Factura32.fecha.ToString();
                        obj.Timporte = Factura32.total.ToString();
                        int canti = Convert.ToInt32(cantidadGlobal);
                        obj.Tpiezas = canti.ToString(); ;
                        obj.Concepto = "";
                        obj.XmlaTexto = xdoc.InnerXml;

                        System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
                        string myString = myFile.ReadToEnd();
                        obj.XmlaTexto = myString;


                        #region valida el Documento
                        //wsBafar.Servicio_ClickFacturaClient cliente = new wsBafar.Servicio_ClickFacturaClient();
                        System.Data.DataSet ds = new System.Data.DataSet();

                        ClickFactura_Facturacion._3_2.CFDI32.Seguridad security = new ClickFactura_Facturacion._3_2.CFDI32.Seguridad();

                        Cadena_XML Objeto_XML = new Cadena_XML();
                        Resultado_XML Resulta = new Resultado_XML();
                        string texto = xdoc.InnerXml;
                        texto = System.Text.RegularExpressions.Regex.Replace(texto, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                        String Code = security.Base64Encode(texto);
                        int largo = Code.Length;
                        List<string> subXML = new List<string>();

                        if (largo >= 6700)
                        {
                            int chunkSize = 6700;
                            int stringLength = Code.Length;
                            for (int ii = 0; ii < stringLength; ii += chunkSize)
                            {
                                if (ii + chunkSize > stringLength) chunkSize = stringLength - ii;
                                subXML.Add(Code.Substring(ii, chunkSize));

                            }
                        }

                        Objeto_XML.Usuario = "demo";
                        //Objeto_XML.RFC = "AAA010101AAA";
                        Objeto_XML.Password = "DEMO";
                        Objeto_XML.Factura_XML = Code;
                        try
                        {

                        //wsBafar.IServicio_ClickFactura _wsBafar = new wsBafar.Servicio_ClickFacturaClient();
                        //Resulta = _wsBafar.Valida_XML(Objeto_XML);//cliente.Valida_XML(Objeto_XML);

                        Resulta.Correcta = _Resultado.resultado;
                        Resulta.Resultado_SAT = _Resultado.estadoSAT;

                            String SAT = Resulta.Resultado_SAT;
                            if (Resulta.Correcta == true)
                            {
                                xmlValido = true;
                                xmlDocumento = true;
                                obj.Error = Resulta.Resultado == null ? "Factura válida." : "Factura válida";
                                _UUID = Resulta.UUID;
                                resultadoUltimoEvaluado = true;
                            }
                            else
                            {
                                if (Resulta.Resultado.Equals("Comentario: El sello del emisor es invalido ;") == true)
                                {
                                    xmlValido = true;
                                    xmlDocumento = true;
                                    resultadoUltimoEvaluado = true;
                                    obj.Error = "Se realiza la excepción de aceptar la factura a pesar del error: Comentario: El sello del emisor es invalido.";
                                }
                                else
                                {
                                    xmlValido = false;
                                    xmlDocumento = false;
                                    resultadoUltimoEvaluado = false;
                                    obj.Error = Resulta.Resultado;
                                }
                                _UUID = extraeUUID(Factura32);
                            }
                            obj.ImporteTrasladado = "0";// Resulta.Factura.impuestosField.totalImpuestosTrasladadosField.ToString();
                            obj.SubTotal = Factura32.subTotal.ToString();

                            #region        Contabiliza la validacion con el servicio Click Factura
                            //try
                            //{
                            //    cs_Validaciones_ClickFactura contabiliza = new cs_Validaciones_ClickFactura();
                            //    obj_registraValidacion porEnviar = new obj_registraValidacion();
                            //    porEnviar.emisor = Factura.Emisor.rfc;
                            //    porEnviar.receptor = Factura.Receptor.rfc;
                            //    porEnviar.fechaValidacion = DateTime.UtcNow.ToString();
                            //    porEnviar.fechaDocumento = Factura.fecha.ToString();
                            //    porEnviar.serie = Factura.serie;
                            //    porEnviar.folio = Factura.folio;
                            //    porEnviar.estatusSAT = Resulta.Resultado_SAT;
                            //    porEnviar.estatus = Resulta.Correcta.ToString();
                            //    contabiliza.registraValidacion(porEnviar);
                            //}
                            //catch (Exception ex)
                            //{

                            //}
                            #endregion Contabiliza la validacion con el servicio Click Factura
                        }
                        catch (Exception ex)
                        {
                            xmlValido = false;
                            xmlDocumento = false;
                            obj.Error = "Problema con el servicio : " + ex.Message;
                            if (ex.Message.Contains("There was no endpoint listening at"))
                            {
                                obj.Error = "El servicio de validación de Facturas de Click Factura esta caido, por favor reporte a  Soporte del Portal Thyssenkrupp";
                            }
                            //There was no endpoint listening at http://192.175.113.36:8090/wsValidacion/validaXmlService that could accept the message. This is often caused by an incorrect address or SOAP action. See InnerException, if present, for more details.
                        }

                        //xmlValido = Resulta.Resultado;
                        //xmlDocumento = cliente.Valida_Documento(xdoc.InnerXml);
                        obj.EstructuraValida = xmlDocumento;
                        obj.ValidoSAT = xmlValido;
                        obj.Conceptos = Conceptos;
                        obj.UUID = Resulta.UUID == null ? _UUID : Resulta.UUID;
                        obj.RFC = Factura32.Emisor.rfc;
                        obj.Moneda = Factura32.Moneda;
                        obj.Descuento = Factura32.descuento == null ? 0 : Factura32.descuento;
                        obj.RFC_Receptor = Factura32.Receptor.rfc;
                        obj.Serie = Factura32.serie;
                        obj.Path = Ruta;
                        obj.NombreArchivo = Archivo;
                        obj.Moneda = Factura32.Moneda;
                        obj.ImporteRetenido = Factura32.Impuestos.totalImpuestosRetenidos.ToString();
                        if (ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("desa_TKPM") == true || ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("qu_HANA_bafar") == true)
                            obj.UUID = "DePruebas" + Convert.ToString((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                        double acumulado = 0;
                        try
                        {
                            obj.ImporteTrasladado = Factura32.Impuestos.totalImpuestosTrasladados.ToString();
                            if (Factura32.Impuestos.Traslados != null)
                            {

                                foreach (var impuestosTrasladados in Factura32.Impuestos.Traslados)
                                {
                                    if (impuestosTrasladados.importe > 0)
                                        acumulado = acumulado + Convert.ToDouble(impuestosTrasladados.importe.ToString());
                                }
                            }
                        }
                        catch
                        {
                            acumulado = 0;
                        }
                        obj.ImporteTrasladado = acumulado.ToString();
                        obj.Impuestos = Factura32.Impuestos;
                        obj.Version = "3.2";
                        #endregion valida el Documento
                        //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                        ClickFactura_Facturacion._3_2.CFDI32.adobjLeidos ad = new ClickFactura_Facturacion._3_2.CFDI32.adobjLeidos();
                        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura obj33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura();
                        //transforma32to33(obj, ref obj33);
                        //Quita VPN
                        listadoA = ad.agregaobjeLeido32_33(obj, listadoA);
                        #endregion envia Almacenar
                        #endregion Extraelas piezas o cantidades

                        try
                        {
                            //exploraXMLporAddenda(Ruta,Archivo,ref listadoAddendas);
                        }
                        catch
                        {
                            // listadoAddendas = null;
                            //
                        }
                        #endregion VERSION 3.2
                    }
                    catch (Exception ex)
                    {
                        string mierror = ex.Message;
                        //Genericos.objLeidoFactura obj = new Genericos.objLeidoFactura();
                        //obj.EstructuraValida = false;
                        //obj.ValidoSAT = false;
                        //obj.Error = "Problema con la factura: " + ex.Message;
                        //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                        //listadoA = ad.agregaobjeLeido(obj, listadoA);
                    }
                    #endregion Sobre operaciones con Version 3.2
                }
            #endregion VERSION 3.2
            return true;
        }

        private void transforma32to33(ClickFactura_Facturacion._3_2.CFDI32.objLeidoFactura obj, ref ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura obj33)
        {
            objLeidoFactura objSalida = new objLeidoFactura();

            obj33.Archivo = obj.Archivo;
            obj33.Folio = obj.Folio;
            obj33.Fecha = obj.Fecha;
            obj33.Tpiezas = obj.Tpiezas;
            obj33.Timporte = obj.Timporte;
            obj33.Codigo = obj.Codigo;
            obj33.XmlaTexto = obj.XmlaTexto;
            obj33.ValidoSAT = obj.ValidoSAT;
            obj33.EstructuraValida = obj.EstructuraValida;
            obj33.UUID=obj.UUID;
            obj33.RFC=obj.RFC;
            obj33.Path=obj.Path;
            obj33.Error=obj.Error;
            obj33.Moneda=obj.Moneda;
            obj33.SubTotal=obj.SubTotal;
            obj33.ImporteTrasladado=obj.ImporteTrasladado;
            obj33.Descuento=obj.Descuento;
            obj33.RFC_Receptor=obj.RFC_Receptor;
            obj33.Serie=obj.Serie;
            obj33.NombreArchivo=obj.NombreArchivo;
            obj33.ImporteRetenido=obj.ImporteRetenido;
            obj33.ImportesFueron=obj.ImportesFueron;
            obj33.ReglasAplicadas=obj.ReglasAplicadas;
            obj33.DiferenciaImportes=obj.DiferenciaImportes;
            obj33.AplicaraProrrateo=obj.AplicaraProrrateo;
            obj33.ImporteRetencionFlete=obj.ImporteRetencionFlete;
            obj33.EsdocumentoReferencia=obj.EsdocumentoReferencia;
            obj33.ImporteRecepcionOrigen=obj.ImporteRecepcionOrigen;
            obj33.ImporteArticulosconIVA=obj.ImporteArticulosconIVA;
            obj33.Documento_Referencia=obj.Documento_Referencia;
            obj33.ImporteUnitario=obj.ImporteUnitario;
            obj33.RecepcionValia=obj.RecepcionValia;
            obj33.Posicion_Documento_Material=obj.Posicion_Documento_Material;
            obj33.NotasCredito=obj.NotasCredito;
            obj33.Num_Proveedor=obj.Num_Proveedor;
            obj33.TipoFactura=obj.TipoFactura;
            obj33.Version=obj.Version;
            #region                                                  Conceptos
            List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos33 = new List<ComprobanteConcepto>();
            foreach(ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto original in obj.Conceptos)
            {
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto destino = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                destino.Cantidad = original.cantidad;
                destino.Descripcion = original.descripcion;
                destino.Importe = original.importe;
                destino.Unidad = original.unidad;
                destino.ValorUnitario = original.valorUnitario;
                Conceptos33.Add(destino);
            }
            obj33.Conceptos = Conceptos33;
            #endregion                                          Conceptos
            #region                                                 Impuestos
            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos Impuestos33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
            ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32 impuestos32Origen = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32();
            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion retenciones = new ComprobanteImpuestosRetencion();
            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado traslado = new ComprobanteImpuestosTraslado();
            obj33.Impuestos33 = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
            impuestos32Origen = obj.Impuestos;
            bool hayRetenciones = false;
            bool hayTrasladados = false;
            if (impuestos32Origen.Retenciones != null)
                hayRetenciones = true;
            if (impuestos32Origen.Traslados != null)
                hayTrasladados = true;
            if(hayRetenciones==true)
            {
               //ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion[] posicionesRetenciones=new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion[obj.Impuestos.Retenciones.Count()];
               // obj33.Impuestos33.Retenciones=posicionesRetenciones;
                obj33.Impuestos33.Retenciones = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion[obj.Impuestos.Retenciones.Count()];
                int pos=0;
                foreach (var imp in obj.Impuestos.Retenciones)
                {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion retencionesDestino = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion();
                    retencionesDestino.Importe = imp.importe;
                    retencionesDestino.Impuesto = imp.impuesto.ToString();
                    obj33.Impuestos33.Retenciones[pos] = retencionesDestino;
                    pos++;
                }
                obj33.Impuestos33.TotalImpuestosRetenidos = obj.Impuestos.totalImpuestosRetenidos;
            }
            if (hayTrasladados == true)
            {
                //ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado[] posicionesTrasladados = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado[obj.Impuestos.Traslados.Count()];
                //obj33.Impuestos33.Traslados = posicionesTrasladados;
                obj33.Impuestos33.Traslados = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado[obj.Impuestos.Traslados.Count()];
                int pos = 0;
                foreach (var imp in obj.Impuestos.Traslados)
                {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado retencionesDestino = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado();
                    retencionesDestino.Importe = imp.importe;
                    retencionesDestino.Impuesto = imp.impuesto.ToString();
                    obj33.Impuestos33.Traslados[pos] = retencionesDestino;
                    pos++;
                }
                obj33.Impuestos33.TotalImpuestosTrasladados = obj.Impuestos.totalImpuestosTrasladados;
            }

            //foreach(var original in obj.Impuestos)
            //{
            //    //ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32
            //    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos destino = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
            //    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion retencionesDestino = new ComprobanteImpuestosRetencion();




            //}
            #endregion                                          Impuestos
            objSalida=obj33;
        }

        public string aXMLConceptos(List<ComprobanteConcepto> Concepto)
        {
            List<string> listado = new List<string>();
            foreach(ComprobanteConcepto Conceptos in Concepto)
            {
                     string datos = "";
                    //datos = Conceptos.Items.ToString();
                    datos = "|"+ Conceptos.Cantidad.ToString();
                    datos = "|"+Conceptos.Unidad.ToString();
                    datos = "|"+Conceptos.NoIdentificacion.ToString();
                    datos = "|"+Conceptos.Descripcion.ToString();
                    datos = "|"+Conceptos.ValorUnitario.ToString();
                    datos = "|"+Conceptos.Importe.ToString();
                    datos="<"+datos+">";
                    listado.Add(datos);
            }
            string salida="";
            foreach(string s in listado)
            {
                salida = salida + s;
            }
            return salida;
        }
        public List<string> desmenuzaXMLConceptos(string Origen)
        {
            List<string> listado = new List<string>();
            const string pipe="|";
            const string inicio = "<";
            const string final = ">";
            foreach(char caracter in Origen.ToArray())
            {
                string texto = "";
                if(caracter!=Convert.ToChar("<") && caracter!=Convert.ToChar(">"))
                {
                    texto = texto + caracter;
                }
                else
                {
                    listado.Add(texto);
                }
            }

            return listado;
        }
        public bool Lectura_NotaCreditoExpress(String Archivo, ref List<objNotaCredito> notacredito, string Ruta, string Tipo, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, decimal _Factor)
        {
            try
            {
                #region Obsoleta
                System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(Comprobante));
                System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                Comprobante Factura = (Comprobante)Serializer.Deserialize(Lector);
                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);
                Lector.Close();
                //Lector.Dispose();

                #region extrae la Pieas o Cantidades
                System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                int i = 0;
                Decimal cantidad = 0;
                string concepto;
                Decimal importe = 0;
                string unidad = "";
                List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
                foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                {
                    ComprobanteConcepto Concepto = new ComprobanteConcepto();
                    try
                    {
                        cantidad = cantidad + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                    }
                    catch
                    {
                        cantidad = cantidad + 0;
                    }
                    try
                    {
                        concepto = NodoDetalladoConcepto[i].Attributes["concepto"].Value;
                    }
                    catch
                    {
                        concepto = "No proporcionado";
                    }
                    try
                    {
                        importe = importe + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                    }
                    catch
                    {
                        importe = importe + 0;
                    }
                    try
                    {
                        unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
                    }
                    catch
                    {
                        unidad = "No proporcionado";
                    }
                    ComprobanteConcepto c = new ComprobanteConcepto();
                    c.Cantidad = cantidad;
                    c.Descripcion = concepto;
                    c.Importe = importe;
                    c.Unidad = unidad;
                    Conceptos.Add(c);
                    i++;
                }
                string UUID = "";
                foreach (XmlElement nodo in NodoSecundarioComplemento)
                {
                    try
                    {
                        UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                    }
                    catch
                    {
                        UUID = "No proporcionado";
                    }
                }

                #region envia Almacenar
                objNotaCredito obj = new objNotaCredito();
                obj.Archivo = Archivo;
                obj.Folio = Factura.Folio.ToString();
                obj.Importe = Factura.Total.ToString();
                int canti = Convert.ToInt16(cantidad);
                obj.XML = xdoc.InnerXml;
                #region valida el Documento
                wsbafar = new Servicio_ClickFacturaClient();
                bool xmlValido = false;
                bool xmlDocumento = false;
                System.Data.DataSet ds = new System.Data.DataSet();
                //Core.Seguridad security = new Core.Seguridad();

                Cadena_XML Objeto_XML = new Cadena_XML();
                Resultado_XML Resulta = new Resultado_XML();

                String Code = Base64Encode(xdoc.InnerXml);

                Objeto_XML.Usuario = "demo";
                //Objeto_XML.RFC = "AAA010101AAA";
                Objeto_XML.Password = "DEMO";
                Objeto_XML.Factura_XML = Code;
                try
                {
                    Resulta = wsbafar.Valida_XML(Objeto_XML);

                    String SAT = Resulta.Resultado_SAT;
                    if (Resulta.Correcta == true)
                    {
                        xmlValido = true;
                        xmlDocumento = true;
                        obj.Error = Resulta.Resultado == null ? "Factura válida " : "Factura válida";
                        resultadoUltimoEvaluado = true;
                    }
                    else
                    {
                        xmlValido = false;
                        xmlDocumento = false;
                        resultadoUltimoEvaluado = false;
                        obj.Error = Resulta.Resultado;
                    }
                }
                catch (Exception ex)
                {
                    xmlValido = false;
                    xmlDocumento = false;
                    obj.Error = "Problema con el servicio : " + ex.Message;
                }

                obj.ValidoEstructura = xmlDocumento;
                obj.ValidoSAT = xmlValido;

                obj.UUID = Resulta.UUID;
                obj.RFC = Factura.Emisor.Rfc;
                obj.Ruta = Ruta;
                obj.Tipo = Tipo;
                obj.Factor = _Factor;
                string ImporteTrasladado = "";
                try
                {
                    ImporteTrasladado = Factura.Impuestos.TotalImpuestosTrasladados.ToString();
                    if (Factura.Impuestos.Traslados != null)
                    {
                        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                        {
                            if (impuestosTrasladados.Importe > 0)
                                ImporteTrasladado = impuestosTrasladados.Importe.ToString();
                        }
                    }
                }
                catch
                {
                    ImporteTrasladado = "0.00";
                }
                if (ImporteTrasladado.Equals("0.00") == true)
                    obj.TieneIVA = false;
                else
                    obj.TieneIVA = true;
                #endregion valida el Documento
                notacredito.Add(obj);

                #endregion envia Almacenar
                #endregion Extraelas piezas o cantidades
                #endregion Obsoleta
                return resultadoUltimoEvaluado;
            }
            catch (Exception ex)
            {
                return false;                
            }
        }
        private string extraeUUID(ClickFactura_Facturacion.version3_2.CFDI32.Comprobante _Facturas)
        {
            string _UUID = "No ubicado";
            //ComprobanteComplemento32 Complemento = _Facturas.Complemento;
            XmlElement[] Elemento = _Facturas.Complemento.Any;
            foreach (XmlElement Element in Elemento)
            {
                foreach (XmlAttribute Atributo in Element.Attributes)
                {
                    switch (Atributo.Name)
                    {
                        case "UUID":
                            _UUID = Atributo.Value;
                            break;
                    }
                }
            }
            return _UUID;
        }
        private string extraeUUID33(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura)
        {
            string _UUID = "No ubicado";
            #region Editada
            //List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteComplemento> Complemento = Factura.Complemento;
            //foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteComplemento complemento in Factura.Complemento)
            //{
            //    foreach (XmlElement elemento in complemento.Any)
            //    {
            //        foreach (XmlAttribute Atributo in elemento.Attributes)
            //        {
            //            switch (Atributo.Name)
            //            {
            //                case "UUID":
            //                    _UUID = Atributo.Value;
            //                    break;
            //            }
            //        }
            //    }
            //}
            #endregion Editada

            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteComplemento Complemento = Factura.Complemento;
            XmlElement[] Elemento = Factura.Complemento.Any;
            foreach (XmlElement Element in Elemento)
            {
                foreach (XmlAttribute Atributo in Element.Attributes)
                {
                    switch (Atributo.Name)
                    {
                        case "UUID":
                            _UUID = Atributo.Value;
                            break;
                    }
                }
            }

            return _UUID;
        }
        private void bajaADiscoDuro(ref string archivo, ref bool seCargo)
        {
            //string filepath = Path.Combine(Path.GetTempPath(), Path.ChangeExtension(Guid.NewGuid().ToString(), ".xml"));
            //byte[] y = System.Text.Encoding.UTF8.GetBytes(archivo);
            //File.WriteAllBytes(filepath, y);
            //if (File.Exists(filepath))
            //{
            //    //File.Delete(filepath);
            //    seCargo = true;
            //}
            //else
            //{
            //    seCargo = false;
            //}
            //archivo = filepath;
        }
        //public List<wsBafar.objLeidoFactura> ConvertirObjeto(List<objLeidoFactura> l)
        //{
        //    //try
        //    //{
        //    //    List<wsBafar.objLeidoFactura> obj = new List<wsBafar.objLeidoFactura>();
        //    //    foreach (var item in l)
        //    //    {
        //    //        List<wsBafar.ComprobanteConcepto> _conceptos = new List<wsBafar.ComprobanteConcepto>();
        //    //        if (item.Conceptos != null)
        //    //        {
        //    //            foreach (var c in item.Conceptos)
        //    //            {
        //    //                _conceptos.Add(new wsBafar.ComprobanteConcepto()
        //    //                {
        //    //                    cantidadField = c.Cantidad,
        //    //                    descripcionField = c.Descripcion,
        //    //                    importeField = c.Importe,
        //    //                    // Modificado el 22 MAyo por cambio de 3.3 Gabo Mayo 22 2017itemsField = c.Items,
        //    //                    noIdentificacionField = c.NoIdentificacion,
        //    //                    unidadField = c.Unidad,
        //    //                    valorUnitarioField = c.ValorUnitario
        //    //                });
        //    //            }
        //    //        }
        //    //        wsBafar.ComprobanteImpuestos _impuestos = new wsBafar.ComprobanteImpuestos();
        //    //        if (item.Impuestos != null)
        //    //        {
        //    //            _impuestos.totalImpuestosRetenidosField = item.Impuestos.TotalImpuestosRetenidos;
        //    //            //Modificacion 22 May Gabo por cambio a 3.3 _impuestos.totalImpuestosRetenidosFieldSpecified = item.Impuestos.TotalImpuestosRetenidosSpecified;
        //    //            _impuestos.totalImpuestosTrasladadosField = item.Impuestos.TotalImpuestosTrasladados;
        //    //            //Modificacion 22 May Gabo por cambio a 3.3  _impuestos.totalImpuestosTrasladadosFieldSpecified = item.Impuestos.TotalImpuestosTrasladadosSpecified;

        //    //            if (item.Impuestos.Retenciones != null)
        //    //            {
        //    //                _impuestos.retencionesField = new wsBafar.ComprobanteImpuestosRetencion[item.Impuestos.Retenciones.Count()];
        //    //                for (int j = 0; j < item.Impuestos.Retenciones.Count(); j++)
        //    //                {
        //    //                    _impuestos.retencionesField[j] = new wsBafar.ComprobanteImpuestosRetencion()
        //    //                    {
        //    //                        importeField = item.Impuestos.Retenciones[j].Importe,
        //    //                        impuestoField = (wsBafar.ComprobanteImpuestosRetencionImpuesto)item.Impuestos.Retenciones[j].Impuesto
        //    //                    };
        //    //                }
        //    //            }
        //    //            if (item.Impuestos.Traslados != null)
        //    //            {
        //    //                _impuestos.trasladosField = new wsBafar.ComprobanteImpuestosTraslado[item.Impuestos.Traslados.Count()];
        //    //                for (int k = 0; k < item.Impuestos.Traslados.Count(); k++)
        //    //                {
        //    //                    _impuestos.trasladosField[k] = new wsBafar.ComprobanteImpuestosTraslado()
        //    //                    {
        //    //                        importeField = item.Impuestos.Traslados[k].Importe,
        //    //                        tasaField = item.Impuestos.Traslados[k].TasaOCuota,
        //    //                        impuestoField = (wsBafar.ComprobanteImpuestosTrasladoImpuesto)item.Impuestos.Traslados[k].Impuesto
        //    //                    };
        //    //                }
        //    //            }
        //    //        }
        //    //        obj.Add(new wsBafar.objLeidoFactura()
        //    //        {
        //    //            AplicaraProrrateo = item.AplicaraProrrateo,
        //    //            Archivo = item.Archivo,
        //    //            Codigo = item.Codigo,
        //    //            Concepto = item.Concepto,
        //    //            Conceptos = _conceptos != null ? _conceptos.ToArray() : null,
        //    //            Descuento = item.Descuento,
        //    //            DiferenciaImportes = item.DiferenciaImportes,
        //    //            Documento_Referencia = item.Documento_Referencia,
        //    //            Error = item.Error,
        //    //            EsdocumentoReferencia = item.EsdocumentoReferencia,
        //    //            EstructuraValida = item.EstructuraValida,
        //    //            Fecha = item.Fecha,
        //    //            Folio = item.Folio,
        //    //            ImporteArticulosconIVA = item.ImporteArticulosconIVA,
        //    //            ImporteRecepcionOrigen = item.ImporteRecepcionOrigen,
        //    //            ImporteRetencionFlete = item.ImporteRetencionFlete,
        //    //            ImporteRetenido = item.ImporteRetenido,
        //    //            ImportesFueron = item.ImportesFueron,
        //    //            ImporteTrasladado = item.ImporteTrasladado,
        //    //            ImporteUnitario = item.ImporteUnitario,
        //    //            Impuestos = _impuestos,
        //    //            Moneda = item.Moneda,
        //    //            NombreArchivo = item.NombreArchivo,
        //    //            NotasCredito = item.NotasCredito,
        //    //            Num_Proveedor = item.Num_Proveedor,
        //    //            Path = item.Path,
        //    //            Posicion_Documento_Material = item.Posicion_Documento_Material,
        //    //            RecepcionValia = item.RecepcionValia,
        //    //            ReglasAplicadas = item.ReglasAplicadas,
        //    //            RFC = item.RFC,
        //    //            RFC_Receptor = item.RFC_Receptor,
        //    //            Serie = item.Serie,
        //    //            SubTotal = item.SubTotal,
        //    //            Timporte = item.Timporte,
        //    //            TipoFactura = item.TipoFactura,
        //    //            Tpiezas = item.Tpiezas,
        //    //            UUID = item.UUID,
        //    //            ValidoSAT = item.ValidoSAT,
        //    //            XmlaTexto = item.XmlaTexto
        //    //        });
        //    //    }
        //    //    return obj;
        //    //}
        //    //catch (Exception e)
        //    //{
        //    //    throw new Exception(e.Message);
        //    //}
        //}

        /// <summary>
        /// Funcion que decodifica una cadena.
        /// </summary>
        /// <param name="Cadena">Cadena codificada</param>
        /// <returns>Devuelve la cadena decodificada</returns>
        public String Base64Decode(string Cadena)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(Cadena);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
        /// <summary>
        /// Función que codifica una cadena
        /// </summary>
        /// <param name="Cadena">Cadena a codificar.</param>
        /// <returns>Devuelve la cadena codificada.</returns>
        public String Base64Encode(String Cadena)
        {
            var bytes = Encoding.UTF8.GetBytes(Cadena);
            var base64 = Convert.ToBase64String(bytes);
            return base64;
        }
        public List<objLeidoFactura> convierteListaObjeLeidoFactura(objLeidoFactura[] origen)
        {
            List<objLeidoFactura> salida = new List<objLeidoFactura>();
            foreach (objLeidoFactura regOrigen in origen)
            {
                salida.Add(regOrigen);
            }
            return salida;
        }
        public List<string> convierteaListaStrings(string[] origen)
        {
            List<string> salida = new List<string>();
            foreach(string reg in origen)
            {
                salida.Add(reg);
            }
            return salida;
        }
        public string XMLtoTXT(string Ruta)
        {
               string cadena = "";
                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);

               version3_3.Clases33.paraVerificacionFactura33.Seguridad security = new version3_3.Clases33.paraVerificacionFactura33.Seguridad();

                string texto = xdoc.InnerXml;
                texto = System.Text.RegularExpressions.Regex.Replace(texto, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                String Code = security.Base64Encode(texto);
                //int largo = Code.Length;
                //List<string> subXML = new List<string>();

                //if (largo >= 6700)
                //{
                //    int chunkSize = 6700;
                //    int stringLength = Code.Length;
                //    for (int ii = 0; ii < stringLength; ii += chunkSize)
                //    {
                //        if (ii + chunkSize > stringLength) chunkSize = stringLength - ii;
                //        subXML.Add(Code.Substring(ii, chunkSize));
                //    }
                //}
                cadena = Code;
                return cadena;
        }
        public string recuperaunValor(string texto, string valor)
        {
            XDocument doc = XDocument.Parse(texto);
           XElement element = XElement.Parse(texto);
                IEnumerable<XAttribute> lista=element.Attributes();
                foreach (XAttribute node in lista)
                {
                    string dat = node.Name.LocalName;
                    if(dat==valor)
                    {
                        valor = node.Value;
                        return valor;
                    }
                }
                return valor;
        }


    }

    public class ConexionWebServiceRestFull_33
    {
        /// <summary>
        /// Conexión que envia y recibe información al webservice RESTFull Click Factura
        /// </summary>
        /// <param name="datos"></param>
        /// <param name="rutaArchivos"></param>
        /// <param name="operacion"> 0 Timbrar, 1 Validar</param>
        /// <returns></returns>
        public void  SendWebService33(Dictionary<string, Object> datos, string rutaArchivos,int operacion,ref Resultado result)
        {
            string user = "AAA010101AAA";
            string pass = "demo";
            datos["user"] = user;
            datos["password"] = pass;
            string url="";
            Dictionary<string, string> valores=new Dictionary<string,string>();
            switch(operacion)
            {
                case 0:
                         url = string.Format("http://clickfactura.mx:8090/ValidadorCfdi/swagger-ui.html#!/Validador_CFDI/validaXmlRest");
                        var json = JsonConvert.SerializeObject(datos);
                        result = EjecutarServicioRestJson<Resultado>(url, json, "POST");
                        valores = result.message;
                        GenerarArchivos(valores["pdf"], valores["xmlData"], rutaArchivos);
                    break;
                case 1:
                        url = string.Format("http://localhost:8090/ValidadorCfdi/api/rest/service/cfdi2");
                        var json1 = JsonConvert.SerializeObject(datos);
                        result = EjecutarServicioRestJson<Resultado>(url, json1, "POST");
                        valores = result.message;
                    break;
            }
        }

        /// <summary>
        /// Genera la versión PDF para un archivo XML de la version 3.2
        /// </summary>
        /// <param name="pdf"></param>
        /// <param name="xml"></param>
        /// <param name="nombreArchivo"></param>
        private void GenerarArchivos(string pdf, string xml, string nombreArchivo)
        {
            try
            {                
                var pdfBytes = System.Convert.FromBase64String(pdf);
                var xmlBytes = System.Convert.FromBase64String(xml);

                using (FileStream fileStream = new FileStream(nombreArchivo + ".pdf", FileMode.Create))
                {
                    fileStream.Write(pdfBytes, 0, pdfBytes.Length);                    
                    fileStream.Seek(0, SeekOrigin.Begin);                    
                }
                using (FileStream fileStream = new FileStream(nombreArchivo + ".xml", FileMode.Create))
                {
                    fileStream.Write(xmlBytes, 0, xmlBytes.Length);
                    fileStream.Seek(0, SeekOrigin.Begin);
                }                
            }
            catch (Exception ex)
            {
                
                throw;
            }
        }

        /// <summary>
        /// Formatea una respuesta a formato JSON
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="uri"></param>
        /// <param name="requestBodyObject"></param>
        /// <param name="method"></param>
        /// <returns></returns>
        private T EjecutarServicioRestJson<T>(string uri, object requestBodyObject, string method = "POST")
        {
            var javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 104857600; //200 MB unicode
            var request = (HttpWebRequest)WebRequest.Create(uri);
            request.Method = method;
            request.Accept = "application/json";
            request.ContentType = "application/json; charset=utf-8";

            //Serialize request object as JSON and write to request body
            if (requestBodyObject != null)
            {
                //var stringBuilder = new StringBuilder();
                //javaScriptSerializer.Serialize(requestBodyObject, stringBuilder);
                var requestBody = requestBodyObject.ToString();
                request.ContentLength = requestBody.Length;
                var streamWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                streamWriter.Write(requestBody);
                streamWriter.Close();
            }

            var response = request.GetResponse();

            if (response == null)
            {
                return default(T);
            }

            //Read JSON response stream and deserialize
            var streamReader = new System.IO.StreamReader(response.GetResponseStream());
            var responseContent = streamReader.ReadToEnd().Trim();
            var jsonObject = javaScriptSerializer.Deserialize<T>(responseContent);
            return jsonObject;
        }
    }
    public class Resultado
    {
        public string status { get; set; }
        public int error_code { get; set; }
        public Dictionary<string, string> message { get; set; }
    }  
    public class objImportes
    {
        string factura;

        public string Factura
        {
            get { return factura; }
            set { factura = value; }
        }
        string documento;

        public string Documento
        {
            get { return documento; }
            set { documento = value; }
        }
        decimal importeFactura;

        public decimal ImporteFactura
        {
            get { return importeFactura; }
            set { importeFactura = value; }
        }
        decimal importeDocumento;

        public decimal ImporteDocumento
        {
            get { return importeDocumento; }
            set { importeDocumento = value; }
        }
        bool cuadra;

        public bool Cuadra
        {
            get { return cuadra; }
            set { cuadra = value; }
        }

        decimal signo = 0;

        public decimal Signo
        {
            get { return signo; }
            set { signo = value; }
        }

        public objImportes()
        {

        }

        public objImportes(string _Factura, string _Documento, decimal _ImporteFactura, decimal _ImporteDocumento, bool _Cuadra)
        {
            Factura = _Factura;
            Documento = _Documento;
            ImporteFactura = _ImporteFactura;
            ImporteDocumento = _ImporteDocumento;
            Cuadra = _Cuadra;
        }


       }

    }

