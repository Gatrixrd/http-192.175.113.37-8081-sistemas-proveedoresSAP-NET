﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33
{
    public class objLeidoFactura
    {
        string archivo;

        public string Archivo
        {
            get { return archivo; }
            set { archivo = value; }
        }
        string folio;

        public string Folio
        {
            get { return folio; }
            set { folio = value; }
        }
        string fecha;

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }
        string tpiezas;

        public string Tpiezas
        {
            get { return tpiezas; }
            set { tpiezas = value; }
        }
        string timporte;

        public string Timporte
        {
            get { return timporte; }
            set { timporte = value; }
        }
        string concepto;

        public string Concepto
        {
            get { return concepto; }
            set { concepto = value; }
        }
        string codigo;

        public string Codigo
        {
            get { return codigo; }
            set { codigo = value; }
        }


        string xmlaTexto;

        bool validoSAT;

        public bool ValidoSAT
        {
            get { return validoSAT; }
            set { validoSAT = value; }
        }
        bool estructuraValida;

        public bool EstructuraValida
        {
            get { return estructuraValida; }
            set { estructuraValida = value; }
        }

        public string XmlaTexto
        {
            get { return xmlaTexto; }
            set { xmlaTexto = value; }
        }
        List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> conceptos;

        public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos
        {
            get { return conceptos; }
            set { conceptos = value; }
        }

        string uUID;

        public string UUID
        {
            get { return uUID; }
            set { uUID = value; }
        }

        string rFC;

        public string RFC
        {
            get { return rFC; }
            set { rFC = value; }
        }

        string subTotal;

        public string SubTotal
        {
            get { return subTotal; }
            set { subTotal = value; }
        }

        string importeTrasladado = "0";

        public string ImporteTrasladado
        {
            get { return importeTrasladado; }
            set { importeTrasladado = value; }
        }
        string path;

        public string Path
        {
            get { return path; }
            set { path = value; }
        }

        string error;

        public string Error
        {
            get { return error; }
            set { error = value; }
        }

        string moneda;

        public string Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }

        decimal descuento;

        public decimal Descuento
        {
            get { return descuento; }
            set { descuento = value; }
        }

        string rFC_Receptor;

        public string RFC_Receptor
        {
            get { return rFC_Receptor; }
            set { rFC_Receptor = value; }
        }
        string serie;

        public string Serie
        {
            get { return serie; }
            set { serie = value; }
        }

        string nombreArchivo;

        public string NombreArchivo
        {
            get { return nombreArchivo; }
            set { nombreArchivo = value; }
        }

        string importeRetenido = "0";

        public string ImporteRetenido
        {
            get { return importeRetenido; }
            set { importeRetenido = value; }
        }

        //Se agregan el 17 Julio 2015 GRD
        //Para administrar mejor el tema de Prorrateos
        string importesFueron = "Iguales";

        public string ImportesFueron
        {
            get { return importesFueron; }
            set { importesFueron = value; }
        }
        string reglasAplicadas = "";

        public string ReglasAplicadas
        {
            get { return reglasAplicadas; }
            set { reglasAplicadas = value; }
        }
        double diferenciaImportes = 0;

        public double DiferenciaImportes
        {
            get { return diferenciaImportes; }
            set { diferenciaImportes = value; }
        }
        bool aplicaraProrrateo = false;

        public bool AplicaraProrrateo
        {
            get { return aplicaraProrrateo; }
            set { aplicaraProrrateo = value; }
        }

        string importeRetencionFlete;

        public string ImporteRetencionFlete
        {
            get { return importeRetencionFlete; }
            set { importeRetencionFlete = value; }
        }

        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos impuestos33;

        public ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos Impuestos33
        {
            get { return impuestos33; }
            set { impuestos33 = value; }
        }

        ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32 impuestos;

        public ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32 Impuestos
        {
            get { return impuestos; }
            set { impuestos = value; }
        }

        string esdocumentoReferencia = "N";

        public string EsdocumentoReferencia
        {
            get { return esdocumentoReferencia; }
            set { esdocumentoReferencia = value; }
        }

        double importeRecepcionOrigen = 0;

        public double ImporteRecepcionOrigen
        {
            get { return importeRecepcionOrigen; }
            set { importeRecepcionOrigen = value; }
        }

        double importeArticulosconIVA = 0;

        public double ImporteArticulosconIVA
        {
            get { return importeArticulosconIVA; }
            set { importeArticulosconIVA = value; }
        }

        string documento_Referencia;

        public string Documento_Referencia
        {
            get { return documento_Referencia; }
            set { documento_Referencia = value; }
        }
        double importeUnitario;
        public double ImporteUnitario
        {
            get { return importeUnitario; }
            set { importeUnitario = value; }
        }
        double recepcionValia = 0;

        public double RecepcionValia
        {
            get { return recepcionValia; }
            set { recepcionValia = value; }
        }

        string posicion_Documento_Material;

        public string Posicion_Documento_Material
        {
            get { return posicion_Documento_Material; }
            set { posicion_Documento_Material = value; }
        }

        double notasCredito;

        public double NotasCredito
        {
            get { return notasCredito; }
            set { notasCredito = value; }
        }
        string num_Proveedor = "";

        public string Num_Proveedor
        {
            get { return num_Proveedor; }
            set { num_Proveedor = value; }
        }

        string tipoFactura = "Normal";

        public string TipoFactura
        {
            get { return tipoFactura; }
            set { tipoFactura = value; }
        }
        string version = "3.3";

        public string Version
        {
            get { return version; }
            set { version = value; }
        }
        public objLeidoFactura()
        {

        }

        /// <summary>
        /// Objeto que almacena la información de cada Linea de la Recepción seleccionada y en vista
        /// </summary>
        /// <param name="_Archivo"></param>
        /// <param name="_Folio"></param>
        /// <param name="_Fecha"></param>
        /// <param name="_Tpiezas"></param>
        /// <param name="_Timporte"></param>
        /// <param name="_Concepto"></param>
        /// <param name="_Codigo"></param>
        /// <param name="_XmlaTexto"></param>
        /// <param name="_ValidoSAT"></param>
        /// <param name="_EstructuraValida"></param>
        /// <param name="_Conceptos"></param>
        /// <param name="_UUID"></param>
        /// <param name="_RFC"></param>
        /// <param name="_Path"></param>
        /// <param name="_Error"></param>
        /// <param name="_Moneda"></param>
        /// <param name="_SubTotal"></param>
        /// <param name="_ImporteTrasladado"></param>
        /// <param name="_descuento"></param>
        /// <param name="_RFC_Receptor"></param>
        /// <param name="_Serie"></param>
        /// <param name="_NombreArchivo"></param>
        /// <param name="_ImpuestoRetenido">Importe Total de los Impuestos Retenidos</param>
        /// <param name="_ImportesFueron">Especifica si fueron Iguales, facturaArriba,facturaAbajo</param>
        /// <param name="_ReglasAplicadas">Almacenara los detalles acerca de si para por +- $50, por % sobre valor del importe vs valor total de la  Factura, +- un % definido por Bafar</param>
        /// <param name="_DiferenciaImportes">Almacenara la diferencia que exista entre los importes de la factura y lo que esta recepcionado en SAP al Evaluar Importes</param>
        /// <param name="_AplicaraProrrateo">Booleano que sugiere si se aplicara o no prorrateo más adelante</param>
        /// <param name="_esdocumentoReferencia">Indica si el valor ID se obtuvo de Documento Referencia</param>
        /// <param name="_ImporteRecepcionOrigen">Importe de la Recepción exactamente igual como lo necesita SAP </param>
        ///  <param name="ImporteArticulosconIVA">Importe de los articulos que si tenian IVA </param> 
        ///  <param name="Documento_Referencia">Valor de la columna Documento Referencia en Detalle Recepciones </param> 
        ///  <param name="ImporteUnitario">Valor de la columna Importe en Detalle Orden de Compra </param> 
        ///  <param name="RecepcionValia">Valor de la Recepción sin prorrateos </param> 
        ///  <param name="Posicion_Documento_Material ">Posicion del Sub Recepción del Material dentro d ela misma Recepción, es ajueno a su posición en la orden de compra y a la posición de como fue Recepcionado </param> 
        ///   <param name="NotaCredito ">Importe de la Nota de Credito aplicada </param> 
        ///   <param name="Num_Proveedor ">Numero de Proveedor, mas utilizado en Importaciones </param> 
        ///   <param name="TipoFactura ">Tipo de Factura probable es decir, Normal, Flete, Renta,Importacion, etc.. </param> 
        public objLeidoFactura(string _Archivo, string _Folio, string _Fecha, string _Tpiezas, string _Timporte, string _Concepto, string _Codigo, string _XmlaTexto, bool _ValidoSAT, bool _EstructuraValida, List<ComprobanteConcepto> _Conceptos, string _UUID, string _RFC, string _Path, string _Error, string _Moneda, string _SubTotal, string _ImporteTrasladado, decimal _descuento, string _RFC_Receptor, string _Serie, string _NombreArchivo, string _ImpuestoRetenido, string _ImportesFueron, string _ReglasAplicadas, double _DiferenciaImportes, bool _AplicaraProrrateo, string _ImporteRetencionFlete, ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestos32  _Impuestos, ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos33, string _esdocumentoReferencia, double _ImporteRecepcionOrigen, double _ImporteArticulosconIVA, string _Documento_Referencia, double _ImporteUnitario, double _RecepcionValia, string _Posicion_Documento_Material, double _NotaCredito, string _Num_Proveedor, string _TipoFactura, string _Version)
        {
            Archivo = _Archivo;
            Folio = _Folio;
            Fecha = _Fecha;
            Tpiezas = _Tpiezas;
            Timporte = _Timporte;
            Concepto = _Concepto;
            Codigo = _Codigo;
            XmlaTexto = _XmlaTexto;
            ValidoSAT = _ValidoSAT;
            EstructuraValida = _EstructuraValida;
            Conceptos = _Conceptos;
            UUID = _UUID;
            RFC = _RFC;
            Path = _Path;
            Error = _Error;
            Moneda = _Moneda;
            SubTotal = _SubTotal;
            ImporteTrasladado = _ImporteTrasladado;
            Descuento = _descuento;
            RFC_Receptor = _RFC_Receptor;
            Serie = _Serie;
            NombreArchivo = _NombreArchivo;
            ImporteRetenido = _ImpuestoRetenido;
            ImportesFueron = _ImportesFueron;
            ReglasAplicadas = _ReglasAplicadas;
            DiferenciaImportes = _DiferenciaImportes;
            AplicaraProrrateo = _AplicaraProrrateo;
            ImporteRetencionFlete = _ImporteRetencionFlete;
            Impuestos = _Impuestos;
            Impuestos33 = _Impuestos33;
            EsdocumentoReferencia = _esdocumentoReferencia;
            ImporteRecepcionOrigen = _ImporteRecepcionOrigen;
            ImporteArticulosconIVA = _ImporteArticulosconIVA;
            Documento_Referencia = _Documento_Referencia;
            ImporteUnitario = _ImporteUnitario;
            RecepcionValia = _RecepcionValia;
            Posicion_Documento_Material = _Posicion_Documento_Material;
            NotasCredito = _NotaCredito;
            Num_Proveedor = _Num_Proveedor;
            TipoFactura = _TipoFactura;
            Version = _Version;
        }
    }
}
