﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Script.Serialization;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;
using System.Runtime.Serialization.Json;

namespace ClickFactura_Facturacion.version3_3.Clases33
{

    public class webserviceRESTFull3_3
    {
        static HttpClient client = new HttpClient();

        /// <summary>
        /// Conexión que envia y recibe información al webservice RESTFull Click Factura
        /// </summary>
        /// <param name="datos"></param>
        /// <param name="rutaArchivos"></param>
        /// <param name="operacion"> 0 Timbrar, 1 Validar</param>
        /// <returns></returns>
        public Resultado_version33 SendWebService33(string rutaArchivos, int operacion, string xmlData)
        {
            Resultado_version33 result = new Resultado_version33();
            Dictionary<string, object> datos = new Dictionary<string, object>();
            string user = "AAA010101AAA";
            string pass = "demo";
            datos["user"] = user;
            datos["password"] = pass;
            datos["xmlData"] = xmlData;// "PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4NCjxjZmRpOkNvbXByb2JhbnRlIHhtbG5zOmNmZGk9Imh0dHA6Ly93d3cuc2F0LmdvYi5teC9jZmQvMyIgeG1sbnM6eHNpPSJodHRwOi8vd3d3LnczLm9yZy8yMDAxL1hNTFNjaGVtYS1pbnN0YW5jZSIgeG1sbnM6aW1wbG9jYWw9Imh0dHA6Ly93d3cuc2F0LmdvYi5teC9pbXBsb2NhbCIgeHNpOnNjaGVtYUxvY2F0aW9uPSJodHRwOi8vd3d3LnNhdC5nb2IubXgvY2ZkLzMgaHR0cDovL3d3dy5zYXQuZ29iLm14L3NpdGlvX2ludGVybmV0L2NmZC8zL2NmZHYzMi54c2QgaHR0cDovL3d3dy5zYXQuZ29iLm14L2ltcGxvY2FsIGh0dHA6Ly93d3cuc2F0LmdvYi5teC9zaXRpb19pbnRlcm5ldC9jZmQvaW1wbG9jYWwvaW1wbG9jYWwueHNkIiB2ZXJzaW9uPSIzLjIiIGZvbGlvPSIzMTciIGZlY2hhPSIyMDE3LTA1LTI0VDE0OjA4OjU3IiBzZWxsbz0iWkt4aHVITnd0RDY3Ti9NQk9NbVFnUzB4Q3V1cm0yVjhSVTBOa0dKVzA0amRVWDBlVjNaU0FHKzA2aFdqZ3hJWHZGZVVVNWpzUW5jaDJMbUVjMDJJQWlQNjFjSzkzYlBvUHQ5V0l1RjNGSUgyQ1NEaTNab1lIb2xFOWhzVk9DYkVlZWF2Y280RkdzUzBjMW1hQUk5b1BvT2R4blBiUXF4MXdLZisrNWswK0tFPSIgZm9ybWFEZVBhZ289IlBhZ28gZW4gdW5hIHNvbGEgZXhoaWJpY2nDs24iIG5vQ2VydGlmaWNhZG89IjAwMDAxMDAwMDAwMzA2NzM1MzMwIiBjZXJ0aWZpY2Fkbz0iTUlJRWRUQ0NBMTJnQXdJQkFnSVVNREF3TURFd01EQXdNREF6TURZM016VXpNekF3RFFZSktvWklodmNOQVFFRkJRQXdnZ0dLTVRnd05nWURWUVFEREM5QkxrTXVJR1JsYkNCVFpYSjJhV05wYnlCa1pTQkJaRzFwYm1semRISmhZMm5EczI0Z1ZISnBZblYwWVhKcFlURXZNQzBHQTFVRUNnd21VMlZ5ZG1samFXOGdaR1VnUVdSdGFXNXBjM1J5WVdOcHc3TnVJRlJ5YVdKMWRHRnlhV0V4T0RBMkJnTlZCQXNNTDBGa2JXbHVhWE4wY21GamFjT3piaUJrWlNCVFpXZDFjbWxrWVdRZ1pHVWdiR0VnU1c1bWIzSnRZV05wdzdOdU1SOHdIUVlKS29aSWh2Y05BUWtCRmhCaFkyOWtjMEJ6WVhRdVoyOWlMbTE0TVNZd0pBWURWUVFKREIxQmRpNGdTR2xrWVd4bmJ5QTNOeXdnUTI5c0xpQkhkV1Z5Y21WeWJ6RU9NQXdHQTFVRUVRd0ZNRFl6TURBeEN6QUpCZ05WQkFZVEFrMVlNUmt3RndZRFZRUUlEQkJFYVhOMGNtbDBieUJHWldSbGNtRnNNUlF3RWdZRFZRUUhEQXREZFdGMWFIVERxVzF2WXpFVk1CTUdBMVVFTFJNTVUwRlVPVGN3TnpBeFRrNHpNVFV3TXdZSktvWklodmNOQVFrQ0RDWlNaWE53YjI1ellXSnNaVG9nUTJ4aGRXUnBZU0JEYjNaaGNuSjFZbWxoY3lCUFkyaHZZVEFlRncweE5UQTBNVEF4TnpFeU1UQmFGdzB4T1RBME1UQXhOekV5TVRCYU1JSEJNU0V3SHdZRFZRUURFeGhLVDFORklFeFZTVk1nVmtWSFFTQklSVkpPUVU1RVJWb3hJVEFmQmdOVkJDa1RHRXBQVTBVZ1RGVkpVeUJXUlVkQklFaEZVazVCVGtSRldqRWhNQjhHQTFVRUNoTVlTazlUUlNCTVZVbFRJRlpGUjBFZ1NFVlNUa0ZPUkVWYU1SWXdGQVlEVlFRdEV3MVdSVWhNTnpjd09USXlVMFk1TVJzd0dRWURWUVFGRXhKV1JVaE1OemN3T1RJeVNFSkRSMUpUTURreElUQWZCZ05WQkFzVEdFcFBVMFVnVEZWSlV5QldSVWRCSUVoRlVrNUJUa1JGV2pDQm56QU5CZ2txaGtpRzl3MEJBUUVGQUFPQmpRQXdnWWtDZ1lFQW1UM2RjTGcrWVJGSUZGdS9VSDQ5Z1BvWEdYRnNTV09tWkNaUnUxcWVpMTlIV0tmN1JxbUlYT2pCQ3NHOFE5aGthUTE5bFNxTFJDWitQYkVKdUJ1bmRUUE9wMlRZK0NiZnR0S091SU5OQmhaNW5qUFVRVy9MWVhtZUFnZE9Lc3lyMitKQkd5K0F6UGJCY0ZzcGgyQk9yK1g2WjN5bDAzOXVoS2wzVzBxSHJRRUNBd0VBQWFNZE1Cc3dEQVlEVlIwVEFRSC9CQUl3QURBTEJnTlZIUThFQkFNQ0JzQXdEUVlKS29aSWh2Y05BUUVGQlFBRGdnRUJBTUgzeWtnRy8xMCtqNUJyQ1VrTW1laEEwTTAwajJJL0dQNTlkenlwclZKN2cva2lNZWRWdXBEZmdRNDZ2OGl6VFlZSnE1eXYxaUNFa1FsTkFYNy9EVnFvS2NjRnZ3VXpZcmk3QUhRckVONEZPWlo0VUd5YVQraTNiU3dCZ0p2QjJDenBQNytuMkhVUjVVMXVaaEhSdDlwZ0hKUkZiQWdnWUFDdTZIdkxVMHJwdzhXYXBiakNNNDNnT29Sa2pFeHVsUzZVaGtkMFk3NHlwak9PZ1MxWkt0dk43VGZrcWxWK2laeUZnMFAxT3ljd3pBQ085ejBEQ0cxL3o0bmRrZDlJbDNreHdHNTZUM3hVZ1grZmJ3OFlrWlowdzRSUEVENE9QY2JTbGRtWEpYM3QrWkMxR3RFbGVSZnRONm5PU2dKc3RuWGpVMUQrVEVVbHYvaWpRQzVremEwPSIgc3ViVG90YWw9IjI1MDAuMDAiIFRpcG9DYW1iaW89IjEuMDAiIE1vbmVkYT0iUEVTT1MiIHRvdGFsPSIyOTAwLjAwIiB0aXBvRGVDb21wcm9iYW50ZT0iaW5ncmVzbyIgbWV0b2RvRGVQYWdvPSIwMiIgTHVnYXJFeHBlZGljaW9uPSJNRVhJQ0FMSSwgQkFKQSBDQUxJRk9STklBIj48Y2ZkaTpFbWlzb3IgcmZjPSJWRUhMNzcwOTIyU0Y5IiBub21icmU9IkpPU0UgTFVJUyBWRUdBIEhFUk5BTkRFWiI+PGNmZGk6RG9taWNpbGlvRmlzY2FsIGNhbGxlPSJBVi4gSUdOQUNJTyBSQU1JUkVaIiBub0V4dGVyaW9yPSIxMTI3IiBjb2xvbmlhPSJST01BIiBtdW5pY2lwaW89Ik1FWElDQUxJIiBlc3RhZG89IkJBSkEgQ0FMSUZPUk5JQSIgcGFpcz0iTcOpeGljbyIgY29kaWdvUG9zdGFsPSIyMTI0MCI+PC9jZmRpOkRvbWljaWxpb0Zpc2NhbD48Y2ZkaTpSZWdpbWVuRmlzY2FsIFJlZ2ltZW49Ik5BIj48L2NmZGk6UmVnaW1lbkZpc2NhbD48L2NmZGk6RW1pc29yPjxjZmRpOlJlY2VwdG9yIHJmYz0iVEhFODQwODE1MTcyIiBub21icmU9IlRIRUNITklDT0xPUiBIT01FIEVOVEVSVEFJTk1FTlQgU0VSVklDRSBNRVhJQ08gUy5ERSBSLkwgREUgQy5WIj48Y2ZkaTpEb21pY2lsaW8gY2FsbGU9IkNBTFouR1VTVEFWTyBWSUxET1NPTEEgQ0FTVFJPIiBub0V4dGVyaW9yPSIxNzY5IiBjb2xvbmlhPSJFWC1FSklETyBDT0FIVUlMQSIgbXVuaWNpcGlvPSJNRVhJQ0FMSSIgZXN0YWRvPSJCQUpBIENBTElGT1JOSUEiIHBhaXM9Ik1FWElDTyIgY29kaWdvUG9zdGFsPSIyMTM2MCI+PC9jZmRpOkRvbWljaWxpbz48L2NmZGk6UmVjZXB0b3I+PGNmZGk6Q29uY2VwdG9zPjxjZmRpOkNvbmNlcHRvIGNhbnRpZGFkPSIxLjAwIiB1bmlkYWQ9IlBaIiBkZXNjcmlwY2lvbj0iU0VSVklDSU8gREUgQUlSRSBBQ09ORElDSU9OQURPIEUgSU5TVEFMQUNJT04gREUgQ09OREVOU0FET1IgTklTU0FOIFRJREEiIHZhbG9yVW5pdGFyaW89IjI1MDAuMDAiIGltcG9ydGU9IjI1MDAuMDAiPjwvY2ZkaTpDb25jZXB0bz48L2NmZGk6Q29uY2VwdG9zPjxjZmRpOkltcHVlc3RvcyB0b3RhbEltcHVlc3Rvc1RyYXNsYWRhZG9zPSI0MDAuMDAiPjxjZmRpOlRyYXNsYWRvcz48Y2ZkaTpUcmFzbGFkbyBpbXB1ZXN0bz0iSVZBIiB0YXNhPSIxNi4wMCIgaW1wb3J0ZT0iNDAwLjAwIj48L2NmZGk6VHJhc2xhZG8+PC9jZmRpOlRyYXNsYWRvcz48L2NmZGk6SW1wdWVzdG9zPjxjZmRpOkNvbXBsZW1lbnRvPjx0ZmQ6VGltYnJlRmlzY2FsRGlnaXRhbCB2ZXJzaW9uPSIxLjAiIFVVSUQ9IjhBOThBMkVCLUI4QTgtNEQxMy1CQzlDLUVEQTQyRUU2QzFERiIgRmVjaGFUaW1icmFkbz0iMjAxNy0wNS0yNFQxNjo1NzoxMiIgc2VsbG9DRkQ9IlpLeGh1SE53dEQ2N04vTUJPTW1RZ1MweEN1dXJtMlY4UlUwTmtHSlcwNGpkVVgwZVYzWlNBRyswNmhXamd4SVh2RmVVVTVqc1FuY2gyTG1FYzAySUFpUDYxY0s5M2JQb1B0OVdJdUYzRklIMkNTRGkzWm9ZSG9sRTloc1ZPQ2JFZWVhdmNvNEZHc1MwYzFtYUFJOW9Qb09keG5QYlFxeDF3S2YrKzVrMCtLRT0iIG5vQ2VydGlmaWNhZG9TQVQ9IjAwMDAxMDAwMDAwMzAxMDIxNTAxIiBzZWxsb1NBVD0iSzRDb0tHUDQyNHpNMmg1aDExMWluUGFqVnpWc1c2MVJtbGVvSEhEWEpYcHdocVVpZkQyS1dCSXE3TWkrc05KOG5WZW9mQ2hlQ0MyUVEwRTIrcmJ5TFUxaFRxMC9jeCswcVpHZXNOTy9DZTR3UUZZLy9ydW4vWDgrbVdLVGxLSkhoS01jTHZ2dFhJeXRYUC9kaG5uSXYwOEJWQVlXcVFCbktVbzBRV2JQdmZRPSIgeHNpOnNjaGVtYUxvY2F0aW9uPSJodHRwOi8vd3d3LnNhdC5nb2IubXgvVGltYnJlRmlzY2FsRGlnaXRhbCBodHRwOi8vd3d3LnNhdC5nb2IubXgvc2l0aW9faW50ZXJuZXQvVGltYnJlRmlzY2FsRGlnaXRhbC9UaW1icmVGaXNjYWxEaWdpdGFsLnhzZCAiIHhtbG5zOnRmZD0iaHR0cDovL3d3dy5zYXQuZ29iLm14L1RpbWJyZUZpc2NhbERpZ2l0YWwiIHhtbG5zOnhzaT0iaHR0cDovL3d3dy53My5vcmcvMjAwMS9YTUxTY2hlbWEtaW5zdGFuY2UiLz48L2NmZGk6Q29tcGxlbWVudG8+PC9jZmRpOkNvbXByb2JhbnRlPg0K";
            string url = "";
            Dictionary<string, string> valores = new Dictionary<string, string>();
            switch (operacion)
            {
                case 1:
                    //url = string.Format("localhost:8090/ValidadorCfdi/api/rest/service/cfdi2");
                    //var json1 = JsonConvert.SerializeObject(datos);
                    //result = EjecutarServicioRestJson<Resultado_version33>(url, json1, "POST");
                    //valores = result.message;
                    //http://clickfactura.mx:8090/ValidadorCfdi/api/rest/service/cfdi2
                    #region   1
                    //var httpWebRequest = (HttpWebRequest)WebRequest.Create("http://clickfactura.mx:8090/ValidadorCfdi/api/rest/service/cfdi2");
                    //httpWebRequest.ContentType = "application/x-www-form-urlencoded";
                    //     httpWebRequest.Method = "POST";

                    //     using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
                    //     {
                    //         string json = "{\"user\":\"AAA010101AAA\", \"pass\":\"demo\",\"xmlData\":\""+xmlData+"\"}";

                    //         streamWriter.Write(json);
                    //         streamWriter.Flush();
                    //         streamWriter.Close();
                    //     }

                    //     var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
                    //     using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
                    //     {
                    //         var _result = streamReader.ReadToEnd();
                    //         foreach(var r in _result)
                    //         {

                    //         }
                    //      }
                    #endregion 1
                    #region        version 2

                    //Parametros_version33 parametros = new Parametros_version33();
                    //parametros.usuario = "AAA010101AAA";
                    //parametros.pass = "demo";
                    //parametros.xmlData = xmlData;
                    //try
                    //{
                    //    var client = new WebClient();
                    //    client.Headers.Add("Accept", "application/json");
                    //    client.Headers.Add("Content-Type", "application/x-www-form-urlencoded");
                    //    DataContractJsonSerializer placesSerializer = new DataContractJsonSerializer(typeof(Parametros_version33));
                    //    Parametros_version33 place = new Parametros_version33 { usuario = "AAA010101AAA", pass = "demo", xmlData = xmlData };
                    //    MemoryStream ms = new MemoryStream();
                    //    placesSerializer.WriteObject(ms, place);
                    //    byte[] json = ms.ToArray();
                    //    ms.Close();
                    //    string jsonString = System.Text.Encoding.UTF8.GetString(json, 0, json.Length);
                    //    client.Encoding = System.Text.Encoding.UTF8;
                    //    string urlBase = "http://clickfactura.mx:8090/ValidadorCfdi/api/rest/service/cfdi2";
                    //    string response = client.UploadString(urlBase, jsonString);
                    //    Console.WriteLine("POST places response " + response);
                    //}
                    //catch(Exception ex)
                    //{

                    //}
                    #endregion version 2
                    #region    version 3
                    Dictionary<string, object> postVariables = new Dictionary<string, object>();
                    string usuario = "AAA010101AAA";
                    string password = "demo";
                    postVariables.Add("usuario", usuario);
                    postVariables.Add("password", password);
                    postVariables.Add("xmlData", xmlData);
                    #region extrae un parametro
                    int resulta = 0;
                    Genericos.adT_Parametros adp = new Genericos.adT_Parametros();
                    List<Genericos.objT_Parametros> objp = new List<Genericos.objT_Parametros>();
                    string entorno = "";
                    bool simulado = false;
                    objp = adp.mABCT_Parametros(out resulta, 0, "simularValidacion", "Vacio", true, "ConsultaValor");
                    {
                        entorno = objp[0].ValorParametro.ToString();
                        simulado = entorno.Equals("1")==true?true:false;
                    }
                    #endregion extrae un parametro
                    if (simulado==true)
                    {
                        string[] error = { "" };
                        result.errores =error;
                        result.estadoSAT = "Vigente";
                        result.resultado = true;
                        result.tipoError = null;
                        result.version = "3.2";
                    }
                    else
                    {
                    result = RESTful_ClickFactura.FormularioHttpRequest.postSynchronous("http://clickfactura.mx:8090/ValidadorCfdi/api/rest/service/cfdi2", postVariables);
                    }
                    #endregion version 3
                    #region version 4
                    //List<KeyValuePair<string, object>> postVariables = new List<KeyValuePair<string, object>>();
                    //string usuario = "AAA010101AAA";
                    //string password = "demo";
                    //var pairs = new List<KeyValuePair<string, string>>
                    //            {
                    //                new KeyValuePair<string,string>("usuario",usuario),
                    //                new KeyValuePair<string,string>("password",password),
                    //                new KeyValuePair<string,string>("xmlData",xmlData.ToString())
                    //            };
                    //var content = new FormUrlEncodedContent(pairs);

                    //var client = new HttpClient { BaseAddress = new Uri("http://clickfactura.mx:8090") };

                    ////Lammar de forma sincrónica
                    //var response = client.PostAsync("/ValidadorCfdi/api/rest/service/cfdi2", content).Result; 
                    //        if (response.IsSuccessStatusCode)
                    //        {
                    //            string respuesta=response.Content.ToString();
                    //        }
                    #endregion version 4
                    break;
            }
            return result;
        }

        /// <summary>
        /// Genera la versión PDF para un archivo XML de la version 3.2
        /// </summary>
        /// <param name="pdf"></param>
        /// <param name="xml"></param>
        /// <param name="nombreArchivo"></param>
        private void GenerarArchivos(string pdf, string xml, string nombreArchivo)
        {
            try
            {
                var pdfBytes = System.Convert.FromBase64String(pdf);
                var xmlBytes = System.Convert.FromBase64String(xml);

                using (FileStream fileStream = new FileStream(nombreArchivo + ".pdf", FileMode.Create))
                {
                    fileStream.Write(pdfBytes, 0, pdfBytes.Length);
                    fileStream.Seek(0, SeekOrigin.Begin);
                }
                using (FileStream fileStream = new FileStream(nombreArchivo + ".xml", FileMode.Create))
                {
                    fileStream.Write(xmlBytes, 0, xmlBytes.Length);
                    fileStream.Seek(0, SeekOrigin.Begin);
                }
            }
            catch (Exception ex)
            {

                throw;
            }
        }

        /// <summary>
        /// Formatea una respuesta a formato JSON
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="uri"></param>
        /// <param name="requestBodyObject"></param>
        /// <param name="method"></param>
        /// <returns></returns>
        private T EjecutarServicioRestJson<T>(string uri, object requestBodyObject, string method = "POST")
        {
            var javaScriptSerializer = new JavaScriptSerializer();
            javaScriptSerializer.MaxJsonLength = 104857600; //200 MB unicode
            var request = (HttpWebRequest)WebRequest.Create(uri);
            request.Method = method;
            request.Accept = "application/json";
            request.ContentType = "application/json; charset=utf-8";

            //Serialize request object as JSON and write to request body
            if (requestBodyObject != null)
            {
                var requestBody = requestBodyObject.ToString();
                request.ContentLength = requestBody.Length;
                var streamWriter = new StreamWriter(request.GetRequestStream(), System.Text.Encoding.ASCII);
                streamWriter.Write(requestBody);
                streamWriter.Close();
            }

            var response = request.GetResponse();

            if (response == null)
            {
                return default(T);
            }

            //Read JSON response stream and deserialize
            var streamReader = new System.IO.StreamReader(response.GetResponseStream());
            var responseContent = streamReader.ReadToEnd().Trim();
            var jsonObject = javaScriptSerializer.Deserialize<T>(responseContent);
            return jsonObject;
        }
    }
}
//public class Resultado_version33
//{
//    public string status { get; set; }
//    public int error_code { get; set; }
//    public Dictionary<string, string> message { get; set; }
//}

public class Resultado_version33
{
    public bool resultado { get; set; }
    public string estadoSAT { get; set; }
    public string tipoError { get; set; }
    public string[] errores { get; set; }
    public string version { get; set; }
}

public class Parametros_version33
{
    public string usuario { get; set; }
    public string pass { get; set; }
    public string xmlData { get; set; }
}

namespace RESTful_ClickFactura
{
    class FormularioHttpRequest
    {
        public static string dictionaryToPostString(Dictionary<string, object> postVariables)
        {
            string postString = "";
            foreach (KeyValuePair<string, object> pair in postVariables)
            {
                postString += HttpUtility.UrlEncode(pair.Key) + "=" + HttpUtility.UrlEncode(pair.Value.ToString()) + "&";
            }

            return postString;
        }

        public static Dictionary<string, object> postStringToDictionary(string postString)
        {
            char[] delimiters = { '&' };
            string[] postPairs = postString.Split(delimiters);

            Dictionary<string, object> postVariables = new Dictionary<string, object>();
            foreach (string pair in postPairs)
            {
                char[] keyDelimiters = { '=' };
                string[] keyAndValue = pair.Split(keyDelimiters);
                if (keyAndValue.Length > 1)
                {
                    postVariables.Add(HttpUtility.UrlDecode(keyAndValue[0]),
                        HttpUtility.UrlDecode(keyAndValue[1]));
                }
            }

            return postVariables;
        }

        public static Resultado_version33 postSynchronous(string url, Dictionary<string, object> postVariables)
        {
            string result = null;
            Resultado_version33 respuesta = new Resultado_version33();
            try
            {
                string postString = dictionaryToPostString(postVariables);
                byte[] postBytes = System.Text.Encoding.ASCII.GetBytes(postString);

                System.Net.HttpWebRequest webRequest = (System.Net.HttpWebRequest)System.Net.WebRequest.Create(url);
                webRequest.Method = "POST";
                webRequest.ContentType = "application/x-www-form-urlencoded";
                webRequest.ContentLength = postBytes.Length;

                Stream postStream = webRequest.GetRequestStream();
                postStream.Write(postBytes, 0, postBytes.Length);
                postStream.Close();

                System.Net.HttpWebResponse webResponse = (System.Net.HttpWebResponse)webRequest.GetResponse();

                Console.WriteLine(webResponse.StatusCode);
                Console.WriteLine(webResponse.Server);

                Stream responseStream = webResponse.GetResponseStream();
                StreamReader responseStreamReader = new StreamReader(responseStream);
                result = responseStreamReader.ReadToEnd();

                try
                {
                    JavaScriptSerializer jss = new JavaScriptSerializer();
                    //var obj = (List<Dictionary<string, object>>)new JavaScriptSerializer().Deserialize(result, typeof(List<Dictionary<string, object>>));
                    respuesta = jss.Deserialize<Resultado_version33>(result);
                    // throw new Exception();
                }
                catch (Exception ex)
                {
                    string errores = ex.Message;
                    respuesta.resultado = false;
                    respuesta.estadoSAT = "Invalido";
                    respuesta.tipoError = "ERROR";
                    string _error = errores;
                    respuesta.errores[0] = _error;
                    respuesta.version = "0.0";
                }
            }
            catch (Exception ex)
            {
                string mensaje = ex.Message;
            }
            return respuesta;
        }



    }
}
