﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;
//using System.Web.UI;
using System.Xml.Linq;
using System.Globalization;
using System.IO;
using ClickFactura_Entidades;
using ClickFactura_Entidades.BD.Entidades;
using System.Data.EntityClient;

namespace ClickFactura_Facturacion.Clases
{
    public class cs_Estaticos
    {
        //public static bool EsAdministradorBafar(string quienEntro)
        //{
        //    bool respuesta=false;
        //    var ctx = new Desarrollo_CF();

        //        var r = (from t in ctx.T_Parametros where t.descParametro == "AdmonBafar" select t.valorParametro).FirstOrDefault();
        //        if (quienEntro.Equals(r.ToString()) == true)
        //            respuesta=true;
        //        else
        //            respuesta= false;

        //    return respuesta;
        //}

        public static string ConfigFecha(DateTime fecha, string separador, bool primerDia = false)
        {
            string _dia = primerDia ? "01" : fecha.Day.ToString("00");
            string _mes = fecha.Month.ToString("00");
            string _año = fecha.Year.ToString();

            return _dia + separador + _mes + separador + _año;
        }

        public static string GenerarRuta(List<string> datos, string nombreArchivo)
        {
            string tmp = string.Empty;
            foreach (var r in datos)
            {
                tmp = Path.Combine(tmp, r);
            }
            string rutaCompleta = Path.Combine(@"C:\TKPM\", tmp);
            if (!System.IO.Directory.Exists(rutaCompleta))
                System.IO.Directory.CreateDirectory(rutaCompleta);

            rutaCompleta = Path.Combine(rutaCompleta, nombreArchivo);
            return rutaCompleta;
        }
        public static DataTable existeCreaAcuerdoComercial(string RFC)
          {
              DataTable _tabla = new DataTable();
              Genericos.Genericos gen = new Genericos.Genericos();
              _tabla = gen.genericos_consultaCualquierTabla("Select * From Cat_AcuerdosComerciales");
              var q = from acu in _tabla.AsEnumerable() where acu.Field<string>("RFC").Equals(RFC) == true select acu;
              if (q != null)
                  {
                          if (q.Count() == 0)
                          {
                              return _tabla;
                          }
                          else
                          {
                              return _tabla;
                          }
                  }
              else
              {
                  return  null;
              }
          }

        public static void creaAcuerdoComercial(string RFC)
        {
            DataTable _tabla = new DataTable();
            Genericos.Genericos gen = new Genericos.Genericos();
            _tabla=gen.genericos_consultaCualquierTabla("Select * From Cat_AcuerdosComerciales");
            var q = from acu in _tabla.AsEnumerable() where acu.Field<string>("RFC").Equals(RFC) == true select acu;
            if (q != null)
                if (q.Count() == 0)
                {
                    Dictionary<string, string> parametros = new Dictionary<string, string>();
                    parametros.Add("IdProveedor", "0");
                    parametros.Add("RFC", RFC);
                    parametros.Add("Num_Proveedor", "Investigar");
                    string tabla = "SP_AcuerdosComerciales";
                    string P_Opcion = "Inserta";
                    System.Data.DataTable t = new System.Data.DataTable();
                    try
                    {
                        t= gen.executaSP_Generico(parametros, P_Opcion, tabla);
                        if (t != null)
                            if (t.Rows.Count > 0)
                            {
                               //###################
                               //Acuerdo ejecutado!!
                               //###################
                            }
                    }
                    catch(Exception ex)
                    {
                        //###################
                        //Ocurrío un problema ejecutando la inserción del acuerdo
                        //###################
                    }
                    //var r = SP_AcuerdosComerciales("0", RFC, "Investigar", "Inserta");
                }
        }


    }
}
