﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Clases.paraVerificacionFactura
{
    class adobjLeidosdelasFacturas
    {
        public List<objLeidoFactura> agregaobjeLeido(objLeidoFactura item, List<objLeidoFactura> listado)
        {
            List<objLeidoFactura> salida = new List<objLeidoFactura>();
            salida = listado;
            if (listado == null)
            {
                //Viene vacia
                salida.Add(item);
            }
            else
            {
                //Ya tenemos previos de esta Factura??
                var facturas = from x in salida
                               where x.Folio.Equals(item.Folio) == true
                               select x;
                if (facturas != null)
                    if (facturas.Count() > 0)
                    {
                        //Ya hay registros anteriores de esta Factura
                        var items = from x in facturas
                                    where x.Concepto.Equals(item.Concepto) == true
                                    select x;
                        if (items != null)
                            if (items.Count() == 0)
                            {
                                //Es NUEVO no existe el Concepto!!
                                salida.Add(item);
                            }
                            else
                            {
                                //Lo ignoramos por que ya estaba!!
                            }
                    }
                    else
                    {
                        //No hay nada de este Folio!!
                        salida.Add(item);
                    }
            }
            return salida;
        }

        public List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> agregaobjeLeido33(objLeidoFactura item, List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> listado)
        {
            //List<objLeidoFactura> salida = new List<objLeidoFactura>();
            List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> salida = new List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura>();
            ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura Nuevo = new ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura();
            #region empata datos
            //using (ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura nuevo=new ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura())
            //{
            //    nuevo.AplicaraProrrateo = item.AplicaraProrrateo;
            //}
            #endregion empata datos
            salida = listado;
            if (listado == null)
            {
            //    //Viene vacia
            //    salida.Add(item);
            //}
            //else
            //{
            //    //Ya tenemos previos de esta Factura??
            //    var facturas = from x in salida
            //                   where x.Folio.Equals(item.Folio) == true
            //                   select x;
            //    if (facturas != null)
            //        if (facturas.Count() > 0)
            //        {
            //            //Ya hay registros anteriores de esta Factura
            //            var items = from x in facturas
            //                        where x.Concepto.Equals(item.Concepto) == true
            //                        select x;
            //            if (items != null)
            //                if (items.Count() == 0)
            //                {
            //                    //Es NUEVO no existe el Concepto!!
            //                    salida.Add(item);
            //                }
            //                else
            //                {
            //                    //Lo ignoramos por que ya estaba!!
            //                }
            //        }
            //        else
            //        {
            //            //No hay nada de este Folio!!
            //            salida.Add(item);
            //        }
            }
            return salida;
        }
    }
}
