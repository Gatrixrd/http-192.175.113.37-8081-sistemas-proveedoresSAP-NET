﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Clases.paraVerificacionFactura
{
    public class obj_facturaAPasivo
    {
        string ordenCompra;

        public string OrdenCompra
        {
            get { return ordenCompra; }
            set { ordenCompra = value; }
        }

        string textoXML;
        public string TextoXML
        {
            get { return textoXML; }
            set { textoXML = value; }
        }

        string fechaFactura;

        public string FechaFactura
        {
            get { return fechaFactura; }
            set { fechaFactura = value; }
        }
        string folioFactura;

        public string FolioFactura
        {
            get { return folioFactura; }
            set { folioFactura = value; }
        }
        string piezas;

        public string Piezas
        {
            get { return piezas; }
            set { piezas = value; }
        }
        string importe;

        public string Importe
        {
            get { return importe; }
            set { importe = value; }
        }

        string noItem;

        public string NoItem
        {
            get { return noItem; }
            set { noItem = value; }
        }
        bool itemEstatus;

        public bool ItemEstatus
        {
            get { return itemEstatus; }
            set { itemEstatus = value; }
        }

        string noRecepcion;

        public string NoRecepcion
        {
            get { return noRecepcion; }
            set { noRecepcion = value; }
        }

        string nombreArchivoXML;

        public string NombreArchivoXML
        {
            get { return nombreArchivoXML; }
            set { nombreArchivoXML = value; }
        }


        string posicion;

        public string Posicion
        {
            get { return posicion; }
            set { posicion = value; }
        }

        string rFC;

        public string RFC
        {
            get { return rFC; }
            set { rFC = value; }
        }

        string año;

        public string Año
        {
            get { return año; }
            set { año = value; }
        }

        string path;

        public string Path
        {
            get { return path; }
            set { path = value; }
        }

        string rFC_Receptor;

        public string RFC_Receptor
        {
            get { return rFC_Receptor; }
            set { rFC_Receptor = value; }
        }

        List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> conceptos = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto>();

        public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos
        {
            get { return conceptos; }
            set { conceptos = value; }
        }

        string uUID;

        public string UUID
        {
            get { return uUID; }
            set { uUID = value; }
        }

        string ivaTrasladadoTotal;

        public string IvaTrasladadoTotal
        {
            get { return ivaTrasladadoTotal; }
            set { ivaTrasladadoTotal = value; }
        }


        decimal descuento;

        public decimal Descuento
        {
            get { return descuento; }
            set { descuento = value; }
        }
        string serie;

        public string Serie
        {
            get { return serie; }
            set { serie = value; }
        }

        decimal importeNotaCredito = 0;

        public decimal ImporteNotaCredito
        {
            get { return importeNotaCredito; }
            set { importeNotaCredito = value; }
        }

        string nombreArchivo;

        public string NombreArchivo
        {
            get { return nombreArchivo; }
            set { nombreArchivo = value; }
        }


        string moneda;

        public string Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }

        string impuestoRetenido = "0";

        public string ImpuestoRetenido
        {
            get { return impuestoRetenido; }
            set { impuestoRetenido = value; }
        }

        //Se agregan el 17 Julio 2015 GRD
        //Para administrar mejor el tema de Prorrateos
        string importesFueron = "Iguales";

        public string ImportesFueron
        {
            get { return importesFueron; }
            set { importesFueron = value; }
        }
        string reglasAplicadas = "";

        public string ReglasAplicadas
        {
            get { return reglasAplicadas; }
            set { reglasAplicadas = value; }
        }
        double diferenciaImportes = 0;

        public double DiferenciaImportes
        {
            get { return diferenciaImportes; }
            set { diferenciaImportes = value; }
        }
        bool aplicaraProrrateo = false;

        public bool AplicaraProrrateo
        {
            get { return aplicaraProrrateo; }
            set { aplicaraProrrateo = value; }
        }

        string impuesto = "V0";

        public string Impuesto
        {
            get { return impuesto; }
            set { impuesto = value; }
        }

        string subTotalXML;

        public string SubTotalXML
        {
            get { return subTotalXML; }
            set { subTotalXML = value; }
        }
        string importeRetencionFlete;

        public string ImporteRetencionFlete
        {
            get { return importeRetencionFlete; }
            set { importeRetencionFlete = value; }
        }
        string retencionISRRenta;

        public string RetencionISRRenta
        {
            get { return retencionISRRenta; }
            set { retencionISRRenta = value; }
        }
        string retencionIVARenta;

        public string RetencionIVARenta
        {
            get { return retencionIVARenta; }
            set { retencionIVARenta = value; }
        }

        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos impuestos;

        public ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos Impuestos
        {
            get { return impuestos; }
            set { impuestos = value; }
        }

        string esdocumentoReferencia = "N";

        public string EsdocumentoReferencia
        {
            get { return esdocumentoReferencia; }
            set { esdocumentoReferencia = value; }
        }

        double importeRecepcionOrigen = 0;

        public double ImporteRecepcionOrigen
        {
            get { return importeRecepcionOrigen; }
            set { importeRecepcionOrigen = value; }
        }

        double importeArticulosconIVA = 0;

        public double ImporteArticulosconIVA
        {
            get { return importeArticulosconIVA; }
            set { importeArticulosconIVA = value; }
        }

        string documento_Referencia;

        public string Documento_Referencia
        {
            get { return documento_Referencia; }
            set { documento_Referencia = value; }
        }
        double importeUnitario;

        public double ImporteUnitario
        {
            get { return importeUnitario; }
            set { importeUnitario = value; }
        }

        double recepcionValia = 0;

        public double RecepcionValia
        {
            get { return recepcionValia; }
            set { recepcionValia = value; }
        }

        string posicion_Documento_Material;

        public string Posicion_Documento_Material
        {
            get { return posicion_Documento_Material; }
            set { posicion_Documento_Material = value; }
        }

        double notasCredito;

        public double NotasCredito
        {
            get { return notasCredito; }
            set { notasCredito = value; }
        }
        string num_Proveedor = "";

        public string Num_Proveedor
        {
            get { return num_Proveedor; }
            set { num_Proveedor = value; }
        }
        string tipoFactura = "Normal";

        public string TipoFactura
        {
            get { return tipoFactura; }
            set { tipoFactura = value; }
        }
        double importeDocumento = 0;

        public double ImporteDocumento
        {
            get { return importeDocumento; }
            set { importeDocumento = value; }
        }


        public obj_facturaAPasivo()
        {

        }

        /// <summary>
        /// Objeto que almacena la Información extraida de la Factura XML más otra información de impacto al generar el pasivo
        /// </summary>
        /// <param name="_ordenCompra"></param>
        /// <param name="_textoXML"></param>
        /// <param name="_fechaFactura"></param>
        /// <param name="_folioFactura"></param>
        /// <param name="_piezas"></param>
        /// <param name="_importe">Total Factura</param>
        /// <param name="_noItem"></param>
        /// <param name="_itemEstatus"></param>
        /// <param name="_nombreArchivoXML"></param>
        /// <param name="_Posicion"></param>
        /// <param name="_Conceptos"></param>
        /// <param name="_UUID"></param>
        /// <param name="_RFC"></param>
        /// <param name="_Path"></param>
        /// <param name="_NoRecepcion"></param>
        /// <param name="_IvaTrasladadoTotal">Impuesto muy importante pára identicar escenarios como: Fletes</param>
        /// <param name="_descuento"></param>
        /// <param name="_RFC_Receptor"></param>
        /// <param name="_Serie"></param>
        /// <param name="_ImporteNotaCredito"></param>
        /// <param name="_NombreArchivo"></param>
        /// <param name="_Moneda"></param>
        /// <param name="_ImpuestoRetenido"></param>
        /// <param name="_ImportesFueron">Especifica si fueron Iguales, facturaArriba,facturaAbajo</param>
        /// <param name="_ReglasAplicadas">Almacenara los detalles acerca de si para por +- $50, por % sobre valor del importe vs valor total de la  Factura, +- un % definido por Bafar</param>
        /// <param name="_DiferenciaImportes">Almacenara la diferencia que exista entre los importes de la factura y lo que esta recepcionado en SAP al Evaluar Importes</param>
        /// <param name="_AplicaraProrrateo">Booleano que sugiere si se aplicara o no prorrateo más adelante</param>
        /// <param name="_Impuesto">Booleano que sugiere si se aplicara o no prorrateo más adelante</param>
        /// <param name="_Impuestos">Objeto Global de Impuestos</param>
        /// <param name="_esdocumentoReferencia">Indica si el valor ID se obtuvo de Documento Referencia</param>
        ///  <param name="_ImporteRecepcionOrigen">Importe de la Recepción exactamente igual como lo necesita SAP </param> ImporteArticulosconIVA
        ///  <param name="ImporteArticulosconIVA">Importe de los articulos que si tenian IVA </param> 
        ///  <param name="Documento_Referencia">Valor de la columna Documento Referencia en Detalle Recepciones </param> 
        ///  <param name="ImporteUnitario">Valor de la columna Importe en Detalle Orden de Compra </param> 
        ///  <param name="Posicion_Documento_Material ">Posicion del Sub Recepción del Material dentro d ela misma Recepción, es ajueno a su posición en la orden de compra y a la posición de como fue Recepcionado </param> 
        ///   <param name="NotasCredito ">Importe de la Nota de Credito </param> 
        ///   <param name="Num_Proveedor ">Numero de Proveedor , se utiliza principalmente en Importaciones </param> 
        ///   <param name="TipoFactura">Tipo de Factura que se calcula se esta trabajando: Normal,Flete,Renta,Importacion,Ticket,etc </param> 
        public obj_facturaAPasivo(string _ordenCompra, string _textoXML, string _fechaFactura, string _folioFactura, string _piezas, string _importe, string _noItem, bool _itemEstatus, string _nombreArchivoXML, string _Posicion, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> _Conceptos, string _UUID, string _RFC, string _Path, string _NoRecepcion, string _IvaTrasladadoTotal, decimal _descuento, string _RFC_Receptor, string _Serie, decimal _ImporteNotaCredito, string _NombreArchivo, string _Moneda, string _ImpuestoRetenido, string _ImportesFueron, string _ReglasAplicadas, double _DiferenciaImportes, bool _AplicaraProrrateo, string _Impuesto, string _SubTotalXML, string _ImporteRetencionFlete, string _RetencionISRRenta, string _RetencionIVARenta, ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos _Impuestos, string _esdocumentoReferencia, double _ImporteRecepcionOrigen, double _ImporteArticulosconIVA, string _Documento_Referencia, double _ImporteUnitario, double _RecepcionValia, string _Posicion_Documento_Material, double _NotaCredito, string _Num_Proveedor, string _TipoFactura, double _ImporteDocumento)
        {
            OrdenCompra = _ordenCompra;
            TextoXML = _textoXML;
            FechaFactura = _fechaFactura;
            FolioFactura = _folioFactura;
            Piezas = _piezas;
            Importe = _importe;
            NoItem = _noItem;
            ItemEstatus = _itemEstatus;
            NombreArchivoXML = _nombreArchivoXML;
            Posicion = _Posicion;
            Conceptos = _Conceptos;
            UUID = _UUID;
            RFC = _RFC;
            Path = _Path;
            NoRecepcion = _NoRecepcion;
            IvaTrasladadoTotal = _IvaTrasladadoTotal;
            Descuento = _descuento;
            RFC_Receptor = _RFC_Receptor;
            Serie = _Serie;
            ImporteNotaCredito = _ImporteNotaCredito;
            NombreArchivo = _NombreArchivo;
            Moneda = _Moneda;
            ImpuestoRetenido = _ImpuestoRetenido;
            ImportesFueron = _ImportesFueron;
            ReglasAplicadas = _ReglasAplicadas;
            DiferenciaImportes = _DiferenciaImportes;
            AplicaraProrrateo = _AplicaraProrrateo;
            Impuesto = _Impuesto;
            SubTotalXML = _SubTotalXML;
            ImporteRetencionFlete = _ImporteRetencionFlete;
            RetencionISRRenta = _RetencionISRRenta;
            RetencionIVARenta = _RetencionIVARenta;
            Impuestos = _Impuestos;
            EsdocumentoReferencia = _esdocumentoReferencia;
            ImporteRecepcionOrigen = _ImporteRecepcionOrigen;
            ImporteArticulosconIVA = _ImporteArticulosconIVA;
            Documento_Referencia = _Documento_Referencia;
            ImporteUnitario = _ImporteUnitario;
            RecepcionValia = _RecepcionValia;
            Posicion_Documento_Material = _Posicion_Documento_Material;
            NotasCredito = _NotaCredito;
            Num_Proveedor = _Num_Proveedor;
            TipoFactura = _TipoFactura;
            ImporteDocumento = _ImporteDocumento;
            IvaTrasladadoTotal = _IvaTrasladadoTotal;
        }

    }
}
