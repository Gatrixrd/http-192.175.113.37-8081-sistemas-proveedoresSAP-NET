﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Clases.paraVerificacionFactura
{
    class Seguridad
    {
    }
}
