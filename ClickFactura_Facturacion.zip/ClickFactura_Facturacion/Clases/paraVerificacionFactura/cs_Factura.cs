﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml;


namespace ClickFactura_Facturacion.Clases.paraVerificacionFactura
{
    public class cs_Factura
    {

        ClickFactura_Facturacion.wsBafar.Servicio_ClickFacturaClient wsbafar;
        public cs_Factura()
        {
            //wsbafar = new Servicio_ClickFacturaClient();
        }
        //public bool Lectura_FacturaExpress(String Archivo, ref List<objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        //{
        //    try
        //    {
        //        System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(Comprobante));
        //        bool seCargo = false;
        //        #region Modificaciones
        //        Comprobante Factura = new Comprobante();
        //        //bajaADiscoDuro(ref Ruta,ref seCargo);
        //        try
        //        {
        //            System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
        //            Comprobante FacturaOriginal = (Comprobante)Serializer.Deserialize(Lector);
        //            Factura = FacturaOriginal;
        //            Lector.Close();
        //            //Lector.Dispose();
        //        }
        //        catch
        //        {
        //            bajaADiscoDuro(ref Ruta, ref seCargo);
        //            System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
        //            Comprobante FacturaModificada = (Comprobante)Serializer.Deserialize(Lector);
        //            Factura = FacturaModificada;
        //            Lector.Close();
        //           //Lector.Dispose();
        //        }

        //        System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
        //        xdoc.Load(Ruta);

        //        #endregion Modificaciones


        //        #region Codigo Original
        //        //System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
        //        //Comprobante Factura = (Comprobante)Serializer.Deserialize(Lector);
        //        //System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
        //        //xdoc.Load(Ruta);
        //        #endregion Codigo Original

        //        #region extrae la Pieas o Cantidades
        //        System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
        //        System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
        //        System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
        //        XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
        //        int i = 0;
        //        Decimal cantidad = 0;
        //        string concepto;
        //        Decimal importe = 0;
        //        Decimal cantidadGlobal = 0;
        //        Decimal importeGlobal = 0;
        //        string unidad = "";
        //        List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
        //        foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
        //        {
        //            ComprobanteConcepto Concepto = new ComprobanteConcepto();
        //            try
        //            {
        //                cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
        //                cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
        //            }
        //            catch
        //            {
        //                cantidadGlobal = cantidadGlobal + 0;
        //                cantidad = 0;
        //            }
        //            try
        //            {
        //                concepto = NodoDetalladoConcepto[i].Attributes["descripcion"].Value;
        //            }
        //            catch
        //            {
        //                concepto = "No proporcionado";
        //            }
        //            try
        //            {
        //                importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
        //                importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
        //            }
        //            catch
        //            {
        //                importeGlobal = importeGlobal + 0;
        //                importe = 0;
        //            }
        //            try
        //            {
        //                unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
        //            }
        //            catch
        //            {
        //                unidad = "No proporcionado";
        //            }
        //            ComprobanteConcepto c = new  ComprobanteConcepto();
        //            c.cantidad = cantidad;
        //            c.descripcion = concepto;
        //            c.importe = importe;
        //            c.unidad = unidad;
        //            Conceptos.Add(c);
        //            i++;
        //        }
        //        string UUID = "";
        //        foreach (XmlElement nodo in NodoSecundarioComplemento)
        //        {
        //            try
        //            {
        //                UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
        //            }
        //            catch
        //            {
        //                UUID = "No proporcionado";
        //            }
        //        }
        //        _UUID = UUID;
        //        RFCEmisor = Factura.Emisor.rfc;
        //        RFCReceptor = Factura.Receptor.rfc;

        //        #region envia Almacenar
        //        objLeidoFactura obj = new objLeidoFactura();
        //        obj.Archivo = Archivo;
        //        obj.Folio = Factura.folio;
        //        _FolioFactura = Factura.folio;
        //        obj.Fecha =cs_Estaticos.ConfigFecha(Factura.fecha, "/");
        //        obj.Timporte = Factura.total.ToString();
        //        int canti = Convert.ToInt32(cantidadGlobal);
        //        obj.Tpiezas = canti.ToString(); ;
        //        obj.Concepto = "";
        //        obj.XmlaTexto = xdoc.InnerXml;

        //        System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
        //        string myString = myFile.ReadToEnd();
        //        myFile.Close();
        //        myFile.Dispose();
        //        obj.XmlaTexto = myString;


        //        #region valida el Documento
        //        wsbafar = new wsBafar.Servicio_ClickFacturaClient();//BAFAR.wsBafar.Servicio_ClickFacturaClient();
        //        bool xmlValido = false;
        //        bool xmlDocumento = false;
        //        System.Data.DataSet ds = new System.Data.DataSet();

        //        //Core.Seguridad security = new Core.Seguridad();

        //        //BAFAR.wsBafar.Cadena_XML Objeto_XML = new BAFAR.wsBafar.Cadena_XML();
        //        //BAFAR.wsBafar.Resultado_XML Resulta = new BAFAR.wsBafar.Resultado_XML();
        //        wsBafar.Cadena_XML Objeto_XML = new wsBafar.Cadena_XML();
        //        wsBafar.Resultado_XML Resulta = new wsBafar.Resultado_XML();
        //        String Code = Base64Encode(xdoc.InnerXml);

        //        Objeto_XML.Usuario = "demo";
        //        //Objeto_XML.RFC = "AAA010101AAA";
        //        Objeto_XML.Password = "DEMO";
        //        Objeto_XML.Factura_XML = Code;
        //        //Objeto_XML.Cadena = Code;
        //        try
        //        {
        //            Resulta = wsbafar.Valida_XML(Objeto_XML);

        //            String SAT = Resulta.Resultado_SAT;
        //            if (Resulta.Correcta == true)
        //            {
        //                xmlValido = true;
        //                xmlDocumento = true;
        //                obj.Error = Resulta.Resultado == null ? "Factura válida." : "Factura válida";
        //                _UUID = Resulta.UUID;
        //                resultadoUltimoEvaluado = true;
        //            }
        //            else
        //            {
        //                if (Resulta.Resultado.Equals("Comentario: El sello del emisor es invalido ;") == true)
        //                {
        //                    xmlValido = true;
        //                    xmlDocumento = true;
        //                    resultadoUltimoEvaluado = true;
        //                    obj.Error = "Se realiza la excepción de aceptar la factura a pesar del error: Comentario: El sello del emisor es invalido.";
        //                }
        //                else
        //                {
        //                    xmlValido = false;
        //                    xmlDocumento = false;
        //                    resultadoUltimoEvaluado = false;
        //                    obj.Error = Resulta.Resultado;
        //                }
        //                _UUID = extraeUUID(Factura);
        //            }
        //            obj.ImporteTrasladado = "0";// Resulta.Factura.impuestosField.totalImpuestosTrasladadosField.ToString();
        //            obj.SubTotal = Factura.subTotal.ToString();
        //        }
        //        catch (Exception ex)
        //        {
        //            xmlValido = false;
        //            xmlDocumento = false;
        //            obj.Error = "Problema con el servicio : " + ex.Message;
        //        }

        //        //xmlValido = Resulta.Resultado;
        //        //xmlDocumento = cliente.Valida_Documento(xdoc.InnerXml);
        //        obj.EstructuraValida = xmlDocumento;
        //        obj.ValidoSAT = xmlValido;
        //        obj.Conceptos = Conceptos;
        //        obj.UUID = Resulta.UUID == null ? _UUID : Resulta.UUID;
        //        obj.RFC = Factura.Emisor.rfc;
        //        obj.Moneda = "MXN";// Factura.Moneda;
        //        obj.Descuento = Factura.descuento;
        //        obj.RFC_Receptor = Factura.Receptor.rfc;
        //        obj.Serie = Factura.serie;
        //        obj.Path = Ruta;
        //        obj.NombreArchivo = Archivo;
        //        obj.ImporteRetenido = Factura.Impuestos.totalImpuestosRetenidos.ToString();
        //        try
        //        {
        //            obj.ImporteTrasladado = Factura.Impuestos.totalImpuestosTrasladados.ToString();
        //            if (Factura.Impuestos.Traslados != null)
        //            {
        //                foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
        //                {
        //                    if (impuestosTrasladados.importe > 0)
        //                        obj.ImporteTrasladado = impuestosTrasladados.importe.ToString();
        //                }
        //            }
        //        }
        //        catch
        //        {
        //            obj.ImporteTrasladado = "0";
        //        }
        //        obj.Impuestos = Factura.Impuestos;

        //        #endregion valida el Documento

        //        adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
        //        listadoA = ad.agregaobjeLeido(obj, listadoA);
        //        #endregion envia Almacenar
        //        #endregion Extraelas piezas o cantidades

        //        //try
        //        //{
        //        //    if (System.IO.File.Exists(Ruta))
        //        //    {
        //        //        System.IO.File.Delete(Ruta);
        //        //    }
        //        //}
        //        //catch
        //        //{

        //        //}

        //        return true;
        //    }
        //    catch (Exception ex)
        //    {
        //        objLeidoFactura obj = new objLeidoFactura();
        //        obj.EstructuraValida = false;
        //        obj.ValidoSAT = false;
        //        obj.Error = "Problema con la factura: " + ex.Message;
        //        adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
        //        listadoA = ad.agregaobjeLeido(obj, listadoA);
        //        //if (System.IO.File.Exists(Ruta))
        //        //{
        //        //    System.IO.File.Delete(Ruta);
        //        //}
        //        return false;
        //    }

        //}

        public bool Lectura_FacturaExpress(String Archivo, ref List<ClickFactura_Entidades.BD.Entidades.T_objLeidoFactura> listadoA, string Ruta, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, ref string _UUID, ref string _FolioFactura)
        {
            bool xmlValido = false;
            bool xmlDocumento = false;
            string version = "3.3";
            try
            {
                #region        VERSION 3.3
                System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante));
                //System.Xml.Serialization.XmlSerializer Serializer = _Serializer;
                bool seCargo = false;
                #region Recostruyendo el XML cargado
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante();
                try
                {
                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaOriginal = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaOriginal;
                }
                catch
                {
                    //                                                bajaADiscoDuro(ref Ruta, ref seCargo);

                    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante FacturaModificada = (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante)Serializer.Deserialize(Lector);
                    Factura = FacturaModificada;
                }

                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);
                #endregion Recostruyendo el XML cargado

                #region Determinando la versión
                version3_3.Clases33.paraVerificacionFactura33.Seguridad security = new version3_3.Clases33.paraVerificacionFactura33.Seguridad();

                string texto = xdoc.InnerXml;
                texto = System.Text.RegularExpressions.Regex.Replace(texto, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                String Code = security.Base64Encode(texto);
                int largo = Code.Length;
                List<string> subXML = new List<string>();

                if (largo >= 6700)
                {
                    int chunkSize = 6700;
                    int stringLength = Code.Length;
                    for (int ii = 0; ii < stringLength; ii += chunkSize)
                    {
                        if (ii + chunkSize > stringLength) chunkSize = stringLength - ii;
                        subXML.Add(Code.Substring(ii, chunkSize));

                    }
                }

                #region Envio  a la validación RESTful 3.3
                cs_Factura csfactura = new cs_Factura();
                ClickFactura_Facturacion.version3_3.Clases33.webserviceRESTFull3_3 version33 = new ClickFactura_Facturacion.version3_3.Clases33.webserviceRESTFull3_3();
                Resultado_version33 Result;//=new Resultado();
                int operacion = 1;
                try
                {
                    Result = version33.SendWebService33(Ruta, operacion, Code);
                    version = Result.version;
                    if (version == "3.2")
                    {
                        goto Version32;
                    }
                    if (Result.version != "0.0" && Result.version != "3.2")
                    {
                        String SAT = Result.estadoSAT;
                        if (Result.resultado == true)
                        {
                            xmlValido = true;
                            xmlDocumento = true;
                            //obj.Error = Result.tipoError == null ? "Factura válida." : "Factura válida";
                            _UUID = csfactura.extraeUUID33(Factura);
                            resultadoUltimoEvaluado = true;
                        }
                        else
                        {
                            xmlValido = false;
                            xmlDocumento = false;
                            resultadoUltimoEvaluado = false;
                            //foreach(var s in Result.errores.ToList())
                            // {
                            //     obj.Error = obj.Error + s;
                            // }
                            _UUID = csfactura.extraeUUID33(Factura);
                        }
                    }
                    else
                    {
                        if (Result.version != "3.2")
                        {
                            xmlValido = false;
                            xmlDocumento = false;
                            resultadoUltimoEvaluado = false;
                            //foreach (var s in Result.errores.ToList())
                            //{
                            //    obj.Error = " ==> " + obj.Error + s;
                            //}
                            _UUID = extraeUUID33(Factura);
                        }
                        else
                        {
                            goto Version32;
                        }
                    }
                }
                catch (Exception ex)
                {
                    xmlValido = false;
                    xmlDocumento = false;
                    //obj.Error = "Problema con el servicio : " + ex.Message;
                    if (ex.Message.Contains("There was no endpoint listening at"))
                    {
                        //obj.Error = "El servicio de validación de Facturas de Click Factura esta caido, por favor reporte a saclaracionescxp@bafar.com.mx en BAFAR o a Soporte del Portal BAFAR";
                    }
                    //There was no endpoint listening at http://192.175.113.36:8090/wsValidacion/validaXmlService that could accept the message. This is often caused by an incorrect address or SOAP action. See InnerException, if present, for more details.
                }

                #region        Contabiliza la validacion con el servicio Click Factura
                try
                {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura contabiliza = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura();
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura.obj_registraValidacion porEnviar = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.cs_Validaciones_ClickFactura.obj_registraValidacion();
                    porEnviar.emisor = Factura.Emisor.Rfc;
                    porEnviar.receptor = Factura.Receptor.Rfc;
                    porEnviar.fechaValidacion = DateTime.UtcNow.ToString();
                    porEnviar.fechaDocumento = Factura.Fecha.ToString();
                    porEnviar.serie = Factura.Serie;
                    porEnviar.folio = Factura.Folio;
                    porEnviar.estatusSAT = "Pendiente";// Resulta.Resultado_SAT;
                    porEnviar.estatus = "Pendiente";// Resulta.Correcta.ToString();
                    //contabiliza.registraValidacion(porEnviar);
                }
                catch (Exception ex)
                {

                }
                #endregion Contabiliza la validacion con el servicio Click Factura

                #endregion Envio a la validación RESTful 3.3
                #endregion Determinando la versión

                #region Extrayendo las Piezas o Cantidades
                System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                int i = 0;
                Decimal cantidad = 0;
                string concepto;
                Decimal importe = 0;
                Decimal cantidadGlobal = 0;
                Decimal importeGlobal = 0;
                string unidad = "";
                List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto> Conceptos = new List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto>();
                List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto> Conceptos33 = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto>();
                //ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.
                foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto Concepto = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                    try
                    {
                        cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Cantidad"].Value), 2);
                        cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Cantidad"].Value), 2);
                    }
                    catch
                    {
                        cantidadGlobal = cantidadGlobal + 0;
                        cantidad = 0;
                    }
                    try
                    {
                        concepto = NodoDetalladoConcepto[i].Attributes["Descripcion"].Value;
                    }
                    catch
                    {
                        concepto = "No proporcionado";
                    }
                    try
                    {
                        importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Importe"].Value), 2);
                        importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["Importe"].Value), 2);
                    }
                    catch
                    {
                        importeGlobal = importeGlobal + 0;
                        importe = 0;
                    }
                    try
                    {
                        unidad = NodoDetalladoConcepto[i].Attributes["Unidad"].Value;
                    }
                    catch
                    {
                        unidad = "No proporcionado";
                    }
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto c = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                    c.Cantidad = cantidad;
                    c.Descripcion = concepto;
                    c.Importe = importe;
                    c.Unidad = unidad;
                    Conceptos33.Add(c);
                    i++;
                }
                #endregion Extrayendo las Piezas o Cantidades

                #region Intentando extraer el UUID
                if (_UUID == "")
                {
                    string UUID = "";
                    foreach (XmlElement nodo in NodoSecundarioComplemento)
                    {
                        try
                        {
                            UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                        }
                        catch
                        {
                            UUID = "No proporcionado";
                        }
                    }
                    _UUID = UUID;
                }
                #endregion Intentando extraer el UUID

                #region Extrayendo el IEPS
                string IEPS = "No proporcionado";
                try
                {
                    foreach (ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado imp in Factura.Impuestos.Traslados)
                    {
                        decimal importeIEPS = 0;
                        try
                        {
                            if (imp.Impuesto.ToString().Contains("IEPS") == true || imp.Impuesto.ToString().Contains("Ieps") == true || imp.Impuesto.ToString().Contains("ieps") == true)
                            {
                                IEPS = imp.Impuesto.ToString();
                                importeIEPS = imp.Importe;
                                if (importeIEPS <= 0)
                                {
                                    IEPS = "No proporcionado";
                                }
                            }
                        }
                        catch
                        {
                            IEPS = "No proporcionado";
                        }
                    }
                }
                catch
                {
                    IEPS = "No proporcionado";
                }
                #endregion Extrayendo el IEPS

                RFCEmisor = Factura.Emisor.Rfc;
                RFCReceptor = Factura.Receptor.Rfc;

                #region        Construyendo el Objeto Factura de SALIDA

                #region recopilando priemra sección de Información del XML
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura obj = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura();
                obj.Archivo = Archivo;
                obj.Folio = Factura.Folio;
                _FolioFactura = Factura.Folio;
                obj.Fecha = Factura.Fecha.ToString();
                obj.Timporte = Factura.Total.ToString();
                int canti = Convert.ToInt32(cantidadGlobal);
                obj.Tpiezas = canti.ToString(); ;
                obj.Concepto = "";
                obj.XmlaTexto = xdoc.InnerXml;

                System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
                string myString = myFile.ReadToEnd();
                obj.XmlaTexto = myString;

                System.Data.DataSet ds = new System.Data.DataSet();
                #endregion recopilando priemra sección de Información del XML

                #region recolilando la segunda Seccion de informacion del XML
                obj.ImporteTrasladado = "0";
                obj.SubTotal = Factura.SubTotal.ToString();
                obj.EstructuraValida = xmlDocumento;
                obj.ValidoSAT = xmlValido;
                obj.Conceptos = Conceptos33;
                obj.UUID = "Pendiente"; //Resulta.UUID == null ? _UUID : Resulta.UUID;
                obj.RFC = Factura.Emisor.Rfc;
                obj.Moneda = "MXN"; //Obsoleto 14 Junio 2017 GRD Factura.Moneda;
                obj.Descuento = Factura.Descuento == null ? 0 : Factura.Descuento;
                obj.RFC_Receptor = Factura.Receptor.Rfc;
                obj.Serie = Factura.Serie;
                obj.Path = Ruta;
                obj.NombreArchivo = Archivo;
                obj.ImporteRetenido = Factura.Impuestos.TotalImpuestosRetenidos.ToString();
                if (ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("desa_TKPM") == true || ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion.Contains("qu_HANA_bafar") == true)
                    obj.UUID = "DePruebas" + Convert.ToString((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                double acumulado = 0;
                try
                {
                    obj.ImporteTrasladado = Factura.Impuestos.TotalImpuestosTrasladados.ToString();
                    if (Factura.Impuestos.Traslados != null)
                    {

                        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                        {
                            if (impuestosTrasladados.Importe > 0)
                                acumulado = acumulado + Convert.ToDouble(impuestosTrasladados.Importe.ToString());
                        }
                    }
                }
                catch
                {
                    acumulado = 0;
                }
                obj.ImporteTrasladado = acumulado.ToString();
                obj.Impuestos33 = Factura.Impuestos; //Obsoleto 14 Junio 2017 GRD Factura.Impuestos;
                obj.Impuestos = null;
                obj.Version = version;
                adobjLeidosdelasFacturas ad = new adobjLeidosdelasFacturas();
               //--- listadoA = ad.agregaobjeLeido(obj, listadoA);
                #endregion recolilando la segunda Seccion de informacion del XML

                #endregion Construyendo el Objeto Factura de SALIDA

                #endregion VERSION 3.3
            }
            catch (Exception ex)
            {
                //Genericos.objLeidoFactura obj = new Genericos.objLeidoFactura();
                //obj.EstructuraValida = false;
                //obj.ValidoSAT = false;
                //obj.Error = "Problema con la factura: " + ex.Message;
                //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                //listadoA = ad.agregaobjeLeido(obj, listadoA);
            }
        // ######################################################################  V E R S I O N    3. 2
        Version32:
            if (version == "3.2")
            {
                #region Sobre operaciones con Version 3.2
                try
                {
                    #region VERSION 3.2
                    //System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(Comprobante));
                    //bool seCargo = false;
                    //#region Modificaciones
                    //Comprobante Factura = new Comprobante();
                    ////bajaADiscoDuro(ref Ruta,ref seCargo);
                    //try
                    //{
                    //    //using (StreamReader reader = new StreamReader(Ruta))
                    //    //{
                    //    //    Comprobante FacturaOriginal = (Comprobante)Serializer.Deserialize(reader);
                    //    //    Factura = FacturaOriginal;
                    //    //}
                    //    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    //    Comprobante FacturaOriginal = (Comprobante)Serializer.Deserialize(Lector);
                    //    Factura = FacturaOriginal;
                    //}
                    //catch
                    //{
                    //    bajaADiscoDuro(ref Ruta, ref seCargo);
                    //    System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    //    Comprobante FacturaModificada = (Comprobante)Serializer.Deserialize(Lector);
                    //    Factura = FacturaModificada;
                    //}

                    //System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                    //xdoc.Load(Ruta);
                    //#endregion Modificaciones

                    //#region Codigo Original
                    ////System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                    ////Comprobante Factura = (Comprobante)Serializer.Deserialize(Lector);
                    ////System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                    ////xdoc.Load(Ruta);
                    //#endregion Codigo Original

                    //#region extrae la Pieas o Cantidades
                    //System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                    //System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                    //System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                    //XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                    //int i = 0;
                    //Decimal cantidad = 0;
                    //string concepto;
                    //Decimal importe = 0;
                    //Decimal cantidadGlobal = 0;
                    //Decimal importeGlobal = 0;
                    //string unidad = "";
                    //List<ComprobanteConcepto> Conceptos = new List<ComprobanteConcepto>();
                    //foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                    //{
                    //    ComprobanteConcepto Concepto = new ComprobanteConcepto();
                    //    try
                    //    {
                    //        cantidadGlobal = cantidadGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                    //        cantidad = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                    //    }
                    //    catch
                    //    {
                    //        cantidadGlobal = cantidadGlobal + 0;
                    //        cantidad = 0;
                    //    }
                    //    try
                    //    {
                    //        concepto = NodoDetalladoConcepto[i].Attributes["descripcion"].Value;
                    //    }
                    //    catch
                    //    {
                    //        concepto = "No proporcionado";
                    //    }
                    //    try
                    //    {
                    //        importeGlobal = importeGlobal + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                    //        importe = Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                    //    }
                    //    catch
                    //    {
                    //        importeGlobal = importeGlobal + 0;
                    //        importe = 0;
                    //    }
                    //    try
                    //    {
                    //        unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
                    //    }
                    //    catch
                    //    {
                    //        unidad = "No proporcionado";
                    //    }
                    //    ComprobanteConcepto c = new ComprobanteConcepto();
                    //    c.cantidad = cantidad;
                    //    c.descripcion = concepto;
                    //    c.importe = importe;
                    //    c.unidad = unidad;
                    //    Conceptos.Add(c);
                    //    i++;
                    //}
                    //string UUID = "";
                    //foreach (XmlElement nodo in NodoSecundarioComplemento)
                    //{
                    //    try
                    //    {
                    //        UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                    //    }
                    //    catch
                    //    {
                    //        UUID = "No proporcionado";
                    //    }
                    //}
                    //_UUID = UUID;
                    //IEPS = "No proporcionado";
                    //try
                    //{
                    //    foreach (ComprobanteImpuestosTraslado imp in Factura.Impuestos.Traslados)
                    //    {
                    //        decimal importeIEPS = 0;
                    //        try
                    //        {
                    //            if (imp.impuesto.ToString().Contains("IEPS") == true || imp.impuesto.ToString().Contains("Ieps") == true || imp.impuesto.ToString().Contains("ieps") == true)
                    //            {
                    //                IEPS = imp.impuesto.ToString();
                    //                importeIEPS = imp.importe;
                    //                if (importeIEPS <= 0)
                    //                {
                    //                    IEPS = "No proporcionado";
                    //                }
                    //            }
                    //        }
                    //        catch
                    //        {
                    //            IEPS = "No proporcionado";
                    //        }
                    //    }
                    //}
                    //catch
                    //{
                    //    IEPS = "No proporcionado";
                    //}


                    //RFCEmisor = Factura.Emisor.rfc;
                    //RFCReceptor = Factura.Receptor.rfc;

                    //#region envia Almacenar
                    //Genericos.objLeidoFactura obj = new Genericos.objLeidoFactura();
                    //obj.Archivo = Archivo;
                    //obj.Folio = Factura.folio;
                    //_FolioFactura = Factura.folio;
                    //obj.Fecha = Factura.fecha.ToString();
                    //obj.Timporte = Factura.total.ToString();
                    //int canti = Convert.ToInt32(cantidadGlobal);
                    //obj.Tpiezas = canti.ToString(); ;
                    //obj.Concepto = "";
                    //obj.XmlaTexto = xdoc.InnerXml;

                    //System.IO.StreamReader myFile = new System.IO.StreamReader(Ruta);
                    //string myString = myFile.ReadToEnd();
                    //obj.XmlaTexto = myString;


                    //#region valida el Documento
                    //PB_ver3.WSBafar.Servicio_ClickFacturaClient cliente = new PB_ver3.WSBafar.Servicio_ClickFacturaClient();
                    //System.Data.DataSet ds = new System.Data.DataSet();

                    //Genericos.Seguridad security = new Seguridad();

                    //Cadena_XML Objeto_XML = new Cadena_XML();
                    //Resultado_XML Resulta = new Resultado_XML();
                    //string texto = xdoc.InnerXml;
                    //texto = System.Text.RegularExpressions.Regex.Replace(texto, @"&#xa;", " ", System.Text.RegularExpressions.RegexOptions.IgnoreCase);

                    //String Code = security.Base64Encode(texto);
                    //int largo = Code.Length;
                    //List<string> subXML = new List<string>();

                    //if (largo >= 6700)
                    //{
                    //    int chunkSize = 6700;
                    //    int stringLength = Code.Length;
                    //    for (int ii = 0; ii < stringLength; ii += chunkSize)
                    //    {
                    //        if (ii + chunkSize > stringLength) chunkSize = stringLength - ii;
                    //        subXML.Add(Code.Substring(ii, chunkSize));

                    //    }
                    //}


                    //Objeto_XML.Usuario = "demo";
                    ////Objeto_XML.RFC = "AAA010101AAA";
                    //Objeto_XML.Password = "DEMO";
                    //Objeto_XML.Factura_XML = Code;
                    ////Objeto_XML.Cadena = Code;
                    //try
                    //{

                    //    //if (Code.Length > 12000)
                    //    //{
                    //    //    Objeto_XML.Factura_XML = "";
                    //    //    Resulta = cliente.Valida_XML_Max(Objeto_XML, Ruta);
                    //    //}
                    //    //else
                    //    //{
                    //    Resulta = cliente.Valida_XML(Objeto_XML);
                    //    //}


                    //    String SAT = Resulta.Resultado_SAT;
                    //    if (Resulta.Correcta == true)
                    //    {
                    //        xmlValido = true;
                    //        xmlDocumento = true;
                    //        obj.Error = Resulta.Resultado == null ? "Factura válida." : "Factura válida";
                    //        _UUID = Resulta.UUID;
                    //        resultadoUltimoEvaluado = true;
                    //    }
                    //    else
                    //    {
                    //        if (Resulta.Resultado.Equals("Comentario: El sello del emisor es invalido ;") == true)
                    //        {
                    //            xmlValido = true;
                    //            xmlDocumento = true;
                    //            resultadoUltimoEvaluado = true;
                    //            obj.Error = "Se realiza la excepción de aceptar la factura a pesar del error: Comentario: El sello del emisor es invalido.";
                    //        }
                    //        else
                    //        {
                    //            xmlValido = false;
                    //            xmlDocumento = false;
                    //            resultadoUltimoEvaluado = false;
                    //            obj.Error = Resulta.Resultado;
                    //        }
                    //        _UUID = extraeUUID(Factura);
                    //    }
                    //    obj.ImporteTrasladado = "0";// Resulta.Factura.impuestosField.totalImpuestosTrasladadosField.ToString();
                    //    obj.SubTotal = Factura.subTotal.ToString();

                    //    #region        Contabiliza la validacion con el servicio Click Factura
                    //    try
                    //    {
                    //        cs_Validaciones_ClickFactura contabiliza = new cs_Validaciones_ClickFactura();
                    //        obj_registraValidacion porEnviar = new obj_registraValidacion();
                    //        porEnviar.emisor = Factura.Emisor.rfc;
                    //        porEnviar.receptor = Factura.Receptor.rfc;
                    //        porEnviar.fechaValidacion = DateTime.UtcNow.ToString();
                    //        porEnviar.fechaDocumento = Factura.fecha.ToString();
                    //        porEnviar.serie = Factura.serie;
                    //        porEnviar.folio = Factura.folio;
                    //        porEnviar.estatusSAT = Resulta.Resultado_SAT;
                    //        porEnviar.estatus = Resulta.Correcta.ToString();
                    //        contabiliza.registraValidacion(porEnviar);
                    //    }
                    //    catch (Exception ex)
                    //    {

                    //    }
                    //    #endregion Contabiliza la validacion con el servicio Click Factura
                    //}
                    //catch (Exception ex)
                    //{
                    //    xmlValido = false;
                    //    xmlDocumento = false;
                    //    obj.Error = "Problema con el servicio : " + ex.Message;
                    //    if (ex.Message.Contains("There was no endpoint listening at"))
                    //    {
                    //        obj.Error = "El servicio de validación de Facturas de Click Factura esta caido, por favor reporte a saclaracionescxp@bafar.com.mx en BAFAR o a Soporte del Portal BAFAR";
                    //    }
                    //    //There was no endpoint listening at http://192.175.113.36:8090/wsValidacion/validaXmlService that could accept the message. This is often caused by an incorrect address or SOAP action. See InnerException, if present, for more details.
                    //}

                    ////xmlValido = Resulta.Resultado;
                    ////xmlDocumento = cliente.Valida_Documento(xdoc.InnerXml);
                    //obj.EstructuraValida = xmlDocumento;
                    //obj.ValidoSAT = xmlValido;
                    //obj.Conceptos = Conceptos;
                    //obj.UUID = Resulta.UUID == null ? _UUID : Resulta.UUID;
                    //obj.RFC = Factura.Emisor.rfc;
                    //obj.Moneda = Factura.Moneda;
                    //obj.Descuento = Factura.descuento == null ? 0 : Factura.descuento;
                    //obj.RFC_Receptor = Factura.Receptor.rfc;
                    //obj.Serie = Factura.serie;
                    //obj.Path = Ruta;
                    //obj.NombreArchivo = Archivo;
                    //obj.Moneda = Factura.Moneda;
                    //obj.ImporteRetenido = Factura.Impuestos.totalImpuestosRetenidos.ToString();
                    //if (Genericos.Configuracion.CadenaConexion.Contains("qu_HANA_bafar") == true)
                    //    obj.UUID = "DePruebas" + Convert.ToString((DateTime.Now - DateTime.MinValue).TotalMilliseconds);
                    //double acumulado = 0;
                    //try
                    //{
                    //    obj.ImporteTrasladado = Factura.Impuestos.totalImpuestosTrasladados.ToString();
                    //    if (Factura.Impuestos.Traslados != null)
                    //    {

                    //        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                    //        {
                    //            if (impuestosTrasladados.importe > 0)
                    //                acumulado = acumulado + Convert.ToDouble(impuestosTrasladados.importe.ToString());
                    //        }
                    //    }
                    //}
                    //catch
                    //{
                    //    acumulado = 0;
                    //}
                    //obj.ImporteTrasladado = acumulado.ToString();
                    //obj.Impuestos = Factura.Impuestos;
                    //#endregion valida el Documento
                    //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                    //listadoA = ad.agregaobjeLeido(obj, listadoA);
                    //#endregion envia Almacenar
                    //#endregion Extraelas piezas o cantidades

                    //try
                    //{
                    //    //exploraXMLporAddenda(Ruta,Archivo,ref listadoAddendas);
                    //}
                    //catch
                    //{
                    //    listadoAddendas = null;
                    //}
                    #endregion VERSION 3.2
                }
                catch (Exception ex)
                {
                    //Genericos.objLeidoFactura obj = new Genericos.objLeidoFactura();
                    //obj.EstructuraValida = false;
                    //obj.ValidoSAT = false;
                    //obj.Error = "Problema con la factura: " + ex.Message;
                    //Genericos.adobjLeidosdelasFacturas ad = new Genericos.adobjLeidosdelasFacturas();
                    //listadoA = ad.agregaobjeLeido(obj, listadoA);
                }
                #endregion Sobre operaciones con Version 3.2
            }
        return true;
        }
        //public string aXMLConceptos(List<ComprobanteConcepto> Concepto)
        //{
        //    List<string> listado = new List<string>();
        //    foreach(ComprobanteConcepto Conceptos in Concepto)
        //    {
        //             string datos = "";
                    
        //            //datos = "|"+ Conceptos.Cantidad.ToString();
        //            //datos = "|"+Conceptos.Unidad.ToString();
        //            //datos = "|"+Conceptos.NoIdentificacion.ToString();
        //            //datos = "|"+Conceptos.Descripcion.ToString();
        //            //datos = "|"+Conceptos.ValorUnitario.ToString();
        //            //datos = "|"+Conceptos.Importe.ToString();
        //            datos="<"+datos+">";
        //            listado.Add(datos);
        //    }
        //    string salida="";
        //    foreach(string s in listado)
        //    {
        //        salida = salida + s;
        //    }
        //    return salida;
        //}

        public List<string> desmenuzaXMLConceptos(string Origen)
        {
            List<string> listado = new List<string>();
            const string pipe="|";
            const string inicio = "<";
            const string final = ">";
            foreach(char caracter in Origen.ToArray())
            {
                string texto = "";
                if(caracter!=Convert.ToChar("<") && caracter!=Convert.ToChar(">"))
                {
                    texto = texto + caracter;
                }
                else
                {
                    listado.Add(texto);
                }
            }

            return listado;
        }

        public bool Lectura_NotaCreditoExpress(String Archivo, ref List<objNotaCredito32> notacredito, string Ruta, string Tipo, ref bool resultadoUltimoEvaluado, ref string RFCEmisor, ref string RFCReceptor, decimal _Factor)
        {
            try
            {
                #region Obsoleta
                System.Xml.Serialization.XmlSerializer Serializer = new System.Xml.Serialization.XmlSerializer(typeof(ClickFactura_Facturacion.version3_2.CFDI32.Comprobante));
                System.Xml.XmlTextReader Lector = new System.Xml.XmlTextReader(Ruta);
                ClickFactura_Facturacion.version3_2.CFDI32.Comprobante Factura = (ClickFactura_Facturacion.version3_2.CFDI32.Comprobante)Serializer.Deserialize(Lector);
                System.Xml.XmlDocument xdoc = new System.Xml.XmlDocument();
                xdoc.Load(Ruta);
                Lector.Close();
                //Lector.Dispose();

                #region extrae la Pieas o Cantidades
                System.Xml.XmlNodeList NodoPrincipal = xdoc.GetElementsByTagName("cfdi:" + "Comprobante");
                System.Xml.XmlNodeList NodoSecundarioConceptos = ((System.Xml.XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi:" + "Conceptos");
                System.Xml.XmlNodeList NodoDetalladoConcepto = ((System.Xml.XmlElement)NodoSecundarioConceptos[0]).GetElementsByTagName("cfdi:" + "Concepto");
                XmlNodeList NodoSecundarioComplemento = ((XmlElement)NodoPrincipal[0]).GetElementsByTagName("cfdi" + "Complemento");
                int i = 0;
                Decimal cantidad = 0;
                string concepto;
                Decimal importe = 0;
                string unidad = "";
                List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto> Conceptos = new List<ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto>();
                foreach (System.Xml.XmlElement nodo in NodoDetalladoConcepto)
                {
                    ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto Concepto = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto();
                    try
                    {
                        cantidad = cantidad + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["cantidad"].Value), 2);
                    }
                    catch
                    {
                        cantidad = cantidad + 0;
                    }
                    try
                    {
                        concepto = NodoDetalladoConcepto[i].Attributes["concepto"].Value;
                    }
                    catch
                    {
                        concepto = "No proporcionado";
                    }
                    try
                    {
                        importe = importe + Math.Round(Convert.ToDecimal(NodoDetalladoConcepto[i].Attributes["importe"].Value), 2);
                    }
                    catch
                    {
                        importe = importe + 0;
                    }
                    try
                    {
                        unidad = NodoDetalladoConcepto[i].Attributes["unidad"].Value;
                    }
                    catch
                    {
                        unidad = "No proporcionado";
                    }
                    ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto c = new ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto();
                    c.cantidad = cantidad;
                    c.descripcion = concepto;
                    c.importe = importe;
                    c.unidad = unidad;
                    Conceptos.Add(c);
                    i++;
                }
                string UUID = "";
                foreach (XmlElement nodo in NodoSecundarioComplemento)
                {
                    try
                    {
                        UUID = NodoSecundarioComplemento[0].Attributes["UUID"].Value;
                    }
                    catch
                    {
                        UUID = "No proporcionado";
                    }
                }

                #region envia Almacenar
                objNotaCredito32 obj = new objNotaCredito32();
                obj.Archivo = Archivo;
                obj.Folio = Factura.folio.ToString();
                obj.Importe = Factura.total.ToString();
                int canti = Convert.ToInt16(cantidad);
                obj.XML = xdoc.InnerXml;
                #region valida el Documento
                wsbafar = new ClickFactura_Facturacion.wsBafar.Servicio_ClickFacturaClient();
                bool xmlValido = false;
                bool xmlDocumento = false;
                System.Data.DataSet ds = new System.Data.DataSet();
                //Core.Seguridad security = new Core.Seguridad();

                ClickFactura_Facturacion.wsBafar.Cadena_XML Objeto_XML = new ClickFactura_Facturacion.wsBafar.Cadena_XML();
                ClickFactura_Facturacion.wsBafar.Resultado_XML Resulta = new ClickFactura_Facturacion.wsBafar.Resultado_XML();

                String Code = Base64Encode(xdoc.InnerXml);

                Objeto_XML.Usuario = "demo";
                //Objeto_XML.RFC = "AAA010101AAA";
                Objeto_XML.Password = "DEMO";
                Objeto_XML.Factura_XML = Code;
                try
                {
                    Resulta = wsbafar.Valida_XML(Objeto_XML);

                    String SAT = Resulta.Resultado_SAT;
                    if (Resulta.Correcta == true)
                    {
                        xmlValido = true;
                        xmlDocumento = true;
                        obj.Error = Resulta.Resultado == null ? "Factura válida " : "Factura válida";
                        resultadoUltimoEvaluado = true;
                    }
                    else
                    {
                        xmlValido = false;
                        xmlDocumento = false;
                        resultadoUltimoEvaluado = false;
                        obj.Error = Resulta.Resultado;
                    }
                }
                catch (Exception ex)
                {
                    xmlValido = false;
                    xmlDocumento = false;
                    obj.Error = "Problema con el servicio : " + ex.Message;
                }

                obj.ValidoEstructura = xmlDocumento;
                obj.ValidoSAT = xmlValido;

                obj.UUID = Resulta.UUID;
                obj.RFC = Factura.Emisor.rfc;
                obj.Ruta = Ruta;
                obj.Tipo = Tipo;
                obj.Factor = _Factor;
                string ImporteTrasladado = "";
                try
                {
                    ImporteTrasladado = Factura.Impuestos.totalImpuestosTrasladados.ToString();
                    if (Factura.Impuestos.Traslados != null)
                    {
                        foreach (var impuestosTrasladados in Factura.Impuestos.Traslados)
                        {
                            if (impuestosTrasladados.importe > 0)
                                ImporteTrasladado = impuestosTrasladados.importe.ToString();
                        }
                    }
                }
                catch
                {
                    ImporteTrasladado = "0.00";
                }
                if (ImporteTrasladado.Equals("0.00") == true)
                    obj.TieneIVA = false;
                else
                    obj.TieneIVA = true;
                #endregion valida el Documento
                notacredito.Add(obj);

                #endregion envia Almacenar
                #endregion Extraelas piezas o cantidades
                #endregion Obsoleta
                return resultadoUltimoEvaluado;
            }
            catch (Exception ex)
            {
                return false;                
            }
        }

        //private string extraeUUID(Comprobante Facturas)
        //{
        //    string _UUID = "No ubicado";
        //    //List<ComprobanteComplemento> Complementos = Facturas.Complemento;
        //    //foreach(ComprobanteComplemento Factura in Complementos)
        //    //{
        //    //       XmlElement[] Elemento = Factura.Complemento.Any;
        //    //        foreach (XmlElement Element in Elemento)
        //    //        {
        //    //            foreach (XmlAttribute Atributo in Element.Attributes)
        //    //            {
        //    //                switch (Atributo.Name)
        //    //                {
        //    //                    case "UUID":
        //    //                        _UUID = Atributo.Value;
        //    //                        break;
        //    //                }
        //    //            }
        //    //        }
        //    //}

        //    return _UUID;
        //}
        private void bajaADiscoDuro(ref string archivo, ref bool seCargo)
        {
            //string filepath = Path.Combine(Path.GetTempPath(), Path.ChangeExtension(Guid.NewGuid().ToString(), ".xml"));
            //byte[] y = System.Text.Encoding.UTF8.GetBytes(archivo);
            //File.WriteAllBytes(filepath, y);
            //if (File.Exists(filepath))
            //{
            //    //File.Delete(filepath);
            //    seCargo = true;
            //}
            //else
            //{
            //    seCargo = false;
            //}
            //archivo = filepath;
        }
        public List<wsBafar.objLeidoFactura> ConvertirObjeto(List<objLeidoFactura> l)
        {
            try
            {
                List<wsBafar.objLeidoFactura> obj = new List<wsBafar.objLeidoFactura>();
                foreach (var item in l)
                {
                    List<wsBafar.ComprobanteConcepto> _conceptos = new List<wsBafar.ComprobanteConcepto>();
                    if (item.Conceptos != null)
                    {
                        foreach (var c in item.Conceptos)
                        {
                            _conceptos.Add(new wsBafar.ComprobanteConcepto()
                            {
                                cantidadField = c.cantidad,
                                descripcionField = c.descripcion,
                                importeField = c.importe,
                                // Modificado el 22 MAyo por cambio de 3.3 Gabo Mayo 22 2017itemsField = c.Items,
                                noIdentificacionField = c.noIdentificacion,
                                unidadField = c.unidad,
                                valorUnitarioField = c.valorUnitario
                            });
                        }
                    }
                    wsBafar.ComprobanteImpuestos _impuestos = new wsBafar.ComprobanteImpuestos();
                    if (item.Impuestos != null)
                    {
                        _impuestos.totalImpuestosRetenidosField = item.Impuestos.totalImpuestosRetenidos;
                        //Modificacion 22 May Gabo por cambio a 3.3 _impuestos.totalImpuestosRetenidosFieldSpecified = item.Impuestos.TotalImpuestosRetenidosSpecified;
                        _impuestos.totalImpuestosTrasladadosField = item.Impuestos.totalImpuestosTrasladados;
                        //Modificacion 22 May Gabo por cambio a 3.3  _impuestos.totalImpuestosTrasladadosFieldSpecified = item.Impuestos.TotalImpuestosTrasladadosSpecified;

                        if (item.Impuestos.Retenciones != null)
                        {
                            _impuestos.retencionesField = new wsBafar.ComprobanteImpuestosRetencion[item.Impuestos.Retenciones.Count()];
                            for (int j = 0; j < item.Impuestos.Retenciones.Count(); j++)
                            {
                                _impuestos.retencionesField[j] = new wsBafar.ComprobanteImpuestosRetencion()
                                {
                                    importeField = item.Impuestos.Retenciones[j].importe,
                                    impuestoField = (wsBafar.ComprobanteImpuestosRetencionImpuesto)item.Impuestos.Retenciones[j].impuesto
                                };
                            }
                        }
                        if (item.Impuestos.Traslados != null)
                        {
                            _impuestos.trasladosField = new wsBafar.ComprobanteImpuestosTraslado[item.Impuestos.Traslados.Count()];
                            for (int k = 0; k < item.Impuestos.Traslados.Count(); k++)
                            {
                                _impuestos.trasladosField[k] = new wsBafar.ComprobanteImpuestosTraslado()
                                {
                                    importeField = item.Impuestos.Traslados[k].importe,
                                    tasaField = item.Impuestos.Traslados[k].tasa,    //.TasaOCuota,
                                    impuestoField = (wsBafar.ComprobanteImpuestosTrasladoImpuesto)item.Impuestos.Traslados[k].impuesto
                                };
                            }
                        }
                    }
                    obj.Add(new wsBafar.objLeidoFactura()
                    {
                        AplicaraProrrateo = item.AplicaraProrrateo,
                        Archivo = item.Archivo,
                        Codigo = item.Codigo,
                        Concepto = item.Concepto,
                        Conceptos = _conceptos != null ? _conceptos.ToArray() : null,
                        Descuento = item.Descuento,
                        DiferenciaImportes = item.DiferenciaImportes,
                        Documento_Referencia = item.Documento_Referencia,
                        Error = item.Error,
                        EsdocumentoReferencia = item.EsdocumentoReferencia,
                        EstructuraValida = item.EstructuraValida,
                        Fecha = item.Fecha,
                        Folio = item.Folio,
                        ImporteArticulosconIVA = item.ImporteArticulosconIVA,
                        ImporteRecepcionOrigen = item.ImporteRecepcionOrigen,
                        ImporteRetencionFlete = item.ImporteRetencionFlete,
                        ImporteRetenido = item.ImporteRetenido,
                        ImportesFueron = item.ImportesFueron,
                        ImporteTrasladado = item.ImporteTrasladado,
                        ImporteUnitario = item.ImporteUnitario,
                        Impuestos = _impuestos,
                        Moneda = item.Moneda,
                        NombreArchivo = item.NombreArchivo,
                        NotasCredito = item.NotasCredito,
                        Num_Proveedor = item.Num_Proveedor,
                        Path = item.Path,
                        Posicion_Documento_Material = item.Posicion_Documento_Material,
                        RecepcionValia = item.RecepcionValia,
                        ReglasAplicadas = item.ReglasAplicadas,
                        RFC = item.RFC,
                        RFC_Receptor = item.RFC_Receptor,
                        Serie = item.Serie,
                        SubTotal = item.SubTotal,
                        Timporte = item.Timporte,
                        TipoFactura = item.TipoFactura,
                        Tpiezas = item.Tpiezas,
                        UUID = item.UUID,
                        ValidoSAT = item.ValidoSAT,
                        XmlaTexto = item.XmlaTexto
                    });
                }
                return obj;
            }
            catch (Exception e)
            {
                throw new Exception(e.Message);
            }
        }

        /// <summary>
        /// Funcion que decodifica una cadena.
        /// </summary>
        /// <param name="Cadena">Cadena codificada</param>
        /// <returns>Devuelve la cadena decodificada</returns>
        public String Base64Decode(string Cadena)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(Cadena);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }
        /// <summary>
        /// Función que codifica una cadena
        /// </summary>
        /// <param name="Cadena">Cadena a codificar.</param>
        /// <returns>Devuelve la cadena codificada.</returns>
        public String Base64Encode(String Cadena)
        {
            var bytes = Encoding.UTF8.GetBytes(Cadena);
            var base64 = Convert.ToBase64String(bytes);
            return base64;
        }

        public List<objLeidoFactura> convierteListaObjeLeidoFactura(objLeidoFactura[] origen)
        {
            List<objLeidoFactura> salida = new List<objLeidoFactura>();
            foreach (objLeidoFactura regOrigen in origen)
            {
                salida.Add(regOrigen);
            }
            return salida;
        }

        public List<string> convierteaListaStrings(string[] origen)
        {
            List<string> salida = new List<string>();
            foreach(string reg in origen)
            {
                salida.Add(reg);
            }
            return salida;
        }

        private string extraeUUID33(ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.Comprobante Factura)
        {
            string _UUID = "No ubicado";
            #region Editada
                    //List<ClickFactura_Facturacion.ComprobanteComplemento> Complemento = Factura.Complemento;
                    //foreach (ClickFactura_Facturacion.ComprobanteComplemento complemento in Factura.Complemento)
                    //{
                    //    foreach (XmlElement elemento in complemento.Any)
                    //    {
                    //        foreach (XmlAttribute Atributo in elemento.Attributes)
                    //        {
                    //            switch (Atributo.Name)
                    //            {
                    //                case "UUID":
                    //                    _UUID = Atributo.Value;
                    //                    break;
                    //            }
                    //        }
                    //    }
                    //}
            #endregion Editada

            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteComplemento Complemento = Factura.Complemento;
            XmlElement[] Elemento = Factura.Complemento.Any;
            foreach (XmlElement Element in Elemento)
            {
                foreach (XmlAttribute Atributo in Element.Attributes)
                {
                    switch (Atributo.Name)
                    {
                        case "UUID":
                            _UUID = Atributo.Value;
                            break;
                    }
                }
            }

            return _UUID;
        }

    }
    public class objImportes
    {
        string factura;

        public string Factura
        {
            get { return factura; }
            set { factura = value; }
        }
        string documento;

        public string Documento
        {
            get { return documento; }
            set { documento = value; }
        }
        decimal importeFactura;

        public decimal ImporteFactura
        {
            get { return importeFactura; }
            set { importeFactura = value; }
        }
        decimal importeDocumento;

        public decimal ImporteDocumento
        {
            get { return importeDocumento; }
            set { importeDocumento = value; }
        }
        bool cuadra;

        public bool Cuadra
        {
            get { return cuadra; }
            set { cuadra = value; }
        }

        decimal signo = 0;

        public decimal Signo
        {
            get { return signo; }
            set { signo = value; }
        }

        public objImportes()
        {

        }

        public objImportes(string _Factura, string _Documento, decimal _ImporteFactura, decimal _ImporteDocumento, bool _Cuadra)
        {
            Factura = _Factura;
            Documento = _Documento;
            ImporteFactura = _ImporteFactura;
            ImporteDocumento = _ImporteDocumento;
            Cuadra = _Cuadra;
        }


       }
    }

