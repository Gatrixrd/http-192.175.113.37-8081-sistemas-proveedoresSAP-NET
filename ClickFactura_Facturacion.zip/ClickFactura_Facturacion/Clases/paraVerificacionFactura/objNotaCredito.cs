﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion.Clases.paraVerificacionFactura
{
    public class objNotaCredito32
    {
        string tipo;

        public string Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        string folio;

        public string Folio
        {
            get { return folio; }
            set { folio = value; }
        }
        string importe;

        public string Importe
        {
            get { return importe; }
            set { importe = value; }
        }
        string uUID;

        public string UUID
        {
            get { return uUID; }
            set { uUID = value; }
        }
        string xML;

        public string XML
        {
            get { return xML; }
            set { xML = value; }
        }
        string ordenCompra;

        public string OrdenCompra
        {
            get { return ordenCompra; }
            set { ordenCompra = value; }
        }
        string folioFacturaOrigen;

        public string FolioFacturaOrigen
        {
            get { return folioFacturaOrigen; }
            set { folioFacturaOrigen = value; }
        }

        bool validoEstructura;

        public bool ValidoEstructura
        {
            get { return validoEstructura; }
            set { validoEstructura = value; }
        }
        bool validoSAT;

        public bool ValidoSAT
        {
            get { return validoSAT; }
            set { validoSAT = value; }
        }

        string archivo;

        public string Archivo
        {
            get { return archivo; }
            set { archivo = value; }
        }

        string ruta;

        public string Ruta
        {
            get { return ruta; }
            set { ruta = value; }
        }
        string rFC;

        public string RFC
        {
            get { return rFC; }
            set { rFC = value; }
        }


        string error;
        public string Error
        {
            get { return error; }
            set { error = value; }
        }

        decimal factor = 0;

        public decimal Factor
        {
            get { return factor; }
            set { factor = value; }
        }

        bool tieneIVA;

        public bool TieneIVA
        {
            get { return tieneIVA; }
            set { tieneIVA = value; }
        }


        public objNotaCredito32()
        {

        }

        public objNotaCredito32(string _Tipo, string _Folio, string _Importe, string _UUID, string _XML, string _OrdenCompra, string _FolioFacturaOrigen, bool _ValidoEstructura, bool _ValidoSAT, string _Archivo, string _Ruta, string _RFC, string _Error, decimal _Factor, bool _TieneIVA)
        {
            Tipo = _Tipo;
            Folio = _Folio;
            Importe = _Importe;
            UUID = _UUID;
            XML = _XML;
            OrdenCompra = _OrdenCompra;
            FolioFacturaOrigen = _FolioFacturaOrigen;
            ValidoEstructura = _ValidoEstructura;
            ValidoSAT = _ValidoSAT;
            Archivo = _Archivo;
            Error = _Error;
            Factor = _Factor;
            TieneIVA = _TieneIVA;
        }
    }
}
