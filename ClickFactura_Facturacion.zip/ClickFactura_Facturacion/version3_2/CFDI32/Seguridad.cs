﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion._3_2.CFDI32
{
    class Seguridad
    {
        public String Base64Decode(string Cadena)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(Cadena);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public String Base64Encode(String Cadena)
        {
            var bytes = Encoding.UTF8.GetBytes(Cadena);
            var base64 = Convert.ToBase64String(bytes);
            return base64;
        }
    }
}
