﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Facturacion._3_2.CFDI32
{
    public class adobjLeidos
    {
        public List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> agregaobjeLeido32_33(objLeidoFactura item32, List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> listado)
        {
            #region       Pasa valores del 32 al 33
            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura item = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura();
            item.Archivo = item32.Archivo;
            item.Folio = item32.Folio;
            item.Fecha = item32.Fecha;
            item.Tpiezas = item32.Tpiezas;
            item.Timporte = item32.Timporte;
            item.Concepto = item32.Concepto;
            item.Codigo = item32.Codigo;
            item.XmlaTexto = item32.XmlaTexto;
            item.ValidoSAT = item32.ValidoSAT;
            item.EstructuraValida = item32.EstructuraValida;
            item.Version = item32.Version;
            item.Conceptos = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto>();
            foreach (ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteConcepto cc32 in item32.Conceptos)
            {
                ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto cc33 = new version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                cc33.Cantidad = cc32.cantidad;
                cc33.Unidad = cc32.unidad;
                cc33.NoIdentificacion = cc32.noIdentificacion;
                cc33.Descripcion = cc32.descripcion;
                cc33.ValorUnitario = cc32.valorUnitario;
                cc33.Importe = cc32.importe;
                //item.Conceptos = new ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteConcepto();
                item.Conceptos.Add(cc33);
            }
            item.UUID = item32.UUID;
            item.RFC = item32.RFC;
            item.Path = item32.Path;
            item.Error = item32.Error;
            item.Moneda = item32.Moneda;
            item.SubTotal = item32.SubTotal;
            item.ImporteTrasladado = item32.ImporteTrasladado;
            item.Descuento = item32.Descuento;
            item.RFC_Receptor = item32.RFC_Receptor;
            item.Serie = item32.Serie;
            item.NombreArchivo = item32.NombreArchivo;
            item.ImporteRetenido = item32.ImporteRetenido;
            item.ImportesFueron = item32.ImportesFueron;
            item.ReglasAplicadas = item32.ReglasAplicadas;
            item.DiferenciaImportes = item32.DiferenciaImportes;
            item.AplicaraProrrateo = item32.AplicaraProrrateo;
            item.ImporteRetencionFlete = item32.ImporteRetencionFlete;

            #region Pasando todo Impuestos
            item.Impuestos33 = new version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();

            ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos icc33 = new version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestos();
            icc33.TotalImpuestosRetenidos = item32.Impuestos.totalImpuestosRetenidos;
            icc33.TotalImpuestosTrasladados = item32.Impuestos.totalImpuestosTrasladados;

            #region Prepara catalogos de la versión 3.3 para su identificación

            ad_CatalogosmySQL_ClickFactura catalogoImpuestos = new ad_CatalogosmySQL_ClickFactura();
            List<string> campos = new List<string>();
            campos.Add("c_Impuesto");
            campos.Add("Descripcion");
            Dictionary<string, string> equivalencias = catalogoImpuestos.consultaCatalogo("cat_33_Impuesto", campos);

            #endregion Prepara catalogos de la versión 3.3 para su identificación

            #region pasando Retenciones de 32 a 33
            if(item32.Impuestos.Retenciones!=null)
            {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion[] Retenciones33;
                    List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion> listaRetenciones33=new List<version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion>();
                    foreach (ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestosRetencion circc32 in item32.Impuestos.Retenciones)
                    {
                        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion circc33 = new version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosRetencion();
                        circc33.Importe = circc32.importe;
                        #region Determina la clave de impuesto de la etiqueta hacia la versión 33
                                 string equivalencia = equivalenciaCatalogoEtiquetaImpuesto(circc32.impuesto.ToString(), equivalencias);
                                 circc33.Impuesto = equivalencia;
                        #endregion Determina la clave de impuesto de la etiqueta hacia la versión 33
                       listaRetenciones33.Add(circc33);
                    }
                    item.Impuestos33.Retenciones = listaRetenciones33.ToArray();
            }
            #endregion pasando Retenciones de 32 a 33

            #region pasando Trasladados de 32 a 33
            if (item32.Impuestos.Traslados!=null)
            {
                    ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado[] Trasladados33;
                    List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado> listaTrasladados33 = new List<version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado>();
                    foreach (ClickFactura_Facturacion.version3_2.CFDI32.ComprobanteImpuestosTraslado citcc32 in item32.Impuestos.Traslados)
                    {
                        ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado citcc33 = new version3_3.Clases33.paraVerificacionFactura33.ComprobanteImpuestosTraslado();
                        citcc33.Importe = citcc32.importe;
                        #region Determina la clave de impuesto de la etiqueta hacia la versión 33
                        string equivalencia = equivalenciaCatalogoEtiquetaImpuesto(citcc32.impuesto.ToString(), equivalencias);
                        citcc33.Impuesto = equivalencia;
                        #endregion Determina la clave de impuesto de la etiqueta hacia la versión 33
                        listaTrasladados33.Add(citcc33);
                    }
                    item.Impuestos33.Traslados = listaTrasladados33.ToArray();
            }
            #endregion pasando Trasladados de 32 a 33

            #endregion Pasando todo Impuestos

            item.EsdocumentoReferencia = item32.EsdocumentoReferencia;
            item.ImporteRecepcionOrigen = item32.ImporteRecepcionOrigen;
            item.ImporteArticulosconIVA = item32.ImporteArticulosconIVA;
            item.Documento_Referencia = item32.Documento_Referencia;
            item.ImporteUnitario = item32.ImporteUnitario;
            item.RecepcionValia = item32.RecepcionValia;
            item.Posicion_Documento_Material = item32.Posicion_Documento_Material;
            item.NotasCredito = item32.NotasCredito;
            item.Num_Proveedor = item32.Num_Proveedor;
            item.TipoFactura = item32.TipoFactura;
            item.Version = item32.Version;

            #endregion Pasa valores del 32 al 33
            List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura> salida = new List<ClickFactura_Facturacion.version3_3.Clases33.paraVerificacionFactura33.objLeidoFactura>();
            salida = listado;
            if (listado == null)
            {
                //Viene vacia
                salida.Add(item);
            }
            else
            {
                //Ya tenemos previos de esta Factura??
                var facturas = from x in salida
                               where x.Folio.Equals(item.Folio) == true
                               select x;
                if (facturas != null)
                    if (facturas.Count() > 0)
                    {
                        //Ya hay registros anteriores de esta Factura
                        var items = from x in facturas
                                    where x.Concepto.Equals(item.Concepto) == true
                                    select x;
                        if (items != null)
                            if (items.Count() == 0)
                            {
                                //Es NUEVO no existe el Concepto!!
                                salida.Add(item);
                            }
                            else
                            {
                                //Lo ignoramos por que ya estaba!!
                            }
                    }
                    else
                    {
                        //No hay nada de este Folio!!
                        salida.Add(item);
                    }
            }
            return salida;
        }

        private string equivalenciaCatalogoEtiquetaImpuesto(string buscado, Dictionary<string, string> listado)
        {
            string etiqueta = "error";
            foreach (KeyValuePair<string, string> etiq in listado)
            {
                if (etiq.Value == buscado)
                {
                    etiqueta = etiq.Value;
                    break;
                }
            }
            return etiqueta;
        }
    }
}
