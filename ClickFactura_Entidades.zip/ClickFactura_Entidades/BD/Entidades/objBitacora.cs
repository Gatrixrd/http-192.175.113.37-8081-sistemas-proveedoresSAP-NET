﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Entidades.BD.Entidades
{
    public class objBitacora
    {
        string descripcion;

        public string Descripcion
        {
            get { return descripcion; }
            set { descripcion = value; }
        }
        DateTime fecha = DateTime.Now;

        public DateTime Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }
        string operacion = "";

        public string Operacion
        {
            get { return operacion; }
            set { operacion = value; }
        }
        string usuario = "";

        public string Usuario
        {
            get { return usuario; }
            set { usuario = value; }
        }

        Int32 idBitacora;

        public Int32 IdBitacora
        {
            get { return idBitacora; }
            set { idBitacora = value; }
        }
        public objBitacora()
        {

        }

        public objBitacora(Int32 _IdBitacora, string _Descripcion, DateTime _Fecha, string _Operacion, string _Usuario)
        {
            IdBitacora = _IdBitacora;
            Descripcion = _Descripcion;
            Fecha = _Fecha;
            Operacion = _Operacion;
            Usuario = _Usuario;
        }
    }
}
