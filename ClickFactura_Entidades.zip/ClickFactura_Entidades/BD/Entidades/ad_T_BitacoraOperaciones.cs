﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Entidades.BD.Entidades
{
    public class ad_T_BitacoraOperaciones
    {

        Desarrollo_CF contexto;
        public ad_T_BitacoraOperaciones()
        {
            using(Desarrollo_CF contexto=new Desarrollo_CF())
            {
                var bitacoras = from b in contexto.T_BitacoraOperaciones select b;
            }
        }
        public void registrarEvento(objT_BitacoraOperaciones obj, string opcion = "Insertar")
        {
            DateTime? _Fecha = DateTime.Now;
            DateTime? _horaOperacion = DateTime.Now;
            DateTime? _FechaFactura = DateTime.Now;
            var b = new ClickFactura_Entidades.BD.Entidades.T_BitacoraOperaciones();//Model.T_BitacoraOperaciones();
            b.IdOperaciones = obj.IdOperaciones;
            b.IdUsuario = obj.IdUsuario;
            b.Num_Proveedor = obj.Num_Proveedor;
            b.Sociedad = obj.Sociedad;
            b.IdProveedor = obj.IdProveedor;
            b.OrdenCompra = obj.OrdenCompra;
            b.NumRecepcion = obj.NumRecepcion;
            b.Posicion = obj.Posicion;
            b.operacionExitosa = obj.operacionExitosa;
            b.Error = obj.Error;
            b.Flujo = obj.Flujo;
            b.Fecha = _Fecha.ToString();
            b.Archivo_Factura = obj.Archivo_Factura;
            b.NotaCredito = obj.NotaCredito;
            b.Archivo_NotaCredito = obj.Archivo_NotaCredito;
            b.FacturaComplementaria = obj.FacturaComplementaria;
            b.Archivo_Complementaria = obj.Archivo_Complementaria;
            b.Mensaje = obj.Mensaje;
            b.FacturaValida = obj.FacturaValida;
            b.FolioFactura = obj.FolioFactura;
            if (obj.FechaFactura != null || obj.FechaFactura != "")
                b.FechaFactura = obj.FechaFactura;
            b.UUID = obj.UUID;
            b.ImporteFactura = obj.ImporteFactura;
            b.ImporteRecepcion = obj.ImporteRecepcion;
            b.ImportePasivo = obj.ImportePasivo;
            b.RFCEmisor = obj.RFCEmisor;
            b.PasivoGenerado = obj.PasivoGenerado;
            b.Moneda = obj.Moneda;
            try
            {
                b.serie = obj.Serie == null ? "No recuperado" : obj.Serie;
            }
            catch
            {
                b.serie = "No recuperado";
            }
            b.Moneda = obj.Moneda;
            try
            {
                b.horaOperacion = _horaOperacion.ToString();
            }
            catch (Exception ex)
            {
                throw new ApplicationException("Fallo campo horaOperacion: " + ex.Message);
            }
            b.serie = obj.Serie;
            if (opcion == "Insertar")
            {
                try
                {
                    contexto = new Desarrollo_CF();
                    contexto.T_BitacoraOperaciones.Add(b);
                    contexto.SaveChanges();
                }
                catch (Exception ex)
                {
                    ad_T_BitacoraOperaciones bb = new ad_T_BitacoraOperaciones();
                    objBitacora obje = new objBitacora();
                    obje.IdBitacora = 0;
                    obje.Descripcion = "Error Insertando Bitacora de Operaciones " + ex.Message + ", " + ex.InnerException;
                    obje.Fecha = DateTime.Now;
                    obje.Operacion = "Problema disparando Pasivo";
                    obje.Usuario = obj.RFCEmisor;
                    bb.registrarBitacora(obje);

                }
            }
            if (opcion == "modificar")
            {

            }
        }

        public void registrarEvento(ClickFactura_Entidades.BD.Entidades.T_BitacoraOperaciones obj)
        {
            try
            {
                contexto.T_BitacoraOperaciones.Add(obj);
                contexto.SaveChanges();
            }
            catch (Exception ex)
            {
                ad_T_BitacoraOperaciones bb = new ad_T_BitacoraOperaciones();
                objBitacora obje = new objBitacora();
                obje.IdBitacora = 0;
                obje.Descripcion = "Error Insertando Bitacora de Operaciones " + ex.Message + ", " + ex.InnerException;
                obje.Fecha = DateTime.Now;
                obje.Operacion = "Problema disparando Pasivo";
                obje.Usuario = obj.RFCEmisor;
                bb.registrarBitacora(obje);
            }
        }

        public void registrarBitacora(objBitacora obj)
        {
            try
            {
                //contexto = new Models.DatosBafarDataContext();
                //var v = contexto.SP_Bitacora(0, obj.Fecha.ToString(), obj.Usuario, obj.Operacion, obj.Descripcion, "Insertar");
            }
            catch (Exception)
            {

                throw;
            }
        }

    }
}
