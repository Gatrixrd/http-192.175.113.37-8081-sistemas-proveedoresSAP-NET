﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Configuration;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Text;
using System.Data.EntityClient;
using System.Data.SqlClient;

namespace ClickFactura_Entidades.BD.Entidades
{
    public class AccesoBD
    {
        public static string CadenaConexion
        {
            get
            {
                //NameValueCollection section = (NameValueCollection)ConfigurationManager.GetSection("connectionStrings");
                var connectionString = ConfigurationManager.ConnectionStrings["Desarrollo_CF"].ConnectionString;
                var connectionStringTKPM = ConfigurationManager.ConnectionStrings["Desarrollo_CF_TKPM"].ConnectionString;

                if (connectionString.ToLower().StartsWith("metadata="))
                {
                    System.Data.Entity.Core.EntityClient.EntityConnectionStringBuilder efBuilder = new System.Data.Entity.Core.EntityClient.EntityConnectionStringBuilder(connectionString);
                    connectionString = efBuilder.ProviderConnectionString;
                }

                //<add name="qa_bafar1ConnectionString" connectionString="Data Source=67.205.93.25;Initial Catalog=qu_HANA_bafar;User ID=bafarv1;Password=154rfb$g" providerName="System.Data.SqlClient" />
                //data source=67.205.93.25;initial catalog=desa_TKPM;user id=bafarv1;password=154rfb$g

                System.Data.SqlClient.SqlConnectionStringBuilder builder = new System.Data.SqlClient.SqlConnectionStringBuilder(connectionString);
                string Servidor = builder.DataSource;             //  eg "MikesServer"
                string BaseDatos = builder.InitialCatalog;
                string Usuario = builder.UserID;
                string Password = builder.Password;

                string newconnectionString = "Data Source= "+Servidor+";Initial Catalog=" + BaseDatos + ";User ID="+Usuario+";Password="+Password;

                bool existe = false;
                string desarrollo = null;
                string qas = null;
                string productivo = null;
                string entorno = "";
                bool local = true;
                int posIni = connectionString.IndexOf("data source=");
                int posFin = connectionString.IndexOf("MultipleActiveResultSets=True;");//App=EntityFramework");
                try
                {
                    existe = connectionString.Contains("desa_TKPM");// section["Desarrollo_CF"];
                    if(existe==true)
                    {
                        desarrollo = connectionString;
                        connectionString = connectionString.Substring(posIni,((posFin-posIni)-1));
                        //if (IsServerConnected(connectionString) == false)
                        //{
                        //    posIni = connectionStringTKPM.IndexOf("data source=");
                        //    posFin = connectionStringTKPM.IndexOf("MultipleActiveResultSets=True;");
                        //    connectionStringTKPM = connectionStringTKPM.Substring(posIni, ((posFin - posIni) - 1));
                        //    local = false;
                        //}
                        entorno ="D";
                    }
                }
                catch
                {
                    try
                    {
                        existe = connectionString.Contains("qas_TKPM");
                         if(existe==true)
                                {
                                       qas  = connectionString;
                                       connectionString = connectionString.Substring(posIni, ((posFin - posIni) - 1));
                                       entorno = "Q";
                                }
                    }
                    catch
                    {
                        existe = connectionString.Contains("prd_TKPM");
                        if (existe == true)
                        {
                            productivo = connectionString;
                            connectionString = connectionString.Substring(posIni, ((posFin - posIni) - 1));
                            entorno = "P";
                        }
                    }
                }
                if(local==true)
                {
                string DataBase = entorno.Equals("P") == true ? "Productivo_CF" : entorno.Equals("Q") == true ? "QAs_CF" : "Desarrollo_CF";
                connectionString = connectionString.Replace("persist security info=True;","");
                connectionString= newconnectionString;
                return connectionString;
                }
                else
                {
                    string DataBase = entorno.Equals("P") == true ? "Productivo_CF" : entorno.Equals("Q") == true ? "QAs_CF" : "Desarrollo_CF";
                    connectionStringTKPM = connectionStringTKPM.Replace("persist security info=True;", "");
                    return connectionStringTKPM;
                }
            }
        }

        private static bool IsServerConnected(string connectionString)
        {
            using (System.Data.SqlClient.SqlConnection connection = new System.Data.SqlClient.SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    return true;
                }
                catch (System.Data.SqlClient.SqlException)
                {
                    return false;
                }
            }
        }

    }
}
