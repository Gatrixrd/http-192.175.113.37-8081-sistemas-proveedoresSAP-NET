﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ClickFactura_Entidades.BD.Entidades
{
    public class objT_BitacoraOperaciones
    {
        Int64 idOperaciones;

        public Int64 IdOperaciones
        {
            get { return idOperaciones; }
            set { idOperaciones = value; }
        }
        int idUsuario;

        public int IdUsuario
        {
            get { return idUsuario; }
            set { idUsuario = value; }
        }
        string num_Proveedor;

        public string Num_Proveedor
        {
            get { return num_Proveedor; }
            set { num_Proveedor = value; }
        }
        string sociedad;

        public string Sociedad
        {
            get { return sociedad; }
            set { sociedad = value; }
        }
        int idProveedor;

        public int IdProveedor
        {
            get { return idProveedor; }
            set { idProveedor = value; }
        }
        string ordenCompra;

        public string OrdenCompra
        {
            get { return ordenCompra; }
            set { ordenCompra = value; }
        }
        string numRecepcion;

        public string NumRecepcion
        {
            get { return numRecepcion; }
            set { numRecepcion = value; }
        }
        string posicion;

        public string Posicion
        {
            get { return posicion; }
            set { posicion = value; }
        }
        bool OperacionExitosa;

        public bool operacionExitosa
        {
            get { return OperacionExitosa; }
            set { OperacionExitosa = value; }
        }
        string error;

        public string Error
        {
            get { return error; }
            set { error = value; }
        }
        string flujo;

        public string Flujo
        {
            get { return flujo; }
            set { flujo = value; }
        }

        string fecha;

        public string Fecha
        {
            get { return fecha; }
            set { fecha = value; }
        }

        string archivo_Factura;

        public string Archivo_Factura
        {
            get { return archivo_Factura; }
            set { archivo_Factura = value; }
        }
        string notaCredito;

        public string NotaCredito
        {
            get { return notaCredito; }
            set { notaCredito = value; }
        }
        string archivo_NotaCredito;

        public string Archivo_NotaCredito
        {
            get { return archivo_NotaCredito; }
            set { archivo_NotaCredito = value; }
        }
        string facturaComplementaria;

        public string FacturaComplementaria
        {
            get { return facturaComplementaria; }
            set { facturaComplementaria = value; }
        }
        string archivo_Complementaria;

        public string Archivo_Complementaria
        {
            get { return archivo_Complementaria; }
            set { archivo_Complementaria = value; }
        }
        string mensaje;

        public string Mensaje
        {
            get { return mensaje; }
            set { mensaje = value; }
        }
        bool facturaValida;

        public bool FacturaValida
        {
            get { return facturaValida; }
            set { facturaValida = value; }
        }

        string folioFactura;

        public string FolioFactura
        {
            get { return folioFactura; }
            set { folioFactura = value; }
        }

        string fechaFactura;

        public string FechaFactura
        {
            get { return fechaFactura; }
            set { fechaFactura = value; }
        }


        string uUID;

        public string UUID
        {
            get { return uUID; }
            set { uUID = value; }
        }

        string importeFactura;

        public string ImporteFactura
        {
            get { return importeFactura; }
            set { importeFactura = value; }
        }
        string importeRecepcion;

        public string ImporteRecepcion
        {
            get { return importeRecepcion; }
            set { importeRecepcion = value; }
        }
        string importePasivo;

        public string ImportePasivo
        {
            get { return importePasivo; }
            set { importePasivo = value; }
        }
        string rFCEmisor;

        public string RFCEmisor
        {
            get { return rFCEmisor; }
            set { rFCEmisor = value; }
        }
        string rFC_Recepctor;

        public string RFC_Recepctor
        {
            get { return rFC_Recepctor; }
            set { rFC_Recepctor = value; }
        }

        string serie;

        public string Serie
        {
            get { return serie; }
            set { serie = value; }
        }

        string moneda;

        public string Moneda
        {
            get { return moneda; }
            set { moneda = value; }
        }
        string pasivoGenerado;

        public string PasivoGenerado
        {
            get { return pasivoGenerado; }
            set { pasivoGenerado = value; }
        }

        public objT_BitacoraOperaciones()
        {

        }


        public objT_BitacoraOperaciones(Int64 _IdOperaciones, int _IdUsuario, string _Num_Proveedor, string _Sociedad, int _IdProveedor, string _OrdenCompra, string _NumRecepcion, string _Posicion, bool _operacionExitosa, string _Error, string _Flujo, string _Fecha, string _Archivo_Factura, string _NotaCredito, string _Archivo_NotaCredito, string _FacturaComplementaria, string _Archivo_Complementaria, string _Mensaje, bool _FacturaValida, string _FolioFactura, string _FechaFactura, string _UUID, string _ImporteFactura, string _ImporteRecepcion, string _ImportePasivo, string _RFCEmisor, string _RFC_Receptor, string _Serie, string _Moneda, string _PasivoGenerado)
        {
            IdOperaciones = _IdOperaciones;
            IdUsuario = _IdUsuario;
            Num_Proveedor = _Num_Proveedor;
            Sociedad = _Sociedad;
            IdProveedor = _IdProveedor;
            OrdenCompra = _OrdenCompra;
            NumRecepcion = _NumRecepcion;
            Posicion = _Posicion;
            OperacionExitosa = _operacionExitosa;
            Error = _Error;
            Flujo = _Flujo;
            Fecha = _Fecha;
            Archivo_Factura = _Archivo_Factura;
            NotaCredito = _NotaCredito;
            Archivo_NotaCredito = _Archivo_NotaCredito;
            FacturaComplementaria = _FacturaComplementaria;
            Archivo_Complementaria = _Archivo_Complementaria;
            Mensaje = _Mensaje;
            FacturaValida = _FacturaValida;
            FolioFactura = _FolioFactura;
            FechaFactura = _FechaFactura;
            UUID = _UUID;
            ImporteFactura = _ImporteFactura;
            ImporteRecepcion = _ImporteRecepcion;
            ImportePasivo = _ImportePasivo;
            RFCEmisor = _RFCEmisor;
            RFC_Recepctor = _RFC_Receptor;
            Serie = _Serie;
            Moneda = _Moneda;
            PasivoGenerado = _PasivoGenerado;
        }
    }
}
