﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ClickFactura_Entidades.BD.Modelos
{
        #region Modelo Base de TablaGeneralModel
        public class TablaGeneralModel
        {
            public TablaGeneralModel()
            {
                NombreGrid = "Grid";
                AlturaGrid = "750px";
                Columnas = new List<Columna>();
                Registros = new List<Registros>();
                NombresModel = new List<string>();
                //ModoSeleccion = Kendo.Mvc.UI.GridSelectionMode.Single;
                ID = "R1";
                Seleccionar = true;
                Agrupar = false;
                Numerico = true;
                CamposAgregadosOperacion = new List<OperacionColumna>();
                CamposAgrupados = new Dictionary<string, Type>();
                ExpresionesOperacion = new List<System.Linq.Expressions.Expression>();
            }
            public string NombreGrid { get; set; }
            public string AlturaGrid { get; set; }
            public List<Columna> Columnas { get; set; }
            public List<Registros> Registros { get; set; }
            #region Config Edicion
            public bool Edicion { get; set; }
            public string TituloEdicion { get; set; }
            public string NombreTemplateEdicion { get; set; }
            public int Ancho { get; set; }
            public int Alto { get; set; }
            #endregion
            #region Config Excel
            public bool Excel { get; set; }
            public string NombreExcel { get; set; }
            #endregion
            #region Config Nuevo
            public bool Nuevo { get; set; }
            #endregion
            #region Config Personalizado
            public bool Personalizar { get; set; }
            public string ControlPersonalizado { get; set; }
            public string NombreBtnPersonalizado { get; set; }
            public string EventoClick { get; set; }
            public bool SendDataKey { get; set; }

            #endregion
            #region Configuracion Datasource
            public string NombreCreate { get; set; }
            public string NombreUpdate { get; set; }
            public string Control { get; set; }
            public List<string> NombresModel { get; set; }
            #endregion
            #region Modo Seleccion
            //public Kendo.Mvc.UI.GridSelectionMode ModoSeleccion { get; set; }
            public bool Seleccionar { get; set; }
            #endregion
            #region Eventos
            public string _Edicion { get; set; }
            public string _Guardar { get; set; }
            #endregion
            #region Celdas
            public bool CeldaAccion { get; set; }
            #endregion
            #region Id
            public string ID { get; set; }
            #endregion
            #region Grupos
            public bool Agrupar { get; set; }
            public Dictionary<string, Type> CamposAgrupados { get; set; }
            #endregion
            #region Agregar Operaciones
            public bool AgregarOperacion { get; set; }
            public List<OperacionColumna> CamposAgregadosOperacion { get; set; }
            public List<System.Linq.Expressions.Expression> ExpresionesOperacion { get; set; }
            #endregion
            #region Config PDF

            #endregion
            #region ToolBar Personalizado
            public bool BtnToolbarPersonalizado { get; set; }
            public string TemplatePersonalizado { get; set; }
            #endregion
            #region Paginado
            public bool Numerico { get; set; }
            #endregion
        }
        public struct OperacionColumna
        {
            public string Campo { get; set; }
            public string Operacion { get; set; }
            public Type Tipo { get; set; }
        }
        public struct Columna
        {
            //public Columna(string nombre, string ancho, bool filtreable, bool oculto, string clientTemplate)
            //{
            //    this.ClientTemplate = clientTemplate;
            //    this.oculto = oculto;
            //    this.filtreable = filtreable;
            //    this.Nombre = nombre;
            //    this.Ancho = ancho;
            //}
            public Type Tipo { get; set; }
            public string Nombre { get; set; }
            public bool oculto { get; set; }
            public bool filtreable { get; set; }
            public string ClientTemplate { get; set; }
            public string Ancho { get; set; }
            public string ClientFooterTemplate { get; set; }
        }
        public class Registros
        {
            public object R1 { get; set; }
            public object R2 { get; set; }
            public object R3 { get; set; }
            public object R4 { get; set; }
            public object R5 { get; set; }
            public object R6 { get; set; }
            public object R7 { get; set; }
            public object R8 { get; set; }
            public object R9 { get; set; }
            public object R10 { get; set; }
            public object R11 { get; set; }
            public object R12 { get; set; }
            public object R13 { get; set; }
            public object R14 { get; set; }
            public object R15 { get; set; }
            public object R16 { get; set; }
            public object R17 { get; set; }
            public object R18 { get; set; }
            public object R19 { get; set; }
            public object R20 { get; set; }

            public Registros MapeaDatos(List<object> lista)
            {
                Registros r = new Registros();
                for (int i = 0; i < lista.Count; i++)
                {
                    switch (i)
                    {
                        case 0:
                            r.R1 = lista[i].ToString().Trim();
                            break;
                        case 1:
                            r.R2 = lista[i].ToString().Trim();
                            break;
                        case 2:
                            r.R3 = lista[i].ToString().Trim();
                            break;
                        case 3:
                            r.R4 = lista[i].ToString().Trim();
                            break;
                        case 4:
                            r.R5 = lista[i].ToString().Trim();
                            break;
                        case 5:
                                {
                                    if(lista[i].ToString().Trim().ToUpper().Contains(".XML")==false)
                                          r.R6 = lista[i].ToString().Trim();
                                    else
                                       r.R18 = lista[i].ToString().Trim();
                                   }
                            break;
                        case 6:
                            r.R7 = lista[i].ToString().Trim();
                            break;
                        case 7:
                            r.R8 = lista[i].ToString().Trim();
                            break;
                        case 8:
                            r.R9 = lista[i].ToString().Trim();
                            break;
                        case 9:
                            r.R10 = lista[i].ToString().Trim();
                            break;
                        case 10:
                            r.R11 = lista[i].ToString().Trim();
                            break;
                        case 11:
                            r.R12 = lista[i].ToString().Trim();
                            break;
                        case 12:
                            r.R13 = lista[i].ToString().Trim();
                            break;
                        case 13:
                            r.R14 = lista[i].ToString().Trim();
                            break;
                        case 14:
                            r.R15 = lista[i].ToString().Trim();
                            break;
                        case 15:
                            r.R16 = lista[i].ToString().Trim();
                            break;
                        case 16:
                            r.R17 = lista[i].ToString().Trim();
                            break;
                        case 17:
                            r.R18 = lista[i].ToString().Trim();
                            break;
                        case 18:
                            r.R19 = lista[i].ToString().Trim();
                            break;
                        case 19:
                            r.R20 = lista[i].ToString().Trim();
                            break;
                        default:
                            break;
                    }
                }
                return r;
            }
        }
        public class TablasDinamicasModel
        {
            //GRD Cambio para introducir Conectores 30 Mayo 2017
            //DatosBafarDataContext contexto;
            //public TablasDinamicasModel()
            //{
            //    contexto = new DatosBafarDataContext();
            //}
            //GRD Cambio para introducir Conectores 30 Mayo 2017

            ClickFactura_Entidades.BD.Entidades.Desarrollo_CF contexto = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF();
            public TablasDinamicasModel()
            {
                contexto = new ClickFactura_Entidades.BD.Entidades.Desarrollo_CF();
            }

            public DataTable EjecutarSP(string nombreSP, List<string> datosParametro, out string mensaje)
            {
                DataTable dtData = new DataTable();
                try
                {
                    mensaje = "";
                    using (SqlConnection sqlConn = new SqlConnection(ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion))//.Connection.ConnectionString))
                    {
                        using (SqlCommand sqlCommand = new SqlCommand(nombreSP, sqlConn))
                        {
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.Parameters.Clear();
                            var NombresParametros = ParametrosSP(nombreSP);
                            for (int i = 0; i < NombresParametros.Count; i++)
                            {
                                sqlCommand.Parameters.AddWithValue(NombresParametros[i], datosParametro[i]);
                            }
                            using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                            {
                                sqlConn.Open();
                                sqlDataAdapter.Fill(dtData);
                                sqlConn.Close();
                                sqlDataAdapter.Dispose();
                                sqlCommand.Dispose();
                            }
                        }
                    }
                    return dtData;
                }
                catch (Exception ex)
                {
                    mensaje = ex.Message;
                    return null;
                }
            }
            private List<string> ParametrosSP(string nombreSP)
            {
                try
                {
                    List<string> lista = new List<string>();
                    using (SqlConnection sqlConn = new SqlConnection(ClickFactura_Entidades.BD.Entidades.AccesoBD.CadenaConexion))
                    {
                        using (SqlCommand sqlCommand = new SqlCommand("sp_helptext", sqlConn))
                        {
                            sqlCommand.CommandType = CommandType.StoredProcedure;
                            sqlCommand.Parameters.Clear();
                            sqlCommand.Parameters.AddWithValue("@objname", nombreSP);
                            using (SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(sqlCommand))
                            {
                                DataTable d = new DataTable();
                                sqlConn.Open();
                                sqlDataAdapter.Fill(d);
                                sqlConn.Close();
                                sqlDataAdapter.Dispose();
                                sqlCommand.Dispose();
                                foreach (DataRow item in d.Rows)
                                {
                                    var cadena = item.ItemArray[0].ToString().Trim();
                                    if (cadena != "")
                                    {
                                        if (cadena.Substring(0, 1).Contains("@"))
                                        {
                                            var param = cadena.Split(' ');
                                            lista.Add(param[0]);
                                        }
                                        if (cadena.Contains("AS") || cadena.Contains("As"))
                                        {
                                            break;
                                        }
                                    }
                                }
                            }
                        }
                    }
                    return lista;
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
        public class TablaPageable
        {
            public List<ClickFactura_Entidades.BD.Entidades.view_FacturasVerirficadas> vista { get; set; }
            public int total { get; set; }
        }
        public class Pasivo_Encabezado
    {
        public bool CalculaImpuesto { get; set; }

        public bool CargoPosterior { get; set; }

        public string ClaseDoc { get; set; }

        public bool Factura { get; set; }

        public string FechaFactura { get; set; }

        public string FechaPedimento { get; set; }

        public string FolioFactura { get; set; }

        public string Importe { get; set; }

        public string ImporteRetencionFlete { get; set; }

        public string Moneda { get; set; }

        public string Proveedor_Diferente { get; set; }

        public string RetencionISRRenta { get; set; }

        public string RetencionIVARenta { get; set; }

        public string Sociedad { get; set; }

        public string SubTotalXml { get; set; }

        public string UUID { get; set; }
        public string PMNTTRMS { get; set; }
            
    }
        public class Pasivo_Detalle
    {

        public string CantidadConcepto { get; set; }

        public string ClaseCondicion { get; set; }

        public string ImporteConcepto { get; set; }

        public string Impuesto { get; set; }

        public string NumeroRecepcion { get; set; }

        public string OrdenCompra { get; set; }

        public string PosicionFactura { get; set; }

        public string PosicionOrden { get; set; }

        public string PosicionRecepcion { get; set; }

        public string YearWE { get; set; }

        public string UnidadMedida { get; set; }
    }
        public class Pasivo_Generado
    {
        public string FolioFactura { get; set; }

        public string Mensaje_Error { get; set; }

        public string NumeroOrden { get; set; }

        public string NumeroPasivo { get; set; }

        public string Tipo_Error { get; set; }

        public string YearFiscal { get; set; }
    }
        public class Mercancias_Recepcionadas
        {
            public string Fecha_Inicio { get; set; }
            public string Hora_Inicio { get; set; }
            public string OrdenCompra { get; set; }
            public string Posicion_OC { get; set; }
            public decimal Cantidad { get; set; }
            public decimal Cantidad_Base { get; set; }
            public string  Unidad_Medida{ get; set; }
            public string Almacen { get; set; }
            public string Planta { get; set; }
            public string Numero_Recepcion { get; set; }
            public string Año_Recepcion { get; set; }
            public string  Fecha_Operacion { get; set; }
            public string Hora_Operacion { get; set; }
            public bool Transaccion_Confirmada { get; set; }
            public string Num_Proveedor { get; set; }
            public string Usuario{ get; set; }//Quien disparo la BAPI
            public string Tipo_OrdenCompra { get; set; } //PO=Cerrada SA=Abierta
            public string Descripcion { get; set; }
            public string Importe { get; set; }
            public string Indicador_IVA { get; set; }
            public string Numero_Material { get; set; }
            public string Moneda { get; set; }

        }
       public class EncabezadoOrdenCompra
    {
        public string OrdenCompra { get; set; }
        public string Sociedad { get; set; }
        public string Proveedor { get; set; }
        public string Moneda{ get; set; }
        public string PMNTTRMS { get; set; }

        public string tipoOrdenCompra { get; set; }

    }
       public class FacturasVerificadasModel
       {
           public string R1 { get; set; }
           public string R2 { get; set; }
           public string R3 { get; set; }
           public string R4 { get; set; }
           public string R5 { get; set; }
           public string R6 { get; set; }
           public string R7 { get; set; }
           public string R8 { get; set; }
           public string R9 { get; set; }
           public string R10 { get; set; }
           public string R11 { get; set; }
           public string R12 { get; set; }
           public string R13 { get; set; }
           public string R14 { get; set; }
           public string R15 { get; set; }
           public string R16 { get; set; }

       }
       public class repositorioArchivosModel
       {
           public string R1 { get; set; }
           public string R2 { get; set; }
           public string R3 { get; set; }
           public string R4 { get; set; }
           public string R5 { get; set; }
           public string R6 { get; set; }
           public string R7 { get; set; }
           public string R8 { get; set; }
           public string R9 { get; set; }
           public string R10 { get; set; }
           public string R11 { get; set; }
           public string R12 { get; set; }
           public string R13 { get; set; }
           public string R14 { get; set; }
           public string R15 { get; set; }
           public string R16 { get; set; }
           public string R17 { get; set; }
           public string R18 { get; set; }
           public string R19 { get; set; }
       }
       public class RespuestasGenericasModel
    {
        public string R1 { get; set; }
        public string R2 { get; set; }
        public string R3 { get; set; }
        public string R4 { get; set; }
        public string R5 { get; set; }
        public string R6 { get; set; }
        public string R7 { get; set; }
        public string R8 { get; set; }
        public byte[] RByte { get; set; }
    }
      public class retencionesProveedor
    {
        public string MANDT { get; set; }
        public string LIFNR { get; set; }
        public string BUKRS { get; set; }
        public string WITHT { get; set; }
        public string WT_SUBJCT { get; set; }
        public string QSREC { get; set; }
        public string WT_WTSTCD { get; set; }
        public string WT_WITHCD { get; set; }
        public string WT_EXNR { get; set; }
        public string WT_EXRT { get; set; }
        public string WT_EXDF { get; set; }
        public string WT_EXDT { get; set; }
        public string WT_WTEXRS { get; set; }
    }
      public class PaquetesOfrecidosModel
    {
        public string R1 { get; set; }
        public string R2 { get; set; }
        public string R3 { get; set; }
        public string R4 { get; set; }
        public string R5 { get; set; }
        public string R6 { get; set; }
    }
     public class ArbolGeneralModel
    {
        public ArbolGeneralModel()
        {
            Nombre = "Arbol";
            DragDrop = false;
            isDataSource = false;
            isItems = false;
            TemplateId = "treeview-template";
            Registros = new List<RegistroArbol>();                        
        }
        public string Nombre { get; set; }
        public bool DragDrop { get; set; }
        #region Eventos
        public string Drag { get; set; }
        public string Drop { get; set; }
        public string DragStart { get; set; }
        public string DragEnd { get; set; }
        public string Expand { get; set; }
        public string Collapse { get; set; }
        public string Check { get; set; }
        public string Select { get; set; }
        public string Change { get; set; }
        public string DataBound { get; set; }
        #endregion
        #region Template
        public string TemplateId { get; set; }
        #endregion
        #region DataSource
        public bool isDataSource { get; set; }
        public string AccionDataSource { get; set; }
        public string ControlDataSource { get; set; }
        public string SpriteClassCampo { get; set; }
        #endregion
        #region Items
        public bool isItems { get; set; }
        #endregion
        public List<RegistroArbol> Registros { get; set; }
     }

     public class Proveedores
     {
         public string LIFNR { get; set; }
         public string BUKRS { get; set; }
         public string LAND1 { get; set; }
         public string NAME1 { get; set; }
         public string ADRNR { get; set; }
         public string KTOKK { get; set; }
         public string LOEVM { get; set; }
         public string STCD1 { get; set; }
         public string XCPDK { get; set; }
         public string STCD3 { get; set; }
         public string BUTXT { get; set; }
         public string RFCSO { get; set; }
     }
     public class CestaMigoMiro
     {
         public string NumProveedor { get; set; }
         public string OrdenCompra { get; set; }
         public string PosicionOC{ get; set; }
         public string IndicadorIVA { get; set; }
         public string CantidadOC { get; set; }
         public string NoRecepcion{ get; set; }
         public string Servicio { get; set; }
         public string XMLAdjunto { get; set; }
         public bool XMLAdjuntoValido { get; set; }

     }

    public struct RegistroArbol
    {
        public string Id { get; set; }
        public bool Expandir { get; set; }
        public string Nombre { get; set; }
        public string Icono { get; set; }
        public string Controlador { get; set; }
        public string Accion { get; set; }
        public List<RegistroArbol> SubMenu { get; set; }
    }
   #endregion Modelo Base de TablaGeneralModel

    #region Estructuras de apoyo para consumir StoreProcedures y Views

        ///Para Substituir y consumir los resultados la vista "view_IndicadoresImpxOrdenxWE"
        ///
    public struct T_BitacoraWF
    {
        public string idBitacoraWF { get; set; }
        public string OrdenCompra { get; set; }
        public string Recepcion { get; set; }
        public string idWF { get; set; }
        public string idTipoUsuarioWF { get; set; }
        public string idUsuarioWF { get; set; }
        public string idfechaEvento { get; set; }
        public bool aprobado { get; set; }


    }
    public struct IndicadoresImpuesto1OrdenxWE
     {
         public string Orden_Compra { get; set; }
         public string Documento_Referencia { get; set; }
         public string Indicador_IVA { get; set; }
     }

     public struct T_FacturasServicios
     {
         public string idFacturasServicios { get; set; }
         public string ordenCompra { get; set; }
         public string numProveedor { get; set; }
         public string usuario { get; set; }
         public string mes { get; set; }
         public string nombreArchivo { get; set; }
         public string rutaCompleta { get; set; }
         public string _XML{ get; set; }
         public string fechaCarga { get; set; }
         public string procesado {get;set; }
         public string fechaFactura { get; set; }
         public string fechaPedimento { get; set; }
         public string calculaImpuesto { get; set; }
         public string cargoPosterior { get; set; }
         public string folioFactura { get; set; }
         public string importe { get; set; }
         public string importeRetencionFlete { get; set; }
         public string moneda { get; set; }
         public string proveedor_Diferente { get; set; }
         public string rertencionISRRenta { get; set; }
         public string retencionIVARenta { get; set; }
         public string sociedad{ get; set; }
         public string subTotalXml { get; set; }
         public string UUID { get; set; }


     }

     public struct objAnalizarImpuestos
     {
                public string version { get; set; }
                public Object Factura33 { get; set; }
                public Object Factura32 { get; set; }
                public string _importeISRRenta { get; set; }
                public string _importeIVARenta { get; set; }
                public string _posibleTipo { get; set; }
                public string _importeTotalTrasladados { get; set; }
                public string siCuentaTrasladados { get; set; }
                public string subTotalXml { get; set; }
                public string Importe { get; set; }
                public string tipoFactura { get; set; }
                public bool calculaImpuesto { get; set; }

     }




    #endregion Estructuras de apoyo para consumir StoreProcedures y Views
    /// <summary>
    /// Vigente al 30 de Mayo de 2017
    /// Utilizado en Proyecto BAFAR ver 1 y 2
    /// Utilizado en Proyecto TKPM ver 1 y ver 3 dentor de la línea de Portales SAP-NET
    /// </summary>

     #region Estructura de la Tabla Detalle de Recepciones 
     public struct Detalle_Recepciones
     {
         public string IdRecepcion { get; set; }
         public string Orden_Compra { get; set; }
        /// public string Posicion_Orden_Compra { get; set; }
        public string Posicion_OrdenCompra { get; set; }
        public string Numero_ActualImput { get; set; }
         public string Clase_Operacion { get; set; }
        //public string Year_Documento { get; set; }
        public string YearDocumento { get; set; }
        public string Numero_Documento { get; set; }
         public string Posicion_Documento { get; set; }
         public string Tipo_Movimiento { get; set; }
         public string Clave_Movimiento { get; set; }
         public string Fecha_Contable { get; set; }
         public string Cantidad { get; set; }
         public string Importe_Local { get; set; }
         public string Importe_Documento { get; set; }
         public string Moneda { get; set; }
         public string IndicadorHD { get; set; }
         public string YearDocumentoRef { get; set; }
         public string Documento_Referencia { get; set; }
         public string Posicion_DocumentoRef{ get; set; }
         public string Cantidad_Medida_Pedido { get; set; }
     }
    #endregion Estructura de la Tabla Detalle de Recepciones 

     /// <summary>
     /// Vigente al 31 de Mayo de 2017
     /// Utilizado en Proyecto BAFAR ver 1 y 2
     /// Utilizado en Proyecto TKPM ver 1 y ver 3 dentor de la línea de Portales SAP-NET
     /// </summary>

     #region Estructura de la Tabla Detalle de Ordenes
     public struct Detalle_OrdenCompra
     {
         public string IDDetalleOrdenCompra { get; set; }
         public string Orden_Compra { get; set; }
         public string Item { get; set; }
         public string Descripcion{ get; set; }
         public string Codigo_Producto { get; set; }
         public string Doc_Mov { get; set; }
         public string Pos_Doc_Mov { get; set; }
         public string Tipo_Mov { get; set; }
         public string Clase_Mov { get; set; }
         public string Fecha_Contable { get; set; }
         public string Cantidad { get; set; }
         public string Importe { get; set; }
         public string Moneda { get; set; }
         public string IndicadorHD { get; set; }
         public string Ejercicio{ get; set; }
         public string Doc_Ref { get; set; }
         public string Pos_Doc_Ref{ get; set; }
         public string Numero_Pasivo { get; set; }
         public string Numero_Cancelacion { get; set; }
         public string Posicion_OC { get; set; }
         public string Borrado { get; set; }
         public string Numero_Material { get; set; }
         public string Planta { get; set; }
         public string Almacen { get; set; }
         public string Numero_Necesidad { get; set; }
         public string Grupo_Articulos { get; set; }
         public string Numero_Compras { get; set; }
         public string Unidad_Medida { get; set; }
         public string Cantidad_Base { get; set; }
         public string Indicador_IVA { get; set; }
         public string Clase_Valoracion { get; set; }
         public string Tipo_OC { get; set; }
         public string Tipo_Imputacion { get; set; }
         public string Cuenta_Imputacion { get; set; }


     }

     #endregion Estructura de la Tabla Detalle de Recepciones 

     #region Estructura de comunición con SAP (Origen en RFC de BAFAR)
     public struct InformacionSAP
     {
         public string R1 { get; set; }
         public string R2 { get; set; }
         public string R3 { get; set; }
         public string R4 { get; set; }
         public string R5 { get; set; }
         public string R6 { get; set; }
         public string R7 { get; set; }
         public string R8 { get; set; }
         public string R9 { get; set; }
         public string R10 { get; set; }
         public string R11 { get; set; }
         public string R12 { get; set; }
         public string R13 { get; set; }
         public string R14 { get; set; }
         public string R15 { get; set; }
         public string R16 { get; set; }
         public string R17 { get; set; }
         public string R18 { get; set; }
         public string R19 { get; set; }
         public string R20 { get; set; }

     }

     #endregion Estructura de comunición con SAP (Origen en RFC de BAFAR)
}
